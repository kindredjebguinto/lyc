# Vehicle Service Management System

## Job quotation workflow

The admin can open a reservation and select **Job Quotation** to prepare an itemized estimate. Every selected service is preloaded, and the admin can add parts, labor, discounts, tax, notes, and a validity date. Save as **Draft** while preparing it, then change the status to **Sent** so the customer can view the grand total and accept or reject it in the Flutter app.

When upgrading an existing database, import `vehicle-service-management/database/mobile_api_migration.sql` in phpMyAdmin once before using this feature.

## Improved service and payment workflow

- Admin reservations now have search, date/status filters, compact service tags, and a clear progress timeline.
- Service stages support diagnosis, quotation review, active work, ready for pickup, and completion.
- Accepted quotations automatically create the exact amount due.
- Customers can upload JPG, PNG, or WEBP payment proof (maximum 5 MB); staff can approve or reject it with notes.
- Approved payments unlock the existing PDF receipt.
- Completed reservations contain mileage, diagnosis, work performed, completion notes, and next-service recommendations.
- Quotations can be printed as PDF and every save creates a revision snapshot.
- Reports can be exported as CSV and important admin actions are recorded in the Audit Log.

After extracting the updated project, run `flutter pub get` because the customer app now uses `image_picker` for payment-proof images. Also make sure Apache/PHP can write to `vehicle-service-management/uploads/payment_proofs`.

## Pre-booking service estimate

The customer app has a separate **Estimate** tab that displays every active service managed by the admin. Customers can search the offerings, select multiple services, and view an itemized estimated total and duration without creating a reservation. Selecting **Book These Services** opens the booking form with the same services already checked. This estimate is intentionally separate from the final job quotation, which may change after inspection when labor, parts, discounts, and tax are confirmed.

## Simplified user experience

The customer navigation is now **Home, Services, Bookings, Account**. A booking opens one details page containing the customer-friendly status, next required action, final quotation, payment, receipt access, and service report. Booking is reduced to three steps: services, vehicle/schedule, and review.

The admin uses **Jobs** instead of a technical reservation workflow. Each job displays only its valid next action, preventing staff from accidentally skipping service stages. Secondary cancellation controls are kept under More Actions, while quotation, payment, mechanic, and service-record information remain within the same job workspace.

This package contains:

- `vehicle-service-management/` — PHP customer website, MySQL database dump, and mobile REST API
- `vehicle-service-management-admin/` — PHP/CSS administrator portal
- `vsm_customer/` — Flutter/Dart customer Android application

## 1. Start the PHP/MySQL server

1. Install and open XAMPP.
2. Start **Apache** and **MySQL**.
3. Place the `Vehicle-Service-System` folder in `C:\xampp\htdocs\`.
4. Open phpMyAdmin at `http://localhost/phpmyadmin`.
5. Create a database named `vehicle_service_system`.
6. Import `vehicle-service-management/database/vehicle_service_system (3).sql`.
7. Test the API at `http://localhost/Vehicle-Service-System/vehicle-service-management/api/test.php`.

If you already imported the database before this mobile update, keep your data and import only `vehicle-service-management/database/mobile_api_migration.sql` to add the token table.

The Flutter default API address is already configured for the Android Studio emulator:

`http://10.0.2.2/Vehicle-Service-System/vehicle-service-management/api`

For a physical Android phone, connect the phone and computer to the same Wi-Fi and run:

```bash
flutter run --dart-define=API_BASE_URL=http://YOUR_COMPUTER_IP/Vehicle-Service-System/vehicle-service-management/api
```

## 2. Run the Flutter application

1. Open `vsm_customer` in Android Studio.
2. Open a terminal in that folder.
3. Run `flutter clean`.
4. Run `flutter pub get`.
5. Start an Android emulator.
6. Run `flutter run`, or click the Android Studio Run button.

## Customer features

- Register and log in
- Dashboard statistics
- Add, edit, view, and delete vehicles
- View active services
- Book a service appointment
- Select multiple services or vehicle concerns in one appointment
- Track reservations and payment status
- View completed service history and assigned mechanic
- View payment records and official receipt details
- Edit profile and change password
- Cancel pending or approved appointments
- Prevent Sunday, after-hours, past, and occupied-slot bookings
- Receive in-app booking and service-status notifications
- Submit password-reset requests for administrator review
- View maintenance reminders
- Save or share PDF payment receipts
- Store optional vehicle type, transmission, fuel, mileage, and VIN details

All private API operations use the bearer token returned during login. Existing app sessions created before this version are automatically sent back to login once so a valid token can be saved.
