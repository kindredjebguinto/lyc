<?php

include "includes/admin_header.php";

$total_customers = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM customers"
    )
)['total'];


$total_vehicles = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM vehicles"
    )
)['total'];


$available_mechanics = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM mechanics
         WHERE status = 'Available'"
    )
)['total'];


$total_revenue = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COALESCE(SUM(amount), 0) AS total
         FROM payments
         WHERE status = 'Paid'"
    )
)['total'];

$total = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations"
    )
)['total'];

$pending = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE status = 'Pending'"
    )
)['total'];

$approved = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE status = 'Approved'"
    )
)['total'];

$in_progress = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE status = 'In Progress'"
    )
)['total'];


$cancelled = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE status = 'Cancelled'"
    )
)['total'];


$today_appointments = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE appointment_date = CURDATE()
         AND status <> 'Cancelled'"
    )
)['total'];

$completed = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM reservations
         WHERE status = 'Completed'"
    )
)['total'];

?>

<h2 class="mb-4">
    Dashboard
</h2>

<div class="row g-6">

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php">

            <h6>Reservation</h6>

            <h2>
                <?= $total; ?>
            </h2>

        </a>

    </div>

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php?status=Pending">

            <h6>Pending</h6>

            <h2>
                <?= $pending; ?>
            </h2>

        </a>

    </div>

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php?status=Approved">

            <h6>Approved</h6>

            <h2>
                <?= $approved; ?>
            </h2>

        </a>

    </div>

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php?status=In+Progress">

            <h6>In Progress</h6>

            <h2>
                <?= $in_progress; ?>
            </h2>

        </a>

    </div>

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php?status=Completed">

            <h6>Completed</h6>

            <h2>
                <?= $completed; ?>
            </h2>

        </a>

    </div>

    <div class="col-md-2">

        <a class="stat-card stat-card-link" href="reservations.php?status=Cancelled">

            <h6>Cancelled</h6>

            <h2>
                <?= $cancelled; ?>
            </h2>

        </a>

    </div>

    <!-- Second Row of Statistics -->

    <div class="row g-5 mt-1">

        <div class="col-md-3">

            <a class="stat-card stat-card-link" href="customers.php">

                <h6>
                    Customers
                </h6>

                <h2>
                    <?= $total_customers; ?>
                </h2>

            </a>

        </div>


        <div class="col-md-3">

            <a class="stat-card stat-card-link" href="customers.php">

                <h6>
                    Vehicles
                </h6>

                <h2>
                    <?= $total_vehicles; ?>
                </h2>

            </a>

        </div>


        <div class="col-md-3">

            <a class="stat-card stat-card-link" href="mechanics.php">

                <h6>
                    Available Mechanics
                </h6>

                <h2>
                    <?= $available_mechanics; ?>
                </h2>

            </a>

        </div>


        <div class="col-md-3">

            <a class="stat-card stat-card-link" href="payments.php">

                <h6>
                    Revenue
                </h6>

                <h2 class="fs-4">

                    ₱<?= number_format(
                    $total_revenue,
                    2
                ); ?>

                </h2>

            </a>

        </div>

    </div>

    <?php

include "includes/admin_footer.php";

?>
