<?php
include_once __DIR__ . '/includes/config.php';
include_once __DIR__ . '/includes/admin_auth.php';

$id = (int) ($_GET['id'] ?? 0);
if (empty($_SESSION['admin_csrf_token'])) {
    $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
}

function payment_redirect($id, $type, $message) {
    $_SESSION['payment_flash'] = ['type' => $type, 'message' => $message];
    header('Location: payment_view.php?id=' . intval($id));
    exit;
}

function payment_notify($conn, $paymentId, $title, $message) {
    $stmt = mysqli_prepare($conn, "SELECT r.user_id FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id=?");
    mysqli_stmt_bind_param($stmt, 'i', $paymentId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    if ($row && (int) $row['user_id'] > 0) {
        $userId = (int) $row['user_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO notifications(user_id,title,message) VALUES(?,?,?)");
        mysqli_stmt_bind_param($stmt, 'iss', $userId, $title, $message);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

function payment_audit($conn, $paymentId, $action, $details) {
    $admin = $_SESSION['admin_name'] ?? 'Staff';
    $stmt = mysqli_prepare($conn, "INSERT INTO admin_audit_logs(admin_name,action,entity_type,entity_id,details) VALUES(?,?,'payment',?,?)");
    mysqli_stmt_bind_param($stmt, 'ssis', $admin, $action, $paymentId, $details);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['admin_csrf_token'], $csrf)) {
        payment_redirect($id, 'danger', 'The payment request expired. Refresh the page and try again.');
    }

    $action = $_POST['action'] ?? '';
    $notes = trim($_POST['admin_notes'] ?? '');

    if ($action === 'approve') {
        $stmt = mysqli_prepare($conn, "UPDATE payments SET status='Paid',paid_at=NOW(),admin_notes=? WHERE id=? AND status='Under Review'");
        mysqli_stmt_bind_param($stmt, 'si', $notes, $id);
        mysqli_stmt_execute($stmt);
        $changed = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
        if ($changed) {
            $paymentRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT reservation_id,payment_type FROM payments WHERE id=".intval($id)));
            if (($paymentRow['payment_type'] ?? '') === 'Reservation Fee') mysqli_query($conn, "UPDATE reservations SET reservation_fee_status='Paid' WHERE id=".intval($paymentRow['reservation_id']));
            payment_audit($conn, $id, 'Approved online payment', $notes ?: 'Online proof verified.');
            payment_notify($conn, $id, 'Payment approved', 'Your online payment was verified. Your receipt is now available.');
            payment_redirect($id, 'success', 'Online payment approved and receipt created.');
        }
        payment_redirect($id, 'danger', 'This payment is no longer waiting for online verification.');
    }

    if ($action === 'reject') {
        if ($notes === '') payment_redirect($id, 'danger', 'Enter a rejection reason for the customer.');
        $stmt = mysqli_prepare($conn, "UPDATE payments SET status='Rejected',paid_at=NULL,admin_notes=? WHERE id=? AND status='Under Review'");
        mysqli_stmt_bind_param($stmt, 'si', $notes, $id);
        mysqli_stmt_execute($stmt);
        $changed = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
        if ($changed) {
            $paymentRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT reservation_id,payment_type FROM payments WHERE id=".intval($id)));
            if (($paymentRow['payment_type'] ?? '') === 'Reservation Fee') mysqli_query($conn, "UPDATE reservations SET reservation_fee_status='Rejected' WHERE id=".intval($paymentRow['reservation_id']));
            payment_audit($conn, $id, 'Rejected online payment', $notes);
            payment_notify($conn, $id, 'Payment proof rejected', 'Your payment proof was rejected: ' . $notes);
            payment_redirect($id, 'warning', 'Proof rejected. The customer can correct and resubmit it.');
        }
        payment_redirect($id, 'danger', 'This payment is no longer waiting for online verification.');
    }

    if ($action === 'cash_received') {
        $receipt = trim($_POST['receipt_number'] ?? '');
        if ($receipt === '') payment_redirect($id, 'danger', 'Enter the official receipt number before confirming cash.');
        $cashNote = $notes !== '' ? $notes : 'Cash received over the counter.';
        $stmt = mysqli_prepare($conn, "UPDATE payments SET payment_method='Cash',reference_number=?,status='Paid',paid_at=NOW(),admin_notes=? WHERE id=? AND status IN ('Pay at Shop','Awaiting Proof','Rejected','Pending')");
        mysqli_stmt_bind_param($stmt, 'ssi', $receipt, $cashNote, $id);
        mysqli_stmt_execute($stmt);
        $changed = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
        if ($changed) {
            payment_audit($conn, $id, 'Confirmed cash payment', $cashNote . ' Official receipt: ' . $receipt);
            payment_notify($conn, $id, 'Cash payment received', 'Your cash payment was confirmed. Official receipt ' . $receipt . ' is now available.');
            payment_redirect($id, 'success', 'Cash received and official receipt recorded.');
        }
        payment_redirect($id, 'danger', 'This payment cannot be confirmed as cash in its current status.');
    }
    if($action==='mark_refunded'){
        $reference=trim($_POST['refund_reference']??'');if($reference==='')payment_redirect($id,'danger','Enter the refund reference.');
        $stmt=mysqli_prepare($conn,"UPDATE payments SET refund_status='Refunded',refund_reference=?,refunded_at=NOW() WHERE id=? AND payment_type='Reservation Fee' AND refund_status IN ('Requested','Under Review','Approved')");mysqli_stmt_bind_param($stmt,'si',$reference,$id);mysqli_stmt_execute($stmt);$changed=mysqli_stmt_affected_rows($stmt);mysqli_stmt_close($stmt);
        if($changed){mysqli_query($conn,"UPDATE reservations r JOIN payments p ON p.reservation_id=r.id SET r.reservation_fee_status='Refunded' WHERE p.id=".intval($id));payment_notify($conn,$id,'Reservation fee refunded','Your ₱200 reservation fee was refunded. Reference: '.$reference);payment_audit($conn,$id,'Completed reservation fee refund',$reference);payment_redirect($id,'success','Refund recorded and customer notified.');}
        payment_redirect($id,'danger','This payment is not awaiting a refund.');
    }
}

$stmt = mysqli_prepare($conn, "SELECT p.*,r.service_type,r.reference_number reservation_reference,r.status reservation_status,
    c.fullname customer_name,v.brand,v.model,v.plate_number
    FROM payments p JOIN reservations r ON p.reservation_id=r.id
    LEFT JOIN customers c ON r.customer_id=c.id JOIN vehicles v ON r.vehicle_id=v.id
    WHERE p.id=? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$p = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
if (!$p) { header('Location: payments.php'); exit; }

$flash = $_SESSION['payment_flash'] ?? null;
unset($_SESSION['payment_flash']);
include 'includes/admin_header.php';
?>
<div class="container-fluid">
  <?php if($flash): ?><div class="alert alert-<?= htmlspecialchars($flash['type']) ?> alert-dismissible fade show" role="alert"><?= htmlspecialchars($flash['message']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
  <div class="page-heading">
    <div><span class="eyebrow">PAYMENT DETAILS</span><h2>Payment #<?= $id ?></h2><p><?= htmlspecialchars($p['customer_name'].' • '.$p['brand'].' '.$p['model']) ?></p></div>
    <div class="d-flex gap-2"><a href="reservation_view.php?id=<?= (int)$p['reservation_id'] ?>" class="btn btn-outline-primary">Open Job</a><a href="payments.php" class="btn btn-light">← Payments</a></div>
  </div>
  <div class="row g-4">
    <div class="col-lg-7">
      <div class="clean-card p-4">
        <div class="d-flex justify-content-between align-items-center"><h5 class="mb-0"><?= $p['payment_method']==='Cash'?'Cash Payment':'Submitted Proof' ?></h5><span class="badge text-bg-<?= $p['status']==='Paid'?'success':($p['status']==='Rejected'?'danger':'warning') ?>"><?= htmlspecialchars($p['status']) ?></span></div>
        <?php if(!empty($p['proof_file'])): ?>
          <a href="<?= PUBLIC_BASE_URL.'/'.htmlspecialchars($p['proof_file']) ?>" target="_blank"><img src="<?= PUBLIC_BASE_URL.'/'.htmlspecialchars($p['proof_file']) ?>" class="img-fluid rounded border mt-3" style="max-height:560px;width:100%;object-fit:contain;background:#f8fafc" alt="Payment proof"></a>
          <p class="text-muted small mt-2 mb-0">Click the image to inspect it at full size.</p>
        <?php elseif($p['status']==='Pay at Shop'): ?>
          <div class="empty-row"><strong>Customer selected Cash at Shop.</strong><br>No image proof is required. Confirm only after receiving the full amount.</div>
        <?php elseif($p['payment_method']==='Cash'&&$p['status']==='Paid'): ?>
          <div class="alert alert-success mt-3 mb-0"><strong>Cash received over the counter.</strong><br>The admin confirmation and official receipt number are the payment proof.</div>
        <?php else: ?>
          <div class="empty-row">No payment proof has been submitted.</div>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="clean-card p-4 mb-4">
        <h5>Payment Summary</h5><span class="badge text-bg-light"><?= htmlspecialchars($p['payment_type']??'Final Balance') ?></span><div class="display-5 fw-bold my-4">₱<?= number_format($p['amount'],2) ?></div>
        <div class="row g-3"><div class="col-6"><div class="detail-label">METHOD</div><div class="detail-value"><?= htmlspecialchars($p['payment_method']) ?></div></div><div class="col-6"><div class="detail-label"><?= $p['payment_method']==='Cash'?'RECEIPT NO.':'REFERENCE' ?></div><div class="detail-value"><?= htmlspecialchars($p['reference_number']?:'—') ?></div></div><div class="col-12"><div class="detail-label">BOOKING</div><div class="detail-value"><?= htmlspecialchars($p['reservation_reference']?:'#'.$p['reservation_id']) ?></div><small><?= htmlspecialchars($p['service_type']) ?></small></div></div>
      </div>
      <?php if($p['status']==='Under Review'): ?>
        <div class="clean-card p-4"><h5>Verify Online Payment</h5><form method="post"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['admin_csrf_token']) ?>"><label class="detail-label">ADMIN NOTE OR REJECTION REASON</label><textarea class="form-control my-2" name="admin_notes" rows="3" placeholder="Required when rejecting proof"></textarea><div class="d-grid gap-2"><button name="action" value="approve" class="btn btn-success" onclick="return confirm('Approve this online payment?')">Approve & Create Receipt</button><button name="action" value="reject" class="btn btn-outline-danger" onclick="return confirm('Reject this proof?')">Reject Proof</button></div></form></div>
      <?php elseif(in_array($p['status'],['Pay at Shop','Awaiting Proof','Rejected','Pending'],true)): ?>
        <div class="clean-card p-4"><h5>Cash Payment at Counter</h5><p class="text-muted">No uploaded proof is needed. Confirm only after physically receiving the complete amount.</p><form method="post"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['admin_csrf_token']) ?>"><label class="detail-label">OFFICIAL RECEIPT NUMBER</label><input class="form-control my-2" name="receipt_number" required placeholder="Example OR-2026-00125"><label class="detail-label mt-2">ADMIN NOTE</label><textarea class="form-control my-2" name="admin_notes" rows="2" placeholder="Optional note"></textarea><button name="action" value="cash_received" class="btn btn-success w-100" onclick="return confirm('Confirm that ₱<?= number_format($p['amount'],2) ?> cash was received?')">Confirm Cash Received</button></form></div>
      <?php elseif(!empty($p['admin_notes'])): ?><div class="alert alert-light border"><strong>Admin note:</strong><br><?= nl2br(htmlspecialchars($p['admin_notes'])) ?></div><?php endif; ?>
      <?php if(($p['payment_type']??'')==='Reservation Fee'&&in_array($p['refund_status']??'', ['Requested','Under Review','Approved'],true)): ?><div class="clean-card p-4 mt-4"><h5>Complete Refund</h5><p class="text-muted">Return the full ₱200, then record the provider or cash refund reference.</p><form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['admin_csrf_token'])?>"><input class="form-control mb-3" name="refund_reference" required placeholder="Refund reference"><button class="btn btn-danger w-100" name="action" value="mark_refunded">Mark ₱200 as Refunded</button></form></div><?php endif;?>
    </div>
  </div>
</div>
<?php include 'includes/admin_footer.php'; ?>
