<?php
include "includes/admin_header.php";
$search=trim($_GET['search']??''); $status=trim($_GET['status']??''); $date=trim($_GET['date']??'');
$allowed=['Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled'];
$where=[]; $types=''; $params=[];
if($search!==''){ $where[]="(r.reference_number LIKE ? OR c.fullname LIKE ? OR v.plate_number LIKE ?)"; $term="%$search%"; $types.='sss'; array_push($params,$term,$term,$term); }
if(in_array($status,$allowed,true)){ $where[]='r.status=?'; $types.='s'; $params[]=$status; }
if($date!==''){ $where[]='r.appointment_date=?'; $types.='s'; $params[]=$date; }
$sql="SELECT r.*,c.fullname customer_name,c.email customer_email,v.brand,v.model,v.plate_number,m.fullname mechanic_name,q.grand_total,q.status quotation_status,p.status payment_status FROM reservations r LEFT JOIN customers c ON r.customer_id=c.id LEFT JOIN vehicles v ON r.vehicle_id=v.id LEFT JOIN mechanics m ON r.mechanic_id=m.id LEFT JOIN job_quotations q ON q.reservation_id=r.id LEFT JOIN payments p ON p.id=(SELECT p2.id FROM payments p2 WHERE p2.reservation_id=r.id ORDER BY p2.created_at DESC,p2.id DESC LIMIT 1)".($where?' WHERE '.implode(' AND ',$where):'')." ORDER BY r.created_at DESC,r.id DESC";
$stmt=mysqli_prepare($conn,$sql); if($params) mysqli_stmt_bind_param($stmt,$types,...$params); mysqli_stmt_execute($stmt); $reservations=mysqli_stmt_get_result($stmt);
$counts=[];$countResult=mysqli_query($conn,"SELECT status,COUNT(*) total FROM reservations GROUP BY status");while($row=mysqli_fetch_assoc($countResult))$counts[$row['status']]=$row['total'];
function badge_class($status){return match($status){'Pending'=>'warning','Approved'=>'primary','Diagnosing'=>'info','Quotation Sent'=>'secondary','Quotation Accepted'=>'primary','In Progress'=>'info','Ready for Pickup'=>'warning','Completed'=>'success','Cancelled','Rejected'=>'danger',default=>'secondary'};}
?>
<div class="container-fluid">
 <div class="page-heading"><div><span class="eyebrow">SERVICE OPERATIONS</span><h2>Jobs</h2><p>Open a job to see its single next required action.</p></div><div class="summary-pill"><strong><?= array_sum($counts) ?></strong><span>Total jobs</span></div></div>
 <div class="row g-3 mb-4"><?php foreach(['Pending','Approved','In Progress','Ready for Pickup'] as $item): ?><div class="col-6 col-xl-3"><div class="mini-stat"><span><?= $item ?></span><strong><?= intval($counts[$item]??0) ?></strong></div></div><?php endforeach; ?></div>
 <form class="filter-bar mb-4" method="get"><div class="row g-2 align-items-end">
  <div class="col-lg-5"><label>Search</label><input class="form-control" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Reference, customer, or plate number"></div>
  <div class="col-lg-3"><label>Status</label><select class="form-select" name="status"><option value="">All statuses</option><?php foreach($allowed as $item): ?><option value="<?= $item ?>" <?= $status===$item?'selected':'' ?>><?= $item ?></option><?php endforeach; ?></select></div>
  <div class="col-lg-2"><label>Date</label><input type="date" class="form-control" name="date" value="<?= htmlspecialchars($date) ?>"></div>
  <div class="col-lg-2 d-flex gap-2"><button class="btn btn-primary flex-fill">Filter</button><a href="reservations.php" class="btn btn-light">Reset</a></div>
 </div></form>
 <div class="clean-card p-0 overflow-hidden"><div class="table-responsive"><table class="table clean-table align-middle mb-0"><thead><tr><th>Booking</th><th>Customer & Vehicle</th><th>Services</th><th>Schedule</th><th>Progress</th><th></th></tr></thead><tbody>
 <?php if(mysqli_num_rows($reservations)): while($r=mysqli_fetch_assoc($reservations)): ?>
  <tr><td><strong><?= htmlspecialchars($r['reference_number']?:'#'.$r['id']) ?></strong><small>Created <?= date('M d',strtotime($r['created_at'])) ?></small></td>
  <td><strong><?= htmlspecialchars($r['customer_name']??'Unknown') ?></strong><small><?= htmlspecialchars(($r['brand']??'').' '.($r['model']??'').' • '.($r['plate_number']??'')) ?></small></td>
  <td><div class="service-tags"><?php foreach(explode(',',$r['service_type']) as $service): ?><span><?= htmlspecialchars(trim($service)) ?></span><?php endforeach; ?></div></td>
  <td><strong><?= date('M d, Y',strtotime($r['appointment_date'])) ?></strong><small><?= date('h:i A',strtotime($r['appointment_time'])) ?><?= $r['mechanic_name']?' • '.htmlspecialchars($r['mechanic_name']):'' ?></small></td>
  <td><span class="badge rounded-pill text-bg-<?= badge_class($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span><small><?= $r['grand_total']!==null?'Quote ₱'.number_format($r['grand_total'],2):'No quotation yet' ?></small></td>
  <td class="text-end"><a class="btn btn-sm btn-primary" href="reservation_view.php?id=<?= $r['id'] ?>">Open Job</a></td></tr>
 <?php endwhile; else: ?><tr><td colspan="6" class="empty-row">No reservations match your filters.</td></tr><?php endif; ?>
 </tbody></table></div></div>
</div>
<?php include "includes/admin_footer.php"; ?>
