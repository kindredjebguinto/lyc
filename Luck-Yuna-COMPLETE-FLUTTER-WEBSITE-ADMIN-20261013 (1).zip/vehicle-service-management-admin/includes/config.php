<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "vehicle_service_system";

$conn = mysqli_connect(
    $host,
    $user,
    $password,
    $database
);

if (!$conn) {
    die(
        "Database connection failed: "
        . mysqli_connect_error()
    );
}

mysqli_set_charset(
    $conn,
    "utf8mb4"
);

// Small support table used by the admin interface. Creating it here keeps
// older installations from crashing before the latest migration is imported.
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id int(11) NOT NULL AUTO_INCREMENT,
    admin_name varchar(100) NOT NULL,
    action varchar(120) NOT NULL,
    entity_type varchar(50) NOT NULL,
    entity_id int(11) DEFAULT NULL,
    details varchar(500) DEFAULT NULL,
    created_at timestamp NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (id), KEY entity_lookup (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");


/*
|--------------------------------------------------------------------------
| ADMIN BASE URL
|--------------------------------------------------------------------------
*/

define(
    'ADMIN_BASE_URL',
    '/Vehicle-Service-System/vehicle-service-management-admin'
);


/*
|--------------------------------------------------------------------------
| PUBLIC WEBSITE URL
|--------------------------------------------------------------------------
*/

define(
    'PUBLIC_BASE_URL',
    '/Vehicle-Service-System/vehicle-service-management'
);
