        </div>

        </main>

        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
        </script>

        <script src="<?= ADMIN_BASE_URL ?>/js/admin.js"></script>

        </body>

        </html>