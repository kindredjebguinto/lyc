import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../api/service_api.dart';
import '../../api/vehicle_api.dart';
import '../../models/service.dart';
import '../../models/vehicle.dart';
import '../../services/session_service.dart';
import '../../widgets/app_widgets.dart';
import '../payments/booking_payment_screen.dart';

class BookServiceScreen extends StatefulWidget {
  final List<int> initialServiceIds;
  const BookServiceScreen({this.initialServiceIds = const [], super.key});

  @override
  State<BookServiceScreen> createState() => _BookServiceScreenState();
}

class _BookServiceScreenState extends State<BookServiceScreen> {
  final _remarksController = TextEditingController();
  List<Vehicle> _vehicles = [];
  List<Service> _services = [];
  final Set<int> _selectedServiceIds = {};
  int _step = 0;
  int? _vehicleId;
  DateTime? _date;
  TimeOfDay? _time;
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String _serviceCategory = 'All';
  bool _policyAccepted = false;
  bool _loadingSlots=false;
  List<Map<String,dynamic>> _slots=[];

  List<String> get _serviceCategories => ['All', ...{for (final service in _services) service.category}];
  List<Service> get _visibleServices => _serviceCategory == 'All' ? _services : _services.where((service) => service.category == _serviceCategory).toList();

  List<Service> get _selectedServices => _services
      .where((service) => _selectedServiceIds.contains(service.id))
      .toList();

  double get _totalPrice => _selectedServices.fold(
        0,
        (total, service) => total + service.price,
      );

  int get _totalMinutes => _selectedServices.fold(
        0,
        (total, service) => total + (service.estimatedDuration ?? 0),
      );

  Vehicle? get _selectedVehicle {
    for (final vehicle in _vehicles) {
      if (vehicle.id == _vehicleId) return vehicle;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _remarksController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final customerId = await SessionService.getCustomerId();
      if (customerId == null) throw Exception('Customer session was not found.');
      final results = await Future.wait([
        VehicleApi.getVehicles(customerId: customerId),
        ServiceApi.getServices(),
      ]);
      if (!mounted) return;
      setState(() {
        _vehicles = results[0] as List<Vehicle>;
        _services = results[1] as List<Service>;
        _selectedServiceIds.addAll(widget.initialServiceIds.where((id) => _services.any((service) => service.id == id)));
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  bool _canContinue() {
    if (_step == 0 && _vehicleId == null) {
      _message('Choose your vehicle.');
      return false;
    }
    if (_step == 1 && _selectedServiceIds.isEmpty) {
      _message('Select at least one service.');
      return false;
    }
    if(_step==2&&(_date==null||_time==null)){_message('Choose an available appointment date and time.');return false;}
    return true;
  }

  void _continue() {
    if (!_canContinue()) return;
    if (_step < 3) setState(() => _step++);
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _submit() async {
    final selectedDate = _date;
    final selectedTime = _time;
    final selectedVehicleId = _vehicleId;
    if (selectedDate == null ||
        selectedTime == null ||
        selectedVehicleId == null ||
        _selectedServices.isEmpty) {
      _message('Please complete all booking steps first.');
      return;
    }
    setState(() => _saving = true);
    final date = '${selectedDate.year.toString().padLeft(4, '0')}-'
        '${selectedDate.month.toString().padLeft(2, '0')}-'
        '${selectedDate.day.toString().padLeft(2, '0')}';
    final time = '${selectedTime.hour.toString().padLeft(2, '0')}:'
        '${selectedTime.minute.toString().padLeft(2, '0')}:00';

    try {
      final result = await CustomerApi.createReservation(
        vehicleId: selectedVehicleId,
        serviceTypes: _selectedServices.map((item) => item.serviceName).toList(),
        date: date,
        time: time,
        remarks: _remarksController.text.trim(),
        policyAccepted: _policyAccepted,
      );
      if (!mounted) return;
      if (result['success'] == true) {
        final paymentId=int.tryParse(result['payment_id']?.toString()??'');
        if(paymentId!=null) await Navigator.push(context,MaterialPageRoute(builder:(_)=>BookingPaymentScreen(paymentId:paymentId)));
        if (mounted) Navigator.pop(context, true);
      } else {
        _message(result['message']?.toString() ?? 'Unable to book service.');
      }
    } catch (error) {
      _message(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Book a Service')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? EmptyState(
                  icon: Icons.cloud_off,
                  title: 'Unable to Load',
                  message: _error!,
                )
              : _vehicles.isEmpty
                  ? const EmptyState(
                      icon: Icons.directions_car,
                      title: 'Add a Vehicle First',
                      message: 'Register a vehicle before booking a service.',
                    )
                  : Stepper(
                      currentStep: _step,
                      onStepTapped: (value) {
                        if (value <= _step) setState(() => _step = value);
                      },
                      onStepContinue: _step == 3 ? _submit : _continue,
                      onStepCancel: _step == 0
                          ? null
                          : () => setState(() => _step--),
                      controlsBuilder: (context, details) => Padding(
                        padding: const EdgeInsets.only(top: 18),
                        child: Row(
                          children: [
                            FilledButton(
                              onPressed: _saving || (_step==3&&!_policyAccepted) ? null : details.onStepContinue,
                              child: Text(
                                _saving
                                    ? 'SUBMITTING...'
                                    : _step == 3
                                        ? 'PAY ₱200 & SUBMIT'
                                        : 'CONTINUE',
                              ),
                            ),
                            if (_step > 0)
                              TextButton(
                                onPressed: details.onStepCancel,
                                child: const Text('BACK'),
                              ),
                          ],
                        ),
                      ),
                      steps: [
                        Step(
                          title: const Text('My Vehicle'),
                          isActive: _step >= 0,
                          state: _vehicleId == null
                              ? StepState.indexed
                              : StepState.complete,
                          content: Column(children: [const Align(alignment: Alignment.centerLeft, child: Text('Choose your vehicle', style: TextStyle(fontWeight: FontWeight.bold))),_vehicleChoices()]),
                        ),
                        Step(
                          title: const Text('Services'),
                          subtitle: const Text('Select one or more'),
                          isActive: _step >= 1,
                          state: _selectedServiceIds.isEmpty ? StepState.indexed : StepState.complete,
                          content: _serviceChecklist(),
                        ),
                        Step(title:const Text('Available Schedule'),isActive:_step>=2,state:_date==null||_time==null?StepState.indexed:StepState.complete,content:_schedule()),
                        Step(
                          title: const Text('Review & Submit'),
                          isActive: _step >= 3,
                          content: _confirmation(),
                        ),
                      ],
                    ),
    );
  }

  Widget _vehicleChoices() => Column(
        children: _vehicles.map((vehicle) {
          return RadioListTile<int>(
            value: vehicle.id,
            groupValue: _vehicleId,
            onChanged: (value) => setState(() => _vehicleId = value),
            title: Text('${vehicle.brand} ${vehicle.model}'),
            subtitle: Text('${vehicle.year} • ${vehicle.plateNumber}'),
            secondary: const Icon(Icons.directions_car),
          );
        }).toList(),
      );

  Widget _serviceChecklist() => Column(
        children: [
          SizedBox(height: 38, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _serviceCategories.length, separatorBuilder: (_, __) => const SizedBox(width: 7), itemBuilder: (_, index) { final category = _serviceCategories[index]; return ChoiceChip(label: Text(category), selected: _serviceCategory == category, onSelected: (_) => setState(() => _serviceCategory = category)); })),
          const SizedBox(height: 10),
          ..._visibleServices.map((service) {
            final selected = _selectedServiceIds.contains(service.id);
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: CheckboxListTile(
                value: selected,
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      _selectedServiceIds.add(service.id);
                    } else {
                      _selectedServiceIds.remove(service.id);
                    }
                    _date=null;_time=null;_slots=[];
                  });
                },
                title: Text(service.serviceName),
                subtitle: Text(
                  '${money(service.price)} • ${service.estimatedDuration ?? 0} minutes\n'
                  '${service.description}',
                ),
                controlAffinity: ListTileControlAffinity.leading,
                secondary: Icon(_serviceIcon(service.serviceName), color: primaryColor),
              ),
            );
          }),
          if (_selectedServiceIds.isNotEmpty)
            ListTile(
              title: Text('${_selectedServiceIds.length} services selected'),
              subtitle: Text('Estimated $_totalMinutes minutes'),
              trailing: Text(
                money(_totalPrice),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),
            ),
        ],
      );

  Future<void> _loadSlots() async {
    if(_date==null||_selectedServices.isEmpty)return;setState((){_loadingSlots=true;_slots=[];_time=null;});
    final date='${_date!.year.toString().padLeft(4,'0')}-${_date!.month.toString().padLeft(2,'0')}-${_date!.day.toString().padLeft(2,'0')}';
    try{final result=await CustomerApi.reservationAvailability(date,_selectedServices.map((s)=>s.serviceName).toList());if(mounted)setState((){_slots=(result['slots'] as List? ?? []).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();_loadingSlots=false;});}catch(e){if(mounted){setState(()=>_loadingSlots=false);_message(e.toString().replaceFirst('Exception: ',''));}}
  }

  Widget _schedule() => Column(
        children: [
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: Text(
              _date == null
                  ? 'Choose appointment date'
                  : '${_date!.month}/${_date!.day}/${_date!.year}',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final value = await showDatePicker(
                context: context,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
                initialDate: DateTime.now().add(const Duration(days: 1)),
              );
              if (value != null) {setState(() => _date = value);_loadSlots();}
            },
          ),
          if(_loadingSlots)const Padding(padding:EdgeInsets.all(16),child:LinearProgressIndicator())
          else if(_date!=null&&_slots.isEmpty)const Padding(padding:EdgeInsets.all(12),child:Text('No schedule information is available. Choose another date.'))
          else if(_slots.isNotEmpty)...[const Align(alignment:Alignment.centerLeft,child:Padding(padding:EdgeInsets.only(top:10,bottom:8),child:Text('Choose an available time',style:TextStyle(fontWeight:FontWeight.bold)))),Wrap(spacing:8,runSpacing:8,children:_slots.map((slot){final available=slot['available']==true;final parts=slot['time'].toString().split(':');final value=TimeOfDay(hour:int.parse(parts[0]),minute:int.parse(parts[1]));final selected=_time?.hour==value.hour&&_time?.minute==value.minute;return ChoiceChip(label:Text(available?slot['label'].toString():'${slot['label']}\nBooked',textAlign:TextAlign.center),selected:selected,onSelected:available?(_)=>setState(()=>_time=value):null);}).toList()),const Padding(padding:EdgeInsets.only(top:10),child:Row(children:[Icon(Icons.info_outline,size:17),SizedBox(width:6),Expanded(child:Text('Unavailable hours are disabled because another booking or service-duration allowance occupies that time.',style:TextStyle(fontSize:12))) ]))],
          const SizedBox(height: 12),
          TextField(
            controller: _remarksController,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Additional remarks (optional)',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      );

  Widget _confirmation() {
    final vehicle = _selectedVehicle;
    final selectedDate = _date;
    final selectedTime = _time;
    final scheduleText = selectedDate == null || selectedTime == null
        ? 'Complete the schedule step first'
        : '${selectedDate.month}/${selectedDate.day}/${selectedDate.year} • '
            '${selectedTime.format(context)}';
    final vehicleText = vehicle == null
        ? 'Select a vehicle first'
        : '${vehicle.brand} ${vehicle.model}';
    final servicesText = _selectedServices.isEmpty
        ? 'Select at least one service'
        : _selectedServices.map((item) => item.serviceName).join(', ');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _summary('Vehicle', vehicleText),
            _summary('Plate', vehicle?.plateNumber ?? ''),
            _summary('Services', servicesText),
            _summary('Estimated total', money(_totalPrice)),
            _summary('Estimated duration', '$_totalMinutes minutes'),
            _summary('Schedule', scheduleText),
            const Divider(height: 24),
            const Text('Refundable reservation fee',style:TextStyle(fontWeight:FontWeight.bold)),
            const SizedBox(height:4),
            const Text('₱200 is required to reserve this schedule. It will be credited to your final bill and fully refunded if you or the service center cancels before inspection begins.'),
            CheckboxListTile(contentPadding:EdgeInsets.zero,value:_policyAccepted,onChanged:(value)=>setState(()=>_policyAccepted=value??false),title:const Text('I accept the booking, cancellation, refund, payment, and privacy policy.'),subtitle:const Text('No-show appointments may forfeit the reservation fee.')),
            Text(
              'Final charges may change after vehicle inspection.',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summary(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 120,
              child: Text(label, style: TextStyle(color: Colors.grey.shade600)),
            ),
            Expanded(
              child: Text(
                value,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      );

  IconData _serviceIcon(String name) {
    final value = name.toLowerCase();
    if (value.contains('oil')) return Icons.oil_barrel;
    if (value.contains('brake')) return Icons.car_crash;
    if (value.contains('battery')) return Icons.battery_charging_full;
    if (value.contains('tire')) return Icons.tire_repair;
    if (value.contains('air')) return Icons.ac_unit;
    if (value.contains('engine')) return Icons.settings;
    return Icons.build_circle;
  }
}
