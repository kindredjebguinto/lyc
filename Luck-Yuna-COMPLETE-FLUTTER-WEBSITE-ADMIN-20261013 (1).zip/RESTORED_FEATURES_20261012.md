# Restored feature checklist

- All mechanics are presented as all-around mechanics; specialization is removed from active forms, lists, reports, assignments, API responses, and customer booking screens.
- Manager-only staff account registration.
- Clickable customer overview cards.
- Reservation schedule is visible in admin.
- Selected service prices and initial total are visible in admin booking details.
- Vehicle inspection is locked until the reserved date and time, in both the button and server validation.
- Notification unread red dot and clickable reservation notifications.
- Saving a quotation redirects to reservation details.
- Guided cancellation reasons, refund eligibility, and confirmation.
- Admin jobs default to newest schedule first.
- Rejected quotations cancel the reservation and request the refundable reservation-fee refund.
- Dashboard primary action is Book Service; booking starts with My Vehicles.
- Multi-service checklist, policy acceptance, and refundable PHP 200 reservation fee.
- Demo GCash QR placeholder; replace it with the shop's official QR before launch.
- Doubled scheduling allowance and overlap blocking in app API and customer website.
- Customer decision buttons for additional-work quotation items; rejecting one does not cancel original work.
- 1–5 star rating and written feedback.
- Registered customers are clickable with their reservation history.
- Cash payments require admin confirmation; the system receipt is the customer's proof after payment.

## External setup still required

True lock-screen notifications cannot be safely shipped with placeholder credentials. Configure Firebase Cloud Messaging and add the real Android/iOS Firebase files before enabling production push notifications. In-app notifications are already functional.
