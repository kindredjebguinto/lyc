</main>
<?php if (empty($_SESSION['customer_id'])): ?>
<footer class="customer-footer"><div class="container text-center"><img src="<?= BASE_URL ?>/images/logo.png" alt="Luck Yuna Car Center logo" class="footer-logo"><p class="mb-1">Luck Yuna Car Center</p><small>Reliable care for every journey.</small></div></footer>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/js/customer.js"></script>
</body>
</html>
