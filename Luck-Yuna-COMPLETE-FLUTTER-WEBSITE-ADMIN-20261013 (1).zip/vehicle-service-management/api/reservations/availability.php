<?php
require_once __DIR__.'/../config/bootstrap.php';
requireMethod('POST');requireCustomer($conn);$data=jsonInput();
$date=trim($data['appointment_date']??'');$serviceTypes=$data['service_types']??[];
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!is_array($serviceTypes)||!$serviceTypes){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Choose a date and at least one service.']);exit;}
$serviceTypes=array_values(array_unique(array_filter(array_map('trim',$serviceTypes))));
$escaped=array_map(fn($name)=>"'".$conn->real_escape_string($name)."'",$serviceTypes);
$result=$conn->query("SELECT service_name,COALESCE(estimated_duration,30) estimated_duration FROM services WHERE status='Active' AND service_name IN (".implode(',',$escaped).")");
if(!$result||$result->num_rows!==count($serviceTypes)){http_response_code(422);echo json_encode(['success'=>false,'message'=>'One or more selected services are unavailable.']);exit;}
$duration=0;while($row=$result->fetch_assoc())$duration+=max(30,(int)$row['estimated_duration'])*2;
$slots=[];for($minutes=8*60;$minutes<=16*60+30;$minutes+=30){$time=sprintf('%02d:%02d:00',intdiv($minutes,60),$minutes%60);$start=strtotime("$date $time");$end=$start+$duration*60;$available=true;$reason='';if((int)date('N',$start)===7){$available=false;$reason='Closed on Sunday';}elseif($start<=time()){$available=false;$reason='Past time';}elseif(date('Y-m-d',$end)!==$date||((int)date('H',$end)*60+(int)date('i',$end))>17*60){$available=false;$reason='Service would finish after closing';}else{$startSql=date('Y-m-d H:i:s',$start);$endSql=date('Y-m-d H:i:s',$end);$stmt=$conn->prepare("SELECT id FROM reservations WHERE status NOT IN ('Cancelled','Completed') AND TIMESTAMP(appointment_date,appointment_time) < ? AND DATE_ADD(TIMESTAMP(appointment_date,appointment_time),INTERVAL scheduled_duration_minutes MINUTE) > ? LIMIT 1");$stmt->bind_param('ss',$endSql,$startSql);$stmt->execute();if($stmt->get_result()->num_rows){$available=false;$reason='Already booked';}$stmt->close();}$slots[]=['time'=>substr($time,0,5),'label'=>date('g:i A',$start),'available'=>$available,'reason'=>$reason];}
echo json_encode(['success'=>true,'duration_minutes'=>$duration,'slots'=>$slots]);
