-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2026 at 06:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vehicle_service_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_tokens`
--

CREATE TABLE `api_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `legacy_user_id` int(11) DEFAULT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `user_id`, `legacy_user_id`, `fullname`, `email`, `phone`, `address`, `created_at`) VALUES
(1, 5, 5, 'Patrice S.F. Guinto', 'kindredjeb@gmail.com', NULL, NULL, '2026-08-27 06:55:56'),
(2, 6, 6, 'Patrice', 'karl@gmail.com', '+639451250831', NULL, '2026-08-27 06:55:56'),
(10, NULL, NULL, 'Patrice S.F. Guinto', 'kindredjebgold@gmail.com', '+639451250831', NULL, '2026-08-27 07:33:40');

-- --------------------------------------------------------

--
-- Table structure for table `mechanics`
--

CREATE TABLE `mechanics` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `status` enum('Available','Busy','Inactive') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mechanics`
--

INSERT INTO `mechanics` (`id`, `fullname`, `email`, `phone`, `specialization`, `status`, `created_at`) VALUES
(1, 'Juan', 'juan@example.com', '09123456789', 'Engine Repair', 'Available', '2026-08-10 04:44:18'),
(2, 'Pedro Santos', 'pedro@example.com', '09234567890', 'Brake and Suspension', 'Available', '2026-08-10 04:44:18'),
(3, 'Mark Reyes', 'mark@example.com', '09345678901', 'Electrical', 'Available', '2026-08-10 04:44:18'),
(4, 'Jay', 'jay@gmail.com', '+639451250831', 'General', 'Available', '2026-08-18 01:26:43');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('Cash','GCash','Bank Transfer','Card') NOT NULL DEFAULT 'Cash',
  `status` enum('Pending','Paid','Cancelled') NOT NULL DEFAULT 'Pending',
  `reference_number` varchar(100) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `reservation_id`, `amount`, `payment_method`, `status`, `reference_number`, `paid_at`, `created_at`) VALUES
(1, 8, 2000.00, 'Cash', 'Paid', '', '2026-08-20 10:25:33', '2026-08-20 02:24:51'),
(2, 9, 2000.00, 'Cash', 'Paid', '', '2026-08-21 10:58:34', '2026-08-21 02:58:32'),
(3, 14, 5000.00, 'Cash', 'Paid', '', '2026-08-30 23:48:20', '2026-08-30 15:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `reference_number` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `vehicle_id` int(11) NOT NULL,
  `service_type` varchar(500) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('Pending','Approved','In Progress','Completed','Cancelled') DEFAULT 'Pending',
  `mechanic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `reference_number`, `user_id`, `customer_id`, `vehicle_id`, `service_type`, `appointment_date`, `appointment_time`, `remarks`, `status`, `mechanic_id`, `created_at`) VALUES
(1, NULL, 6, 2, 5, 'Oil Change', '2027-04-16', '19:41:00', 'haktog', 'Completed', NULL, '2026-08-12 18:36:12'),
(3, NULL, 5, 1, 8, 'General Maintenance', '2026-09-10', '14:34:00', 'just general maintenance', 'Completed', NULL, '2026-08-13 06:34:49'),
(4, NULL, 5, 1, 9, 'General Maintenance', '2026-10-09', '19:03:00', 'kasi inom ng inom ng coke kaya kaya kailangan magpageneral check up para makita kung anong problema ng aking system', 'Cancelled', NULL, '2026-08-13 11:04:01'),
(5, NULL, 5, 1, 9, 'Oil Change', '2026-10-09', '08:00:00', 'need oil change mabaho na siya', 'Completed', 2, '2026-08-16 15:51:15'),
(6, NULL, 5, 1, 9, 'General Maintenance', '2026-10-09', '09:29:00', '', 'Completed', 4, '2026-08-18 01:29:12'),
(7, NULL, 5, 1, 9, 'General Maintenance', '2026-10-09', '22:33:00', '', 'Completed', 4, '2026-08-18 02:33:53'),
(8, NULL, 5, 1, 9, 'Engine Check', '2026-08-20', '08:00:00', 'may sira ang engine', 'Completed', 1, '2026-08-19 10:22:43'),
(9, NULL, 5, 1, 8, 'Engine Check', '2026-10-20', '08:30:00', '', 'Completed', 4, '2026-08-19 10:27:19'),
(10, 'VSMS-20260827-E7D9A7', NULL, 10, 11, 'Tire Service', '2027-08-31', '08:00:00', 'dont know', 'Pending', NULL, '2026-08-27 07:33:40'),
(11, 'VSMS-20260827-BCC326', NULL, 10, 11, 'Battery Service', '2026-10-09', '16:36:00', '', 'Pending', NULL, '2026-08-27 09:36:53'),
(12, 'VSMS-20260828-DE4D31', NULL, 2, 5, 'Battery Service', '2026-08-29', '10:33:00', '', 'Pending', NULL, '2026-08-28 02:33:07'),
(13, 'VSMS-20260829-123737', NULL, 10, 11, 'Brake Service', '2026-08-31', '12:00:00', '', 'Pending', NULL, '2026-08-29 05:08:56'),
(14, 'VSMS-20260829-BE05EF', NULL, 10, 11, 'Engine Check', '2026-08-31', '14:00:00', '', 'Completed', 4, '2026-08-29 06:22:06');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estimated_duration` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `description`, `price`, `estimated_duration`, `status`, `created_at`) VALUES
(1, 'General Maintenance', 'General inspection and preventive vehicle maintenance.', 1500.00, 120, 'Active', '2026-08-20 01:51:59'),
(2, 'Oil Change', 'Engine oil and oil filter replacement.', 1200.00, 60, 'Active', '2026-08-20 01:51:59'),
(3, 'Brake Service', 'Brake inspection, cleaning, adjustment, and repair.', 1800.00, 120, 'Active', '2026-08-20 01:51:59'),
(4, 'Engine Check', 'Engine inspection and diagnostic checking.', 2000.00, 120, 'Active', '2026-08-20 01:51:59'),
(5, 'Battery Service', 'Battery testing, charging, and terminal inspection.', 800.00, 45, 'Inactive', '2026-08-20 01:51:59'),
(6, 'Tire Service', 'Tire inspection, rotation, and basic tire service.', 1000.00, 60, 'Active', '2026-08-20 01:51:59'),
(7, 'Air Conditioning Service', 'Vehicle air-conditioning inspection and maintenance.', 1800.00, 120, 'Inactive', '2026-08-20 01:51:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','staff') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Kindred Jeb Guinto', 'kindredjebgold@gmail.com', '$2y$10$eSV1mdoFxI/JwhGJuTay0OorVEG8qMNPahrsODRsyTT6S.LX06uQ6', 'staff', '2026-08-02 12:01:32'),
(5, 'Patrice S.F. Guinto', 'kindredjeb@gmail.com', '$2y$10$EGRBapkqzLjwutz8BMFd..TSOKzfiVE.sgvh.3lHD9FerxiyOrDfO', 'customer', '2026-08-10 06:03:03'),
(6, 'karl', 'karl@gmail.com', '$2y$10$q9unYfE/Hl0NztZpZv9JOeVv9rsID4yHg53bbFL79Q6uZFYuWB.ia', 'customer', '2026-08-12 03:03:59');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` year(4) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `color` varchar(30) DEFAULT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `transmission` varchar(30) DEFAULT NULL,
  `fuel_type` varchar(30) DEFAULT NULL,
  `mileage` int(11) DEFAULT NULL,
  `vin` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `user_id`, `customer_id`, `brand`, `model`, `year`, `plate_number`, `color`, `created_at`) VALUES
(5, 6, 2, 'suzuki', 'selerio', '2016', 'nbx 9268', 'white', '2026-08-12 18:32:13'),
(8, 5, 1, 'toyota', 'inova', '2026', 'nbx 9268', 'black', '2026-08-13 03:24:14'),
(9, 5, 1, 'Suzuki', 'Celerio', '2013', 'fpj 0516', 'white', '2026-08-13 11:01:52'),
(11, NULL, 10, 'toyota', 'Celerio', '2001', 'NBX 9268', 'white', '2026-08-27 07:33:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `legacy_user_id` (`legacy_user_id`),
  ADD KEY `idx_customer_email` (`email`),
  ADD KEY `idx_customer_phone` (`phone`);

--
-- Indexes for table `mechanics`
--
ALTER TABLE `mechanics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_reservation_payment` (`reservation_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `fk_reservation_mechanic` (`mechanic_id`),
  ADD KEY `fk_reservation_customer` (`customer_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_vehicle_customer` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_tokens`
--
ALTER TABLE `api_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `mechanics`
--
ALTER TABLE `mechanics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `password_reset_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('Pending','Resolved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `password_reset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Constraints for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD CONSTRAINT `api_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payment_reservation` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_reservation_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `fk_reservation_mechanic` FOREIGN KEY (`mechanic_id`) REFERENCES `mechanics` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `fk_vehicle_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

-- Job quotations (itemized estimate for a reservation)
ALTER TABLE `payments`
  MODIFY `payment_method` enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected',
  MODIFY `status` enum('Pending','Awaiting Proof','Pay at Shop','Under Review','Paid','Rejected','Cancelled') NOT NULL DEFAULT 'Awaiting Proof',
  ADD COLUMN `proof_file` varchar(255) DEFAULT NULL,
  ADD COLUMN `submitted_at` datetime DEFAULT NULL,
  ADD COLUMN `admin_notes` varchar(500) DEFAULT NULL;

ALTER TABLE `reservations`
  MODIFY `status` enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') DEFAULT 'Pending',
  ADD COLUMN `intake_mileage` int(11) DEFAULT NULL,
  ADD COLUMN `diagnosis` text DEFAULT NULL,
  ADD COLUMN `work_performed` text DEFAULT NULL,
  ADD COLUMN `completion_notes` text DEFAULT NULL,
  ADD COLUMN `next_service_date` date DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `entity_lookup` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(40) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(1000) DEFAULT NULL,
  `status` enum('Draft','Sent','Accepted','Rejected') NOT NULL DEFAULT 'Draft',
  `valid_until` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `quotation_number` (`quotation_number`),
  UNIQUE KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `job_quotations_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `item_type` enum('Service','Part','Labor','Other') NOT NULL DEFAULT 'Service',
  `description` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`), KEY `quotation_id` (`quotation_id`),
  CONSTRAINT `job_quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `job_quotations` ADD COLUMN `responded_at` datetime DEFAULT NULL;
CREATE TABLE IF NOT EXISTS `job_quotation_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT, `quotation_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL, `snapshot_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_version` (`quotation_id`,`version_number`),
  CONSTRAINT `job_quotation_versions_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
