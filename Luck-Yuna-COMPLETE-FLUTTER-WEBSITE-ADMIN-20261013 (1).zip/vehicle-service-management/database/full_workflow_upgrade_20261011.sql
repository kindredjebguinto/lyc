-- Select the correct hosting database before importing. No USE statement is included.

ALTER TABLE reservations
  ADD COLUMN IF NOT EXISTS cancellation_reason varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS cancellation_details varchar(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refund_eligibility varchar(150) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_version varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_accepted_at datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_source enum('Website','Android','iOS') DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_ip varchar(45) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS scheduled_duration_minutes int NOT NULL DEFAULT 60,
  ADD COLUMN IF NOT EXISTS reservation_fee_status enum('Awaiting Payment','Under Review','Paid','Refund Requested','Refunded','Rejected','Forfeited') NOT NULL DEFAULT 'Awaiting Payment',
  ADD COLUMN IF NOT EXISTS reservation_fee_payment_id int DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS no_show_at datetime DEFAULT NULL;
ALTER TABLE reservations MODIFY status enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') NOT NULL DEFAULT 'Pending';

ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS proof_file varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS submitted_at datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS admin_notes text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS payment_type enum('Reservation Fee','Final Balance','Additional Work') NOT NULL DEFAULT 'Final Balance',
  ADD COLUMN IF NOT EXISTS gross_amount decimal(10,2) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS reservation_fee_credit decimal(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS amount_received decimal(10,2) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS received_by varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refund_status enum('Not Applicable','Requested','Under Review','Approved','Refunded','Rejected') NOT NULL DEFAULT 'Not Applicable',
  ADD COLUMN IF NOT EXISTS refund_reference varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refunded_at datetime DEFAULT NULL;
ALTER TABLE payments MODIFY payment_method enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected';
ALTER TABLE payments MODIFY status enum('Pending','Awaiting Proof','Under Review','Rejected','Pay at Shop','Paid','Cancelled') NOT NULL DEFAULT 'Pending';

ALTER TABLE payments ADD INDEX IF NOT EXISTS payment_reservation_fk_idx (reservation_id);
ALTER TABLE payments DROP INDEX IF EXISTS unique_reservation_payment;
ALTER TABLE payments ADD INDEX IF NOT EXISTS reservation_payment_type (reservation_id,payment_type);

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS staff_level enum('Manager','Service Adviser','Cashier','Mechanic','Staff') DEFAULT NULL;
ALTER TABLE users MODIFY staff_level enum('Manager','Service Adviser','Cashier','Mechanic','Staff') DEFAULT NULL;
UPDATE users SET staff_level='Manager' WHERE role='staff' AND staff_level IS NULL ORDER BY id LIMIT 1;
UPDATE users SET staff_level='Staff' WHERE role='staff' AND staff_level IS NULL;

CREATE TABLE IF NOT EXISTS booking_policy_acceptances (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  reservation_id int NOT NULL,
  policy_version varchar(20) NOT NULL,
  accepted_at datetime NOT NULL,
  source enum('Website','Android','iOS') NOT NULL,
  ip_address varchar(45) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY one_policy_per_reservation (reservation_id),
  KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS shop_closed_dates (
  id int NOT NULL AUTO_INCREMENT,
  closed_date date NOT NULL,
  reason varchar(150) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY closed_date (closed_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
  id bigint NOT NULL AUTO_INCREMENT,
  identifier varchar(190) NOT NULL,
  ip_address varchar(45) NOT NULL,
  attempted_at datetime NOT NULL DEFAULT current_timestamp(),
  success tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY lookup_attempts (identifier,ip_address,attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_feedback (
  id int NOT NULL AUTO_INCREMENT,
  reservation_id int NOT NULL,
  user_id int NOT NULL,
  rating tinyint NOT NULL,
  review varchar(1000) DEFAULT NULL,
  created_at datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY one_feedback_per_job (reservation_id,user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE notifications
  ADD COLUMN IF NOT EXISTS link_type varchar(40) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS link_id int DEFAULT NULL;

ALTER TABLE job_quotation_items
  ADD COLUMN IF NOT EXISTS is_additional tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS customer_decision enum('Pending','Accepted','Rejected') DEFAULT NULL;
