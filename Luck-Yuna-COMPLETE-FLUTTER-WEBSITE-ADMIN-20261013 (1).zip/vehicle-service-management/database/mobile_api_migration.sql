-- Run this file in phpMyAdmin only when upgrading an existing database.
USE `vehicle_service_system`;

CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `api_tokens_ibfk_1`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `reservations`
  MODIFY `service_type` varchar(500) NOT NULL;

ALTER TABLE `vehicles`
  ADD COLUMN IF NOT EXISTS `vehicle_type` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `transmission` varchar(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `fuel_type` varchar(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `mileage` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `vin` varchar(50) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `password_reset_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('Pending','Resolved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `password_reset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(40) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(1000) DEFAULT NULL,
  `status` enum('Draft','Sent','Accepted','Rejected') NOT NULL DEFAULT 'Draft',
  `valid_until` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `quotation_number` (`quotation_number`),
  UNIQUE KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `job_quotations_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `item_type` enum('Service','Part','Labor','Other') NOT NULL DEFAULT 'Service',
  `description` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`), KEY `quotation_id` (`quotation_id`),
  CONSTRAINT `job_quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `payments`
  MODIFY `payment_method` enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected',
  MODIFY `status` enum('Pending','Awaiting Proof','Pay at Shop','Under Review','Paid','Rejected','Cancelled') NOT NULL DEFAULT 'Awaiting Proof',
  ADD COLUMN IF NOT EXISTS `proof_file` varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `submitted_at` datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `admin_notes` varchar(500) DEFAULT NULL;

ALTER TABLE `reservations`
  MODIFY `status` enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') DEFAULT 'Pending',
  ADD COLUMN IF NOT EXISTS `intake_mileage` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `diagnosis` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `work_performed` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `completion_notes` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `next_service_date` date DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `entity_lookup` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `job_quotations` ADD COLUMN IF NOT EXISTS `responded_at` datetime DEFAULT NULL;
CREATE TABLE IF NOT EXISTS `job_quotation_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT, `quotation_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL, `snapshot_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_version` (`quotation_id`,`version_number`),
  CONSTRAINT `job_quotation_versions_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
