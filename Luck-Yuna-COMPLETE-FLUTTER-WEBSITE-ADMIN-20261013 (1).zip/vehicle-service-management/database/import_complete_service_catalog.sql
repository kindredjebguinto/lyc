-- Adds the former 16-item service catalog to the current services table.
-- Existing services and reservations are not deleted or changed.

INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Basic', 'Basic preventive maintenance package including standard vehicle inspection.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Basic');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Standard', 'Preventive maintenance package with additional fluid and safety checks.', 2500.00, 120, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Standard');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Premium', 'Comprehensive preventive maintenance package for complete vehicle care.', 4500.00, 180, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Premium');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Regular Oil Change', 'Regular engine oil replacement with oil filter inspection.', 1200.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Regular Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Semi-Synthetic Oil Change', 'Semi-synthetic oil service suitable for regular driving conditions.', 1800.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Semi-Synthetic Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Fully Synthetic Oil Change', 'Premium fully synthetic engine oil replacement.', 2600.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Fully Synthetic Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Air Conditioning Check', 'Inspection of the air conditioning system and cooling performance.', 800.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Air Conditioning Check');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'AC Cleaning', 'Air conditioning cleaning service.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'AC Cleaning');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Brake Inspection', 'Inspection of brake pads, rotors and braking performance.', 500.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Brake Inspection');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Brake Cleaning and Adjustment', 'Brake cleaning and adjustment service.', 1200.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Brake Cleaning and Adjustment');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Tire Rotation', 'Rotate tires for more even tread wear.', 700.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Tire Rotation');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Tire Inspection', 'Inspection of tire condition, pressure and tread.', 350.00, 30, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Tire Inspection');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Engine Diagnostic', 'Basic engine diagnostic inspection.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Engine Diagnostic');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Engine Tune-Up', 'General engine tune-up service.', 2200.00, 120, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Engine Tune-Up');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Battery Check', 'Battery health and charging system inspection.', 400.00, 30, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Battery Check');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Battery Replacement Service', 'Battery removal, replacement and charging-system check.', 800.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Battery Replacement Service');

-- Restore former general services that may currently be inactive.
UPDATE services SET status = 'Active' WHERE service_name IN ('Battery Service', 'Air Conditioning Service');
