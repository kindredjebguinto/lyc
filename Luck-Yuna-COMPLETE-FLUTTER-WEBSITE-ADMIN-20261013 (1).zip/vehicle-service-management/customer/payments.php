<?php
require_once __DIR__ . '/../includes/customer_auth.php';
$user_id=(int)$_SESSION['customer_id'];
$stmt=mysqli_prepare($conn,"SELECT p.id AS payment_id,p.amount,p.payment_method,p.status AS payment_status,p.reference_number,p.paid_at,p.created_at,
    r.id AS reservation_id,r.reference_number AS booking_reference,r.service_type,r.appointment_date,
    v.brand,v.model,v.plate_number
    FROM payments p INNER JOIN reservations r ON p.reservation_id=r.id INNER JOIN vehicles v ON r.vehicle_id=v.id
    WHERE r.user_id=? ORDER BY p.created_at DESC");
mysqli_stmt_bind_param($stmt,'i',$user_id);mysqli_stmt_execute($stmt);$result=mysqli_stmt_get_result($stmt);$payments=[];while($row=mysqli_fetch_assoc($result))$payments[]=$row;mysqli_stmt_close($stmt);
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header"><div><h1>Payments & Receipts</h1><p>Your complete payment history stays here. Pay only from the specific booking that requires payment.</p></div></div>
<?php if($payments):?><div class="customer-list"><?php foreach($payments as $payment):?>
<article class="customer-card appointment-card">
    <div class="appointment-card-top"><div><small class="text-muted"><?=htmlspecialchars($payment['booking_reference']?:'#'.$payment['reservation_id'])?></small><h3><?=htmlspecialchars($payment['brand'].' '.$payment['model'])?></h3><span class="plate"><?=htmlspecialchars($payment['plate_number'])?></span></div><span class="status-pill status-<?=strtolower(str_replace(' ','-',$payment['payment_status']))?>"><?=htmlspecialchars($payment['payment_status'])?></span></div>
    <p class="mt-3 mb-1 fw-semibold"><?=htmlspecialchars($payment['service_type'])?></p>
    <div class="appointment-meta"><span><i class="bi bi-cash-stack"></i>₱<?=number_format((float)$payment['amount'],2)?></span><span><i class="bi bi-credit-card"></i><?=htmlspecialchars($payment['payment_method']?:'Not selected')?></span><span><i class="bi bi-calendar3"></i><?=date('M d, Y',strtotime($payment['appointment_date']))?></span></div>
    <?php if($payment['reference_number']):?><p class="small text-muted mt-3 mb-0">Payment reference: <?=htmlspecialchars($payment['reference_number'])?></p><?php endif;?>
    <?php if(in_array($payment['payment_status'],['Awaiting Proof','Rejected'],true)):?><div class="mt-3"><a class="btn btn-danger btn-sm" href="<?=BASE_URL?>/customer/payment_submit.php?id=<?=(int)$payment['payment_id']?>"><i class="bi bi-wallet2"></i> Pay This Booking</a></div><?php elseif($payment['payment_status']==='Paid'):?><div class="mt-3"><a class="btn btn-outline-success btn-sm" href="<?=BASE_URL?>/customer/receipt.php?id=<?=(int)$payment['payment_id']?>"><i class="bi bi-receipt"></i> View Receipt</a></div><?php endif;?>
</article>
<?php endforeach;?></div><?php else:?><div class="customer-card customer-empty"><i class="bi bi-wallet2"></i><h2 class="h5 mt-2">No payment records</h2><p class="text-muted mb-0">Payments will appear after a quotation is prepared for your booking.</p></div><?php endif;?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
