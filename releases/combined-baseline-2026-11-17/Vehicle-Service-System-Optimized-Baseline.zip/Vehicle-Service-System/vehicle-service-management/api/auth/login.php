<?php

require_once __DIR__ . "/../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$input = json_decode(file_get_contents("php://input"), true);

$email = trim($input["email"] ?? "");
$password = $input["password"] ?? "";

if ($email === "" || $password === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Email and password are required."
    ]);

    exit;
}

$stmt = $conn->prepare("
    SELECT
        id,
        fullname,
        email,
        password,
        role
    FROM users
    WHERE email = ?
    LIMIT 1
");

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    exit;
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user["password"])) {

    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    exit;
}

if ($user["role"] !== "customer") {

    http_response_code(403);

    echo json_encode([
        "success" => false,
        "message" => "This application is for customers only."
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Find customer profile
|--------------------------------------------------------------------------
*/

// Repair older website accounts only after their password has been verified.
// Lock the account so simultaneous logins cannot create duplicate profiles.
$conn->begin_transaction();
try {
    $lock = $conn->prepare("SELECT id,fullname,email FROM users WHERE id=? AND role='customer' FOR UPDATE");
    $lock->bind_param("i", $user["id"]);
    $lock->execute();
    $currentUser = $lock->get_result()->fetch_assoc();
    $lock->close();
    if (!$currentUser) throw new RuntimeException('Customer account unavailable.');

    $customerStmt = $conn->prepare("SELECT * FROM customers WHERE user_id=? ORDER BY id LIMIT 1");
    $customerStmt->bind_param("i", $user["id"]);
    $customerStmt->execute();
    $customer = $customerStmt->get_result()->fetch_assoc();
    $customerStmt->close();
    if (!$customer) {
        // Create a new owned profile; do not adopt a guest record by email.
        $profile = $conn->prepare("INSERT INTO customers(user_id,fullname,email) VALUES(?,?,?)");
        $profile->bind_param("iss", $currentUser["id"], $currentUser["fullname"], $currentUser["email"]);
        $profile->execute();
        $customerId = $conn->insert_id;
        $profile->close();
        $customerStmt = $conn->prepare("SELECT * FROM customers WHERE id=?");
        $customerStmt->bind_param("i", $customerId);
        $customerStmt->execute();
        $customer = $customerStmt->get_result()->fetch_assoc();
        $customerStmt->close();
    }
    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    http_response_code(503);
    echo json_encode(["success" => false, "message" => "Unable to load your customer profile. Please try again."]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Generate API Token
|--------------------------------------------------------------------------
*/

$token = bin2hex(random_bytes(32));

$tokenHash = hash("sha256", $token);

$expiresAt = date(
    "Y-m-d H:i:s",
    strtotime("+7 days")
);

$tokenStmt = $conn->prepare("
    INSERT INTO api_tokens
    (
        user_id,
        token_hash,
        expires_at
    )
    VALUES (?, ?, ?)
");

$tokenStmt->bind_param(
    "iss",
    $user["id"],
    $tokenHash,
    $expiresAt
);

$tokenStmt->execute();

/*
|--------------------------------------------------------------------------
| Successful Login
|--------------------------------------------------------------------------
*/

echo json_encode([
    "success" => true,
    "message" => "Login successful.",

    "token" => $token,

    "expires_at" => $expiresAt,

    "user" => [
        "id" => (int) $user["id"],
        "fullname" => $user["fullname"],
        "email" => $user["email"],
        "role" => $user["role"]
    ],

    "customer" => $customer
]);
