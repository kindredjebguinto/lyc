import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vsm_customer/screens/payments/payment_proof_dialog.dart';

void main() {
  late Directory fixtures;
  late XFile image;
  late XFile largeImage;
  setUpAll(() async {
    fixtures = await Directory.systemTemp.createTemp('lyc-payment-dialog-');
    final recorder = ui.PictureRecorder();
    Canvas(
      recorder,
    ).drawRect(const Rect.fromLTWH(0, 0, 4, 4), Paint()..color = Colors.green);
    final picture = recorder.endRecording();
    final bitmap = await picture.toImage(4, 4);
    final bytes = await bitmap.toByteData(format: ui.ImageByteFormat.png);
    final file = File('${fixtures.path}/proof.png');
    await file.writeAsBytes(bytes!.buffer.asUint8List());
    image = XFile(file.path);
    bitmap.dispose();
    picture.dispose();
    final large = File('${fixtures.path}/large.png');
    await large.writeAsBytes(List.filled(5 * 1024 * 1024 + 1, 0));
    largeImage = XFile(large.path);
  });
  tearDownAll(() => fixtures.delete(recursive: true));

  Future<void> open(
    WidgetTester tester, {
    double width = 390,
    double scale = 1,
    double keyboard = 0,
    bool fee = true,
    Future<XFile?> Function()? picker,
    ValueChanged<PaymentProofSubmission?>? onResult,
  }) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = Size(width, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(scale),
            viewInsets: EdgeInsets.only(bottom: keyboard),
          ),
          child: child!,
        ),
        home: Scaffold(
          body: Builder(
            builder: (context) => TextButton(
              onPressed: () async {
                final result = await showDialog<PaymentProofSubmission>(
                  context: context,
                  builder: (_) => PaymentProofDialog(
                    isReservationFee: fee,
                    pickImage: picker ?? () async => image,
                  ),
                );
                onResult?.call(result);
              },
              child: const Text('Open payment'),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('Open payment'));
    await tester.pumpAndSettle();
  }

  Future<void> pick(WidgetTester tester) async {
    await tester.ensureVisible(find.byKey(const Key('choosePaymentProof')));
    await tester.runAsync(() async {
      await tester.tap(find.byKey(const Key('choosePaymentProof')));
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await tester.pumpAndSettle();
  }

  for (final width in [320.0, 390.0, 768.0]) {
    testWidgets('finite preview and submission at ${width.toInt()}px', (
      tester,
    ) async {
      PaymentProofSubmission? submitted;
      await open(tester, width: width, onResult: (value) => submitted = value);
      expect(tester.takeException(), isNull);
      await pick(tester);
      expect(find.byKey(const Key('paymentProofPreview')), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.ensureVisible(find.byKey(const Key('paymentReference')));
      await tester.enterText(
        find.byKey(const Key('paymentReference')),
        'TEST-REFERENCE-123',
      );
      await tester.tap(find.text('SUBMIT PROOF'));
      await tester.pumpAndSettle();
      expect(submitted?.proof?.path, image.path);
      expect(submitted?.reference, 'TEST-REFERENCE-123');
      expect(tester.takeException(), isNull);
    });
  }
  testWidgets('keyboard and large text keep dialog usable', (tester) async {
    await open(tester, scale: 1.6, keyboard: 280);
    await pick(tester);
    expect(find.byKey(const Key('paymentProofPreview')), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('Cancel'));
    await tester.pumpAndSettle();
    expect(find.byType(PaymentProofDialog), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets('reference and proof are required for online payment', (
    tester,
  ) async {
    await open(tester);
    await tester.tap(find.text('SUBMIT PROOF'));
    await tester.pumpAndSettle();
    expect(
      find.text('Enter the transaction reference number.'),
      findsOneWidget,
    );
    await tester.ensureVisible(find.byKey(const Key('paymentReference')));
    await tester.enterText(find.byKey(const Key('paymentReference')), 'REF');
    await tester.tap(find.text('SUBMIT PROOF'));
    await tester.pumpAndSettle();
    expect(find.text('Choose a payment proof image.'), findsOneWidget);
    expect(find.byType(PaymentProofDialog), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('cancel during native picker does not update disposed state', (
    tester,
  ) async {
    final pending = Completer<XFile?>();
    await open(tester, picker: () => pending.future);
    await tester.ensureVisible(find.byKey(const Key('choosePaymentProof')));
    await tester.tap(find.byKey(const Key('choosePaymentProof')));
    await tester.pump();
    await tester.tap(find.text('Cancel'));
    await tester.pumpAndSettle();
    pending.complete(image);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });
  testWidgets('oversized image rejected without layout failure', (
    tester,
  ) async {
    await open(tester, picker: () async => largeImage);
    await pick(tester);
    expect(find.text('Choose an image smaller than 5 MB.'), findsOneWidget);
    expect(find.byKey(const Key('paymentProofPreview')), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets('final payment permits cash without proof or reference', (
    tester,
  ) async {
    PaymentProofSubmission? submitted;
    await open(tester, fee: false, onResult: (value) => submitted = value);
    await tester.tap(find.byType(DropdownButtonFormField<String>));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Cash at Shop').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('choosePaymentProof')), findsNothing);
    await tester.tap(find.text('SELECT CASH'));
    await tester.pumpAndSettle();
    expect(submitted?.method, 'Cash');
    expect(submitted?.proof, isNull);
    expect(submitted?.reference, '');
    expect(tester.takeException(), isNull);
  });
}
