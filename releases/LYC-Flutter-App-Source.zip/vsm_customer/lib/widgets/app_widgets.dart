import 'package:flutter/material.dart';

const primaryColor = Color(0xFF111111);
const accentColor = Color(0xFFD71920);
const appBackground = Color(0xFFF7F7F7);

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const PageHeader(this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4), Text(subtitle, style: TextStyle(color: Colors.grey.shade600)),
    ]),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon; final String title; final String message;
  const EmptyState({required this.icon, required this.title, required this.message, super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 58, color: Colors.blueGrey.shade300), const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6), Text(message, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)),
    ]),
  ));
}

Color statusColor(String status) {
  switch (status.toLowerCase()) {
    case 'paid': case 'completed': return Colors.green;
    case 'pending': case 'awaiting proof': case 'pay at shop': return Colors.orange;
    case 'under review': return Colors.blueGrey;
    case 'rejected': return Colors.red;
    case 'approved': case 'appointment confirmed': return const Color(0xFFD71920);
    case 'in progress': case 'service in progress': return const Color(0xFF7B1FA2);
    case 'vehicle inspection': case 'approval needed': return Colors.deepOrange;
    case 'ready for pickup': return Colors.teal;
    case 'cancelled': return Colors.red;
    default: return Colors.grey;
  }
}

String customerStatus(String status) {
  switch (status) {
    case 'Pending': return 'Request Sent';
    case 'Approved': return 'Appointment Confirmed';
    case 'Diagnosing': return 'Vehicle Inspection';
    case 'Quotation Sent': return 'Approval Needed';
    case 'Quotation Accepted':
    case 'In Progress': return 'Service in Progress';
    case 'Ready for Pickup': return 'Ready for Pickup';
    default: return status;
  }
}

class StatusChip extends StatelessWidget {
  final String status; const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Chip(
    label: Text(status, style: const TextStyle(color: Colors.white, fontSize: 12)),
    backgroundColor: statusColor(status), visualDensity: VisualDensity.compact,
  );
}

String money(dynamic value) {
  final amount = double.tryParse(value?.toString() ?? '') ?? 0;
  return '₱${amount.toStringAsFixed(2)}';
}
