class ApiConfig {
  // Android Studio emulator reaches the host computer through 10.0.2.2.
  // Override for a real phone with:
  // flutter run --dart-define=API_BASE_URL=http://YOUR_PC_IP/Vehicle-Service-System/vehicle-service-management/api
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2/Vehicle-Service-System/vehicle-service-management/api',
  );

  static const String loginUrl = '$baseUrl/auth/login.php';
  static const String registerUrl = '$baseUrl/auth/register.php';
  static const String logoutUrl = '$baseUrl/auth/logout.php';
  static const String forgotPasswordUrl = '$baseUrl/auth/forgot_password.php';

  static const String vehiclesListUrl = '$baseUrl/vehicles/list.php';

  static const String vehicleAddUrl = '$baseUrl/vehicles/add.php';

  static const String vehicleUpdateUrl = '$baseUrl/vehicles/update.php';

  static const String vehicleDeleteUrl = '$baseUrl/vehicles/delete.php';

  static const String servicesListUrl = '$baseUrl/services/list.php';
  static const String dashboardUrl = '$baseUrl/dashboard/summary.php';
  static const String reservationsListUrl = '$baseUrl/reservations/list.php';
  static const String reservationCreateUrl = '$baseUrl/reservations/create.php';
  static const String reservationCancelUrl = '$baseUrl/reservations/cancel.php';
  static const String reservationAvailabilityUrl = '$baseUrl/reservations/availability.php';
  static const String paymentsListUrl = '$baseUrl/payments/list.php';
  static const String receiptUrl = '$baseUrl/payments/receipt.php';
  static const String paymentSubmitUrl = '$baseUrl/payments/submit.php';
  static const String profileUrl = '$baseUrl/profile/get.php';
  static const String profileUpdateUrl = '$baseUrl/profile/update.php';
  static const String passwordUrl = '$baseUrl/profile/password.php';
  static const String notificationsUrl = '$baseUrl/notifications/list.php';
  static const String notificationsReadUrl = '$baseUrl/notifications/read.php';
  static const String quotationViewUrl = '$baseUrl/quotations/view.php';
  static const String quotationRespondUrl = '$baseUrl/quotations/respond.php';
  static const String quotationItemRespondUrl = '$baseUrl/quotations/respond_item.php';
  static const String feedbackSubmitUrl = '$baseUrl/feedback/submit.php';
}
