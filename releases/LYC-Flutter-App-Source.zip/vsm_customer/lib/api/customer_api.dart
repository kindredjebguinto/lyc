import 'api_client.dart';
import 'api_config.dart';

class CustomerApi {
  static Future<Map<String, dynamic>> dashboard() => ApiClient.get(ApiConfig.dashboardUrl);

  static Future<List<Map<String, dynamic>>> reservations({bool completedOnly = false}) async {
    final url = completedOnly ? '${ApiConfig.reservationsListUrl}?completed=1' : ApiConfig.reservationsListUrl;
    final result = await ApiClient.get(url);
    if (result['success'] != true) throw Exception(result['message'] ?? 'Unable to load reservations.');
    return (result['reservations'] as List? ?? []).whereType<Map<String, dynamic>>().toList();
  }

  static Future<Map<String, dynamic>> createReservation({
    required int vehicleId,
    required List<String> serviceTypes,
    required String date,
    required String time,
    required String remarks,
    required bool policyAccepted,
  }) => ApiClient.post(ApiConfig.reservationCreateUrl, {
    'vehicle_id': vehicleId, 'service_types': serviceTypes,
    'appointment_date': date, 'appointment_time': time, 'remarks': remarks,
    'policy_accepted': policyAccepted, 'policy_version': '1.0-2026-10', 'policy_source': 'Android',
  });

  static Future<Map<String, dynamic>> cancelReservation(int reservationId, {String reason = 'Other', String details = 'Cancelled by customer'}) =>
      ApiClient.post(ApiConfig.reservationCancelUrl, {
        'reservation_id': reservationId,
        'reason': reason, 'details': details,
      });

  static Future<Map<String,dynamic>> reservationAvailability(String date,List<String> serviceTypes)=>ApiClient.post(ApiConfig.reservationAvailabilityUrl,{'appointment_date':date,'service_types':serviceTypes});

  static Future<List<Map<String, dynamic>>> notifications() async {
    final result = await ApiClient.get(ApiConfig.notificationsUrl);
    if (result['success'] != true) {
      throw Exception(result['message'] ?? 'Unable to load notifications.');
    }
    return (result['notifications'] as List? ?? [])
        .whereType<Map<String, dynamic>>()
        .toList();
  }

  static Future<void> markNotificationsRead() async {
    await ApiClient.post(ApiConfig.notificationsReadUrl, {});
  }

  static Future<List<Map<String, dynamic>>> payments() async {
    final result = await ApiClient.get(ApiConfig.paymentsListUrl);
    if (result['success'] != true) throw Exception(result['message'] ?? 'Unable to load payments.');
    return (result['payments'] as List? ?? []).whereType<Map<String, dynamic>>().toList();
  }

  static Future<Map<String, dynamic>> submitPayment({required int paymentId, required String method, required String reference, String? filePath}) =>
      ApiClient.multipart(ApiConfig.paymentSubmitUrl, {
        'payment_id': paymentId.toString(), 'payment_method': method, 'reference_number': reference,
      }, fieldName: filePath == null ? null : 'proof', filePath: filePath);

  static Future<Map<String, dynamic>> receipt(int id) async {
    final result = await ApiClient.get('${ApiConfig.receiptUrl}?id=$id');
    if (result['success'] != true) throw Exception(result['message'] ?? 'Unable to load receipt.');
    return Map<String, dynamic>.from(result['receipt'] as Map);
  }

  static Future<Map<String, dynamic>> profile() async {
    final result = await ApiClient.get(ApiConfig.profileUrl);
    if (result['success'] != true) throw Exception(result['message'] ?? 'Unable to load profile.');
    return Map<String, dynamic>.from(result['profile'] as Map);
  }

  static Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) =>
      ApiClient.post(ApiConfig.profileUpdateUrl, data);

  static Future<Map<String, dynamic>> changePassword(Map<String, dynamic> data) =>
      ApiClient.post(ApiConfig.passwordUrl, data);

  static Future<Map<String, dynamic>?> quotation(int reservationId) async {
    final result = await ApiClient.get('${ApiConfig.quotationViewUrl}?reservation_id=$reservationId');
    if (result['success'] != true) throw Exception(result['message'] ?? 'Unable to load quotation.');
    final value = result['quotation'];
    return value is Map ? Map<String, dynamic>.from(value) : null;
  }

  static Future<Map<String, dynamic>> respondQuotation(int reservationId, String status) =>
      ApiClient.post(ApiConfig.quotationRespondUrl, {
        'reservation_id': reservationId,
        'status': status,
      });

  static Future<Map<String, dynamic>> respondQuotationItem(int itemId, String decision) =>
      ApiClient.post(ApiConfig.quotationItemRespondUrl, {
        'item_id': itemId,
        'decision': decision,
      });

  static Future<Map<String,dynamic>> submitFeedback(int reservationId,int rating,String review)=>ApiClient.post(ApiConfig.feedbackSubmitUrl,{'reservation_id':reservationId,'rating':rating,'review':review});
}
