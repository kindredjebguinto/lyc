import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';

class JobQuotationScreen extends StatefulWidget {
  final int reservationId;
  const JobQuotationScreen({required this.reservationId, super.key});

  @override
  State<JobQuotationScreen> createState() => _JobQuotationScreenState();
}

class _JobQuotationScreenState extends State<JobQuotationScreen> {
  Map<String, dynamic>? quotation;
  bool loading = true;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await CustomerApi.quotation(widget.reservationId);
      if (mounted) setState(() { quotation = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString().replaceFirst('Exception: ', ''); loading = false; });
    }
  }

  Future<void> respond(String status) async {
    final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text('$status Quotation?'),
      content: Text(status == 'Accepted' ? 'You confirm that you approve this itemized cost.' : 'The service center will be informed that you rejected this quotation.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(status))],
    ));
    if (confirmed != true) return;
    try {
      final result = await CustomerApi.respondQuotation(widget.reservationId, status);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message']?.toString() ?? 'Quotation updated.')));
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')), backgroundColor: Colors.red));
    }
  }

  Future<void> respondItem(int itemId,String decision) async {
    try { final result=await CustomerApi.respondQuotationItem(itemId,decision); if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result['message']?.toString()??'Item updated.')));await load(); }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ','')),backgroundColor:Colors.red));}
  }

  Future<void> printQuotation() async {
    final q = quotation!;
    final items = (q['items'] as List? ?? []).whereType<Map>().toList();
    final document = pw.Document();
    document.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, build: (_) => [
      pw.Text('JOB QUOTATION', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.Text(q['quotation_number']?.toString() ?? ''), pw.SizedBox(height: 16),
      pw.Text('${q['brand'] ?? ''} ${q['model'] ?? ''} • ${q['plate_number'] ?? ''}'), pw.SizedBox(height: 14),
      pw.TableHelper.fromTextArray(headers: ['Type','Description','Qty','Unit Price','Amount'], data: items.map((raw) { final item=Map<String,dynamic>.from(raw); return [item['item_type'],item['description'],item['quantity'],money(item['unit_price']),money(item['amount'])]; }).toList()),
      pw.SizedBox(height: 18), pw.Align(alignment: pw.Alignment.centerRight, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [pw.Text('Subtotal: ${money(q['subtotal'])}'),pw.Text('Discount: ${money(q['discount'])}'),pw.Text('Tax: ${money(q['tax'])}'),pw.Divider(),pw.Text('TOTAL TO PAY: ${money(q['grand_total'])}', style: pw.TextStyle(fontSize: 18,fontWeight: pw.FontWeight.bold))])),
      if((q['notes']??'').toString().isNotEmpty)...[pw.SizedBox(height:16),pw.Text('Notes: ${q['notes']}')],
    ]));
    await Printing.layoutPdf(onLayout: (_) => document.save(), name: '${q['quotation_number'] ?? 'job-quotation'}.pdf');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Job Quotation')),
    body: RefreshIndicator(onRefresh: load, child: loading
      ? const Center(child: CircularProgressIndicator())
      : error != null ? ListView(children: [EmptyState(icon: Icons.error_outline, title: 'Unable to Load', message: error!)])
      : quotation == null ? ListView(children: const [EmptyState(icon: Icons.request_quote_outlined, title: 'Quotation Not Ready', message: 'The service center has not sent a quotation for this reservation yet.')])
      : _content()),
  );

  Widget _content() {
    final q = quotation!;
    final items = (q['items'] as List? ?? []).whereType<Map>().toList();
    final status = q['status']?.toString() ?? '';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(q['quotation_number']?.toString() ?? 'Job Quotation', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), StatusChip(status)]),
        const SizedBox(height: 8),
        Text('${q['brand'] ?? ''} ${q['model'] ?? ''} • ${q['plate_number'] ?? ''}'),
        if ((q['valid_until']?.toString() ?? '').isNotEmpty) Text('Valid until: ${q['valid_until']}', style: TextStyle(color: Colors.grey.shade600)),
      ]))),
      const SizedBox(height: 12),
      const Text('Quotation Items', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...items.map((raw) { final item = Map<String,dynamic>.from(raw);final additional=item['is_additional']==true;final decision=item['customer_decision']?.toString(); return Card(child: Padding(padding:const EdgeInsets.all(12),child:Column(children:[ListTile(contentPadding:EdgeInsets.zero,
        leading: CircleAvatar(child: Icon(_icon(item['item_type']?.toString()))),title: Text(item['description']?.toString() ?? ''),
        subtitle: Text('${item['item_type']} • ${item['quantity']} × ${money(item['unit_price'])}${additional?'\nAdditional work':''}'),trailing: Text(money(item['amount']), style: const TextStyle(fontWeight: FontWeight.bold))),
        if(additional&&decision=='Pending')Row(children:[Expanded(child:OutlinedButton(onPressed:()=>respondItem(item['id'] as int,'Rejected'),child:const Text('Reject'))),const SizedBox(width:10),Expanded(child:FilledButton(onPressed:()=>respondItem(item['id'] as int,'Accepted'),child:const Text('Accept')))])
        else if(additional)Align(alignment:Alignment.centerRight,child:StatusChip(decision??'Pending'))]))); }),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        _total('Subtotal', q['subtotal']),
        if ((q['discount'] as num? ?? 0) > 0) _total('Discount', -((q['discount'] as num?) ?? 0)),
        if ((q['tax'] as num? ?? 0) > 0) _total('Tax', q['tax']),
        const Divider(height: 24),
        Row(children: [const Expanded(child: Text('TOTAL TO PAY', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), Text(money(q['grand_total']), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: primaryColor))]),
      ]))),
      if ((q['notes']?.toString() ?? '').isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.notes), title: const Text('Notes'), subtitle: Text(q['notes'].toString()))),
      OutlinedButton.icon(onPressed: printQuotation, icon: const Icon(Icons.picture_as_pdf), label: const Text('Print / Save Quotation PDF')),
      if (status == 'Sent') Padding(padding: const EdgeInsets.only(top: 16), child: Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => respond('Rejected'), style: OutlinedButton.styleFrom(foregroundColor: Colors.red), child: const Text('Reject'))),
        const SizedBox(width: 12), Expanded(child: FilledButton(onPressed: () => respond('Accepted'), child: const Text('Accept Quotation'))),
      ])),
      const SizedBox(height: 24),
    ]);
  }

  Widget _total(String label, dynamic value) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Expanded(child: Text(label)), Text(money(value))]));
  IconData _icon(String? type) => switch (type) { 'Part' => Icons.settings, 'Labor' => Icons.engineering, 'Other' => Icons.add_box_outlined, _ => Icons.build_outlined };
}
