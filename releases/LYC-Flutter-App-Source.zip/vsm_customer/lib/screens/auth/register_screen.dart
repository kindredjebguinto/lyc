import 'package:flutter/material.dart';
import '../../api/auth_api.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}
class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final name = TextEditingController(), email = TextEditingController(), phone = TextEditingController(),
      address = TextEditingController(), password = TextEditingController(), confirm = TextEditingController();
  bool loading = false, obscure = true;
  @override void dispose() { for (final c in [name,email,phone,address,password,confirm]) { c.dispose(); } super.dispose(); }
  Future<void> submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => loading = true);
    try {
      final r = await AuthApi.register(fullname: name.text.trim(), email: email.text.trim(), password: password.text, phone: phone.text.trim(), address: address.text.trim());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['message']?.toString() ?? ''), backgroundColor: r['success'] == true ? Colors.green : Colors.red));
      if (r['success'] == true) Navigator.pop(context);
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')), backgroundColor: Colors.red)); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create Account')),
    body: Form(key: _form, child: ListView(padding: const EdgeInsets.all(24), children: [
      const Icon(Icons.directions_car, size: 64, color: Color(0xFFD71920)), const SizedBox(height: 18),
      field(name, 'Full Name', Icons.person_outline, required: true),
      field(email, 'Email', Icons.email_outlined, required: true, emailField: true),
      field(phone, 'Phone Number', Icons.phone_outlined), field(address, 'Address', Icons.home_outlined),
      field(password, 'Password', Icons.lock_outline, required: true, secret: obscure),
      field(confirm, 'Confirm Password', Icons.lock_outline, required: true, secret: obscure),
      CheckboxListTile(contentPadding: EdgeInsets.zero, value: !obscure, onChanged: (v) => setState(() => obscure = !(v ?? false)), title: const Text('Show passwords')),
      const SizedBox(height: 8), SizedBox(height: 50, child: FilledButton(onPressed: loading ? null : submit, child: loading ? const CircularProgressIndicator() : const Text('REGISTER'))),
    ])),
  );
  Widget field(TextEditingController c, String label, IconData icon, {bool required=false, bool emailField=false, bool secret=false}) => Padding(
    padding: const EdgeInsets.only(bottom: 14), child: TextFormField(controller: c, obscureText: secret, keyboardType: emailField ? TextInputType.emailAddress : TextInputType.text,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), border: const OutlineInputBorder()),
      validator: (v) { if (required && (v ?? '').trim().isEmpty) return '$label is required.'; if (emailField && !(v ?? '').contains('@')) return 'Enter a valid email.'; if (c == password && (v ?? '').length < 8) return 'Use at least 8 characters.'; if (c == confirm && v != password.text) return 'Passwords do not match.'; return null; }),
  );
}
