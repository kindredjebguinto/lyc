import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../api/auth_api.dart';
import '../../services/session_service.dart';
import '../../widgets/app_widgets.dart';
import '../auth/login_screen.dart';
import '../payments/payments_screen.dart';
import '../profile/profile_screen.dart';
import '../reservations/reservations_screen.dart';
import '../vehicles/vehicles_screen.dart';
import '../notifications/notifications_screen.dart';
import '../services/service_estimate_screen.dart';
import '../reservations/book_service_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tab = 0;
  String _name = 'Customer';
  String _email = '';
  Map<String, dynamic> _summary = {};
  Map<String, dynamic>? _nextAppointment;
  String? _maintenanceReminder;
  int _unreadNotifications = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final identity = await Future.wait([
      SessionService.getCustomerName(),
      SessionService.getCustomerEmail(),
    ]);

    try {
      final result = await CustomerApi.dashboard();
      if (!mounted) return;
      setState(() {
        _name = identity[0] ?? 'Customer';
        _email = identity[1] ?? '';
        _summary = Map<String, dynamic>.from(result['summary'] ?? {});
        final next = result['next_appointment'];
        _nextAppointment = next is Map
            ? Map<String, dynamic>.from(next)
            : null;
        _maintenanceReminder = result['maintenance_reminder']?.toString();
        _unreadNotifications = int.tryParse((_summary['unread_notifications'] ?? 0).toString()) ?? 0;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _name = identity[0] ?? 'Customer';
        _email = identity[1] ?? '';
        _loading = false;
      });
    }
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    _load();
  }

  Future<void> _logout() async {
    await AuthApi.logout();
    await SessionService.logout();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  void _selectTab(int index) {
    setState(() => _tab = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          _home(),
          const ServiceEstimateScreen(),
          const ReservationsScreen(embedded: true),
          _account(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: _selectTab,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.design_services_outlined), selectedIcon: Icon(Icons.design_services), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }

  Widget _home() {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                const CircleAvatar(
                  radius: 25,
                  backgroundColor: primaryColor,
                  child: Icon(Icons.person, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Hello, $_name', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      Text('How can we help your vehicle?', style: TextStyle(color: Colors.grey.shade600)),
                    ],
                  ),
                ),
                Stack(children: [IconButton(onPressed: () async { await _open(const NotificationsScreen()); _load(); }, icon: const Icon(Icons.notifications_outlined)),if(_unreadNotifications>0)Positioned(right:7,top:7,child:Container(width:10,height:10,decoration:const BoxDecoration(color:Colors.red,shape:BoxShape.circle)))]),
              ],
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () => _open(const BookServiceScreen()),
              icon: const Icon(Icons.add_circle_outline),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 15),
                child: Text('BOOK SERVICE'),
              ),
            ),
            const SizedBox(height: 24),
            const Text('Next Appointment', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _nextAppointmentCard(),
            if (_maintenanceReminder != null) ...[
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFFFFF8E1),
                child: ListTile(
                  leading: const Icon(Icons.notifications_active, color: Colors.orange),
                  title: const Text('Maintenance Reminder', style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(_maintenanceReminder!),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => setState(() => _tab = 1),
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text('Overview', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (_loading)
              const LinearProgressIndicator()
            else
              Row(
                children: [
                  Expanded(child: _stat('Vehicles', _summary['total_vehicles'] ?? 0, Icons.directions_car, accentColor, () => _open(const VehiclesScreen()))),
                  const SizedBox(width: 10),
                  Expanded(child: _stat('Bookings', _summary['total_reservations'] ?? 0, Icons.event, Colors.green, () => setState(() => _tab=2))),
                  const SizedBox(width: 10),
                  Expanded(child: _stat('Pending', _summary['pending_reservations'] ?? 0, Icons.schedule, Colors.orange, () => setState(() => _tab=2))),
                ],
              ),
            const SizedBox(height: 24),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              leading: const CircleAvatar(child: Icon(Icons.track_changes)),
              title: const Text('Track Service', style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: const Text('Check approval and repair progress'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => setState(() => _tab = 2),
            ),
          ],
        ),
      ),
    );
  }

  Widget _nextAppointmentCard() {
    final item = _nextAppointment;
    if (item == null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(Icons.event_available, size: 42, color: Colors.grey.shade400),
              const SizedBox(height: 8),
              const Text('No upcoming appointment'),
            ],
          ),
        ),
      );
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text('${item['brand']} ${item['model']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                StatusChip(customerStatus(item['status']?.toString() ?? '')),
              ],
            ),
            Text(item['plate_number']?.toString() ?? '', style: TextStyle(color: Colors.grey.shade600)),
            const Divider(height: 24),
            Text(item['service_type']?.toString() ?? ''),
            const SizedBox(height: 6),
            Text('${item['appointment_date']} • ${item['appointment_time']}', style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _account() {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Account', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: const CircleAvatar(radius: 28, child: Icon(Icons.person)),
              title: Text(_name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(_email),
            ),
          ),
          const SizedBox(height: 16),
          _accountItem(Icons.directions_car, 'My Vehicles', 'Manage registered vehicles', const VehiclesScreen()),
          _accountItem(Icons.notifications, 'Notifications', 'Booking and service updates', const NotificationsScreen()),
          _accountItem(Icons.history, 'Service History', 'View completed services', const ReservationsScreen(historyOnly: true)),
          _accountItem(Icons.payments, 'Payments & Receipts', 'Review payment records', const PaymentsScreen()),
          _accountItem(Icons.manage_accounts, 'Profile & Password', 'Update account details', const ProfileScreen()),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: _logout, icon: const Icon(Icons.logout), label: const Text('LOG OUT')),
        ],
      ),
    );
  }

  Widget _accountItem(IconData icon, String title, String subtitle, Widget page) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(icon, color: primaryColor),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _open(page),
      ),
    );
  }

  Widget _stat(String title, dynamic value, IconData icon, Color color, VoidCallback onTap) {
    return Card(child: InkWell(borderRadius:BorderRadius.circular(12),onTap:onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 6),
            Text('$value', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(title, style: const TextStyle(fontSize: 12)),
          ],
        ),
      )),
    );
  }
}
