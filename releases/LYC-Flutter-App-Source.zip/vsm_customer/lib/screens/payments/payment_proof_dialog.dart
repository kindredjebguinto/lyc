import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class PaymentProofSubmission {
  final String method;
  final String reference;
  final XFile? proof;

  const PaymentProofSubmission({
    required this.method,
    required this.reference,
    this.proof,
  });
}

class PaymentProofDialog extends StatefulWidget {
  final bool isReservationFee;
  // Allows the native picker to be replaced in focused widget tests.
  final Future<XFile?> Function()? pickImage;

  const PaymentProofDialog({
    required this.isReservationFee,
    this.pickImage,
    super.key,
  });

  @override
  State<PaymentProofDialog> createState() => _PaymentProofDialogState();
}

class _PaymentProofDialogState extends State<PaymentProofDialog> {
  final _reference = TextEditingController();
  String _method = 'GCash';
  XFile? _proof;
  String? _validationMessage;
  bool _picking = false;

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _chooseImage() async {
    setState(() => _picking = true);
    try {
      final picked =
          await (widget.pickImage?.call() ??
              ImagePicker().pickImage(
                source: ImageSource.gallery,
                imageQuality: 85,
              ));
      if (!mounted || picked == null) return;
      final extension = picked.name.split('.').last.toLowerCase();
      if (!['jpg', 'jpeg', 'png', 'webp'].contains(extension)) {
        setState(() => _validationMessage = 'Choose a JPG, PNG or WEBP image.');
        return;
      }
      if (await picked.length() > 5 * 1024 * 1024) {
        if (mounted) {
          setState(
            () => _validationMessage = 'Choose an image smaller than 5 MB.',
          );
        }
        return;
      }
      if (!mounted) return;
      setState(() {
        _proof = picked;
        _validationMessage = null;
      });
    } catch (_) {
      if (mounted) {
        setState(
          () => _validationMessage =
              'Unable to open this image. Please choose it again.',
        );
      }
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  void _submit() {
    final isCash = _method == 'Cash';
    if (!isCash && _reference.text.trim().isEmpty) {
      setState(
        () => _validationMessage = 'Enter the transaction reference number.',
      );
      return;
    }
    if (!isCash && _proof == null) {
      setState(() => _validationMessage = 'Choose a payment proof image.');
      return;
    }
    Navigator.of(context).pop(
      PaymentProofSubmission(
        method: _method,
        reference: isCash ? '' : _reference.text.trim(),
        proof: isCash ? null : _proof,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isCash = _method == 'Cash';
    final methods = [
      'GCash',
      'Maya',
      'Bank Transfer',
      'Card',
      if (!widget.isReservationFee) 'Cash',
    ];
    return AlertDialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      title: const Text('Payment Method'),
      // AlertDialog asks its content for an intrinsic width. Bound that width
      // before measuring full-width buttons and the proof image; the outer
      // dialog still shrinks to fit narrow screens and keyboard insets.
      content: SizedBox(
        width: 360,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _method,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Choose method',
                  border: OutlineInputBorder(),
                ),
                items: methods
                    .map(
                      (value) => DropdownMenuItem(
                        value: value,
                        child: Text(value == 'Cash' ? 'Cash at Shop' : value),
                      ),
                    )
                    .toList(),
                onChanged: _picking
                    ? null
                    : (value) => setState(() {
                        _method = value ?? _method;
                        _validationMessage = null;
                      }),
              ),
              const SizedBox(height: 14),
              if (widget.isReservationFee)
                const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text(
                    'The ₱200 reservation fee must be paid online. Cash at Shop is not available for app reservations.',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ),
              if (isCash)
                const Card(
                  color: Color(0xFFFFF7E0),
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Pay the exact amount at the service counter. No proof image or transaction reference is required.',
                    ),
                  ),
                )
              else ...[
                if (_method == 'GCash') ...[
                  Center(
                    child: Column(
                      children: [
                        Container(
                          color: Colors.white,
                          padding: const EdgeInsets.all(10),
                          child: CustomPaint(
                            size: const Size(150, 150),
                            painter: _DemoQrPainter(),
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'DEMO GCASH QR — replace with the shop’s official QR',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                ],
                TextField(
                  key: const Key('paymentReference'),
                  controller: _reference,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    labelText: 'Transaction Reference Number',
                    hintText: 'Required',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                if (_proof != null) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(
                      File(_proof!.path),
                      key: const Key('paymentProofPreview'),
                      height: 150,
                      width: double.infinity,
                      fit: BoxFit.contain,
                      cacheWidth: 1024,
                      errorBuilder: (_, _, _) => const SizedBox(
                        height: 150,
                        child: Center(
                          child: Text(
                            'Preview unavailable. Choose another image if this file cannot be opened.',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    key: const Key('choosePaymentProof'),
                    onPressed: _picking ? null : _chooseImage,
                    icon: const Icon(Icons.image_outlined),
                    label: Text(
                      _picking
                          ? 'Opening gallery…'
                          : _proof == null
                          ? 'Choose Proof Image'
                          : 'Change Proof Image',
                    ),
                  ),
                ),
                const Text(
                  'JPG, PNG or WEBP • maximum 5 MB',
                  style: TextStyle(fontSize: 12),
                ),
              ],
              if (_validationMessage != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    _validationMessage!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _picking ? null : _submit,
          child: Text(isCash ? 'SELECT CASH' : 'SUBMIT PROOF'),
        ),
      ],
    );
  }
}

class _DemoQrPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black;
    const grid = 21.0;
    final cell = size.width / grid;
    bool dark(int x, int y) {
      if ((x < 7 && y < 7) || (x > 13 && y < 7) || (x < 7 && y > 13)) {
        final lx = x < 7 ? x : x - 14, ly = y < 7 ? y : y - 14;
        return lx == 0 ||
            lx == 6 ||
            ly == 0 ||
            ly == 6 ||
            (lx >= 2 && lx <= 4 && ly >= 2 && ly <= 4);
      }
      return ((x * 3 + y * 5 + x * y) % 7) < 3;
    }

    for (var y = 0; y < 21; y++) {
      for (var x = 0; x < 21; x++) {
        if (dark(x, y)) {
          canvas.drawRect(
            Rect.fromLTWH(x * cell, y * cell, cell + .3, cell + .3),
            paint,
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
