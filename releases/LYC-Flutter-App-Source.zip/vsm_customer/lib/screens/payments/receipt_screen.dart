import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';

class ReceiptScreen extends StatelessWidget {
  final int paymentId;
  const ReceiptScreen({required this.paymentId, super.key});

  Future<void> _share(Map<String, dynamic> receipt) async {
    final document = pw.Document();
    document.addPage(pw.Page(pageFormat: PdfPageFormat.a4, build: (_) => pw.Padding(
      padding: const pw.EdgeInsets.all(24),
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Center(child: pw.Text('VEHICLE SERVICE MANAGEMENT', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold))),
        pw.Center(child: pw.Text('Official Payment Receipt')),
        pw.SizedBox(height: 24),
        pw.Text('Receipt No.: #$paymentId'),
        pw.Text('Booking: ${receipt['reservation_reference'] ?? '#${receipt['reservation_id'] ?? ''}'}'),
        pw.Text('Customer: ${receipt['fullname'] ?? ''}'),
        pw.Text('Email: ${receipt['email'] ?? ''}'),
        pw.Divider(),
        pw.Text('Vehicle: ${receipt['brand'] ?? ''} ${receipt['model'] ?? ''}'),
        pw.Text('Plate Number: ${receipt['plate_number'] ?? ''}'),
        pw.Text('Services: ${receipt['service_type'] ?? ''}'),
        pw.Text('Appointment: ${receipt['appointment_date'] ?? ''} ${receipt['appointment_time'] ?? ''}'),
        pw.Divider(),
        pw.Text('Payment Method: ${receipt['payment_method'] ?? ''}'),
        pw.Text('${receipt['payment_method'] == 'Cash' ? 'Official Receipt' : 'Transaction Reference'}: ${(receipt['reference_number'] ?? '').toString().isEmpty ? 'N/A' : receipt['reference_number']}'),
        if (receipt['subtotal'] != null) pw.Text('Quotation Subtotal: PHP ${receipt['subtotal']}'),
        if ((double.tryParse(receipt['discount']?.toString() ?? '') ?? 0) > 0) pw.Text('Discount: PHP ${receipt['discount']}'),
        if ((double.tryParse(receipt['tax']?.toString() ?? '') ?? 0) > 0) pw.Text('Tax: PHP ${receipt['tax']}'),
        pw.Text('Amount Paid: PHP ${receipt['amount'] ?? '0.00'}', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
      ]),
    )));
    await Printing.sharePdf(bytes: await document.save(), filename: 'receipt-$paymentId.pdf');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Receipt #$paymentId')),
    body: FutureBuilder<Map<String, dynamic>>(
      future: CustomerApi.receipt(paymentId),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError || snapshot.data == null) return EmptyState(icon: Icons.error_outline, title: 'Unable to Load Receipt', message: snapshot.error?.toString() ?? 'Receipt was not found.');
        final receipt = snapshot.data!;
        return ListView(padding: const EdgeInsets.all(20), children: [
          Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
            const Icon(Icons.verified, color: Colors.green, size: 52),
            const Text('Luck Yuna Car Center', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            const Text('Official Payment Receipt'), const Divider(height: 32),
            _info('Receipt No.', '#$paymentId'), _info('Booking', receipt['reservation_reference'] ?? '#${receipt['reservation_id'] ?? ''}'), _info('Payment Date', receipt['paid_at'] ?? ''),
            const Divider(), _info('Customer', receipt['fullname'] ?? ''), _info('Email', receipt['email'] ?? ''),
            const Divider(), _info('Vehicle', '${receipt['brand']} ${receipt['model']}'), _info('Plate', receipt['plate_number'] ?? ''),
            const Divider(), _info('Services', receipt['service_type'] ?? ''), _info('Appointment', '${receipt['appointment_date']} ${receipt['appointment_time']}'),
            const Divider(), _info('Method', receipt['payment_method'] ?? ''), _info(receipt['payment_method'] == 'Cash' ? 'Official Receipt' : 'Transaction Reference', (receipt['reference_number'] ?? '').toString().isEmpty ? 'N/A' : receipt['reference_number']),
            const SizedBox(height: 12), Text(money(receipt['amount']), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.green)),
          ]))),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: () => _share(receipt), icon: const Icon(Icons.picture_as_pdf), label: const Text('SAVE OR SHARE PDF')),
        ]);
      },
    ),
  );

  Widget _info(String label, dynamic value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 120, child: Text(label, style: const TextStyle(color: Colors.grey))),
      Expanded(child: Text(value.toString(), style: const TextStyle(fontWeight: FontWeight.w500))),
    ]),
  );
}
