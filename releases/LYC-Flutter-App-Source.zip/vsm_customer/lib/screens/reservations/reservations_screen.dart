import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import '../services/service_estimate_screen.dart';
import 'reservation_details_screen.dart';

class ReservationsScreen extends StatefulWidget {
  final bool historyOnly;
  final bool embedded;

  const ReservationsScreen({this.historyOnly = false, this.embedded = false, super.key});

  @override
  State<ReservationsScreen> createState() => _ReservationsScreenState();
}

class _ReservationsScreenState extends State<ReservationsScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final items = await CustomerApi.reservations(
        completedOnly: widget.historyOnly,
      );
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  Future<void> _bookService() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ServiceEstimateScreen()),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final content = RefreshIndicator(onRefresh: _load, child: _buildBody());
    if (widget.embedded) {
      return SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 18, 12, 8), child: Row(children: [const Expanded(child: Text('My Bookings', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold))), IconButton(tooltip:'Browse services',onPressed:_bookService,icon:const Icon(Icons.add)),IconButton(onPressed: _load, icon: const Icon(Icons.refresh))])),
        Expanded(child: content),
      ]));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.historyOnly ? 'Service History' : 'My Reservations',
        ),
      ),
      floatingActionButton: widget.historyOnly
          ? null
          : FloatingActionButton.extended(
              onPressed: _bookService,
              icon: const Icon(Icons.add),
              label: const Text('Book Service'),
            ),
      body: content,
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return ListView(
        children: [
          EmptyState(
            icon: Icons.error_outline,
            title: 'Unable to Load',
            message: _error!,
          ),
        ],
      );
    }

    if (_items.isEmpty) {
      return ListView(
        children: [
          EmptyState(
            icon: widget.historyOnly ? Icons.history : Icons.event_busy,
            title: widget.historyOnly
                ? 'No Completed Services'
                : 'No Reservations',
            message: widget.historyOnly
                ? 'Completed services will appear here.'
                : 'Your appointments will appear here.',
          ),
        ],
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _items.length,
      itemBuilder: (context, index) => _reservationCard(_items[index]),
    );
  }

  Widget _reservationCard(Map<String, dynamic> reservation) {
    final brand = reservation['brand'] ?? '';
    final model = reservation['model'] ?? '';
    final status = reservation['status']?.toString() ?? '';
    final date = reservation['appointment_date'] ?? '';
    final time = reservation['appointment_time'] ?? '';
    final mechanic = reservation['mechanic_name']?.toString() ?? '';
    final paymentStatus = reservation['payment_status']?.toString();
    final paymentAmount = reservation['payment_amount'];
    final remarks = reservation['remarks']?.toString() ?? '';
    final diagnosis = reservation['diagnosis']?.toString() ?? '';
    final workPerformed = reservation['work_performed']?.toString() ?? '';
    final nextService = reservation['next_service_date']?.toString() ?? '';

    final mechanicText = mechanic.isEmpty
        ? 'Not assigned'
        : mechanic;
    final paymentText = paymentStatus == null
        ? 'No Payment'
        : paymentAmount == null
            ? paymentStatus
            : '$paymentStatus • ${money(paymentAmount)}';

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '$brand $model',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                StatusChip(customerStatus(status)),
              ],
            ),
            Text(
              reservation['plate_number']?.toString() ?? '',
              style: TextStyle(color: Colors.grey.shade600),
            ),
            const Divider(height: 24),
            Text(
              reservation['service_type']?.toString() ?? '',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            _detail(Icons.calendar_today, '$date • $time'),
            if ((reservation['original_appointment_at'] ?? '').toString().isNotEmpty)
              _detail(Icons.history, 'Original booking: ${reservation['original_appointment_at']}'),
            if ((reservation['expected_finish_at'] ?? '').toString().isNotEmpty)
              _detail(Icons.update, 'Expected finish: ${reservation['expected_finish_at']} (Manila time)'),
            _detail(Icons.engineering, mechanicText),
            if (!widget.historyOnly && status != 'Cancelled') ...[
              const SizedBox(height: 16),
              _progress(status),
            ],
            if (!widget.historyOnly)
              _detail(Icons.payments_outlined, paymentText),
            if (remarks.isNotEmpty) _detail(Icons.notes, remarks),
            if (widget.historyOnly && diagnosis.isNotEmpty) _detail(Icons.search, 'Diagnosis: $diagnosis'),
            if (widget.historyOnly && workPerformed.isNotEmpty) _detail(Icons.build_circle_outlined, 'Work performed: $workPerformed'),
            if (widget.historyOnly && reservation['intake_mileage'] != null) _detail(Icons.speed, 'Mileage: ${reservation['intake_mileage']} km'),
            if (widget.historyOnly && nextService.isNotEmpty) _detail(Icons.event_repeat, 'Next recommended service: $nextService'),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: FilledButton.tonalIcon(onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ReservationDetailsScreen(reservation: reservation))); _load(); }, icon: const Icon(Icons.arrow_forward), label: const Text('Open Booking'))),
            if (!widget.historyOnly &&
                (status == 'Pending' || status == 'Approved')) ...[
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () => _cancel(reservation['id'] as int),
                  icon: const Icon(Icons.cancel_outlined),
                  label: const Text('Cancel Appointment'),
                  style: TextButton.styleFrom(foregroundColor: Colors.red),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _detail(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: Colors.blueGrey),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }

  Widget _progress(String status) {
    const stages = ['Sent', 'Confirmed', 'Inspection', 'In Service', 'Ready'];
    final current = switch (status) {
      'Pending' => 0,
      'Approved' => 1,
      'Diagnosing' || 'Quotation Sent' => 2,
      'Quotation Accepted' || 'In Progress' => 3,
      'Ready for Pickup' || 'Completed' => 4,
      _ => -1,
    };
    return Row(
      children: List.generate(stages.length, (index) {
        final active = current >= index;
        return Expanded(
          child: Column(
            children: [
              Row(
                children: [
                  if (index > 0)
                    Expanded(
                      child: Divider(
                        color: active ? primaryColor : Colors.grey.shade300,
                        thickness: 2,
                      ),
                    ),
                  CircleAvatar(
                    radius: 10,
                    backgroundColor:
                        active ? primaryColor : Colors.grey.shade300,
                    child: active
                        ? const Icon(Icons.check, size: 12, color: Colors.white)
                        : null,
                  ),
                  if (index < stages.length - 1)
                    Expanded(
                      child: Divider(
                        color: current > index
                            ? primaryColor
                            : Colors.grey.shade300,
                        thickness: 2,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                stages[index],
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: active ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Future<void> _cancel(int reservationId) async {
    const reasons=['Service no longer needed','Change of mind','Schedule conflict','Price concern','Found another service provider','Vehicle unavailable','Emergency / unexpected situation','Other'];
    String? reason;final details=TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder:(context,setDialogState)=>AlertDialog(
        title: const Text('Cancel Appointment'),
        content: SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Select a reason'),...reasons.map((value)=>RadioListTile<String>(contentPadding:EdgeInsets.zero,dense:true,value:value,groupValue:reason,onChanged:(selected)=>setDialogState(()=>reason=selected))),if(reason=='Other')TextField(controller:details,maxLines:2,decoration:const InputDecoration(labelText:'Please specify',border:OutlineInputBorder())),const SizedBox(height:10),const Text('Refund eligibility',style:TextStyle(fontWeight:FontWeight.bold)),const Text('A verified ₱200 reservation fee will be submitted for a full refund when you or the service center cancels before inspection begins.')])) ,
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Keep Booking')),
          FilledButton(
            onPressed: reason==null||(reason=='Other'&&details.text.trim().isEmpty)?null:() => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Cancel Appointment'),
          ),
        ],
      )),
    );
    if (confirmed != true){details.dispose();return;}
    try {
      final result = await CustomerApi.cancelReservation(reservationId,reason:reason!,details:reason=='Other'?details.text.trim():'');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message']?.toString() ?? 'Appointment cancelled.')));
      _load();
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString().replaceFirst('Exception: ', '')), backgroundColor: Colors.red));
    } finally { details.dispose(); }
  }
}
