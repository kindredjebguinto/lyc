import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import '../payments/booking_payment_screen.dart';
import '../quotations/job_quotation_screen.dart';

class ReservationDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> reservation;
  const ReservationDetailsScreen({required this.reservation, super.key});

  @override
  State<ReservationDetailsScreen> createState() => _ReservationDetailsScreenState();
}

class _ReservationDetailsScreenState extends State<ReservationDetailsScreen> {
  late Map<String, dynamic> item;
  Map<String, dynamic>? quotation;
  bool loadingQuote = true;

  int get id => int.parse(item['id'].toString());
  String get status => item['status']?.toString() ?? '';

  @override
  void initState() { super.initState(); item = Map<String, dynamic>.from(widget.reservation); _loadQuotation(); }

  Future<void> _loadQuotation() async {
    try { final result = await CustomerApi.quotation(id); if (mounted) setState(() { quotation=result; if(result?['status']=='Accepted'){item['status']='Quotation Accepted';item['payment_status']??='Awaiting Proof';item['payment_amount']??=result?['grand_total'];} loadingQuote=false; }); }
    catch (_) { if (mounted) setState(() => loadingQuote=false); }
  }

  Future<void> _cancel() async {
    const reasons=['Service no longer needed','Change of mind','Schedule conflict','Price concern','Found another service provider','Vehicle unavailable','Emergency / unexpected situation','Other'];String? reason;final details=TextEditingController();
    final confirmed=await showDialog<bool>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(context,setDialogState)=>AlertDialog(title:const Text('Cancel Appointment'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Select a reason'),...reasons.map((value)=>RadioListTile<String>(dense:true,contentPadding:EdgeInsets.zero,value:value,groupValue:reason,onChanged:(selected)=>setDialogState(()=>reason=selected))),if(reason=='Other')TextField(controller:details,maxLines:2,decoration:const InputDecoration(labelText:'Please specify',border:OutlineInputBorder())),const SizedBox(height:10),const Text('Refund eligibility',style:TextStyle(fontWeight:FontWeight.bold)),const Text('A verified ₱200 fee will be requested for a full refund if cancellation happens before inspection.')])) ,actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('Keep Booking')),FilledButton(onPressed:reason==null||(reason=='Other'&&details.text.trim().isEmpty)?null:()=>Navigator.pop(dialogContext,true),style:FilledButton.styleFrom(backgroundColor:Colors.red),child:const Text('Confirm Cancellation'))])));
    if(confirmed!=true){details.dispose();return;}
    final result=await CustomerApi.cancelReservation(id,reason:reason!,details:reason=='Other'?details.text.trim():'');details.dispose();if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${result['message']??'Appointment cancelled.'}\n${result['refund_eligibility']??''}')));setState(()=>item['status']='Cancelled');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Booking Details')),
    body: RefreshIndicator(onRefresh: _loadQuotation, child: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children:[Expanded(child:Text('${item['brand']??''} ${item['model']??''}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold))),StatusChip(customerStatus(status))]),
        Text(item['plate_number']?.toString()??'',style:TextStyle(color:Colors.grey.shade600)),const SizedBox(height:12),
        _row(Icons.calendar_today,'${item['appointment_date']??''} • ${item['appointment_time']??''}'),
        _row(Icons.build_outlined,item['service_type']?.toString()??''),
        if((item['mechanic_name']??'').toString().isNotEmpty)_row(Icons.engineering,'Mechanic: ${item['mechanic_name']}'),
      ]))),
      const SizedBox(height:12),_nextAction(),
      const SizedBox(height:12),
      _section('₱200 Reservation Fee',Icons.verified_outlined,item['reservation_fee_status']?.toString()??'Awaiting Payment',item['reservation_fee_payment_id']==null?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>BookingPaymentScreen(paymentId:int.parse(item['reservation_fee_payment_id'].toString()))))),
      _section('Final Job Quotation', Icons.request_quote_outlined, loadingQuote?'Checking quotation…':quotation==null?'Not issued yet':'${money(quotation!['grand_total'])} • ${quotation!['status']}', quotation==null?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>JobQuotationScreen(reservationId:id))).then((_)=>_loadQuotation())),
      _section('Payment & Receipt', Icons.payments_outlined, item['payment_status']==null?'Available after quotation acceptance':'${money(item['payment_amount'])} • ${item['payment_status']}', item['payment_id']==null?null:()=>_openPayment()),
      if((item['diagnosis']??'').toString().isNotEmpty|| (item['work_performed']??'').toString().isNotEmpty) Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Service Report',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),if((item['diagnosis']??'').toString().isNotEmpty)_info('Diagnosis',item['diagnosis'].toString()),if((item['work_performed']??'').toString().isNotEmpty)_info('Work performed',item['work_performed'].toString()),if(item['intake_mileage']!=null)_info('Mileage','${item['intake_mileage']} km'),if((item['next_service_date']??'').toString().isNotEmpty)_info('Next service',item['next_service_date'].toString())]))),
      if(status=='Pending'||status=='Approved')TextButton.icon(onPressed:_cancel,icon:const Icon(Icons.cancel_outlined),label:const Text('Cancel Appointment'),style:TextButton.styleFrom(foregroundColor:Colors.red)),
      if(status=='Completed')FilledButton.icon(onPressed:_feedback,icon:const Icon(Icons.star_outline),label:const Text('RATE THIS SERVICE')),
      const SizedBox(height:24),
    ])),
  );

  Widget _nextAction() {
    String title='No action required';String message='We will notify you when there is an update.';IconData icon=Icons.schedule;
    VoidCallback? action;String? label;
    if(status=='Quotation Sent'&&quotation?['status']=='Rejected'){title='Quotation revision requested';message='The service center will send an updated quotation.';icon=Icons.edit_note;}
    else if(status=='Quotation Sent'){title='Your approval is needed';message='Review the final quotation before the service begins.';icon=Icons.priority_high;label='Review Quotation';action=()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>JobQuotationScreen(reservationId:id))).then((_)=>_loadQuotation());}
    else if(status=='Quotation Accepted'&&(item['payment_status']=='Awaiting Proof'||item['payment_status']=='Rejected')){title='Submit your payment';message='Pay only for this booking and upload its proof.';icon=Icons.upload_file;label='Pay This Booking';action=_openPayment;}
    else if(item['payment_status']=='Pay at Shop'){title='Pay cash at the shop';message='No proof is required. Staff will issue your receipt after confirming the cash payment.';icon=Icons.storefront;label='View Payment';action=_openPayment;}
    else if(item['payment_status']=='Under Review'){title='Payment under review';message='The service center is checking your submitted proof.';icon=Icons.hourglass_top;}
    else if(status=='Ready for Pickup'){title='Your vehicle is ready';message='Please coordinate with the service center for pickup.';icon=Icons.directions_car;}
    else if(status=='Completed'){title='Service completed';message='Your service report and receipt are available below.';icon=Icons.check_circle;}
    return Card(color:const Color(0xFFFFF1F2),child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,color:primaryColor),const SizedBox(width:10),Expanded(child:Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)))]),const SizedBox(height:6),Text(message),if(action!=null)...[const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton(onPressed:action,child:Text(label!)))]])));
  }

  Future<void> _openPayment() async {
    final paymentId = int.tryParse(item['payment_id']?.toString() ?? '');
    if (paymentId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('The payment record is not ready yet. Please refresh this booking.')));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => BookingPaymentScreen(paymentId: paymentId)));
  }

  Future<void> _feedback() async {int rating=5;final review=TextEditingController();final send=await showDialog<bool>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(context,setDialogState)=>AlertDialog(title:const Text('Rate your service'),content:Column(mainAxisSize:MainAxisSize.min,children:[Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(5,(i)=>IconButton(onPressed:()=>setDialogState(()=>rating=i+1),icon:Icon(i<rating?Icons.star:Icons.star_border,color:Colors.amber))),),TextField(controller:review,maxLines:3,decoration:const InputDecoration(labelText:'Review (optional)',border:OutlineInputBorder()))]),actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),child:const Text('Submit'))])));if(send==true){final result=await CustomerApi.submitFeedback(id,rating,review.text.trim());if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result['message']?.toString()??'Thank you.')));}review.dispose();}

  Widget _section(String title,IconData icon,String subtitle,VoidCallback? onTap)=>Card(child:ListTile(contentPadding:const EdgeInsets.all(16),leading:CircleAvatar(child:Icon(icon)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(subtitle),trailing:onTap==null?null:const Icon(Icons.chevron_right),onTap:onTap));
  Widget _row(IconData icon,String value)=>Padding(padding:const EdgeInsets.only(top:8),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,size:18,color:Colors.blueGrey),const SizedBox(width:8),Expanded(child:Text(value))]));
  Widget _info(String label,String value)=>Padding(padding:const EdgeInsets.only(top:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:TextStyle(fontSize:12,color:Colors.grey.shade600)),Text(value)]));
}
