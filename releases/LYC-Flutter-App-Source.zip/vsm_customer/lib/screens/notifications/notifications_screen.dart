import 'package:flutter/material.dart';
import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import '../reservations/reservation_details_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try {
      final items = await CustomerApi.notifications();
      await CustomerApi.markNotificationsRead();
      if (mounted) setState(() { _items = items; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notifications')),
    body: _loading ? const Center(child: CircularProgressIndicator()) :
      _items.isEmpty ? const EmptyState(icon: Icons.notifications_none, title: 'No Notifications', message: 'Booking and service updates will appear here.') :
      RefreshIndicator(onRefresh: _load, child: ListView.separated(
        padding: const EdgeInsets.all(16), itemCount: _items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, index) { final item = _items[index]; return Card(child: ListTile(
          leading: CircleAvatar(backgroundColor: item['is_read'] == true ? Colors.grey.shade200 : Colors.blue.shade100, child: const Icon(Icons.notifications)),
          title: Text(item['title']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${item['message'] ?? ''}\n${item['created_at'] ?? ''}'), isThreeLine: true,
          trailing: item['link_type']=='reservation' ? const Icon(Icons.chevron_right) : null,
          onTap: () async { final id=int.tryParse(item['link_id']?.toString()??''); if(item['link_type']=='reservation'&&id!=null){final reservations=await CustomerApi.reservations();Map<String,dynamic>? match;for(final reservation in reservations){if(reservation['id']==id){match=reservation;break;}}if(match!=null&&context.mounted)Navigator.push(context,MaterialPageRoute(builder:(_)=>ReservationDetailsScreen(reservation:match!)));}},
        )); },
      )),
  );
}
