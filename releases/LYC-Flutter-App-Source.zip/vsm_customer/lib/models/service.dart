class Service {
  final int id;
  final String serviceName;
  final String category;
  final String description;
  final double price;
  final int? estimatedDuration;
  final String status;

  const Service({
    required this.id,
    required this.serviceName,
    required this.category,
    required this.description,
    required this.price,
    this.estimatedDuration,
    required this.status,
  });

  factory Service.fromJson(Map<String, dynamic> json) {
    return Service(
      id: int.parse(json['id'].toString()),
      serviceName: json['service_name']?.toString() ?? '',
      category: json['category']?.toString() ?? _categoryFor(json['service_name']?.toString() ?? ''),
      description: json['description']?.toString() ?? '',
      price: double.tryParse(json['price'].toString()) ?? 0,
      estimatedDuration: json['estimated_duration'] == null
          ? null
          : int.tryParse(json['estimated_duration'].toString()),
      status: json['status']?.toString() ?? '',
    );
  }

  static String _categoryFor(String serviceName) {
    final name = serviceName.toLowerCase();
    if (name.contains('pms') || name.contains('maintenance')) return 'PMS Packages';
    if (name.contains('oil') || name.contains('periodic')) return 'Oil & Periodic';
    if (name.contains('air conditioning') || name.contains('ac ')) return 'Air Conditioning';
    if (name.contains('brake')) return 'Brakes';
    if (name.contains('tire')) return 'Tires';
    if (name.contains('engine')) return 'Engine';
    if (name.contains('battery')) return 'Battery';
    return 'Other';
  }
}
