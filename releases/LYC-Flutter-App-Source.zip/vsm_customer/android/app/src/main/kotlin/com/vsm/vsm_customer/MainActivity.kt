package com.vsm.vsm_customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
