import json,urllib.request,urllib.error,subprocess,os,hashlib,uuid
from pathlib import Path
root=Path('/workspace/work/manual-gcash');fixture=json.loads((root/'backend-fixture.json').read_text());ids=fixture['payment_ids'];checks=[]
base='http://127.0.0.1:8094/Vehicle-Service-System/vehicle-service-management/api/'
php='/workspace/work/runtime/root/usr/bin/php8.4';env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/runtime/root/usr/lib/x86_64-linux-gnu'
def check(n,b):
 checks.append({'name':n,'passed':bool(b)})
 if not b:raise AssertionError(n)
def sql(s,read=False):
 code="$c=new mysqli('localhost','root','','manual_wallet_test',0,'/workspace/work/db/mysql.sock');$r=$c->query("+json.dumps(s)+");"+("echo json_encode($r->fetch_assoc());" if read else '')
 r=subprocess.run([php,'-c','/workspace/work/php.ini','-r',code],capture_output=True,text=True,env=env)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 return json.loads(r.stdout) if read else None
def request(path,body=None,auth=True,content='application/json'):
 headers={'Content-Type':content}
 if auth:headers['Authorization']='Bearer manual-api-test-token'
 try:r=urllib.request.urlopen(urllib.request.Request(base+path,data=body,headers=headers),timeout=10)
 except urllib.error.HTTPError as e:r=e
 raw=r.read().decode()
 try:data=json.loads(raw)
 except Exception:raise RuntimeError(str(r.status)+': '+raw[:1000])
 return r.status,data
def submit(pid,method,ref,extra=None,image=None,filename='receipt.png',auth=True):
 boundary='----WalletTest'+uuid.uuid4().hex
 fields={'payment_id':str(pid),'payment_method':method,'reference_number':ref};fields.update(extra or {})
 body=b''
 for k,v in fields.items():body+=('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+str(v)+'\r\n').encode()
 if image is not False:
  raw=(root/'test-private/test-image.png').read_bytes() if image is None else image
  body+=('--'+boundary+'\r\nContent-Disposition: form-data; name="proof"; filename="'+filename+'"\r\nContent-Type: image/png\r\n\r\n').encode()+raw+b'\r\n'
 body+=('--'+boundary+'--\r\n').encode()
 return request('payments/submit.php',body,auth,'multipart/form-data; boundary='+boundary)
status,j=request('payments/manual_details.php?method=GCash',auth=False);check('Wallet details require authentication',status==401)
status,j=request('payments/manual_details.php?method=GCash');w=j['wallet'];check('Configured GCash details load',status==200 and w['configured']);check('Approved recipient is exact',w['account_name']=='TEDDY GIL LICO' and w['account_number']=='09068624144')
import base64
check('QR bytes returned without re-encoding',base64.b64decode(w['qr_image_base64'])==(root/'test-private/test-image.png').read_bytes())
status,m=request('payments/manual_details.php?method=Maya');check('Maya supported',status==200 and m['wallet']['configured'])
status,j=request('payments/manual_details.php?method=Bank%20Transfer');check('New wallet endpoint excludes Bank Transfer',status==422)
status,j=request('payments/gcash/create.php',b'{}');check('Old gateway creation disabled',status==410)
status,j=submit(ids[0],'GCash','1234-5678 90123',{'shop_configuration_version':w['configuration_version']});check('Modern GCash proof submitted',status==200 and j['success'])
row=sql('SELECT p.status,p.amount,r.reservation_fee_status FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id='+str(ids[0]),True)
check('Submission stays Under Review and amount unchanged',row['status']=='Under Review' and row['amount']=='200.00' and row['reservation_fee_status']=='Under Review')
status,j=submit(ids[1],'Maya','1234567890123');check('Duplicate normalized reference blocked across wallets',status==409)
status,j=submit(ids[0],'GCash','1234567890123');check('Repeat submission cannot overwrite pending review',status==409)
status,j=submit(ids[2],'GCash','REF-MISSING-IMAGE',image=False);check('Missing receipt rejected',status==422)
status,j=submit(ids[3],'GCash','REF-BAD-MIME',image=b'not an image');check('Renamed text file rejected',status==422)
status,j=submit(ids[4],'GCash','REF-OVERSIZE',image=b'X'*(5*1024*1024+1));check('Oversized proof rejected',status==422)
status,j=submit(ids[5],'GCash','REF-NO-AUTH',auth=False);check('Submission requires authentication',status==401)
status,j=submit(2147483647,'GCash','REF-FOREIGN');check('Unowned payment rejected',status==409)
status,j=submit(ids[7],'GCash','REF-STALE',{'shop_configuration_version':'old'});check('Stale merchant configuration rejected',status==409)
status,j=submit(ids[8],'Maya','REF-REVIEW',{'receipt_review_requested':'1','receipt_screening':'VALID_FOR_SUBMISSION','payment_status':'Paid','amount':'0'});check('Manual review fallback can submit a valid image',status==200)
row=sql('SELECT status,amount,admin_notes FROM payments WHERE id='+str(ids[8]),True);check('Forged client Paid/amount/OCR claims never approve payment',row['status']=='Under Review' and row['amount']=='200.00' and 'unverified' in row['admin_notes'])
status,j=submit(ids[9],'Card','CARD-REF');check('Manual Card API remains compatible',status==200)
status,j=submit(ids[10],'Bank Transfer','BANK-LEGACY');check('Legacy Bank Transfer API preserved for existing clients',status==200)
status,j=submit(ids[11],'Cash','');check('Cash reservation fee still prohibited',status==422)
sql('UPDATE payments SET amount=250.00 WHERE id='+str(ids[13]));status,j=submit(ids[13],'GCash','REF-WRONG-QR-AMOUNT',{'shop_configuration_version':w['configuration_version']});check('Fixed 200 QR cannot be submitted for different recorded amount',status==409)
status,j=submit(ids[14],'GCash','R'*101);check('Reference length bounded',status==422)
# Config/helper checks are local function calls, not remote OCR/provider calls.
helper=root/'current/Vehicle-Service-System/vehicle-service-management/api/payments/manual_wallets.php'
code='require '+json.dumps(str(helper))+';echo json_encode([manualNormalizeReference(" ab-12 34 "),manualAmountMinor("200.00"),manualWalletPublic("GCash",[])["configured"]]);'
r=subprocess.run([php,'-c','/workspace/work/php.ini','-r',code],capture_output=True,text=True,env=env);v=json.loads(r.stdout);check('Reference normalization and decimal centavos are deterministic',v[0]=='AB1234' and v[1]==20000);check('Missing shop configuration fails closed',v[2] is False)
(root/'backend-tests.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'environment':'isolated local test DB and HTTP server; no real payment, no external OCR'},indent=2));print(len(checks),'backend checks passed.')
