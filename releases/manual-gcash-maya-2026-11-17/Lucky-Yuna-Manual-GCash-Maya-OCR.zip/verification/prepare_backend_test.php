<?php
$admin=new mysqli('localhost','root','',null,0,'/workspace/work/db/mysql.sock');
$admin->query('CREATE DATABASE IF NOT EXISTS manual_wallet_test');
$c=new mysqli('localhost','root','','manual_wallet_test',0,'/workspace/work/db/mysql.sock');
$r=$c->query('SHOW TABLES');while($row=$r->fetch_row())$c->query('DROP TABLE `'.$row[0].'`');
$r=$c->query('SHOW TABLES FROM vehicle_service_system');while($row=$r->fetch_row()){
 $t=$row[0];if($t==='payment_gateway_attempts')continue;
 $c->query("CREATE TABLE `$t` LIKE vehicle_service_system.`$t`");
 if(in_array($t,['users','customers','vehicles','reservations','job_quotations'],true))$c->query("INSERT INTO `$t` SELECT * FROM vehicle_service_system.`$t`");
}
$uid=(int)$c->query("SELECT u.id FROM users u JOIN customers c ON c.user_id=u.id WHERE u.role='customer' LIMIT 1")->fetch_assoc()['id'];
$rid=(int)$c->query('SELECT id FROM reservations LIMIT 1')->fetch_assoc()['id'];
$c->query("UPDATE reservations SET user_id=$uid,status='Pending',reservation_fee_status='Awaiting Payment' WHERE id=$rid");
$hash=hash('sha256','manual-api-test-token');$c->query("INSERT INTO api_tokens(user_id,token_hash,expires_at) VALUES($uid,'$hash',DATE_ADD(NOW(),INTERVAL 1 HOUR))");
$ids=[];foreach(range(1,15) as $n){$c->query("INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount) VALUES($rid,200.00,'GCash','Awaiting Proof','Reservation Fee',200.00)");$ids[]=$c->insert_id;}
file_put_contents('/workspace/work/manual-gcash/backend-fixture.json',json_encode(['user_id'=>$uid,'reservation_id'=>$rid,'payment_ids'=>$ids]));echo "Prepared isolated manual_wallet_test (no gateway attempt table).\n";
