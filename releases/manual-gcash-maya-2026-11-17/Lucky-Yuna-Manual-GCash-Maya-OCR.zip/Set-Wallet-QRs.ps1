param(
    [string]$PrivateDirectory = 'C:\xampp\lyc-private',
    [string]$GCashQr,
    [string]$MayaQr
)
$ErrorActionPreference = 'Stop'
function Pick-OriginalQr([string]$Wallet) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Select your original $Wallet shop QR image (PHP 200)"
    $dialog.Filter = 'QR images (*.png;*.jpg;*.jpeg;*.webp)|*.png;*.jpg;*.jpeg;*.webp'
    $dialog.CheckFileExists = $true
    try {
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Cancelled. No QR settings were changed.' }
        return $dialog.FileName
    } finally { $dialog.Dispose() }
}
if (-not $GCashQr) { $GCashQr = Pick-OriginalQr 'GCash' }
if (-not $MayaQr) { $MayaQr = Pick-OriginalQr 'Maya' }
$selected = @($GCashQr, $MayaQr)
foreach ($path in $selected) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Image not found: $path" }
    if ((Get-Item -LiteralPath $path).Length -gt 2MB) { throw 'QR image must be 2 MB or smaller. Use the original PNG/JPG/WEBP file.' }
    if ([IO.Path]::GetExtension($path).ToLowerInvariant() -notin @('.png','.jpg','.jpeg','.webp')) { throw 'Choose PNG, JPG, JPEG, or WEBP.' }
}
New-Item -ItemType Directory -Force -Path $PrivateDirectory | Out-Null
$backup = Join-Path (Join-Path $PrivateDirectory 'backups') (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
foreach ($name in @('gcash-qr.original','maya-qr.original','manual_wallets.php')) {
    $old = Join-Path $PrivateDirectory $name
    if (Test-Path -LiteralPath $old) {
        New-Item -ItemType Directory -Force -Path $backup | Out-Null
        Copy-Item -LiteralPath $old -Destination (Join-Path $backup $name)
    }
}
$targets = @((Join-Path $PrivateDirectory 'gcash-qr.original'), (Join-Path $PrivateDirectory 'maya-qr.original'))
for ($i = 0; $i -lt 2; $i++) {
    $expected = (Get-FileHash -LiteralPath $selected[$i] -Algorithm SHA256).Hash
    if ([IO.Path]::GetFullPath($selected[$i]) -ne [IO.Path]::GetFullPath($targets[$i])) {
        Copy-Item -LiteralPath $selected[$i] -Destination $targets[$i] -Force
    }
    if ((Get-FileHash -LiteralPath $targets[$i] -Algorithm SHA256).Hash -ne $expected) { throw 'QR copy integrity check failed. Review your files before accepting payment.' }
}
$config = @'
<?php
// Recipient details explicitly approved by the shop owner. Original QR bytes are not rewritten.
return [
    'GCash' => [
        'account_name' => 'TEDDY GIL LICO',
        'account_number' => '09068624144',
        'approved_names' => [],
        'qr_file' => __DIR__.'/gcash-qr.original',
        'qr_amount_minor' => 20000,
    ],
    'Maya' => [
        'account_name' => 'TEDDY GIL LICO',
        'account_number' => '09068624144',
        'approved_names' => [],
        'qr_file' => __DIR__.'/maya-qr.original',
        'qr_amount_minor' => 20000,
    ],
];
'@
[IO.File]::WriteAllText((Join-Path $PrivateDirectory 'manual_wallets.php'), $config, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "Saved original QR files and approved recipient configuration in $PrivateDirectory"
Write-Host 'Approved recipient for both wallets: TEDDY GIL LICO / 09068624144. QR amount: PHP 200.'
Write-Host 'Open each wallet in the app and verify the actual QR recipient in GCash/Maya before accepting real payments.'
Write-Host 'No database changes, payment transfers, OCR uploads or website deployment were performed by this script.'
