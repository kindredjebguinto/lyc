import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/models/receipt_screening.dart';
import 'package:vsm_customer/services/receipt_classifier.dart';
import 'package:vsm_customer/services/receipt_validation_rules.dart';

const validText =
    'GCash\nPayment successfully sent\nAmount Sent: PHP 200.00\nSent to: TEDDY GIL LICO\n09068624144\nReference No.: 1234567890123';
ReceiptScreening screen(String value) => ReceiptValidationRules().validate(
  ReceiptClassifier().classify(value),
  expectedAmountMinor: 20000,
  accountName: 'TEDDY GIL LICO',
  accountNumber: '09068624144',
);
void main() {
  test('GCash Ref. No. and Maya Reference ID labels are readable', () {
    expect(
      screen(validText.replaceFirst('Reference No.:', 'Ref. No.:'))
          .fields
          .reference,
      '1234567890123',
    );
    expect(
      screen(validText.replaceFirst('Reference No.:', 'Reference ID:'))
          .fields
          .reference,
      '1234567890123',
    );
  });
  test('readable GCash receipt is eligible only for manual submission', () {
    expect(screen(validText).state, ReceiptValidationState.validForSubmission);
  });
  test('readable Maya receipt is supported', () {
    expect(
      screen(validText.replaceFirst('GCash', 'Maya')).state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test(
    'QR Ph receipt from another wallet can match the approved recipient',
    () {
      expect(
        screen(validText.replaceFirst('GCash', 'InstaPay')).state,
        ReceiptValidationState.validForSubmission,
      );
    },
  );
  test('clearly unrelated readable screenshot is invalid', () {
    expect(
      screen(
        'A beautiful mountain landscape description with holiday weather observations and several paragraphs about sunshine and travel.',
      ).state,
      ReceiptValidationState.invalid,
    );
  });
  test('random gallery photo with no readable text requires review', () {
    expect(screen('').state, ReceiptValidationState.needsReview);
  });
  test('blurred incomplete OCR requires review', () {
    expect(
      screen('G C ash\n2O O\nRef ...').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('cropped receipt requires review', () {
    expect(
      screen('GCash\nAmount: PHP 200.00').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('wrong readable amount is invalid', () {
    expect(
      screen(validText.replaceFirst('200.00', '250.00')).state,
      ReceiptValidationState.invalid,
    );
  });
  test('conflicting name and matching number requires review', () {
    expect(
      screen(validText.replaceFirst('TEDDY GIL LICO', 'TEDDY GIL UCO')).state,
      ReceiptValidationState.needsReview,
    );
  });
  test('cropped name requires review rather than an automatic rejection', () {
    expect(
      screen(
        validText
            .replaceFirst('TEDDY GIL LICO', 'TEDDY GIL')
            .replaceFirst('09068624144', '0906***4144'),
      ).state,
      ReceiptValidationState.needsReview,
    );
  });
  test('wrong readable recipient is invalid', () {
    expect(
      screen(
        validText
            .replaceFirst('TEDDY GIL LICO', 'OTHER PERSON')
            .replaceFirst('09068624144', '09123456789'),
      ).state,
      ReceiptValidationState.invalid,
    );
  });
  test('wrong readable full recipient number is invalid', () {
    expect(
      screen(validText.replaceFirst('09068624144', '09123456789')).state,
      ReceiptValidationState.invalid,
    );
  });
  test('masked recipient is uncertain rather than automatically wrong', () {
    expect(
      screen(
        validText
            .replaceFirst('TEDDY GIL LICO', 'TE**Y G**L')
            .replaceFirst('09068624144', '0906***4144'),
      ).state,
      ReceiptValidationState.needsReview,
    );
  });
  test('missing reference requires review', () {
    expect(
      screen(validText.replaceFirst('Reference No.: 1234567890123', '')).state,
      ReceiptValidationState.needsReview,
    );
  });
  test('fee balance and total do not replace the transfer amount', () {
    final r = screen(
      '$validText\nTransfer Fee: PHP 15.00\nTotal Amount: PHP 215.00\nBalance: PHP 1000.00',
    );
    expect(r.state, ReceiptValidationState.validForSubmission);
    expect(r.fields.amountsMinor, [20000]);
  });
  test('conflicting labelled amounts require review', () {
    expect(
      screen('$validText\nAmount Paid: PHP 250.00').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('reference normalization preserves ambiguous O and zero', () {
    expect(ReceiptClassifier.normalizeReference('REF-O 123-456'), 'REFO123456');
  });
  test('phone normalization accepts international number', () {
    expect(ReceiptClassifier.normalizePhone('+63 906 862 4144'), '09068624144');
  });
  test(
    'internally coherent fabricated text cannot be authenticated by OCR',
    () {
      expect(
        screen(validText).state,
        ReceiptValidationState.validForSubmission,
      );
      expect(screen(validText).reasons.single, contains('Staff'));
    },
  );
}
