import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

abstract class ReceiptOcr {
  Future<String> read(String filePath);
  Future<void> close();
}

class MlKitReceiptOcr implements ReceiptOcr {
  final TextRecognizer _recognizer = TextRecognizer(
    script: TextRecognitionScript.latin,
  );
  @override
  Future<String> read(String filePath) async =>
      (await _recognizer.processImage(InputImage.fromFilePath(filePath))).text;
  @override
  Future<void> close() => _recognizer.close();
}
