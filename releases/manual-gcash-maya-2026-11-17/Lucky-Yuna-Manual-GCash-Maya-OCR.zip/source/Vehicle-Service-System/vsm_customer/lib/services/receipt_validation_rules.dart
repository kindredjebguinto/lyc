import '../models/receipt_screening.dart';
import 'receipt_classifier.dart';

class ReceiptValidationRules {
  ReceiptScreening validate(
    ReceiptFields fields, {
    required int expectedAmountMinor,
    required String accountName,
    required String accountNumber,
    List<String> approvedNames = const [],
  }) {
    final invalid = <String>[], review = <String>[];
    if (fields.clearlyUnrelated) {
      invalid.add('This image does not appear to be a payment receipt.');
    }
    if (!fields.looksLikeReceipt || !fields.hasWalletIndicator) {
      review.add('Wallet transaction details could not be identified clearly.');
    }
    if (fields.amountsMinor.length != 1) {
      review.add('The transfer amount is missing or ambiguous.');
    } else if (fields.amountsMinor.single != expectedAmountMinor) {
      invalid.add(
        'The readable transfer amount does not match the amount due.',
      );
    }
    final allowedNames = [
      accountName,
      ...approvedNames,
    ].map(ReceiptClassifier.normalizeName).toSet();
    final name = fields.recipientName == null
        ? null
        : ReceiptClassifier.normalizeName(fields.recipientName!);
    final phone = fields.recipientPhone;
    var recipientMatches = false;
    if (phone != null) {
      if (phone == ReceiptClassifier.normalizePhone(accountNumber)) {
        recipientMatches = true;
      } else {
        invalid.add(
          'The readable recipient number does not match the shop account.',
        );
      }
    }
    if (name != null && name.isNotEmpty) {
      if (allowedNames.contains(name)) {
        recipientMatches = true;
      } else if (phone == ReceiptClassifier.normalizePhone(accountNumber) ||
          allowedNames.any((full) => full.startsWith('$name '))) {
        review.add(
          'The recipient name is incomplete or conflicts with the readable number.',
        );
      } else {
        invalid.add(
          'The readable recipient name does not match the shop account.',
        );
      }
    }
    if (!recipientMatches) {
      review.add(
        'The recipient is incomplete, masked, or could not be confirmed.',
      );
    }
    if (fields.reference == null) {
      review.add('The transaction reference could not be read.');
    }
    if (invalid.isNotEmpty) {
      return ReceiptScreening(ReceiptValidationState.invalid, invalid, fields);
    }
    if (review.isNotEmpty) {
      return ReceiptScreening(
        ReceiptValidationState.needsReview,
        review,
        fields,
      );
    }
    return ReceiptScreening(ReceiptValidationState.validForSubmission, const [
      'Receipt is ready for submission. Staff must still verify the actual funds received.',
    ], fields);
  }
}
