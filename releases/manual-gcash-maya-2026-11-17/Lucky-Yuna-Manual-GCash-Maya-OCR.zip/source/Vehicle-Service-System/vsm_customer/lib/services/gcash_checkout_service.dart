// Redirect integration retired. No provider or deep-link calls are made.
@Deprecated('Use manual QR payments with staff verification.')
class GCashCheckoutService {
  GCashCheckoutService._();
  static final instance = GCashCheckoutService._();
  Future<void> start() async {}
}
