import '../models/receipt_screening.dart';

// OCR text extraction/classification only. This never establishes authenticity.
class ReceiptClassifier {
  static String normalizeName(String value) => value
      .toUpperCase()
      .replaceAll(RegExp(r"[^A-Z ]"), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  static String? normalizePhone(String value) {
    if (value.contains('*') || value.contains('•')) return null;
    var digits = value.replaceAll(RegExp(r'\D'), '');
    if (digits.startsWith('63') && digits.length == 12) {
      digits = '0${digits.substring(2)}';
    }
    if (RegExp(r'^09\d{9}$').hasMatch(digits)) return digits;
    return null;
  }

  static String normalizeReference(String value) =>
      value.toUpperCase().replaceAll(RegExp(r'[\s-]+'), '');

  ReceiptFields classify(String text) {
    final lines = text
        .split(RegExp(r'[\r\n]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    final wallet = RegExp(
      r'\b(gcash|maya|paymaya|instapay|qr\s*ph)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final receipt = RegExp(
      r'\b(receipt|transaction|reference|successfully|payment|sent|paid)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final amounts = <int>{};
    // Only clearly-labelled transfer amounts; exclude fee/balance/total calculations.
    final amountRe = RegExp(
      r'(?:\bamount(?:[ \t]+(?:sent|paid|transferred))?|\bsent|\bpaid)[ \t]*:?[ \t]*(?:\n[ \t]*)?(?:PHP|P|₱)?[ \t]*([0-9][0-9,]*(?:\.[0-9]{2})?)(?![0-9.])',
      caseSensitive: false,
    );
    for (final m in amountRe.allMatches(text)) {
      final before = text
          .substring((m.start - 15).clamp(0, text.length), m.start)
          .toLowerCase();
      if (RegExp(r'(?:fee|balance|total)[ \t]*$').hasMatch(before)) continue;
      final raw = m.group(1)!.replaceAll(',', '');
      final parts = raw.split('.');
      final whole = int.tryParse(parts[0]);
      if (whole != null && whole <= 999999999) {
        amounts.add(
          whole * 100 + (parts.length == 2 ? int.parse(parts[1]) : 0),
        );
      }
    }
    String? reference, name, phone;
    for (var i = 0; i < lines.length; i++) {
      final ref = RegExp(
        r'^(?:reference(?:\s+(?:no\.?|number|id))?|ref\.?(?:\s+(?:no\.?|number))?|transaction\s+(?:id|no\.?|number))\s*[:#.]?\s*(.*)$',
        caseSensitive: false,
      ).firstMatch(lines[i]);
      if (ref != null) {
        final value = ref.group(1)!.isNotEmpty
            ? ref.group(1)!
            : (i + 1 < lines.length ? lines[i + 1] : '');
        final cleaned = normalizeReference(value);
        if (RegExp(r'^[A-Z0-9]{6,100}$').hasMatch(cleaned) &&
            RegExp(r'\d').hasMatch(cleaned)) {
          reference = cleaned;
        }
      }
      final recipient = RegExp(
        r'^(?:sent\s+to|paid\s+to|recipient(?:\s+name)?|account\s+name|to)\s*:?\s*(.*)$',
        caseSensitive: false,
      ).firstMatch(lines[i]);
      if (recipient != null) {
        final value = recipient.group(1)!.isNotEmpty
            ? recipient.group(1)!
            : (i + 1 < lines.length ? lines[i + 1] : '');
        final p = RegExp(r'(?:\+?63|0)9[0-9 \-]{9,15}').firstMatch(value);
        if (p != null) phone = normalizePhone(p.group(0)!);
        final candidate = value
            .replaceAll(RegExp(r'(?:\+?63|0)9[0-9 \-]{9,15}'), '')
            .trim();
        if (!candidate.contains('*') &&
            !candidate.contains('•') &&
            RegExp(r"^[A-Za-z .,'-]{3,}$").hasMatch(candidate)) {
          name = candidate;
        }
        // A following full phone is associated with the recipient block only.
        final phoneLine = i + (recipient.group(1)!.isNotEmpty ? 1 : 2);
        if (phoneLine < lines.length && phone == null) {
          phone = normalizePhone(lines[phoneLine]);
        }
      }
    }
    return ReceiptFields(
      amountsMinor: amounts.toList(),
      recipientName: name,
      recipientPhone: phone,
      reference: reference,
      hasWalletIndicator: wallet,
      looksLikeReceipt: receipt,
      clearlyUnrelated: text.trim().length >= 80 && !wallet && !receipt,
    );
  }
}
