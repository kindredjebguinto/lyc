import 'dart:convert';
import 'dart:typed_data';

class ManualWalletDetails {
  final bool configured;
  final String method, accountName, accountNumber, version, mimeType, message;
  final List<String> approvedNames;
  final int qrAmountMinor;
  final Uint8List? qrBytes;
  const ManualWalletDetails({
    required this.method,
    required this.configured,
    this.accountName = '',
    this.accountNumber = '',
    this.version = '',
    this.mimeType = '',
    this.message = '',
    this.approvedNames = const [],
    this.qrAmountMinor = 20000,
    this.qrBytes,
  });
  factory ManualWalletDetails.fromMap(Map<String, dynamic> value) {
    Uint8List? bytes;
    if (value['configured'] == true) {
      if (!['GCash', 'Maya'].contains(value['method']) ||
          (value['account_name']?.toString().trim() ?? '').isEmpty ||
          !RegExp(r'^09[0-9]{9}$')
              .hasMatch(value['account_number']?.toString() ?? '') ||
          !RegExp(r'^[a-f0-9]{64}$')
              .hasMatch(value['configuration_version']?.toString() ?? '') ||
          ![
            'image/png',
            'image/jpeg',
            'image/webp',
          ].contains(value['qr_mime_type'])) {
        throw const FormatException('Invalid shop payment details.');
      }

      bytes = base64Decode(value['qr_image_base64']?.toString() ?? '');
      if (bytes.isEmpty || bytes.length > 2 * 1024 * 1024) {
        throw const FormatException('Invalid shop QR image.');
      }
    }
    return ManualWalletDetails(
      method: value['method']?.toString() ?? '',
      configured: value['configured'] == true,
      accountName: value['account_name']?.toString() ?? '',
      accountNumber: value['account_number']?.toString() ?? '',
      version: value['configuration_version']?.toString() ?? '',
      mimeType: value['qr_mime_type']?.toString() ?? '',
      message: value['message']?.toString() ?? '',
      approvedNames: (value['approved_names'] as List? ?? [])
          .whereType<String>()
          .toList(),
      qrAmountMinor: (value['qr_amount_minor'] as num?)?.toInt() ?? 20000,
      qrBytes: bytes,
    );
  }
}
