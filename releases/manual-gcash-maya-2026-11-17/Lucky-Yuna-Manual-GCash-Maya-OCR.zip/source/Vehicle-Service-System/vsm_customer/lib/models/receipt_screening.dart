enum ReceiptValidationState { validForSubmission, invalid, needsReview }

class ReceiptFields {
  final List<int> amountsMinor;
  final String? recipientName;
  final String? recipientPhone;
  final String? reference;
  final bool hasWalletIndicator;
  final bool looksLikeReceipt;
  final bool clearlyUnrelated;
  const ReceiptFields({
    this.amountsMinor = const [],
    this.recipientName,
    this.recipientPhone,
    this.reference,
    this.hasWalletIndicator = false,
    this.looksLikeReceipt = false,
    this.clearlyUnrelated = false,
  });
}

class ReceiptScreening {
  final ReceiptValidationState state;
  final List<String> reasons;
  final ReceiptFields fields;
  const ReceiptScreening(this.state, this.reasons, this.fields);
  factory ReceiptScreening.unreadable([
    String reason = 'Receipt could not be read. Try a clearer image or request manual review.',
  ]) => ReceiptScreening(ReceiptValidationState.needsReview, [
    reason,
  ], const ReceiptFields());
}
