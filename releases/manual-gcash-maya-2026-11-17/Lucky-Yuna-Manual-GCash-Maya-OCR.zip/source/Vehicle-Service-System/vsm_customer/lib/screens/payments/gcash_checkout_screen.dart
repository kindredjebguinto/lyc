import 'package:flutter/material.dart';

@Deprecated('Use BookingPaymentScreen for manual proof verification.')
class GCashCheckoutScreen extends StatelessWidget {
  final int paymentId;
  final bool startCheckout;
  const GCashCheckoutScreen({required this.paymentId, this.startCheckout = false, super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Payment')),
    body: const Padding(padding: EdgeInsets.all(24), child: Text('Redirect checkout has been discontinued. Open Payments for manual receipt verification.')));
}
