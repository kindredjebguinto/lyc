<?php
// Actual QR files/config stay outside the web root. No external OCR or gateway.
$root=rtrim($_SERVER['DOCUMENT_ROOT']??'', '/\\');
$default=$root!==''?dirname($root).'/lyc-private/manual_wallets.php':'';
$path=getenv('LYC_MANUAL_WALLETS_FILE')?:$default;
if($path==='' || !is_file($path)) return [];
$config=require $path;
return is_array($config)?$config:[];
