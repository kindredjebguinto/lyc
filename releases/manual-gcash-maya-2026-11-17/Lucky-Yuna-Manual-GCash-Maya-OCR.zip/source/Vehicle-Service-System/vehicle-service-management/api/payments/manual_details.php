<?php
require_once __DIR__.'/../config/bootstrap.php';require_once __DIR__.'/manual_wallets.php';
requireMethod('GET');requireCustomer($conn);header('Cache-Control: private, no-store');
$method=$_GET['method']??'';
if(!is_string($method)||!in_array($method,['GCash','Maya'],true)){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Select GCash or Maya.']);exit;}
echo json_encode(['success'=>true,'wallet'=>manualWalletConfig($method)]);
