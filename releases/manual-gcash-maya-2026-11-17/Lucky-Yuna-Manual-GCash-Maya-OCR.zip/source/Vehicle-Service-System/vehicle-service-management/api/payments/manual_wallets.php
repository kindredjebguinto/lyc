<?php
function manualWalletConfig(string $method): array {
    $all=require __DIR__.'/../config/manual_wallets.php';
    return manualWalletPublic($method,$all[$method]??[]);
}
function manualWalletPublic(string $method,array $c): array {
    $base=['configured'=>false,'method'=>$method,'message'=>'Shop QR payment details are not configured. Please contact the service center.'];
    if(!in_array($method,['GCash','Maya'],true))return $base;
    $name=trim((string)($c['account_name']??''));$phone=trim((string)($c['account_number']??''));$file=(string)($c['qr_file']??'');
    if($name==='' || !preg_match('/^09[0-9]{9}$/D',$phone) || !is_file($file) || filesize($file)>2*1024*1024)return $base;
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file);$dimensions=@getimagesize($file);
    if(!in_array($mime,['image/jpeg','image/png','image/webp'],true) || !$dimensions || $dimensions[0]<100 || $dimensions[1]<100 || $dimensions[0]>4096 || $dimensions[1]>4096)return $base;
    $bytes=file_get_contents($file);$amount=(int)($c['qr_amount_minor']??20000);
    if($bytes===false || $amount<=0)return $base;
    $aliases=array_values(array_filter($c['approved_names']??[],fn($n)=>is_string($n)&&trim($n)!==''));
    $version=hash('sha256',json_encode([$method,$name,$phone,$amount,$aliases,hash('sha256',$bytes)]));
    return ['configured'=>true,'method'=>$method,'account_name'=>$name,'account_number'=>$phone,'approved_names'=>$aliases,
        'qr_amount_minor'=>$amount,'qr_image_base64'=>base64_encode($bytes),'qr_mime_type'=>$mime,'configuration_version'=>$version,
        'message'=>'Check the recipient in your wallet before transferring. Receipts are verified manually by staff.'];
}
function manualNormalizeReference(string $reference): string {
    return strtoupper(preg_replace('/[\s-]+/','',$reference));
}
function manualReferenceExists(mysqli $conn,string $normalized,int $paymentId): bool {
    // Cross-wallet duplicate check: both supplied QR codes use QR Ph/InstaPay.
    $s=$conn->prepare("SELECT id FROM payments WHERE id<>? AND payment_method IN ('GCash','Maya') AND status IN ('Under Review','Paid') AND UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(reference_number,' ',''),'-',''),CHAR(9),''),CHAR(10),''),CHAR(13),''))=? LIMIT 1");
    $s->bind_param('is',$paymentId,$normalized);$s->execute();$exists=$s->get_result()->num_rows>0;$s->close();return $exists;
}

function manualAmountMinor(string $value): int {
    if(!preg_match('/^(0|[1-9][0-9]{0,9})\\.([0-9]{2})$/D',$value,$m))throw new DomainException('Invalid recorded amount.');
    return (int)$m[1]*100+(int)$m[2];
}
