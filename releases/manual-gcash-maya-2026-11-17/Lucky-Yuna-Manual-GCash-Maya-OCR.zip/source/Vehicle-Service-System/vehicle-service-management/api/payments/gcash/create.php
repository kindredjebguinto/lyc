<?php
require_once __DIR__.'/../../config/bootstrap.php';requireMethod('POST');requireCustomer($conn);
header('Cache-Control: no-store');http_response_code(410);
echo json_encode(['success'=>false,'message'=>'Redirect checkout has been discontinued. Use the updated app to submit GCash or Maya proof for staff verification.']);
