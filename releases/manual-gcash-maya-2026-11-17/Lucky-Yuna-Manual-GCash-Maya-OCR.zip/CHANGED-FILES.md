# Source changes

- `vsm_customer/pubspec.yaml`
- `vsm_customer/lib/main.dart`
- `vsm_customer/lib/screens/splash/splash_screen.dart`
- `vsm_customer/lib/services/session_service.dart`
- `vsm_customer/lib/api/api_config.dart`
- `vsm_customer/lib/api/customer_api.dart`
- `vsm_customer/lib/models/manual_wallet_details.dart`
- `vsm_customer/lib/models/receipt_screening.dart`
- `vsm_customer/lib/services/receipt_classifier.dart`
- `vsm_customer/lib/services/receipt_validation_rules.dart`
- `vsm_customer/lib/services/receipt_ocr_service.dart`
- `vsm_customer/lib/services/gcash_checkout_service.dart`
- `vsm_customer/lib/screens/payments/gcash_checkout_screen.dart`
- `vsm_customer/lib/screens/payments/booking_payment_screen.dart`
- `vsm_customer/lib/screens/payments/payment_proof_dialog.dart`
- `vsm_customer/android/app/src/main/AndroidManifest.xml`
- `vsm_customer/ios/Runner/Info.plist`
- `vsm_customer/ios/Runner.xcodeproj/project.pbxproj`
- `vsm_customer/test/payment_proof_dialog_test.dart`
- `vsm_customer/test/receipt_rules_test.dart`
- `vsm_customer/test/manual_wallet_ui_test.dart`
- `vehicle-service-management/api/config/manual_wallets.php`
- `vehicle-service-management/api/payments/manual_wallets.php`
- `vehicle-service-management/api/payments/manual_details.php`
- `vehicle-service-management/api/payments/submit.php`
- `vehicle-service-management/api/payments/gcash/create.php`

No Admin Website, Customer Website, schema, DB credentials, or Gradle versions are overwritten.
