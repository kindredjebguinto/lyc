import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:vsm_customer/screens/payments/gcash_checkout_screen.dart';
import 'package:vsm_customer/services/gcash_checkout_service.dart';
import 'package:vsm_customer/services/session_service.dart';

void main() {
  setUp(() {
    FlutterSecureStorage.setMockInitialValues({'api_token': 'test-token'});
  });

  test('return links accept navigation only; ignore success claims', () {
    expect(GCashCheckoutService.paymentIdFromReturn(Uri.parse('luckyyuna://payments/return?payment_id=9&status=paid')), 9);
    expect(GCashCheckoutService.paymentIdFromReturn(Uri.parse('https://evil.example/return?payment_id=9')), isNull);
    expect(GCashCheckoutService.paymentIdFromReturn(Uri.parse('luckyyuna://payments/return?payment_id=-1')), isNull);
    expect(GCashCheckoutService.paymentIdFromReturn(Uri.parse('luckyyuna://other/return?payment_id=9')), isNull);
  });

  for (final entry in {
    'paid': 'Payment successful',
    'pending': 'Payment pending',
    'failed': 'Payment failed',
    'cancelled': 'Checkout cancelled',
    'expired': 'Checkout expired',
    'unknown': 'Payment needs verification',
    'review': 'Payment needs verification',
  }.entries) {
    testWidgets('verified ${entry.key} result has correct actions', (tester) async {
      final client = MockClient((request) async {
        expect(request.headers['Authorization'], 'Bearer test-token');
        expect(request.url.queryParameters['payment_id'], '9');
        return http.Response(jsonEncode({
          'success': true, 'gateway_status': entry.key,
          'amount': '200.00', 'reference': entry.key == 'paid' ? 'pay_test9' : null,
          'message': 'Server verified result',
        }), 200);
      });
      await http.runWithClient(() async {
        await tester.pumpWidget(const MaterialApp(home: GCashCheckoutScreen(paymentId: 9)));
        await tester.pumpAndSettle();
        expect(find.text(entry.value), findsOneWidget);
        expect(find.textContaining('SANDBOX'), findsOneWidget);
        expect(find.text('Choose Proof Image'), findsNothing);
        if (entry.key == 'paid') {
          expect(find.text('View Receipt'), findsOneWidget);
          expect(find.text('Check payment status'), findsNothing);
          expect(find.textContaining('pay_test9'), findsOneWidget);
        } else {
          expect(find.text('View Receipt'), findsNothing);
          expect(find.text('Check payment status'), findsOneWidget);
        }
        expect(find.text('Start a new checkout'), ['expired', 'cancelled'].contains(entry.key) ? findsOneWidget : findsNothing);
        await tester.pumpWidget(const SizedBox.shrink());
      }, () => client);
    });
  }

  testWidgets('app resume refreshes pending payment to server verified paid', (tester) async {
    var paid = false;
    var calls = 0;
    final client = MockClient((_) async {
      calls++;
      return http.Response(jsonEncode({'success':true,'gateway_status':paid?'paid':'pending','amount':'200.00','reference':paid?'pay_resume':null}),200);
    });
    await http.runWithClient(() async {
      await tester.pumpWidget(const MaterialApp(home: GCashCheckoutScreen(paymentId:9)));
      await tester.pumpAndSettle();
      expect(find.text('Payment pending'),findsOneWidget);
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
      paid = true;
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
      await tester.pumpAndSettle();
      expect(find.text('Payment successful'),findsOneWidget);
      expect(calls,2);
      await tester.pumpWidget(const SizedBox.shrink());
    },()=>client);
  });

  testWidgets('closed app retains payment ID and reopened screen reconciles', (tester) async {
    var paid = false;
    await SessionService.setPendingGCashPayment(9);
    final client = MockClient((_) async => http.Response(jsonEncode({
      'success': true, 'gateway_status': paid ? 'paid' : 'pending', 'amount': '200.00', 'reference': paid ? 'pay_reopened' : null,
    }), 200));
    await http.runWithClient(() async {
      await tester.pumpWidget(const MaterialApp(home: GCashCheckoutScreen(paymentId: 9)));
      await tester.pumpAndSettle();
      await tester.pumpWidget(const SizedBox.shrink());
      expect(await SessionService.pendingGCashPayment(), 9);
      paid = true;
      final pending = await SessionService.pendingGCashPayment();
      await tester.pumpWidget(MaterialApp(home: GCashCheckoutScreen(paymentId: pending!)));
      await tester.pumpAndSettle();
      expect(find.text('Payment successful'), findsOneWidget);
      expect(await SessionService.pendingGCashPayment(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    }, () => client);
  });

  testWidgets('invalid or unavailable backend never displays success', (tester) async {
    final client=MockClient((_)async=>http.Response(jsonEncode({'success':false,'message':'Unable to verify. Do not pay again.'}),503));
    await http.runWithClient(()async{
      await tester.pumpWidget(const MaterialApp(home:GCashCheckoutScreen(paymentId:9)));
      await tester.pumpAndSettle();
      expect(find.text('Payment successful'),findsNothing);
      expect(find.text('View Receipt'),findsNothing);
      expect(find.text('Unable to verify. Do not pay again.'),findsOneWidget);
      await tester.pumpWidget(const SizedBox.shrink());
    },()=>client);
  });
}
