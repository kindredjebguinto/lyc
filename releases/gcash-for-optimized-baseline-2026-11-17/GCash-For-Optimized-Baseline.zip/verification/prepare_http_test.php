<?php
$c=new mysqli('localhost','root','','gcash_gateway_test',0,'/workspace/work/db/mysql.sock');
$r=$c->query("SHOW TABLES FROM vehicle_service_system");while($v=$r->fetch_row()){$t=$v[0];if($t==='payment_gateway_attempts')continue;$c->query("CREATE TABLE IF NOT EXISTS `$t` LIKE vehicle_service_system.`$t`");}
foreach(['users','customers','vehicles'] as $t){$c->query("INSERT IGNORE INTO `$t` SELECT * FROM vehicle_service_system.`$t`");}
$customer=$c->query("SELECT u.id FROM users u JOIN customers c ON c.user_id=u.id WHERE u.role='customer' LIMIT 1")->fetch_assoc();$uid=(int)$customer['id'];
$staff=$c->query("SELECT id FROM users WHERE role='staff' LIMIT 1")->fetch_assoc();$sid=(int)$staff['id'];$c->query("UPDATE users SET staff_level='Manager' WHERE id=$sid");
$c->query("UPDATE reservations SET user_id=$uid WHERE id=(SELECT reservation_id FROM payments ORDER BY id LIMIT 1)");
$token='gcash-local-http-test-only';$hash=hash('sha256',$token);$c->query("INSERT IGNORE INTO api_tokens(user_id,token_hash,expires_at) VALUES($uid,'$hash',DATE_ADD(NOW(),INTERVAL 1 HOUR))");
$payment=$c->query("SELECT p.id FROM payments p JOIN payment_gateway_attempts a ON a.payment_id=p.id WHERE a.state='review' LIMIT 1")->fetch_assoc();$pid=(int)$payment['id'];$rid=(int)$c->query("SELECT reservation_id FROM payments WHERE id=$pid")->fetch_assoc()['reservation_id'];$c->query("UPDATE reservations SET user_id=$uid,status='Pending' WHERE id=$rid");
$c->query("UPDATE payments SET status='Awaiting Proof' WHERE id=$pid");
$csrf='gcash-test-csrf';session_id('gcashadmintest');session_start();$_SESSION=['admin_id'=>$sid,'admin_role'=>'staff','admin_csrf_token'=>$csrf];session_write_close();
session_id('gcashcustomertest');session_start();$_SESSION=['customer_id'=>$uid,'customer_role'=>'customer','csrf_token'=>$csrf];session_write_close();
file_put_contents('/workspace/work/gcash-integration/http-fixture.json',json_encode(['payment_id'=>$pid,'user_id'=>$uid,'csrf'=>$csrf]));
echo "Prepared isolated HTTP fixtures.\n";
