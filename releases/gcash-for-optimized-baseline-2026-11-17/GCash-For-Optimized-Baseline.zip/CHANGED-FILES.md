# Changed source files

- `vsm_customer/android/app/src/main/AndroidManifest.xml`
- `vsm_customer/ios/Runner/Info.plist`
- `vsm_customer/lib/api/api_config.dart`
- `vsm_customer/lib/api/customer_api.dart`
- `vsm_customer/lib/main.dart`
- `vsm_customer/lib/screens/payments/booking_payment_screen.dart`
- `vsm_customer/lib/screens/payments/gcash_checkout_screen.dart`
- `vsm_customer/lib/screens/payments/payment_proof_dialog.dart`
- `vsm_customer/lib/screens/payments/payments_screen.dart`
- `vsm_customer/lib/screens/splash/splash_screen.dart`
- `vsm_customer/lib/services/gcash_checkout_service.dart`
- `vsm_customer/lib/services/session_service.dart`
- `vsm_customer/pubspec.yaml`
- `vehicle-service-management/api/config/payment_gateway.php`
- `vehicle-service-management/api/gateways/paymongo.php`
- `vehicle-service-management/api/payments/gcash/cancel.php`
- `vehicle-service-management/api/payments/gcash/create.php`
- `vehicle-service-management/api/payments/gcash/return.php`
- `vehicle-service-management/api/payments/gcash/status.php`
- `vehicle-service-management/api/payments/gcash/webhook.php`
- `vehicle-service-management/api/payments/submit.php`
- `vehicle-service-management/api/reservations/cancel.php`
- `vehicle-service-management/customer/payment_submit.php`
- `vehicle-service-management/database/migrations/20261117_payment_gateway_attempts.sql`
- `vehicle-service-management/includes/payment_balance.php`
- `vehicle-service-management/includes/payment_gateway_guard.php`
- `vehicle-service-management/tools/reconcile_gcash.php`
- `vehicle-service-management-admin/payment_view.php`

pubspec.lock is excluded. flutter pub get resolves new dependencies using the installed SDK.
