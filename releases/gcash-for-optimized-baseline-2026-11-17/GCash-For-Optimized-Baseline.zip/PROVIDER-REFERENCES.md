# Provider references inspected

Public read-only sources, 17 November 2026:

- https://github.com/paymongo/magento-extension/blob/main/Gateway/PaymongoClient.php — official organization example of hosted Checkout API request, retrieval, and session expiry.
- https://github.com/paymongo/magento-extension/blob/main/Controller/Payment/Webhook.php — checkout_session.payment.paid and raw-body signature validation with mode-specific signatures and timestamp tolerance.
- https://github.com/paymongo/magento-extension/blob/main/Model/Order/CheckoutStart.php — processing payment can complete even after checkout page expiry.
- https://developers.paymongo.com/reference/create-a-checkout — direct reference fetch returned HTTP 403 in this workspace.
- https://developers.paymongo.com/docs/creating-webhooks — direct reference fetch returned HTTP 403 in this workspace.

No third-party Magento code is bundled as application code. This Flutter/PHP implementation uses the existing project's architecture. Public examples do not replace validation of your own account's current sandbox API responses, eligibility, signing secrets, events and dashboard configuration.
