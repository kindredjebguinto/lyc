import 'dart:async';

import 'package:flutter/material.dart';

import 'services/gcash_checkout_service.dart';
import 'services/session_service.dart';
import 'screens/payments/gcash_checkout_screen.dart';

import 'screens/splash/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await GCashCheckoutService.instance.start();
  } catch (_) {
    /* Payments remains available for manual status checks. */
  }
  runApp(const VSMApp());
}

class VSMApp extends StatefulWidget {
  const VSMApp({super.key});

  @override
  State<VSMApp> createState() => _VSMAppState();
}

class _VSMAppState extends State<VSMApp> {
  final _navigator = GlobalKey<NavigatorState>();
  StreamSubscription<int>? _returns;
  @override
  void initState() {
    super.initState();
    _returns = GCashCheckoutService.instance.returns.listen((id) async {
      if (GCashCheckoutService.instance.activePaymentId == id) return;
      if (!await SessionService.isLoggedIn() || !mounted) return;
      _navigator.currentState?.push(
        MaterialPageRoute(builder: (_) => GCashCheckoutScreen(paymentId: id)),
      );
    });
  }

  @override
  void dispose() {
    _returns?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigator,
      title: 'Luck Yuna Car Center',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF111111)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: Color(0xFFE5E5E5)),
          ),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
