import 'dart:async';

import 'package:app_links/app_links.dart';
import 'package:flutter/foundation.dart';

import 'session_service.dart';

class GCashCheckoutService {
  GCashCheckoutService._();
  static final instance = GCashCheckoutService._();
  final _returns = StreamController<int>.broadcast();
  Stream<int> get returns => _returns.stream;
  StreamSubscription<Uri>? _subscription;
  int? activePaymentId;

  static int? paymentIdFromReturn(Uri uri) {
    if (uri.scheme != 'luckyyuna' ||
        uri.host != 'payments' ||
        uri.path != '/return') {
      return null;
    }
    final id = int.tryParse(uri.queryParameters['payment_id'] ?? '');
    return id != null && id > 0 ? id : null;
  }

  Future<void> start() async {
    if (_subscription != null) return;
    final links = AppLinks();
    _subscription = links.uriLinkStream.listen(
      _receive,
      onError: (Object e) {
        debugPrint(
          'Unable to receive payment return link. Open Payments to check status.',
        );
      },
    );
    final initial = await links.getInitialLink();
    if (initial != null) await _receive(initial);
  }

  Future<void> _receive(Uri uri) async {
    final id = paymentIdFromReturn(uri);
    if (id == null) return;
    // Link contents are navigation hints only. Server still checks payment ownership.
    await SessionService.setPendingGCashPayment(id);
    _returns.add(id);
  }
}
