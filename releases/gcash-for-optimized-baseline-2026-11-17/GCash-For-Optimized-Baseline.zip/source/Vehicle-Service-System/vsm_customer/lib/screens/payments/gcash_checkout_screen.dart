import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../api/customer_api.dart';
import '../../services/gcash_checkout_service.dart';
import '../../services/session_service.dart';
import '../../widgets/app_widgets.dart';
import 'receipt_screen.dart';

class GCashCheckoutScreen extends StatefulWidget {
  final int paymentId;
  final bool startCheckout;
  const GCashCheckoutScreen({
    required this.paymentId,
    this.startCheckout = false,
    super.key,
  });
  @override
  State<GCashCheckoutScreen> createState() => _GCashCheckoutScreenState();
}

class _GCashCheckoutScreenState extends State<GCashCheckoutScreen>
    with WidgetsBindingObserver {
  Map<String, dynamic>? _result;
  String? _error;
  bool _busy = false;
  bool _paused = false;
  int _polls = 0;
  Timer? _timer;
  StreamSubscription<int>? _returns;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    GCashCheckoutService.instance.activePaymentId = widget.paymentId;
    _returns = GCashCheckoutService.instance.returns.listen((id) {
      if (id == widget.paymentId) _refresh();
    });
    if (widget.startCheckout) {
      _create();
    } else {
      _refresh();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _returns?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    if (GCashCheckoutService.instance.activePaymentId == widget.paymentId) {
      GCashCheckoutService.instance.activePaymentId = null;
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _paused = state != AppLifecycleState.resumed;
    if (_paused) {
      _timer?.cancel();
    } else {
      _polls = 0;
      _refresh();
    }
  }

  Future<void> _create() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // Remember before the request: timeout/app termination must not encourage another charge.
      await SessionService.setPendingGCashPayment(widget.paymentId);
      final result = await CustomerApi.createGCashCheckout(widget.paymentId);
      if (!mounted) return;
      if (result['success'] != true) {
        throw Exception(result['message'] ?? 'Unable to start checkout.');
      }
      setState(() => _result = result);
      final url = result['checkout_url']?.toString();
      if (url != null) await _openCheckout(url);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _schedule();
      }
    }
  }

  Future<void> _openCheckout(String value) async {
    final uri = Uri.tryParse(value);
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host != 'checkout.paymongo.com' ||
        uri.userInfo.isNotEmpty) {
      throw Exception(
        'Invalid secure checkout URL. Contact the service center.',
      );
    }
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception(
        'Unable to open checkout. You can reopen the same checkout below.',
      );
    }
  }

  Future<void> _reopen() async {
    try {
      await _openCheckout(_result!['checkout_url'].toString());
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  Future<void> _closeCheckout() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final result = await CustomerApi.cancelGCashCheckout(widget.paymentId);
      if (result['success'] != true) {
        throw Exception(
          result['message'] ?? 'Unable to close checkout. Check its status.',
        );
      }
      if (!mounted) return;
      setState(() => _result = result);
      if (['paid', 'expired', 'cancelled'].contains(result['gateway_status'])) {
        await SessionService.clearPendingGCashPayment(widget.paymentId);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _schedule();
      }
    }
  }

  Future<void> _refresh() async {
    if (_busy) return;
    _timer?.cancel();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final result = await CustomerApi.gcashCheckoutStatus(widget.paymentId);
      if (result['success'] != true) {
        throw Exception(result['message'] ?? 'Unable to verify payment.');
      }
      if (!mounted) return;
      setState(() => _result = result);
      if ([
        'paid',
        'expired',
        'cancelled',
        'not_started',
      ].contains(result['gateway_status'])) {
        await SessionService.clearPendingGCashPayment(widget.paymentId);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _schedule();
      }
    }
  }

  void _schedule() {
    _timer?.cancel();
    if (_paused ||
        _polls >= 12 ||
        !['pending', 'failed'].contains(_result?['gateway_status'])) {
      return;
    }
    _timer = Timer(const Duration(seconds: 10), () {
      _polls++;
      _refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = _result?['gateway_status']?.toString() ?? 'checking';
    final paid = state == 'paid';
    final title = switch (state) {
      'paid' => 'Payment successful',
      'expired' => 'Checkout expired',
      'unknown' || 'review' || 'creating' => 'Payment needs verification',
      'not_started' => 'Pay with GCash',
      'failed' => 'Payment failed',
      'cancelled' => 'Checkout cancelled',
      _ => 'Payment pending',
    };
    return Scaffold(
      appBar: AppBar(title: const Text('GCash Payment')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'SANDBOX — test payments only. No real funds are received.',
              ),
            ),
          ),
          const SizedBox(height: 24),
          Icon(
            paid ? Icons.check_circle : Icons.account_balance_wallet_outlined,
            size: 64,
            color: paid ? Colors.green : primaryColor,
          ),
          const SizedBox(height: 16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          if (_result != null) ...[
            Text(
              money(_result!['amount']),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 28),
            ),
            const SizedBox(height: 12),
            Text(
              _result!['message']?.toString() ?? '',
              textAlign: TextAlign.center,
            ),
            if (paid) ...[
              const SizedBox(height: 12),
              Text('Verified reference: ${_result!['reference'] ?? ''}'),
              const Text('No proof-of-payment screenshot is required.'),
            ],
          ],
          if (_busy)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            ),
          const SizedBox(height: 20),
          if (paid)
            FilledButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ReceiptScreen(paymentId: widget.paymentId),
                ),
              ),
              icon: const Icon(Icons.receipt_long),
              label: const Text('View Receipt'),
            ),
          if (!paid) ...[
            FilledButton(
              onPressed: _busy ? null : _refresh,
              child: const Text('Check payment status'),
            ),
            if (_result?['checkout_url'] != null)
              OutlinedButton(
                onPressed: _busy ? null : _reopen,
                child: const Text('Continue the same checkout'),
              ),
            if (['expired', 'cancelled', 'not_started'].contains(state))
              OutlinedButton(
                onPressed: _busy ? null : _create,
                child: const Text('Start a new checkout'),
              ),
            if (['pending', 'failed'].contains(state))
              TextButton(
                onPressed: _busy ? null : _closeCheckout,
                child: const Text('Close checkout and verify cancellation'),
              ),
            const SizedBox(height: 12),
            const Text(
              'If you cancelled, closed checkout, or saw a failed payment, check the verified status before paying again. An active checkout may still accept payment.',
            ),
          ],
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Return to booking / payments'),
          ),
        ],
      ),
    );
  }
}
