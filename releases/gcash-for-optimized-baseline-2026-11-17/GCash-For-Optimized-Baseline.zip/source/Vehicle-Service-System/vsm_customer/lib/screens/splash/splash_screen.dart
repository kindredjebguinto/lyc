import 'package:flutter/material.dart';

import '../../services/session_service.dart';
import '../payments/gcash_checkout_screen.dart';
import '../auth/login_screen.dart';
import '../dashboard/dashboard_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    final loggedIn = await SessionService.isLoggedIn();

    final pendingPayment = loggedIn
        ? await SessionService.pendingGCashPayment()
        : null;
    if (!mounted) return;

    final navigator = Navigator.of(context);
    navigator.pushReplacement(
      MaterialPageRoute(
        builder: (_) =>
            loggedIn ? const DashboardScreen() : const LoginScreen(),
      ),
    );
    if (pendingPayment != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!navigator.mounted) return;
        navigator.push(
          MaterialPageRoute(
            builder: (_) => GCashCheckoutScreen(paymentId: pendingPayment),
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/logo.png', width: 110, height: 110),
            const SizedBox(height: 18),
            const Text(
              'Luck Yuna Car Center',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 22),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
