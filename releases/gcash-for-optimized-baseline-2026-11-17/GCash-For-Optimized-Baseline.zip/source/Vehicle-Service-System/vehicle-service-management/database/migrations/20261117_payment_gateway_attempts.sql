-- Additive migration. Run once against a BACKED-UP test database first.
-- Existing tables/enums are unchanged. All payment tables must use InnoDB.
CREATE TABLE IF NOT EXISTS payment_gateway_attempts (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 payment_id INT NOT NULL,
 attempt_token CHAR(48) NOT NULL,
 provider VARCHAR(20) NOT NULL DEFAULT 'paymongo',
 mode VARCHAR(8) NOT NULL DEFAULT 'test',
 checkout_session_id VARCHAR(100) NULL,
 provider_payment_id VARCHAR(100) NULL,
 checkout_url VARCHAR(1000) NULL,
 expected_amount_minor BIGINT UNSIGNED NOT NULL,
 currency CHAR(3) NOT NULL DEFAULT 'PHP',
 last_outcome VARCHAR(24) NOT NULL DEFAULT 'pending',
 state VARCHAR(24) NOT NULL DEFAULT 'creating',
 previous_status VARCHAR(32) NOT NULL,
 last_event_id VARCHAR(100) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_gateway_token (attempt_token),
 UNIQUE KEY uq_gateway_checkout (checkout_session_id),
 UNIQUE KEY uq_gateway_payment (provider_payment_id),
 KEY ix_gateway_payment_state (payment_id,state),
 CONSTRAINT fk_gateway_payment FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
