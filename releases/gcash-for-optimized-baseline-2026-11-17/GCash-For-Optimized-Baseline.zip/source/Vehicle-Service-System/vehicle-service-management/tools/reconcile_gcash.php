<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require_once dirname(__DIR__).'/api/config/database.php';require_once dirname(__DIR__).'/api/gateways/paymongo.php';
try{
    $id=(int)($argv[1]??0);$sid=$argv[2]??'';
    $s=$conn->prepare('SELECT * FROM payment_gateway_attempts WHERE id=?');$s->bind_param('i',$id);$s->execute();$a=$s->get_result()->fetch_assoc();$s->close();if(!$a)throw new RuntimeException('Attempt not found.');
    if(!$a['checkout_session_id']){
        if(!preg_match('/^cs_[A-Za-z0-9]+$/D',$sid))throw new RuntimeException('Find the checkout in PayMongo using attempt_token, then supply its cs_ ID. Never unlock an uncertain attempt blindly.');
        $snapshot=gcashRequest('GET','checkout_sessions/'.rawurlencode($sid));$candidate=$a;$candidate['checkout_session_id']=$sid;
        gcashInspect($candidate,$snapshot); // must match token, payment, mode and amount
        $url=$snapshot['attributes']['checkout_url']??'';if(!gcashCheckoutUrl($url))throw new RuntimeException('Invalid checkout URL.');
        $s=$conn->prepare("UPDATE payment_gateway_attempts SET checkout_session_id=?,checkout_url=?,state='pending' WHERE id=? AND checkout_session_id IS NULL AND state IN ('unknown','creating')");$s->bind_param('ssi',$sid,$url,$id);$s->execute();$s->close();$a=$candidate;
    }
    gcashReconcile($conn,$a);echo "Reconciliation completed. Check Payments for the verified result.\n";
}catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}
