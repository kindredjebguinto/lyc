<?php
require_once dirname(__DIR__,2).'/includes/payment_gateway_guard.php';
function gcashConfig(bool $creating=false): array {
    $c=require dirname(__DIR__).'/config/payment_gateway.php';
    if (($creating && !$c['enabled']) || !str_starts_with($c['secret_key'],'sk_test_') || $c['webhook_secret']==='' ||
        !filter_var($c['return_url'],FILTER_VALIDATE_URL) || parse_url($c['return_url'],PHP_URL_SCHEME)!=='https' ||
        parse_url($c['return_url'],PHP_URL_QUERY) || parse_url($c['return_url'],PHP_URL_FRAGMENT)) {
        throw new DomainException('GCash sandbox checkout is not configured yet. Please use another available payment method.');
    }
    if (!function_exists('curl_init')) throw new DomainException('GCash requires the PHP cURL extension on the backend.');
    return $c;
}
function gcashAmountMinor(string $decimal): int {
    if (!preg_match('/^(0|[1-9][0-9]{0,9})\.([0-9]{2})$/D',$decimal,$m)) throw new DomainException('Invalid recorded payment amount.');
    $minor=(int)$m[1]*100+(int)$m[2];
    if ($minor<=0) throw new DomainException('No amount is due.');
    return $minor;
}
function gcashRequest(string $method,string $path,?array $body=null): array {
    $c=gcashConfig();
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL extension is required.');
    $ch=curl_init('https://api.paymongo.com/v1/'.$path);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,
        CURLOPT_USERPWD=>$c['secret_key'].':',CURLOPT_HTTPAUTH=>CURLAUTH_BASIC,
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],
        CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    if ($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_THROW_ON_ERROR));
    $raw=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    // Even an error may follow a successfully-created remote checkout. Never auto-retry POST.
    if ($raw===false || $code<200 || $code>=300) throw new RuntimeException('Payment provider unavailable. The checkout must be reconciled before another attempt.');
    $d=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
    if (!is_array($d['data']??null)) throw new RuntimeException('Unexpected provider response.');
    return $d['data'];
}
function gcashCheckoutUrl(string $url): bool {
    $host=strtolower((string)parse_url($url,PHP_URL_HOST));
    return parse_url($url,PHP_URL_SCHEME)==='https' && ($host==='checkout.paymongo.com') &&
        !parse_url($url,PHP_URL_USER) && !parse_url($url,PHP_URL_PASS);
}
function gcashVerifySignature(string $body,string $header,string $secret,?int $now=null): bool {
    if ($secret==='' || strlen($header)>2048) return false;
    $parts=[];
    foreach(explode(',',$header) as $part){$v=explode('=',trim($part),2);if(count($v)===2)$parts[$v[0]]=$v[1];}
    $t=$parts['t']??'';$sig=$parts['te']??''; // sandbox signature; never accept live `li`
    $clock=$now??time();
    if (!ctype_digit($t) || (int)$t<$clock-300 || (int)$t>$clock+60 || !preg_match('/^[a-f0-9]{64}$/iD',$sig)) return false;
    return hash_equals(hash_hmac('sha256',$t.'.'.$body,$secret),strtolower($sig));
}
// Pure validation shared by reconciliation and tests. Provider GET is the source of truth.
function gcashInspect(array $attempt,array $session): array {
    $a=$session['attributes']??[];
    if (($session['id']??'')!==$attempt['checkout_session_id'] || ($session['type']??'')!=='checkout_session' ||
        ($a['livemode']??null)!==false || ($a['metadata']['attempt_token']??'')!==$attempt['attempt_token'] ||
        (string)($a['metadata']['payment_id']??'')!==(string)$attempt['payment_id']) throw new DomainException('Gateway session mapping mismatch.');
    $paid=[];
    foreach(($a['payments']??[]) as $p){
        $v=$p['attributes']??[];
        if (($v['status']??'')!=='paid') continue;
        if (($p['type']??'')!=='payment' || !preg_match('/^pay_[A-Za-z0-9]+$/D',$p['id']??'') ||
            ($v['livemode']??null)!==false || ($v['currency']??'')!=='PHP' ||
            !is_int($v['amount']??null) || $v['amount']!==(int)$attempt['expected_amount_minor'] ||
            ($v['source']['type']??'')!=='gcash') throw new DomainException('Gateway payment amount, currency, mode or method mismatch.');
        $paid[]=$p['id'];
    }
    if(count($paid)>1)throw new DomainException('Multiple captured payments require staff reconciliation.');
    if($paid)return ['state'=>'paid','reference'=>$paid[0]];
    // A processing payment can settle even after the checkout page expires.
    $intentStatus=$a['payment_intent']['attributes']['status']??null;
    $inFlight=in_array($intentStatus,['processing','awaiting_next_action'],true);
    foreach(($a['payments']??[]) as $p) if(in_array($p['attributes']['status']??'', ['pending','processing'],true))$inFlight=true;
    if($inFlight)return ['state'=>'pending','outcome'=>'pending'];
    // Missing/unknown intent data never releases a payment for a second charge.
    if(($a['status']??'')==='expired' && in_array($intentStatus,['awaiting_payment_method','cancelled','failed'],true))return ['state'=>'expired'];
    $failed=false;
    foreach(($a['payments']??[]) as $p) if(($p['attributes']['status']??'')==='failed')$failed=true;
    return ['state'=>'pending','outcome'=>$failed?'failed':'pending'];
}
function gcashAttemptView(?array $a,array $payment): array {
    $state=$payment['status']==='Paid'?'paid':($a['state']??'not_started');
    if($state==='pending' && ($a['last_outcome']??'')==='failed')$state='failed';
    if($state==='expired' && ($a['last_outcome']??'')==='cancelled')$state='cancelled';
    return ['success'=>true,'payment_id'=>(int)$payment['id'],'payment_status'=>$payment['status'],
        'amount'=>(string)$payment['amount'],'currency'=>'PHP','gateway_status'=>$state,
        'reference'=>$payment['reference_number']??null,
        'checkout_url'=>(in_array($state,['pending','failed'],true) && $a && gcashCheckoutUrl($a['checkout_url']??''))?$a['checkout_url']:null,
        'message'=>match($state){'paid'=>'Payment verified. Your receipt is available.',
            'expired'=>'Checkout expired. You may choose a new payment attempt.',
            'cancelled'=>'Checkout was closed and its expiry verified. You may choose another payment attempt.',
            'failed'=>'The last payment failed. Continue the same checkout or close and verify it before retrying.',
            'unknown','creating','review'=>'Payment needs reconciliation. Do not pay again. Contact the service center.',
            'pending'=>'Waiting for verified payment. Returning from checkout does not confirm payment.',
            default=>'Ready to start a GCash checkout.'}];
}
function gcashOwnedPayment(mysqli $conn,int $id,int $userId): array {
    $s=$conn->prepare('SELECT p.* FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id=? AND r.user_id=?');
    $s->bind_param('ii',$id,$userId);$s->execute();$r=$s->get_result()->fetch_assoc();$s->close();
    if(!$r)throw new DomainException('Payment not found.');return $r;
}
function gcashReconcile(mysqli $conn,array $attempt,string $eventId=''): void {
    if(empty($attempt['checkout_session_id']))return;
    $session=gcashRequest('GET','checkout_sessions/'.rawurlencode($attempt['checkout_session_id']));
    gcashApplySnapshot($conn,$attempt,$session,$eventId);
}
function gcashApplySnapshot(mysqli $conn,array $attempt,array $session,string $eventId=''): void {
    // Lock reservation then payment: same order as quote and cancellation workflows.
    $conn->begin_transaction();
    try {
        $s=$conn->prepare('SELECT reservation_id FROM payments WHERE id=?');$s->bind_param('i',$attempt['payment_id']);$s->execute();$rid=(int)$s->get_result()->fetch_assoc()['reservation_id'];$s->close();
        $s=$conn->prepare('SELECT status FROM reservations WHERE id=? FOR UPDATE');$s->bind_param('i',$rid);$s->execute();$booking=$s->get_result()->fetch_assoc();$s->close();
        $s=$conn->prepare('SELECT * FROM payments WHERE id=? FOR UPDATE');$s->bind_param('i',$attempt['payment_id']);$s->execute();$p=$s->get_result()->fetch_assoc();$s->close();
        $s=$conn->prepare('SELECT * FROM payment_gateway_attempts WHERE id=? FOR UPDATE');$s->bind_param('i',$attempt['id']);$s->execute();$a=$s->get_result()->fetch_assoc();$s->close();
        if($a['state']==='paid'){$conn->commit();return;}
        try {
            if(gcashAmountMinor((string)$p['amount'])!==(int)$a['expected_amount_minor'])throw new DomainException('Recorded payment amount changed.');
            $result=gcashInspect($a,$session);
        } catch(DomainException $e){
            $s=$conn->prepare("UPDATE payment_gateway_attempts SET state='review',last_event_id=? WHERE id=?");$s->bind_param('si',$eventId,$a['id']);$s->execute();$s->close();$conn->commit();throw $e;
        }
        $state=$result['state'];
        // Never regress an already terminal attempt from an older provider snapshot.
        if($a['state']==='expired' && $state!=='paid'){$conn->commit();return;}
        if($state==='paid'){
            $reference=$result['reference'];
            if($p['status']==='Paid' && ($p['reference_number']??'')!==$reference)throw new DomainException('Another payment is already recorded. Staff reconciliation required.');
            $s=$conn->prepare("UPDATE payments SET status='Paid',payment_method='GCash',reference_number=?,proof_file=NULL,paid_at=NOW(),submitted_at=NOW(),amount_received=amount,received_by='PayMongo sandbox (server verified)',admin_notes='Verified sandbox payment; no real funds received.' WHERE id=? AND status<>'Paid'");
            $s->bind_param('si',$reference,$p['id']);$s->execute();$new=$s->affected_rows>0;$s->close();
            if($p['payment_type']==='Reservation Fee'){
                $feeStatus=$booking['status']==='Cancelled'?'Refund Requested':'Paid';
                $s=$conn->prepare('UPDATE reservations SET reservation_fee_status=? WHERE id=?');$s->bind_param('si',$feeStatus,$rid);$s->execute();$s->close();
                if($booking['status']==='Cancelled'){$s=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE id=? AND refund_status='Not Applicable'");$s->bind_param('i',$p['id']);$s->execute();$s->close();}
            }
            $s=$conn->prepare("UPDATE payment_gateway_attempts SET state='paid',provider_payment_id=?,last_event_id=? WHERE id=?");$s->bind_param('ssi',$reference,$eventId,$a['id']);$s->execute();$s->close();
            if($new){
                $s=$conn->prepare("INSERT INTO notifications(user_id,title,message) SELECT user_id,'GCash sandbox payment verified','Your test payment was verified. No screenshot is needed. No real funds were received.' FROM reservations WHERE id=?");$s->bind_param('i',$rid);$s->execute();$s->close();
                $details='Sandbox provider payment '.$reference;
                $s=$conn->prepare("INSERT INTO admin_audit_logs(admin_name,action,entity_type,entity_id,details) VALUES('PayMongo sandbox','Gateway payment verified','payment',?,?)");$s->bind_param('is',$p['id'],$details);$s->execute();$s->close();
            }
        }else{
            // A validation mismatch remains blocked until staff reconciliation, even if retried.
            if($a['state']==='review'){$conn->commit();return;}
            $outcome=$result['outcome']??$state;
            $s=$conn->prepare('UPDATE payment_gateway_attempts SET state=?,last_outcome=?,last_event_id=? WHERE id=?');$s->bind_param('sssi',$state,$outcome,$eventId,$a['id']);$s->execute();$s->close();
            if($state==='expired'){
                $s=$conn->prepare("UPDATE payments SET status=? WHERE id=? AND status='Pending'");$s->bind_param('si',$a['previous_status'],$p['id']);$s->execute();$s->close();
            }
        }
        $conn->commit();
    }catch(Throwable $e){$conn->rollback();throw $e;}
}
function gcashReplyError(Throwable $e): void {
    http_response_code($e instanceof DomainException?409:503);
    header('Cache-Control: no-store');
    echo json_encode(['success'=>false,'message'=>$e instanceof DomainException?$e->getMessage():'Unable to verify GCash right now. Do not pay again until its status is checked.']);
}
