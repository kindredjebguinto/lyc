<?php
require_once __DIR__.'/../../config/bootstrap.php';require_once __DIR__.'/../../gateways/paymongo.php';
requireMethod('POST');header('Cache-Control: no-store');
try {
    $c=gcashConfig();$body=file_get_contents('php://input',false,null,0,1048577);
    if(strlen($body)>1048576 || !gcashVerifySignature($body,$_SERVER['HTTP_PAYMONGO_SIGNATURE']??'',$c['webhook_secret'])){
        http_response_code(401);echo json_encode(['success'=>false,'message'=>'Invalid webhook authentication.']);exit;
    }
    $event=json_decode($body,true,512,JSON_THROW_ON_ERROR)['data']??[];
    if(($event['type']??'')!=='event' || !preg_match('/^evt_[A-Za-z0-9]+$/D',$event['id']??''))throw new DomainException('Invalid webhook event.');
    $a=$event['attributes']??[];
    if(($a['livemode']??null)!==false)throw new DomainException('Only sandbox events are accepted.');
    if(($a['type']??'')!=='checkout_session.payment.paid'){echo json_encode(['success'=>true,'ignored'=>true]);exit;}
    $session=$a['data']??[];$sid=$session['id']??'';
    if(($session['type']??'')!=='checkout_session' || !preg_match('/^cs_[A-Za-z0-9]+$/D',$sid))throw new DomainException('Invalid checkout event.');
    $s=$conn->prepare('SELECT * FROM payment_gateway_attempts WHERE checkout_session_id=? LIMIT 1');$s->bind_param('s',$sid);$s->execute();$attempt=$s->get_result()->fetch_assoc();$s->close();
    // Retry when webhook arrives before checkout creation persisted its provider ID.
    if(!$attempt)throw new RuntimeException('Checkout mapping is not available yet.');
    gcashReconcile($conn,$attempt,$event['id']);echo json_encode(['success'=>true]);
}catch(Throwable $e){gcashReplyError($e);}
