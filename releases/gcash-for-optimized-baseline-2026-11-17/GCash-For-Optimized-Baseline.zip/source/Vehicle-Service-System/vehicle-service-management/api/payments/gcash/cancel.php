<?php
require_once __DIR__.'/../../config/bootstrap.php';require_once __DIR__.'/../../gateways/paymongo.php';
requireMethod('POST');$user=requireCustomer($conn);header('Cache-Control: no-store');
try {
    $id=(int)(jsonInput()['payment_id']??0);$p=gcashOwnedPayment($conn,$id,(int)$user['id']);
    $a=gatewayActiveAttempt($conn,$id);
    if(!$a || empty($a['checkout_session_id']) || $a['state']!=='pending')throw new DomainException('Check the payment status first. This attempt needs reconciliation before it can be closed.');
    // Expiry request is not proof of cancellation: always retrieve and verify again.
    gcashRequest('POST','checkout_sessions/'.rawurlencode($a['checkout_session_id']).'/expire',[]);
    gcashReconcile($conn,$a);
    $s=$conn->prepare("UPDATE payment_gateway_attempts SET last_outcome='cancelled' WHERE id=? AND state='expired'");$s->bind_param('i',$a['id']);$s->execute();$s->close();
    $s=$conn->prepare('SELECT * FROM payment_gateway_attempts WHERE id=?');$s->bind_param('i',$a['id']);$s->execute();$a=$s->get_result()->fetch_assoc();$s->close();
    $p=gcashOwnedPayment($conn,$id,(int)$user['id']);echo json_encode(gcashAttemptView($a,$p));
}catch(Throwable $e){gcashReplyError($e);}
