<?php
// Navigation only. No status mutation, no customer data, and no provider keys.
header('Content-Type: text/html; charset=UTF-8');header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'");
header('Referrer-Policy: no-referrer');
$id=max(0,(int)($_GET['payment_id']??0));
$link='luckyyuna://payments/return?payment_id='.$id;
?>
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Return to Lucky Yuna</title>
<style>body{font:18px system-ui;max-width:34rem;margin:12vh auto;padding:24px;line-height:1.6}a{display:inline-block;background:#111;color:white;padding:12px 20px;border-radius:12px;text-decoration:none}</style>
<h1>Continue in Lucky Yuna</h1><p>Your payment result will be checked securely in the app. Returning here does not confirm payment.</p>
<a href="<?=htmlspecialchars($link,ENT_QUOTES,'UTF-8')?>">Return to application</a><p>If the app does not open, open it manually and check Payments. Do not pay again while verification is pending.</p></html>
