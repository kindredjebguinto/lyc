<?php
require_once __DIR__.'/../../config/bootstrap.php';require_once __DIR__.'/../../gateways/paymongo.php';
requireMethod('GET');$user=requireCustomer($conn);header('Cache-Control: no-store');
try {
    $id=(int)($_GET['payment_id']??0);$p=gcashOwnedPayment($conn,$id,(int)$user['id']);$a=null;
    if(gatewayTableExists($conn)){
        $s=$conn->prepare('SELECT *,TIMESTAMPDIFF(SECOND,updated_at,NOW()) AS age_seconds FROM payment_gateway_attempts WHERE payment_id=? ORDER BY id DESC LIMIT 1');$s->bind_param('i',$id);$s->execute();$a=$s->get_result()->fetch_assoc();$s->close();
        if($a && in_array($a['state'],['pending','unknown','creating','review'],true) && $a['checkout_session_id'] && (int)$a['age_seconds']>=8){
            gcashReconcile($conn,$a);$p=gcashOwnedPayment($conn,$id,(int)$user['id']);
            $s=$conn->prepare('SELECT * FROM payment_gateway_attempts WHERE id=?');$s->bind_param('i',$a['id']);$s->execute();$a=$s->get_result()->fetch_assoc();$s->close();
        }
    }
    echo json_encode(gcashAttemptView($a,$p));
}catch(Throwable $e){gcashReplyError($e);}
