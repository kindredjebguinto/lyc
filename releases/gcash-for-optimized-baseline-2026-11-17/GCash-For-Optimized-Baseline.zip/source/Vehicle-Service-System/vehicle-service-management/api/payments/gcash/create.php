<?php
require_once __DIR__.'/../../config/bootstrap.php';
require_once __DIR__.'/../../gateways/paymongo.php';
requireMethod('POST');$user=requireCustomer($conn);header('Cache-Control: no-store');
$input=jsonInput();$id=(int)($input['payment_id']??0);$attempt=null;
try {
    $config=gcashConfig(true);
    if(!gatewayTableExists($conn))throw new DomainException('GCash database migration has not been installed.');
    $p=gcashOwnedPayment($conn,$id,(int)$user['id']);
    $conn->begin_transaction();
    $s=$conn->prepare('SELECT status FROM reservations WHERE id=? FOR UPDATE');$s->bind_param('i',$p['reservation_id']);$s->execute();$booking=$s->get_result()->fetch_assoc();$s->close();
    $s=$conn->prepare('SELECT * FROM payments WHERE id=? FOR UPDATE');$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();$s->close();
    if($p['status']==='Paid'){$conn->commit();echo json_encode(gcashAttemptView(null,$p));exit;}
    $active=gatewayActiveAttempt($conn,$id);
    if($active){$conn->commit();echo json_encode(gcashAttemptView($active,$p));exit;}
    if($booking['status']==='Cancelled' || !in_array($p['status'],['Awaiting Proof','Rejected','Pay at Shop'],true))throw new DomainException('Payment is not eligible for checkout.');
    if($p['payment_type']!=='Reservation Fee'){
        $s=$conn->prepare("SELECT id FROM job_quotations WHERE reservation_id=? AND status='Accepted' LIMIT 1");$s->bind_param('i',$p['reservation_id']);$s->execute();$ok=$s->get_result()->num_rows;$s->close();
        if(!$ok)throw new DomainException('Accept the service quotation first.');
    }
    $minor=gcashAmountMinor((string)$p['amount']);$token=bin2hex(random_bytes(24));$previous=$p['status'];
    $s=$conn->prepare('INSERT INTO payment_gateway_attempts(payment_id,attempt_token,expected_amount_minor,previous_status) VALUES(?,?,?,?)');$s->bind_param('isis',$id,$token,$minor,$previous);$s->execute();$aid=$conn->insert_id;$s->close();
    $s=$conn->prepare("UPDATE payments SET status='Pending',payment_method='GCash' WHERE id=?");$s->bind_param('i',$id);$s->execute();$s->close();
    $conn->commit();$attempt=['id'=>$aid];
    // The committed creating row reserves the payment during the external network call.
    $return=$config['return_url'].'?payment_id='.$id;
    $session=gcashRequest('POST','checkout_sessions',['data'=>['attributes'=>[
        'line_items'=>[['name'=>'Lucky Yuna '.$p['payment_type'],'amount'=>$minor,'currency'=>'PHP','quantity'=>1]],
        'payment_method_types'=>['gcash'],'success_url'=>$return,'cancel_url'=>$return.'&cancelled=1',
        'description'=>'Lucky Yuna sandbox payment #'.$id,'send_email_receipt'=>false,
        'show_description'=>true,'show_line_items'=>true,
        'metadata'=>['payment_id'=>(string)$id,'attempt_token'=>$token],
    ]]]);
    $sid=$session['id']??'';$url=$session['attributes']['checkout_url']??'';
    if(!preg_match('/^cs_[A-Za-z0-9]+$/D',$sid) || !gcashCheckoutUrl($url) || ($session['attributes']['livemode']??null)!==false)throw new RuntimeException('Unexpected checkout response.');
    $s=$conn->prepare("UPDATE payment_gateway_attempts SET checkout_session_id=?,checkout_url=?,state='pending' WHERE id=? AND state IN ('creating','unknown')");$s->bind_param('ssi',$sid,$url,$aid);$s->execute();$s->close();
    $a=gatewayActiveAttempt($conn,$id);$p=gcashOwnedPayment($conn,$id,(int)$user['id']);
    echo json_encode(gcashAttemptView($a,$p));
}catch(Throwable $e){
    $conn->rollback();
    if($attempt){$aid=$attempt['id'];$s=$conn->prepare("UPDATE payment_gateway_attempts SET state='unknown' WHERE id=? AND state='creating'");$s->bind_param('i',$aid);$s->execute();$s->close();}
    gcashReplyError($e);
}
