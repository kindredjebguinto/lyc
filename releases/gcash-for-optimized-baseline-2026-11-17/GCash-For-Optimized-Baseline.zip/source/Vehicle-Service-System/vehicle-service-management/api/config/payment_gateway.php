<?php
// Server environment only. Never put secrets in Flutter, Git, or public .env files.
// Sandbox-only implementation: live keys are deliberately rejected.
return [
    'enabled' => getenv('PAYMONGO_ENABLED') === '1',
    'secret_key' => getenv('PAYMONGO_SECRET_KEY') ?: '',
    'webhook_secret' => getenv('PAYMONGO_WEBHOOK_SECRET') ?: '',
    // Full public HTTPS URL ending /api/payments/gcash/return.php
    'return_url' => getenv('PAYMONGO_RETURN_URL') ?: '',
];
