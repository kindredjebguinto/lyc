<?php
// Shared by API, customer portal, admin portal and quote calculation.
// Caller holds the payment row lock until its write commits.
function gatewayTableExists(mysqli $conn): bool {
    static $ready = null;
    if ($ready === null) {
        $r = $conn->query("SELECT COUNT(*) n FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='payment_gateway_attempts'");
        $ready = (int)$r->fetch_assoc()['n'] > 0;
    }
    return $ready;
}
function gatewayActiveAttempt(mysqli $conn, int $paymentId): ?array {
    if (!gatewayTableExists($conn)) return null; // backwards compatible before migration
    $s=$conn->prepare("SELECT * FROM payment_gateway_attempts WHERE payment_id=? AND state IN ('creating','pending','unknown','review') ORDER BY id DESC LIMIT 1");
    $s->bind_param('i',$paymentId);$s->execute();$r=$s->get_result()->fetch_assoc();$s->close();return $r;
}
function gatewayAssertManualAllowed(mysqli $conn, int $paymentId): void {
    $s=$conn->prepare('SELECT reservation_id FROM payments WHERE id=?');$s->bind_param('i',$paymentId);$s->execute();$row=$s->get_result()->fetch_assoc();$s->close();
    if($row){$rid=(int)$row['reservation_id'];$s=$conn->prepare('SELECT id FROM reservations WHERE id=? FOR UPDATE');$s->bind_param('i',$rid);$s->execute();$s->get_result();$s->close();}
    $s=$conn->prepare('SELECT id FROM payments WHERE id=? FOR UPDATE');$s->bind_param('i',$paymentId);$s->execute();$s->get_result();$s->close();
    if (gatewayActiveAttempt($conn,$paymentId)) throw new DomainException('A GCash checkout is active or awaiting reconciliation. Check its verified gateway status before accepting another payment.');
}
