# Staff workspace update

Implemented the recommended admin structure and workflows:

- Today: date-specific active appointments, arrival/check-in tasks, actionable confirmation, assignment, quotation, proof and refund queues. Financial cards appear only for authorized roles.
- Schedule: a column per active mechanic, half-hour rows, complete reserved intervals, free cells and an unassigned lane. Mechanic accounts see only their linked mechanic's schedule.
- Jobs: searchable, paginated queues with plain-language statuses and the next action. Job workspace combines customer/vehicle information, check-in, assignment, service notes, quotation, all payment records, prior vehicle history and staff activity.
- Payments: separate verification, unpaid, refund and verified queues, type/search filters, side-by-side proof and amount/reference, required rejection reason, verifier identity and audit log. Proofs are served only to authorized staff; direct Apache file access is denied.
- Role-focused navigation and server permissions for Manager, Service Adviser, Cashier, Mechanic and read-only Staff. Authority is reloaded on each request. Mechanic scope is checked on both views and writes. POST forms require CSRF, including legacy forms.
- Workflow guardrails: arrival and reserved time before inspection, work notes before pickup-ready, resolved payment before vehicle release. The older reservation-action endpoint now uses the same state-transition rules.
- Customer quotation decisions can be recorded with a consent reference. They unlock service work and create an idempotent final balance. Accepted/rejected quotations become read-only. Verified, unrefunded fee amounts are credited instead of an unconditional 200; a covered balance needs no additional transfer.
- One-time localhost manager initialization, a clean fresh-install SQL, an upgrade migration and a XAMPP testing guide. Local Bootstrap assets/icons and licenses eliminate website styling CDN dependencies.

## Verification

- Five-role page/endpoint permissions, mechanic list/schedule/job scope, denied foreign edits, CSRF, inspection, notes, quotation, work, payment and release checks passed.
- Customer decision reference, final-balance creation, agreed-quote read-only behavior, verifier audit and immediate permission revocation checks passed.
- Responsive admin pages at 390, 768 and 1440 pixels passed without page-wide horizontal overflow.
- Isolated balance tests passed for unverified, paid, refunded and refund-requested fees, actual fee amount, credit cap, zero balance, idempotency, unsubmitted guest estimate and verified-payment conflict.
- Fresh SQL import and Apache manager setup/login/pages/native CSRF/authorized proof serving/direct-file denial passed.
- Existing website, booking-capacity and payment-proof checks and PHP/JavaScript syntax checks passed. Test records/proofs were removed.

See XAMPP_TESTING_GUIDE.md for installation and the test workflow. Flutter source is supplied but its build remains unverified; no APK or Windows XAMPP run is claimed. No real provider transactions or merchant details were created.
