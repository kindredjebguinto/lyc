<?php
// One-time local XAMPP setup. Never provides a default or shared password.
require_once __DIR__.'/includes/config.php';
if(session_status()===PHP_SESSION_NONE)session_start();
$remote=$_SERVER['REMOTE_ADDR']??'';$host=strtolower($_SERVER['HTTP_HOST']??'');
$local=in_array($remote,['127.0.0.1','::1'],true)&&preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/',$host);
if(!$local){http_response_code(403);exit('Initial manager setup is available only from localhost on the XAMPP computer.');}
$hasLevel=$conn->query("SHOW COLUMNS FROM users LIKE 'staff_level'")->num_rows>0;
if(!$hasLevel){http_response_code(503);exit('Import the database installation SQL before creating the first manager.');}
if((int)$conn->query("SELECT COUNT(*) n FROM users WHERE role='staff' AND staff_level='Manager'")->fetch_assoc()['n']){http_response_code(404);exit('Initial setup is closed. Sign in with an existing manager account.');}
if(empty($_SESSION['setup_csrf']))$_SESSION['setup_csrf']=bin2hex(random_bytes(32));$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $token=$_POST['csrf_token']??'';$name=trim($_POST['fullname']??'');$email=strtolower(trim($_POST['email']??''));$password=$_POST['password']??'';
 if(!is_string($token)||!hash_equals($_SESSION['setup_csrf'],$token))$error='The form expired. Refresh and try again.';
 elseif(!$name||strlen($name)>100||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>100||strlen($password)<12)$error='Enter your name, a valid email and a password of at least 12 characters.';
 else{
  try{
   $locked=(int)$conn->query("SELECT GET_LOCK('lyc-first-manager',10) acquired")->fetch_assoc()['acquired'];if(!$locked)throw new RuntimeException();
   if((int)$conn->query("SELECT COUNT(*) n FROM users WHERE role='staff' AND staff_level='Manager'")->fetch_assoc()['n'])throw new DomainException('A manager was already created. Sign in instead.');
   $hash=password_hash($password,PASSWORD_DEFAULT);$stmt=$conn->prepare("INSERT INTO users(fullname,email,password,role,staff_level) VALUES(?,?,?,'staff','Manager')");$stmt->bind_param('sss',$name,$email,$hash);$stmt->execute();$stmt->close();$conn->query("SELECT RELEASE_LOCK('lyc-first-manager')");unset($_SESSION['setup_csrf']);$_SESSION['manager_setup_complete']=true;header('Location: login.php');exit;
  }catch(Throwable $e){$conn->query("SELECT RELEASE_LOCK('lyc-first-manager')");$error=$e instanceof DomainException?$e->getMessage():'The manager could not be created. Check whether this email already exists and try again.';}
 }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create first manager | Luck Yuna</title><style>body{font:16px system-ui;background:#f7f7f7;color:#222;margin:0;padding:24px}main{max-width:480px;margin:6vh auto;background:white;border:1px solid #ddd;border-radius:16px;padding:28px}label{display:block;margin-top:16px}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #aaa;border-radius:8px;font:inherit;margin-top:6px}button{margin-top:20px;background:#b71920;color:white;padding:14px;border:0;border-radius:8px;width:100%;font:inherit}.error{color:#9d1515}</style></head><body><main><h1>Create your manager account</h1><p>This one-time setup works only on the XAMPP computer and closes after the first manager is created.</p><?php if($error):?><p class="error" role="alert"><?= htmlspecialchars($error) ?></p><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['setup_csrf']) ?>"><label for="setupName">Full name</label><input id="setupName" name="fullname" maxlength="100" required><label for="setupEmail">Email</label><input id="setupEmail" name="email" type="email" maxlength="100" autocomplete="username" required><label for="setupPassword">Password (at least 12 characters)</label><input id="setupPassword" name="password" type="password" minlength="12" autocomplete="new-password" required><button>Create manager</button></form><p><a href="login.php">Back to staff sign in</a></p></main></body></html>
