<?php
function adminH($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function adminCan(string $capability): bool
{
    $grants = [
        'Manager'=>['*'],
        'Service Adviser'=>['today','schedule','jobs.view','jobs.manage','jobs.work','quotes','customers','team.view','services.view'],
        'Cashier'=>['today','jobs.view','finance'],
        'Mechanic'=>['today','schedule','jobs.view','jobs.work'],
        'Staff'=>['today','schedule','jobs.view','services.view'],
    ];
    $allowed = $grants[$_SESSION['admin_staff_level'] ?? 'Staff'] ?? [];
    return in_array('*', $allowed, true) || in_array($capability, $allowed, true);
}
function adminDeny(string $message = 'Your staff role does not have access to this action.'): void
{
    http_response_code(403);
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Access restricted</title><body style="font:16px system-ui;padding:40px;max-width:680px;margin:auto"><h1>Access restricted</h1><p>'.adminH($message).'</p><a href="'.ADMIN_BASE_URL.'/dashboard.php">Return to Today</a></body></html>';
    exit;
}
function adminIsMechanic(): bool { return ($_SESSION['admin_staff_level'] ?? '') === 'Mechanic'; }
function adminJobScope(string $alias = 'r'): string
{
    if (!adminIsMechanic()) return '';
    $id=(int)($_SESSION['admin_mechanic_id'] ?? 0);
    return $id ? ' AND '.$alias.'.mechanic_id='.$id : ' AND 1=0';
}
function adminRequireJob(mysqli $conn, int $id): array
{
    $stmt = $conn->prepare('SELECT * FROM reservations r WHERE r.id=?'.adminJobScope('r').' LIMIT 1');
    $stmt->bind_param('i', $id); $stmt->execute(); $job = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$job) adminDeny('This job is unavailable or is not assigned to your mechanic account.');
    return $job;
}
function adminStatus(string $status): string
{
    return ['Pending'=>'Awaiting confirmation','Approved'=>'Appointment confirmed','Diagnosing'=>'Vehicle inspection','Quotation Sent'=>'Waiting for customer approval','Quotation Accepted'=>'Ready to start work','In Progress'=>'Work in progress','Ready for Pickup'=>'Ready for pickup','Completed'=>'Completed','Cancelled'=>'Cancelled','Under Review'=>'Proof to verify','Awaiting Proof'=>'Waiting for payment proof','Rejected'=>'Proof needs correction','Paid'=>'Payment verified','Pay at Shop'=>'Pay at the shop'][$status] ?? $status;
}
function adminBadge(string $status): string
{
    $tone = match($status) {
        'Paid','Completed'=>'success', 'Cancelled','Rejected'=>'danger',
        'In Progress','Diagnosing','Under Review'=>'info',
        'Approved','Quotation Accepted'=>'primary', default=>'warning'
    };
    return '<span class="badge rounded-pill text-bg-'.$tone.'">'.adminH(adminStatus($status)).'</span>';
}
function adminNextAction(array $job): array
{
    $id = (int)$job['id'];
    $url = 'reservation_view.php?id='.$id;
    if ($job['status'] === 'Pending' && ($job['reservation_fee_status'] ?? '') !== 'Paid' && ($job['fee_required'] ?? !empty($job['user_id']))) {
        return ['Review reservation fee', $url.'#job-payments', 'Verify the fee before confirming the appointment.'];
    }
    if (in_array($job['status'],['Approved','Quotation Accepted'],true) && empty($job['checked_in_at'])) return ['Check in vehicle', $url.'#job-action', 'Record the customer’s arrival before starting inspection.'];
    if ($job['status'] === 'Approved' && empty($job['mechanic_id'])) return ['Assign mechanic', $url.'#job-action', 'Choose a mechanic who is free for the full job.'];
    return match($job['status']) {
        'Pending'=>['Confirm appointment',$url.'#job-action','Check the schedule and customer details.'],
        'Approved'=>['Start inspection',$url.'#job-action','Available when the appointment time arrives.'],
        'Diagnosing'=>['Prepare quotation',$url.'#job-record','Record the diagnosis, then prepare the quotation.'],
        'Quotation Sent'=>['Waiting for customer',$url,'The customer needs to respond to the quotation.'],
        'Quotation Accepted'=>['Start work',$url.'#job-action','The customer has accepted the quotation.'],
        'In Progress'=>['Complete service work',$url.'#job-record','Record the work performed before marking ready.'],
        'Ready for Pickup'=>['Review payment and release',$url.'#job-payments','Check the balance before releasing the vehicle.'],
        default=>['View job',$url,'Open the complete job record.']
    };
}
function adminActor(): string
{
    $letters=preg_split('//u',$_SESSION['admin_name']??'Staff',-1,PREG_SPLIT_NO_EMPTY)?:[];
    return implode('',array_slice($letters,0,75)).' (#'.(int)($_SESSION['admin_id']??0).')';
}
function adminAudit(mysqli $conn, string $action, string $entity, int $id, string $details): void
{
    $actor=adminActor();
    $stmt = $conn->prepare('INSERT INTO admin_audit_logs(admin_name,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)');
    $stmt->bind_param('sssis',$actor,$action,$entity,$id,$details); $stmt->execute(); $stmt->close();
}
function adminCsrfInput(): string { return '<input type="hidden" name="csrf_token" value="'.adminH($_SESSION['admin_csrf_token']).'">'; }
