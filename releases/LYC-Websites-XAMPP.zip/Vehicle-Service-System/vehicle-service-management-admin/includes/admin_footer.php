        </div>

        </main>

        </div>

        <script src="<?= PUBLIC_BASE_URL ?>/vendor/bootstrap/js/bootstrap.bundle.min.js">
        </script>

        <script src="<?= ADMIN_BASE_URL ?>/js/admin.js"></script>

        </body>

        </html>