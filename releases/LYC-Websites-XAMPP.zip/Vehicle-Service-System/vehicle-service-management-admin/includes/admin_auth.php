<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/workspace.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? '') !== 'staff') {
    header('Location: '.ADMIN_BASE_URL.'/login.php'); exit;
}
// Reload authority from the database, so a demotion takes effect immediately.
$hasMapping = $conn->query("SHOW COLUMNS FROM users LIKE 'mechanic_id'")->num_rows > 0;
$stmt = $conn->prepare('SELECT fullname,role,staff_level,'.($hasMapping?'mechanic_id':'NULL AS mechanic_id').' FROM users WHERE id=? LIMIT 1');
$stmt->bind_param('i', $_SESSION['admin_id']); $stmt->execute(); $account=$stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$account || $account['role'] !== 'staff') { unset($_SESSION['admin_id'],$_SESSION['admin_role']); header('Location: '.ADMIN_BASE_URL.'/login.php'); exit; }
$_SESSION['admin_staff_level']=$account['staff_level'] ?: 'Staff';
$_SESSION['admin_name']=$account['fullname']; $_SESSION['admin_mechanic_id']=(int)($account['mechanic_id']??0);
if (empty($_SESSION['admin_csrf_token'])) $_SESSION['admin_csrf_token']=bin2hex(random_bytes(32));
date_default_timezone_set('Asia/Manila');
$conn->query("SET time_zone='+08:00'");
$pages = [
 'dashboard.php'=>'today','schedule.php'=>'schedule','reservations.php'=>'jobs.view','reservation_view.php'=>'jobs.view',
 'reservation_update.php'=>'jobs.work','service_record_save.php'=>'jobs.work',
 'walk_in.php'=>'jobs.manage','check_in.php'=>'jobs.manage','reservation_action.php'=>'jobs.manage','assign_mechanic.php'=>'jobs.manage','job_quotation.php'=>'quotes',
 'customers.php'=>'customers','customer_view.php'=>'customers',
 'mechanics.php'=>'team.view','mechanic_add.php'=>'team.manage','mechanic_edit.php'=>'team.manage','mechanic_status.php'=>'team.manage',
 'services.php'=>'services.view','service_add.php'=>'services.manage','service_edit.php'=>'services.manage',
 'payments.php'=>'finance','payment_view.php'=>'finance','payment_add.php'=>'finance','payment_proof.php'=>'finance',
 'reports.php'=>'reports','report_export.php'=>'reports','staff_accounts.php'=>'staff.manage','password_requests.php'=>'accounts.manage','audit_logs.php'=>'audit'
];
$page = basename($_SERVER['SCRIPT_FILENAME'] ?? '');
if (!isset($pages[$page]) || !adminCan($pages[$page])) adminDeny();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token=$_POST['csrf_token']??'';
    if (!is_string($token) || !hash_equals($_SESSION['admin_csrf_token'],$token)) { http_response_code(419); exit('The form expired. Go back, refresh the page and try again.'); }
}
