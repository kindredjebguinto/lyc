<?php
require_once __DIR__.'/admin_auth.php';
$currentAdminPage=basename($_SERVER['SCRIPT_FILENAME']);
$navigation=[
 ['Operations','Today','dashboard.php','today',['dashboard.php']],
 ['Operations','Schedule','schedule.php','schedule',['schedule.php']],
 ['Operations',adminIsMechanic()?'My jobs':'Jobs','reservations.php','jobs.view',['reservations.php','reservation_view.php','job_quotation.php']],
 ['Operations','Customers','customers.php','customers',['customers.php','customer_view.php']],
 ['Operations','Payments','payments.php','finance',['payments.php','payment_view.php','payment_add.php']],
 ['Management','Team','mechanics.php','team.view',['mechanics.php','mechanic_add.php','mechanic_edit.php']],
 ['Management','Services','services.php','services.view',['services.php','service_add.php','service_edit.php']],
 ['Management','Reports','reports.php','reports',['reports.php']],
 ['Management','Staff access','staff_accounts.php','staff.manage',['staff_accounts.php']],
 ['Management','Account requests','password_requests.php','accounts.manage',['password_requests.php']],
 ['Management','Activity log','audit_logs.php','audit',['audit_logs.php']],
];
// Supply a native CSRF field to legacy POST forms as well as new workspace forms.
ob_start(function($html) {
    return preg_replace_callback('/(<form\b[^>]*\bmethod\s*=\s*["\']?post["\']?[^>]*>)(.*?)(<\/form>)/is', function($match) {
        return $match[1].(preg_match('/name\s*=\s*["\']csrf_token["\']/i',$match[2])?'':adminCsrfInput()).$match[2].$match[3];
    }, $html);
});
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Staff workspace | Luck Yuna Car Center</title>
<link href="<?= PUBLIC_BASE_URL ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= ADMIN_BASE_URL ?>/css/admin.css?v=<?= filemtime(__DIR__.'/../css/admin.css') ?>">
<link rel="stylesheet" href="<?= ADMIN_BASE_URL ?>/css/workspace.css?v=<?= filemtime(__DIR__.'/../css/workspace.css') ?>">
</head><body>
<a class="skip-link" href="#workspace-content">Skip to content</a>
<div class="admin-wrapper">
<aside class="sidebar" id="staffNavigation" aria-label="Staff navigation"><div class="sidebar-logo"><img src="<?= PUBLIC_BASE_URL ?>/images/logo.png" alt=""><span>Luck Yuna<br><small>Staff workspace</small></span></div>
<nav><ul class="sidebar-menu"><?php $group=''; foreach($navigation as [$section,$label,$url,$cap,$activePages]): if(!adminCan($cap)) continue; if($group!==$section):$group=$section;?><li class="menu-label"><?= adminH($section) ?></li><?php endif; ?>
<li><a href="<?= ADMIN_BASE_URL.'/'.$url ?>" <?= in_array($currentAdminPage,$activePages,true)?'class="active" aria-current="page"':'' ?>><?= adminH($label) ?></a></li><?php endforeach; ?>
<li class="logout-item"><a href="<?= ADMIN_BASE_URL ?>/logout.php">Sign out</a></li></ul></nav></aside>
<main class="admin-main"><header class="topbar"><div class="d-flex align-items-center gap-3"><button type="button" class="btn btn-light nav-toggle" id="staffMenuToggle" aria-controls="staffNavigation" aria-expanded="false">Menu</button><strong>Daily service desk</strong></div><div class="admin-user"><span class="admin-avatar"><?= adminH(strtoupper(substr($_SESSION['admin_name'],0,1))) ?></span><span><strong><?= adminH($_SESSION['admin_name']) ?></strong><small><?= adminH($_SESSION['admin_staff_level']) ?></small></span></div></header>
<div class="admin-content" id="workspace-content" tabindex="-1">
<?php if(adminIsMechanic() && !$_SESSION['admin_mechanic_id']): ?><div class="alert alert-warning">Your account is not linked to a mechanic yet. Ask a manager to link it in Staff access. No job records will be shown until then.</div><?php endif; ?>
