<?php
include_once __DIR__ . "/includes/config.php";
include_once __DIR__ . "/includes/admin_auth.php";

require_once __DIR__.'/../vehicle-service-management/includes/payment_balance.php';

$reservation_id = intval($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT r.*, c.fullname AS customer_name, v.brand, v.model, v.plate_number
  FROM reservations r LEFT JOIN customers c ON r.customer_id=c.id
  LEFT JOIN vehicles v ON r.vehicle_id=v.id WHERE r.id=? LIMIT 1");
mysqli_stmt_bind_param($stmt, "i", $reservation_id);
mysqli_stmt_execute($stmt);
$reservation = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
if (!$reservation) { header("Location: ".ADMIN_BASE_URL."/reservations.php"); exit; }
$hasAppAccount = !empty($reservation['user_id']);

function load_quote($conn, $reservation_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM job_quotations WHERE reservation_id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $reservation_id); mysqli_stmt_execute($stmt);
    $quote = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)); mysqli_stmt_close($stmt);
    if ($quote) {
        $stmt = mysqli_prepare($conn, "SELECT * FROM job_quotation_items WHERE quotation_id=? ORDER BY id");
        mysqli_stmt_bind_param($stmt, "i", $quote['id']); mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt); $quote['items'] = [];
        while ($row = mysqli_fetch_assoc($result)) $quote['items'][] = $row;
        mysqli_stmt_close($stmt);
    }
    return $quote;
}

$message = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prior=load_quote($conn,$reservation_id);
    if(in_array($reservation['status'],['Completed','Cancelled'],true)||($prior&&in_array($prior['status'],['Accepted','Rejected'],true))){http_response_code(409);exit('This quotation is closed to editing. Review its saved version from the job workspace.');}
    $decision=$_POST['status']??'Draft';
    $consent=trim($_POST['customer_consent']??'');
    if(in_array($decision,['Accepted','Rejected'],true)&&($consent===''||strlen($consent)>400)){http_response_code(422);exit('Record the customer approval/rejection reference before saving this decision.');}

    $types = $_POST['item_type'] ?? []; $descriptions = $_POST['description'] ?? [];
    $quantities = $_POST['quantity'] ?? []; $prices = $_POST['unit_price'] ?? []; $additionals=$_POST['is_additional']??[];
    $items = []; $subtotal = 0;
    foreach ($descriptions as $i => $description) {
        $description = trim($description); $quantity = max(0.01, floatval($quantities[$i] ?? 1));
        $price = max(0, floatval($prices[$i] ?? 0));
        $type = in_array(($types[$i] ?? ''), ['Service','Part','Labor','Other'], true) ? $types[$i] : 'Other';
        if ($description === '') continue;
        $amount = round($quantity * $price, 2); $subtotal += $amount;
        $isAdditional = !empty($additionals[$i]) ? 1 : 0;
        $items[] = [$type, $description, $quantity, $price, $amount, $isAdditional];
    }
    if (!$items) $error = 'Add at least one quotation item.';
    else {
        $discount = max(0, floatval($_POST['discount'] ?? 0));
        $tax = max(0, floatval($_POST['tax'] ?? 0));
        $grand_total = max(0, round($subtotal - $discount + $tax, 2));
        $notes = trim($_POST['notes'] ?? ''); $valid_until = $_POST['valid_until'] ?: null;
        $status = in_array(($_POST['status'] ?? ''), ['Draft','Sent','Accepted','Rejected'], true) ? $_POST['status'] : 'Draft';
        $existing = load_quote($conn, $reservation_id);
        mysqli_begin_transaction($conn);
        try {
            if ($existing) {
                $quote_id = intval($existing['id']);
                $stmt = mysqli_prepare($conn, "UPDATE job_quotations SET subtotal=?,discount=?,tax=?,grand_total=?,notes=?,status=?,valid_until=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, "ddddsssi", $subtotal, $discount, $tax, $grand_total, $notes, $status, $valid_until, $quote_id);
                mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
                $stmt = mysqli_prepare($conn, "DELETE FROM job_quotation_items WHERE quotation_id=?");
                mysqli_stmt_bind_param($stmt, "i", $quote_id); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
            } else {
                $number = 'JQ-'.date('Ymd').'-'.strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
                $stmt = mysqli_prepare($conn, "INSERT INTO job_quotations (quotation_number,reservation_id,subtotal,discount,tax,grand_total,notes,status,valid_until) VALUES (?,?,?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt, "siddddsss", $number, $reservation_id, $subtotal, $discount, $tax, $grand_total, $notes, $status, $valid_until);
                mysqli_stmt_execute($stmt); $quote_id = mysqli_insert_id($conn); mysqli_stmt_close($stmt);
            }
            $stmt = mysqli_prepare($conn, "INSERT INTO job_quotation_items (quotation_id,item_type,description,quantity,unit_price,amount,is_additional,customer_decision) VALUES (?,?,?,?,?,?,?,?)");
            foreach ($items as $item) {
                [$type,$description,$quantity,$price,$amount,$isAdditional] = $item;
                $decision=$isAdditional?'Pending':null;
                mysqli_stmt_bind_param($stmt, "issdddis", $quote_id, $type, $description, $quantity, $price, $amount, $isAdditional, $decision);
                mysqli_stmt_execute($stmt);
            }
            mysqli_stmt_close($stmt);
            $version_result = mysqli_query($conn, "SELECT COALESCE(MAX(version_number),0)+1 next_version FROM job_quotation_versions WHERE quotation_id=".intval($quote_id));
            $version_number = intval(mysqli_fetch_assoc($version_result)['next_version']);
            $snapshot = json_encode(['subtotal'=>$subtotal,'discount'=>$discount,'tax'=>$tax,'grand_total'=>$grand_total,'notes'=>$notes,'status'=>$status,'valid_until'=>$valid_until,'items'=>$items], JSON_UNESCAPED_UNICODE);
            $stmt = mysqli_prepare($conn, "INSERT INTO job_quotation_versions (quotation_id,version_number,snapshot_json) VALUES (?,?,?)");
            mysqli_stmt_bind_param($stmt, "iis", $quote_id, $version_number, $snapshot); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
            if ($status === 'Sent' && (!$existing || $existing['status'] !== 'Sent')) {
                $status_stmt = mysqli_prepare($conn, "UPDATE reservations SET status='Quotation Sent' WHERE id=? AND status IN ('Approved','Diagnosing')");
                mysqli_stmt_bind_param($status_stmt, "i", $reservation_id); mysqli_stmt_execute($status_stmt); mysqli_stmt_close($status_stmt);
                // A guest walk-in can receive a printed/PDF quote without an app
                // account. A user-0 notification would violate the foreign key
                // and roll back the quote, its items and the job-stage update.
                if ($hasAppAccount) {
                    $title = 'Job quotation ready';
                    $notice = 'Your itemized job quotation is ready. Total: PHP '.number_format($grand_total, 2).'.';
                    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (user_id,title,message,link_type,link_id) VALUES (?,?,?,'reservation',?)");
                    $reservation_user_id = intval($reservation['user_id']);
                    mysqli_stmt_bind_param($stmt, "issi", $reservation_user_id, $title, $notice, $reservation_id);
                    mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
                }
            }
            if($status==='Accepted'){
                $stage=$conn->prepare("UPDATE reservations SET status='Quotation Accepted' WHERE id=? AND status IN ('Approved','Diagnosing','Quotation Sent')");$stage->bind_param('i',$reservation_id);$stage->execute();$stage->close();
                createFinalBalance($conn,$reservation_id,$grand_total);
            }
            if($status==='Rejected'){
                $stage=$conn->prepare("UPDATE reservations SET status='Cancelled',cancellation_reason='Quotation rejected by customer' WHERE id=? AND status IN ('Approved','Diagnosing','Quotation Sent')");$stage->bind_param('i',$reservation_id);$stage->execute();$stage->close();
                $refund=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid' AND refund_status='Not Applicable'");$refund->bind_param('i',$reservation_id);$refund->execute();$refund->close();$feeState=$conn->prepare("UPDATE reservations SET reservation_fee_status='Refund Requested',refund_eligibility='Verified fee refund requested.' WHERE id=? AND EXISTS(SELECT 1 FROM payments p WHERE p.reservation_id=reservations.id AND p.payment_type='Reservation Fee' AND p.refund_status='Requested')");$feeState->bind_param('i',$reservation_id);$feeState->execute();$feeState->close();
            }
            adminAudit($conn,'Saved quotation','reservation',$reservation_id,'Status: '.$status.(in_array($status,['Accepted','Rejected'],true)?'; customer decision reference: '.$consent:''));
            mysqli_commit($conn); $_SESSION['admin_flash']=['type'=>'success','message'=>'Job quotation saved successfully.'];header('Location: reservation_view.php?id='.$reservation_id);exit;
        } catch (Throwable $e) { mysqli_rollback($conn); $error = $e instanceof DomainException ? $e->getMessage() : 'Unable to save the quotation. Refresh and try again.'; }
    }
}

$quote = load_quote($conn, $reservation_id);
if (!$quote) {
    $quote = ['discount'=>0,'tax'=>0,'notes'=>'','status'=>'Draft','valid_until'=>'','items'=>[]];
    $service_result = mysqli_query($conn, "SELECT service_name,price FROM services"); $service_prices=[];
    while ($service = mysqli_fetch_assoc($service_result)) $service_prices[strtolower(trim($service['service_name']))] = $service['price'];
    foreach (explode(',', $reservation['service_type']) as $service_name) {
        $service_name=trim($service_name); if ($service_name==='') continue;
        $price=$service_prices[strtolower($service_name)] ?? 0;
        $quote['items'][]=['item_type'=>'Service','description'=>$service_name,'quantity'=>1,'unit_price'=>$price];
    }
}
$version_count = 0;
if (!empty($quote['id'])) { $version_result=mysqli_query($conn,"SELECT COUNT(*) total FROM job_quotation_versions WHERE quotation_id=".intval($quote['id'])); $version_count=intval(mysqli_fetch_assoc($version_result)['total']); }
include "includes/admin_header.php";
?>
<div class="container-fluid">
 <div class="d-flex justify-content-between align-items-center mb-4">
  <div><h2>Job Quotation</h2><p class="text-muted mb-0"><?= htmlspecialchars($reservation['customer_name']) ?> • <?= htmlspecialchars($reservation['brand'].' '.$reservation['model'].' ('.$reservation['plate_number'].')') ?></p></div>
  <a class="btn btn-secondary" href="<?= ADMIN_BASE_URL ?>/reservation_view.php?id=<?= $reservation_id ?>">← Reservation</a>
 </div>
 <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
 <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
 <?php if (!$hasAppAccount): ?><p class="alert alert-info">This booking is not linked to an app account. Use <strong>Print / Save PDF</strong> to show the quotation to the customer. Select <strong>Presented to customer</strong> after presenting it, then record Accepted or Rejected with the customer's decision reference. No app notification, email or SMS is sent for this guest booking.</p><?php else: ?><p class="text-muted">Saving with status Sent makes the quotation available in the customer's app and creates an in-app notification.</p><?php endif; ?>
 <?php $quoteLocked=in_array($quote['status'],['Accepted','Rejected'],true)||in_array($reservation['status'],['Completed','Cancelled'],true); if($quoteLocked): ?><p class="alert alert-info">Customer decision recorded. This quotation is read-only so the agreed amount stays consistent with billing.</p><?php endif; ?>
<button type="button" onclick="window.print()" class="btn btn-outline-secondary me-2">Print / Save PDF</button>
 <form method="post" class="dashboard-card"><fieldset <?= $quoteLocked?'disabled':'' ?>>
  <?php if (!empty($quote['quotation_number'])): ?><div class="mb-3 d-flex justify-content-between"><strong><?= htmlspecialchars($quote['quotation_number']) ?></strong><span class="badge text-bg-light">Revision <?= $version_count ?></span></div><?php endif; ?>
  <div class="table-responsive"><table class="table align-middle" id="itemsTable"><thead><tr><th>Type</th><th>Description</th><th style="width:110px">Qty</th><th style="width:150px">Unit Price</th><th style="width:110px">Additional</th><th style="width:140px">Amount</th><th></th></tr></thead><tbody>
  <?php foreach ($quote['items'] as $item): ?><tr>
   <td><select name="item_type[]" class="form-select"><?php foreach(['Service','Part','Labor','Other'] as $type): ?><option <?= $item['item_type']===$type?'selected':'' ?>><?= $type ?></option><?php endforeach; ?></select></td>
   <td><input required class="form-control" name="description[]" value="<?= htmlspecialchars($item['description']) ?>"></td>
   <td><input required min="0.01" step="0.01" class="form-control qty" name="quantity[]" value="<?= htmlspecialchars($item['quantity']) ?>"></td>
   <td><input required min="0" step="0.01" class="form-control price" name="unit_price[]" value="<?= htmlspecialchars($item['unit_price']) ?>"></td><td><input type="hidden" name="is_additional[]" value="0"><input type="checkbox" onchange="this.previousElementSibling.value=this.checked?'1':'0'" <?= !empty($item['is_additional'])?'checked':'' ?>></td>
   <td class="line-total fw-bold">0.00</td><td><button type="button" class="btn btn-outline-danger remove-row">×</button></td>
  </tr><?php endforeach; ?>
  </tbody></table></div>
  <button type="button" id="addRow" class="btn btn-outline-primary mb-4">+ Add Item</button>
  <div class="row g-3"><div class="col-md-3"><label class="form-label">Discount (PHP)</label><input min="0" step="0.01" type="number" class="form-control total-input" name="discount" value="<?= htmlspecialchars($quote['discount']) ?>"></div>
  <div class="col-md-3"><label class="form-label">Tax (PHP)</label><input min="0" step="0.01" type="number" class="form-control total-input" name="tax" value="<?= htmlspecialchars($quote['tax']) ?>"></div>
  <div class="col-md-3"><label class="form-label">Valid Until</label><input type="date" class="form-control" name="valid_until" value="<?= htmlspecialchars($quote['valid_until'] ?? '') ?>"></div>
  <div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status"><?php foreach(['Draft','Sent','Accepted','Rejected'] as $quote_status): ?><option value="<?= $quote_status ?>" <?= $quote['status']===$quote_status?'selected':'' ?>><?= $quote_status==='Sent'&&!$hasAppAccount?'Presented to customer':$quote_status ?></option><?php endforeach; ?></select></div></div>
  <div class="row mt-3"><div class="col-lg-8"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="3"><?= htmlspecialchars($quote['notes'] ?? '') ?></textarea></div>
  <div class="col-lg-4"><div class="bg-light rounded p-3"><div class="d-flex justify-content-between"><span>Subtotal</span><strong id="subtotal">PHP 0.00</strong></div><div class="d-flex justify-content-between border-top mt-2 pt-2 fs-5"><span>Total</span><strong id="grandTotal">PHP 0.00</strong></div></div></div></div>
  <div class="mt-3"><label class="form-label" for="customerConsent">Customer decision reference (required for Accepted or Rejected)</label><input class="form-control" id="customerConsent" name="customer_consent" maxlength="400" placeholder="For example: customer approved by phone, with date and staff notes"><small class="text-muted">Use Draft or Sent until the customer has actually responded. Their response is recorded in job activity.</small></div>
  <div class="text-end mt-4"><button class="btn btn-primary px-4">Save Quotation</button></div>
 </fieldset></form>
</div>
<template id="rowTemplate"><tr><td><select name="item_type[]" class="form-select"><option>Service</option><option>Part</option><option>Labor</option><option>Other</option></select></td><td><input required class="form-control" name="description[]"></td><td><input required min="0.01" step="0.01" class="form-control qty" name="quantity[]" value="1"></td><td><input required min="0" step="0.01" class="form-control price" name="unit_price[]" value="0"></td><td><input type="hidden" name="is_additional[]" value="0"><input type="checkbox" onchange="this.previousElementSibling.value=this.checked?'1':'0'"></td><td class="line-total fw-bold">0.00</td><td><button type="button" class="btn btn-outline-danger remove-row">×</button></td></tr></template>
<script>
const tbody=document.querySelector('#itemsTable tbody');
function calculate(){let subtotal=0;tbody.querySelectorAll('tr').forEach(row=>{const amount=(parseFloat(row.querySelector('.qty').value)||0)*(parseFloat(row.querySelector('.price').value)||0);row.querySelector('.line-total').textContent=amount.toFixed(2);subtotal+=amount});const discount=parseFloat(document.querySelector('[name=discount]').value)||0,tax=parseFloat(document.querySelector('[name=tax]').value)||0;document.querySelector('#subtotal').textContent='PHP '+subtotal.toFixed(2);document.querySelector('#grandTotal').textContent='PHP '+Math.max(0,subtotal-discount+tax).toFixed(2)}
document.querySelector('#addRow').onclick=()=>{tbody.append(document.querySelector('#rowTemplate').content.cloneNode(true));calculate()};
document.addEventListener('input',e=>{if(e.target.matches('.qty,.price,.total-input'))calculate()});document.addEventListener('click',e=>{if(e.target.matches('.remove-row')){e.target.closest('tr').remove();calculate()}});calculate();
</script>
<?php include "includes/admin_footer.php"; ?>
