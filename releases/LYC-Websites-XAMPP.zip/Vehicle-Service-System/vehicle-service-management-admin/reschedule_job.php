<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/job_schedule.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);adminRequireJob($conn,$id);$locked=false;
try {
    $reason=trim((string)($_POST['reason']??''));$consent=trim((string)($_POST['consent_reference']??''));
    if($reason===''||mb_strlen($reason)>500||$consent===''||mb_strlen($consent)>400)throw new DomainException('Record a reason and the customer agreement reference (who agreed, when and how).');
    $date=(string)($_POST['appointment_date']??'');$time=(string)($_POST['appointment_time']??'');$start=bookingDateTime($date,$time);$mechanic=(int)($_POST['mechanic_id']??0);
    if(!$start)throw new DomainException('Choose a valid date and half-hour start.');
    bookingLock($conn,'');$locked=true;$conn->begin_transaction();
    $stmt=$conn->prepare('SELECT * FROM reservations WHERE id=? FOR UPDATE');$stmt->bind_param('i',$id);$stmt->execute();$job=$stmt->get_result()->fetch_assoc();
    if(!$job)throw new DomainException('This job is no longer available.');
    if(!in_array($job['status'],['Pending','Approved'],true))throw new DomainException('Only a booking that has not started inspection can be rescheduled.');
    if((string)($_POST['expected_start']??'')!==jobStart($job)->format('Y-m-d H:i:s')||(int)($_POST['expected_duration']??0)!==(int)$job['scheduled_duration_minutes']||(int)($_POST['expected_mechanic']??-1)!==(int)$job['mechanic_id'])throw new DomainException('The booking changed. Refresh before recording a new start.');
    if($start==jobStart($job))throw new DomainException('Choose a different start time. Use reassignment to keep the original time.');
    bookingRequireSlot($conn,$date,$time,(int)$job['scheduled_duration_minutes'],false,$id);
    $after=$job;$after['appointment_date']=$date;$after['appointment_time']=$time;
    if($mechanic&&!in_array($mechanic,array_map('intval',array_column(jobFreeMechanics($conn,$after),'id')),true))throw new DomainException('That mechanic is not free for the complete new service window. Choose another mechanic or leave unassigned.');
    $mechanicValue=$mechanic?:null;
    $stmt=$conn->prepare('UPDATE reservations SET original_appointment_at=COALESCE(original_appointment_at,TIMESTAMP(appointment_date,appointment_time)),appointment_date=?,appointment_time=?,mechanic_id=? WHERE id=?');$stmt->bind_param('ssii',$date,$time,$mechanicValue,$id);$stmt->execute();
    jobScheduleEvent($conn,$job,$after,'Rescheduled',$reason,$consent);
    adminAudit($conn,'Recorded agreed new start','reservation',$id,jobStart($job)->format('M j H:i').' → '.$start->format('M j H:i').'; '.mb_substr($consent,0,200));
    jobScheduleNotice($conn,$job,'Agreed appointment change','Your agreed appointment start is '.$start->format('M j, Y g:i A').' (Manila time). Your original booking remains in the service desk history.');
    $conn->commit();$_SESSION['admin_flash']=['type'=>'success','message'=>'Agreed start recorded. The original appointment is retained in history.'];
} catch(Throwable $e){$conn->rollback();$_SESSION['admin_flash']=['type'=>'warning','message'=>$e instanceof DomainException||$e instanceof BookingScheduleBusyException?$e->getMessage():'The agreed start could not be saved. Refresh and try again.'];}
finally{if($locked)bookingUnlock($conn,'');}
header('Location: reservation_view.php?id='.$id.'#job-schedule');exit;
