<?php
require_once __DIR__.'/includes/admin_auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);adminRequireJob($conn,$id);$target=$_POST['status']??'';
$transitions=['Pending'=>['Approved','Cancelled'],'Approved'=>['Diagnosing','Cancelled'],'Diagnosing'=>[],'Quotation Sent'=>[],'Quotation Accepted'=>['In Progress'],'In Progress'=>['Ready for Pickup'],'Ready for Pickup'=>['Completed']];
try{
 $conn->begin_transaction();$stmt=$conn->prepare('SELECT * FROM reservations WHERE id=? FOR UPDATE');$stmt->bind_param('i',$id);$stmt->execute();$job=$stmt->get_result()->fetch_assoc();$stmt->close();
 if(adminIsMechanic() && (int)$job['mechanic_id']!==(int)$_SESSION['admin_mechanic_id'])throw new DomainException('This job is no longer assigned to your account.');
 if(!in_array($target,$transitions[$job['status']]??[],true))throw new DomainException('The job changed or that action is not available at this stage. Refresh and try again.');
 if(in_array($target,['Approved','Cancelled','Completed'],true)&&!adminCan('jobs.manage'))throw new DomainException('Ask a service adviser or manager to confirm, cancel or release the job.');
 if($target==='Approved' && !empty($job['user_id']) && !in_array($job['reservation_fee_status'],['Paid','Not Required'],true))throw new DomainException('A cashier must verify the reservation fee first.');
 if(in_array($target,['Diagnosing','In Progress'],true) && (empty($job['checked_in_at']) || !$job['mechanic_id'] || strtotime($job['appointment_date'].' '.$job['appointment_time'])>time()))throw new DomainException('Check in the vehicle, assign a mechanic and wait until the appointment time before starting inspection or service work.');
 if($target==='Ready for Pickup' && trim($job['work_performed']??'')==='')throw new DomainException('Save the work performed in the service record before marking the vehicle ready.');
 if($target==='Completed'){$stmt=$conn->prepare("SELECT COUNT(*) n FROM payments WHERE reservation_id=? AND amount>0 AND status NOT IN ('Paid','Cancelled')");$stmt->bind_param('i',$id);$stmt->execute();$due=(int)$stmt->get_result()->fetch_assoc()['n'];$stmt->close();if($due)throw new DomainException('Resolve the outstanding payments before releasing the vehicle.');}
 $reason=trim($_POST['cancellation_reason']??'');if($target==='Cancelled'&&$reason==='')throw new DomainException('Choose a cancellation reason.');
 if($target==='Cancelled'){$fee=$job['reservation_fee_status']==='Paid'?'Refund Requested':$job['reservation_fee_status'];$eligibility=$job['reservation_fee_status']==='Paid'?'Verified reservation-fee refund requested.':'No verified reservation fee to refund.';$stmt=$conn->prepare('UPDATE reservations SET status=?,cancellation_reason=?,refund_eligibility=?,reservation_fee_status=? WHERE id=?');$stmt->bind_param('ssssi',$target,$reason,$eligibility,$fee,$id);$stmt->execute();$stmt->close();$stmt=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid' AND refund_status='Not Applicable'");$stmt->bind_param('i',$id);$stmt->execute();$stmt->close();}
 else{$stmt=$conn->prepare('UPDATE reservations SET status=? WHERE id=?');$stmt->bind_param('si',$target,$id);$stmt->execute();$stmt->close();}
 if($job['user_id']){$title='Service status updated';$message='Your booking is now: '.adminStatus($target).'.';$stmt=$conn->prepare("INSERT INTO notifications(user_id,title,message,link_type,link_id) VALUES(?,?,?,'reservation',?)");$stmt->bind_param('issi',$job['user_id'],$title,$message,$id);$stmt->execute();$stmt->close();}
 adminAudit($conn,'Updated job stage','reservation',$id,$job['status'].' → '.$target);
 $conn->commit();$_SESSION['admin_flash']=['type'=>'success','message'=>'Job updated: '.adminStatus($target).'.'];
}catch(Throwable $e){$conn->rollback();$_SESSION['admin_flash']=['type'=>'warning','message'=>$e instanceof DomainException?$e->getMessage():'The update could not be saved. Refresh and try again.'];}
header('Location: reservation_view.php?id='.$id);exit;
