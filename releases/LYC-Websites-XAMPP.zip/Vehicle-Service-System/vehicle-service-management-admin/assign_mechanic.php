<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/job_schedule.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);adminRequireJob($conn,$id);$locked=false;
try {
    $mechanic=(int)($_POST['mechanic_id']??0);$reason=trim((string)($_POST['reason']??''));
    bookingLock($conn,'');$locked=true;$conn->begin_transaction();
    $stmt=$conn->prepare('SELECT * FROM reservations WHERE id=? FOR UPDATE');$stmt->bind_param('i',$id);$stmt->execute();$job=$stmt->get_result()->fetch_assoc();
    if(!$job)throw new DomainException('This job is no longer available.');
    if(!in_array($job['status'],['Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress'],true))throw new DomainException('A mechanic cannot be assigned during this job stage.');
    $reassign=!empty($job['mechanic_id']);
    if($reassign){
        if($job['status']!=='Approved')throw new DomainException('A job already under inspection or service cannot be reassigned here.');
        if((int)($_POST['expected_mechanic']??-1)!==(int)$job['mechanic_id'])throw new DomainException('The assignment changed. Refresh before reassigning.');
        if($reason===''||mb_strlen($reason)>500)throw new DomainException('Enter a reassignment reason within 500 characters.');
        if($mechanic===(int)$job['mechanic_id'])throw new DomainException('Choose another free mechanic.');
    }
    if(!$mechanic||!in_array($mechanic,array_map('intval',array_column(jobFreeMechanics($conn,$job),'id')),true))throw new DomainException('That mechanic is not free for the complete service window. Choose another mechanic.');
    $stmt=$conn->prepare('UPDATE reservations SET mechanic_id=? WHERE id=?');$stmt->bind_param('ii',$mechanic,$id);$stmt->execute();
    if($reassign)jobScheduleEvent($conn,$job,$job,'Reassigned',$reason);
    adminAudit($conn,$reassign?'Reassigned mechanic':'Assigned mechanic','reservation',$id,'Mechanic #'.(int)$job['mechanic_id'].' → #'.$mechanic.($reason?'; '.mb_substr($reason,0,300):''));
    $conn->commit();$_SESSION['admin_flash']=['type'=>'success','message'=>$reassign?'Mechanic reassigned. The customer’s appointment time is unchanged.':'Mechanic assigned successfully.'];
} catch(Throwable $e){$conn->rollback();$_SESSION['admin_flash']=['type'=>'warning','message'=>$e instanceof DomainException||$e instanceof BookingScheduleBusyException?$e->getMessage():'The assignment could not be saved. Refresh and try again.'];}
finally{if($locked)bookingUnlock($conn,'');}
header('Location: reservation_view.php?id='.$id.'#job-schedule');exit;
