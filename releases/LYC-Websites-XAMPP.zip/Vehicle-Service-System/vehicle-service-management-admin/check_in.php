<?php
require_once __DIR__.'/includes/admin_auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);$job=adminRequireJob($conn,$id);
try{
 if($job['appointment_date']>date('Y-m-d'))throw new DomainException('Check-in opens on the appointment date.');
 $conn->begin_transaction();$stmt=$conn->prepare("UPDATE reservations SET checked_in_at=NOW() WHERE id=? AND checked_in_at IS NULL AND status NOT IN ('Pending','Cancelled','Completed')");$stmt->bind_param('i',$id);$stmt->execute();$changed=$stmt->affected_rows;$stmt->close();if(!$changed)throw new DomainException('The vehicle is already checked in or this job is not ready for arrival.');adminAudit($conn,'Checked in vehicle','reservation',$id,'Customer arrived at the shop.');$conn->commit();$_SESSION['admin_flash']=['type'=>'success','message'=>'Vehicle checked in. Assign a mechanic if needed, then start inspection at the reserved time.'];
}catch(Throwable $e){$conn->rollback();$_SESSION['admin_flash']=['type'=>'warning','message'=>$e instanceof DomainException?$e->getMessage():'Check-in could not be saved.'];}
header('Location: reservation_view.php?id='.$id.'#job-action');
