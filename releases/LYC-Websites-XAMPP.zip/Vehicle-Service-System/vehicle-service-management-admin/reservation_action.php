<?php
// Compatibility endpoint: every stage change uses the same guarded workflow.
require_once __DIR__.'/includes/admin_auth.php';
$map=['approve'=>'Approved','cancel'=>'Cancelled','start'=>'In Progress','complete'=>'Completed'];
$_POST['status']=$map[$_POST['action']??'']??'';
require __DIR__.'/reservation_update.php';
