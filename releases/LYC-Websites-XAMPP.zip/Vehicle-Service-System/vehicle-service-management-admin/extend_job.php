<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/job_schedule.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);adminRequireJob($conn,$id);$locked=false;
try {
    $minutes=filter_var($_POST['minutes']??null,FILTER_VALIDATE_INT);$reason=trim((string)($_POST['reason']??''));
    if(!$minutes || $minutes<15 || $minutes>240 || $minutes%15)throw new DomainException('Choose an extension of 15–240 minutes in 15-minute steps.');
    if($reason==='' || mb_strlen($reason)>500)throw new DomainException('Enter a reason within 500 characters.');
    bookingLock($conn,'');$locked=true;$conn->begin_transaction();
    $stmt=$conn->prepare('SELECT * FROM reservations WHERE id=? FOR UPDATE');$stmt->bind_param('i',$id);$stmt->execute();$job=$stmt->get_result()->fetch_assoc();
    if(!$job)throw new DomainException('This job is no longer available.');
    if(adminIsMechanic()&&(int)$job['mechanic_id']!==(int)$_SESSION['admin_mechanic_id'])throw new DomainException('This job is no longer assigned to you.');
    if(!$job['mechanic_id']||!$job['checked_in_at']||!in_array($job['status'],['Diagnosing','Quotation Sent','Quotation Accepted','In Progress'],true))throw new DomainException('Only an assigned, checked-in job under inspection or service can be extended.');
    $start=jobStart($job);$now=new DateTimeImmutable('now',new DateTimeZone('Asia/Manila'));
    if($start>$now)throw new DomainException('This job has not reached its reserved start time.');
    if((int)($_POST['expected_duration']??0)!==(int)$job['scheduled_duration_minutes'])throw new DomainException('The expected finish changed. Refresh before extending again.');
    $oldEnd=jobFinish($job);$base=$oldEnd>$now?$oldEnd:$now;$end=$base->modify("+$minutes minutes");
    $duration=(int)ceil(($end->getTimestamp()-$start->getTimestamp())/60);
    $stmt=$conn->prepare('UPDATE reservations SET original_duration_minutes=COALESCE(original_duration_minutes,scheduled_duration_minutes),scheduled_duration_minutes=? WHERE id=?');$stmt->bind_param('ii',$duration,$id);$stmt->execute();
    $after=$job;$after['scheduled_duration_minutes']=$duration;
    jobScheduleEvent($conn,$job,$after,'Extended',$reason);
    $conflicts=jobConflicts($conn,$after);
    adminAudit($conn,'Extended expected finish','reservation',$id,'Finish '.$oldEnd->format('M j H:i').' → '.jobFinish($after)->format('M j H:i').'; '.count($conflicts).' conflict(s). '.mb_substr($reason,0,250));
    jobScheduleNotice($conn,$job,'Service taking longer','Your service expected completion is now '.jobFinish($after)->format('M j, g:i A').' (Manila time). Please contact the service desk for details.');
    $conn->commit();$_SESSION['admin_flash']=['type'=>$conflicts?'warning':'success','message'=>'Expected finish updated. '.count($conflicts).' conflicting booking(s) need review. Existing appointment times have not been moved.'];
} catch(Throwable $e){$conn->rollback();$_SESSION['admin_flash']=['type'=>'warning','message'=>$e instanceof DomainException?$e->getMessage():'The extension could not be saved. Refresh and try again.'];}
finally{if($locked)bookingUnlock($conn,'');}
header('Location: reservation_view.php?id='.$id.'#job-schedule');exit;
