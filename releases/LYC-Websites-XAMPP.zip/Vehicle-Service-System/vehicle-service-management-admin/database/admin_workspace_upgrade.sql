-- Import after the existing website migrations. Compatible with XAMPP MariaDB.
ALTER TABLE users ADD COLUMN IF NOT EXISTS mechanic_id INT DEFAULT NULL;
ALTER TABLE users ADD INDEX IF NOT EXISTS staff_mechanic_idx (mechanic_id);
ALTER TABLE users ADD UNIQUE INDEX IF NOT EXISTS staff_mechanic_unique (mechanic_id);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS checked_in_at DATETIME DEFAULT NULL;
