<?php
require_once __DIR__.'/includes/admin_auth.php';
$id=(int)($_GET['id']??0);$stmt=$conn->prepare('SELECT proof_file FROM payments WHERE id=?');$stmt->bind_param('i',$id);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
$root=realpath(__DIR__.'/../vehicle-service-management/uploads/payment_proofs');$file=$row?realpath(__DIR__.'/../vehicle-service-management/'.$row['proof_file']):false;
if(!$root||!$file||!str_starts_with($file,$root.DIRECTORY_SEPARATOR)||!is_file($file)){http_response_code(404);exit('Proof unavailable.');}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($file);if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(415);exit('Unsupported proof type.');}
header('Content-Type: '.$mime);header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');header('Content-Security-Policy: default-src \'none\'; img-src \'self\'; sandbox');readfile($file);
