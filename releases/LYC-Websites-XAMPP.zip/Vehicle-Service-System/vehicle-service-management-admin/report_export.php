<?php
include_once __DIR__.'/includes/config.php';include_once __DIR__.'/includes/admin_auth.php';
header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=vehicle-service-report-'.date('Y-m-d').'.csv');
$out=fopen('php://output','w');fputcsv($out,['Reference','Customer','Vehicle','Plate','Services','Appointment','Status','Quotation Total','Payment Status','Amount Paid']);
$result=mysqli_query($conn,"SELECT r.reference_number,c.fullname,v.brand,v.model,v.plate_number,r.service_type,r.appointment_date,r.status,q.grand_total,p.status payment_status,CASE WHEN p.status='Paid' THEN p.amount ELSE 0 END amount_paid FROM reservations r LEFT JOIN customers c ON r.customer_id=c.id LEFT JOIN vehicles v ON r.vehicle_id=v.id LEFT JOIN job_quotations q ON q.reservation_id=r.id LEFT JOIN payments p ON p.reservation_id=r.id ORDER BY r.appointment_date DESC");
while($row=mysqli_fetch_assoc($result))fputcsv($out,[$row['reference_number'],$row['fullname'],$row['brand'].' '.$row['model'],$row['plate_number'],$row['service_type'],$row['appointment_date'],$row['status'],$row['grand_total'],$row['payment_status'],$row['amount_paid']]);fclose($out);
