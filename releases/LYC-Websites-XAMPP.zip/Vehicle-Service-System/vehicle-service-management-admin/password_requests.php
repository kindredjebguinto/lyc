<?php
include "includes/admin_header.php";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    $status = ($_POST['status'] ?? '') === 'Resolved' ? 'Resolved' : 'Rejected';
    $stmt = mysqli_prepare($conn, "UPDATE password_reset_requests SET status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $status, $id);
    mysqli_stmt_execute($stmt);
}
$result = mysqli_query($conn, "SELECT pr.*, u.fullname FROM password_reset_requests pr INNER JOIN users u ON u.id = pr.user_id ORDER BY pr.created_at DESC");
?>
<h2 class="mb-4">Password Reset Requests</h2>
<div class="dashboard-card">
<div class="table-responsive"><table class="table table-hover align-middle">
<thead><tr><th>Customer</th><th>Email</th><th>Requested</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php while ($row = mysqli_fetch_assoc($result)): ?>
<tr><td><?= htmlspecialchars($row['fullname']); ?></td><td><?= htmlspecialchars($row['email']); ?></td><td><?= htmlspecialchars($row['created_at']); ?></td><td><?= htmlspecialchars($row['status']); ?></td><td>
<?php if ($row['status'] === 'Pending'): ?>
<form method="post" class="d-inline"><input type="hidden" name="id" value="<?= $row['id']; ?>"><button class="btn btn-sm btn-success" name="status" value="Resolved">Mark Resolved</button><button class="btn btn-sm btn-outline-danger" name="status" value="Rejected">Reject</button></form>
<?php else: ?>—<?php endif; ?>
</td></tr>
<?php endwhile; ?>
</tbody></table></div></div>
<?php include "includes/admin_footer.php"; ?>
