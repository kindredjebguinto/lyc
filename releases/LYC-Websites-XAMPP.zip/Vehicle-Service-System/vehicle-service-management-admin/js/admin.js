document.addEventListener('DOMContentLoaded', () => {
  const toggle=document.getElementById('staffMenuToggle'),menu=document.getElementById('staffNavigation');
  const close=()=>{menu?.classList.remove('menu-open');toggle?.setAttribute('aria-expanded','false');};
  toggle?.addEventListener('click',()=>{const open=menu.classList.toggle('menu-open');toggle.setAttribute('aria-expanded',String(open));});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){close();toggle?.focus();}});
  document.addEventListener('click',event=>{if(menu?.classList.contains('menu-open')&&!menu.contains(event.target)&&!toggle.contains(event.target))close();});
  document.querySelectorAll('form[data-confirm]').forEach(form=>form.addEventListener('submit',event=>{if(!confirm(form.dataset.confirm))event.preventDefault();}));
});
