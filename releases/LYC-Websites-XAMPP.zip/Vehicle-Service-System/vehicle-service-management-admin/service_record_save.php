<?php
require_once __DIR__.'/includes/admin_auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);$job=adminRequireJob($conn,$id);
if(in_array($job['status'],['Completed','Cancelled'],true)){$_SESSION['admin_flash']=['type'=>'warning','message'=>'This job is closed. Its service record is read-only.'];header('Location: reservation_view.php?id='.$id);exit;}
$mileage=($_POST['intake_mileage']??'')===''?null:max(0,(int)$_POST['intake_mileage']);$diagnosis=trim($_POST['diagnosis']??'');$work=trim($_POST['work_performed']??'');$notes=trim($_POST['completion_notes']??'');$next=trim($_POST['next_service_date']??'')?:null;
if($next){$dt=DateTimeImmutable::createFromFormat('!Y-m-d',$next);if(!$dt||$dt->format('Y-m-d')!==$next){http_response_code(422);exit('Choose a valid next service date.');}}
$stmt=$conn->prepare('UPDATE reservations r SET intake_mileage=?,diagnosis=?,work_performed=?,completion_notes=?,next_service_date=? WHERE id=? AND status NOT IN (\'Completed\',\'Cancelled\')'.adminJobScope('r'));$stmt->bind_param('issssi',$mileage,$diagnosis,$work,$notes,$next,$id);$stmt->execute();$stmt->close();adminAudit($conn,'Updated service record','reservation',$id,'Diagnosis, work, mileage, completion notes and maintenance date saved.');
$_SESSION['admin_flash']=['type'=>'success','message'=>'Service record saved.'];header('Location: reservation_view.php?id='.$id.'#job-record');
