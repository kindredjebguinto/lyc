<?php

include "includes/public_header.php";
require_once __DIR__ . '/includes/service_categories.php';


$serviceResult = mysqli_query(
    $conn,
    "SELECT
        id,
        service_name,
        description,
        price,
        estimated_duration

     FROM services

     WHERE status = 'Active'

     ORDER BY service_name ASC"
);
$services = [];
while ($serviceResult && $row = mysqli_fetch_assoc($serviceResult)) $services[] = $row;
$serviceCategories = service_categories_for($services);

?>


<section class="inner-hero">

    <div class="container">

        <span class="section-label">
            OUR SERVICES
        </span>

        <h1>
            Professional Vehicle Services
        </h1>

        <p>
            Choose the service your vehicle needs and schedule
            your appointment online.
        </p>

    </div>

</section>


<section class="services-page">

    <div class="container">


        <?php if ($services): ?>

        <div class="service-category-tabs justify-content-md-center">
            <button class="service-category-tab active" type="button" data-category="all">All</button>
            <?php foreach ($serviceCategories as $category): ?>
            <button class="service-category-tab" type="button" data-category="<?= service_category_slug($category) ?>"><?= htmlspecialchars($category) ?></button>
            <?php endforeach; ?>
        </div>


        <div class="row g-4">


            <?php foreach ($services as $service): ?>


            <div class="col-md-6 col-lg-4" data-service-category="<?= service_category_slug(service_category($service['service_name'])) ?>">

                <div class="service-card">


                    <div class="service-icon">
                        🔧
                    </div>


                    <h3>

                        <?= htmlspecialchars(
                                    $service[
                                        'service_name'
                                    ]
                                ); ?>

                    </h3>


                    <p>

                        <?= htmlspecialchars(
                                    !empty(
                                        $service[
                                            'description'
                                        ]
                                    )
                                        ? $service[
                                            'description'
                                        ]
                                        : 'Professional vehicle maintenance and service.'
                                ); ?>

                    </p>


                    <div class="service-meta">


                        <strong>

                            ₱<?= number_format(
                                        $service[
                                            'price'
                                        ],
                                        2
                                    ); ?>

                        </strong>


                        <?php if (
                                    !empty(
                                        $service[
                                            'estimated_duration'
                                        ]
                                    )
                                ): ?>

                        <span>

                            Approx.

                            <?= intval(
                                            $service[
                                                'estimated_duration'
                                            ]
                                        ); ?>

                            mins

                        </span>

                        <?php endif; ?>


                    </div>


                    <a href="<?= BASE_URL ?>/appointment.php?service=<?= intval($service['id']); ?>"
                        class="service-book-link">

                        BOOK THIS SERVICE →

                    </a>


                </div>

            </div>


            <?php endforeach; ?>


        </div>


        <?php else: ?>


        <div class="alert alert-light text-center">

            No active services are currently available.

        </div>


        <?php endif; ?>


    </div>

</section>

<script>
document.querySelectorAll('.service-category-tab').forEach(tab => tab.addEventListener('click', () => {
    document.querySelectorAll('.service-category-tab').forEach(item => item.classList.toggle('active', item === tab));
    document.querySelectorAll('[data-service-category]').forEach(card => {
        card.hidden = tab.dataset.category !== 'all' && card.dataset.serviceCategory !== tab.dataset.category;
    });
}));
</script>


<?php

include "includes/public_footer.php";

?>
