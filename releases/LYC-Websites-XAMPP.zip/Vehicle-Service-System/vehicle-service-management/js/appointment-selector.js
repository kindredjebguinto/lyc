document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('appointmentForm');
  if (!form) return;
  const input = document.getElementById('selectedServicesInput');
  const selected = new Map();
  const cards = [...document.querySelectorAll('.service-card')];
  const tabs = [...document.querySelectorAll('.category-button')];
  const search = document.getElementById('serviceSearch');
  const list = document.getElementById('selectedServices');
  const badge = document.getElementById('selectedBadge');
  const totalEl = document.getElementById('summaryTotal');
  const overlay = document.getElementById('reviewOverlay');
  const reviewButton = document.getElementById('reviewButton');
  let active = Number(tabs[0]?.dataset.category || 0);
  function esc(value) { const div = document.createElement('div'); div.textContent = value || ''; return div.innerHTML; }
  function money(value) { return new Intl.NumberFormat('en-PH', {style: 'currency', currency: 'PHP'}).format(value); }
  function add(button) { selected.set(Number(button.dataset.id), {id: Number(button.dataset.id), name: button.dataset.name, price: Number(button.dataset.price)}); }
  try {
    JSON.parse(input.value || '[]').forEach(id => {
      const button = document.querySelector(`[data-add-service][data-id="${Number(id)}"]`);
      if (button) add(button);
    });
  } catch (_) { /* Start with an empty cart if restored selections are invalid. */ }
  function render() {
    let total = 0;
    list.replaceChildren();
    selected.forEach(service => {
      total += service.price;
      const chip = document.createElement('span');
      chip.className = 'selected-chip';
      chip.innerHTML = `${esc(service.name)} <strong>${money(service.price)}</strong> <button type="button" data-remove="${service.id}" aria-label="Remove ${esc(service.name)}">×</button>`;
      list.appendChild(chip);
    });
    if (!selected.size) list.textContent = 'No services selected yet.';
    badge.textContent = selected.size;
    totalEl.textContent = money(total);
    input.value = JSON.stringify([...selected.keys()]);
    document.querySelectorAll('[data-add-service]').forEach(button => {
      const added = selected.has(Number(button.dataset.id));
      button.disabled = added;
      button.textContent = added ? 'Added ✓' : 'Add to Cart';
    });
    form.dispatchEvent(new Event('booking-services-changed'));
  }
  function filter() {
    const query = search.value.trim().toLowerCase();
    cards.forEach(card => card.hidden = query ? !card.dataset.name.includes(query) : Number(card.dataset.category) !== active);
  }
  tabs.forEach(tab => tab.addEventListener('click', () => {
    tabs.forEach(item => item.classList.toggle('active', item === tab));
    active = Number(tab.dataset.category);
    search.value = '';
    filter();
  }));
  search.addEventListener('input', filter);
  document.querySelectorAll('[data-add-service]').forEach(button => button.addEventListener('click', () => { add(button); render(); }));
  list.addEventListener('click', event => {
    const button = event.target.closest('[data-remove]');
    if (button) { selected.delete(Number(button.dataset.remove)); render(); }
  });
  function closeReview() { overlay.hidden = true; reviewButton.focus(); }
  document.getElementById('reviewClose').addEventListener('click', closeReview);
  document.getElementById('reviewBack').addEventListener('click', closeReview);
  overlay.addEventListener('click', event => { if (event.target === overlay) closeReview(); });
  overlay.addEventListener('keydown', event => {
    if (event.key === 'Escape') { event.preventDefault(); closeReview(); }
    if (event.key !== 'Tab') return;
    const buttons = [...overlay.querySelectorAll('button:not(:disabled)')];
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  reviewButton.addEventListener('click', () => {
    if (!selected.size || !form.elements.appointment_time.value || !form.reportValidity()) return;
    const data = new FormData(form);
    const services = [...selected.values()];
    const total = services.reduce((sum, service) => sum + service.price, 0);
    const schedule = form.querySelector('.booking-slot-summary')?.textContent || `${data.get('appointment_date')} · ${data.get('appointment_time')}`;
    document.getElementById('reviewContent').innerHTML = `
      <div class="review-grid">
        <div class="review-block"><span>Customer</span><strong>${esc(data.get('fullname'))}</strong><br>${esc(data.get('email'))}<br>${esc(data.get('phone'))}</div>
        <div class="review-block"><span>Vehicle</span><strong>${esc(data.get('year'))} ${esc(data.get('brand'))} ${esc(data.get('model'))}</strong><br>${esc(data.get('plate_number'))}${data.get('color') ? ' · ' + esc(data.get('color')) : ''}</div>
        <div class="review-block"><span>Appointment window</span><p>${esc(schedule)}</p></div>
        <div class="review-block"><span>Payment preference</span><strong>${esc(data.get('payment_method'))}</strong><p>Estimated services: ${money(total)}</p><small>This is an estimate. Submitting an appointment does not confirm a payment.</small></div>
      </div>
      <h3 class="h5">Selected services</h3>
      <div class="review-services">${services.map(service => `<div class="review-service-row"><span>${esc(service.name)}</span><strong>${money(service.price)}</strong></div>`).join('')}
      <div class="review-service-row"><strong>Estimated total</strong><strong>${money(total)}</strong></div></div>`;
    overlay.hidden = false;
    document.getElementById('reviewClose').focus();
  });
  filter();
  render();
});
