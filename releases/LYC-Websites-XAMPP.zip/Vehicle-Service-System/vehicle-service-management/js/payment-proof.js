document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('paymentProofForm');
  if (!form) return;
  const input = document.getElementById('paymentProof');
  const preview = document.getElementById('proofPreview');
  const feedback = document.getElementById('proofFeedback');
  const submit = document.getElementById('proofSubmit');
  const originalLabel = submit.textContent;
  const limit = Number(form.dataset.proofLimit || 5 * 1024 * 1024);
  const limitLabel = form.dataset.proofLimitLabel || '5 MB';
  let previewUrl;
  function resetSubmission() { submit.disabled = false; submit.textContent = originalLabel; }
  input.addEventListener('change', () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    preview.hidden = true;
    preview.removeAttribute('src');
    input.setCustomValidity('');
    feedback.textContent = '';
    const file = input.files[0];
    if (!file) return;
    if (file.size <= 0 || file.size > limit || !['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      const message = `Choose a JPG, PNG, or WEBP image up to ${limitLabel}.`;
      input.setCustomValidity(message);
      feedback.textContent = message;
      return;
    }
    previewUrl = URL.createObjectURL(file);
    preview.src = previewUrl;
    preview.hidden = false;
    feedback.textContent = `${file.name} · ${Math.max(1, Math.round(file.size / 1024))} KB selected. Check that the details are readable.`;
  });
  form.addEventListener('submit', () => { submit.disabled = true; submit.textContent = 'Uploading proof…'; });
  window.addEventListener('pageshow', resetSubmission);
  document.getElementById('paymentError')?.focus();
});
