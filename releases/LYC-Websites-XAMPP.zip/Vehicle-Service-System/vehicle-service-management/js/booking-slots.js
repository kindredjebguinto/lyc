document.addEventListener('DOMContentLoaded', () => {
  const picker = document.querySelector('[data-booking-slots]');
  if (!picker) return;
  const form = picker.closest('form');
  const date = form.elements.appointment_date;
  const time = form.elements.appointment_time;
  const status = picker.querySelector('[role="status"]');
  const grid = picker.querySelector('[data-slot-grid]');
  const summary = document.createElement('p');
  summary.className = 'booking-slot-summary';
  summary.setAttribute('aria-live', 'polite');
  grid.after(summary);
  const actions = [...form.querySelectorAll('[type="submit"], #reviewButton')];
  let controller;
  let requestId = 0;
  const enable = value => actions.forEach(button => button.disabled = !value);
  const selectedIds = () => picker.dataset.catalog === 'guest'
    ? JSON.parse(form.elements.selected_services.value || '[]')
    : [...form.querySelectorAll('input[name="services[]"]:checked')].map(input => Number(input.value));

  async function load(keepSelection = false) {
    const id = ++requestId;
    if (controller) controller.abort();
    controller = new AbortController();
    const previous = keepSelection ? time.value : '';
    time.value = '';
    enable(false);
    grid.replaceChildren();
    summary.textContent = '';
    const services = selectedIds();
    if (!date.value || !services.length) {
      status.textContent = 'Choose services and a date to see available slots.';
      return;
    }
    status.textContent = 'Checking mechanic availability…';
    try {
      const response = await fetch(picker.dataset.endpoint, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        signal: controller.signal,
        body: JSON.stringify({appointment_date: date.value, service_ids: services, catalog: picker.dataset.catalog})
      });
      const result = await response.json();
      if (id !== requestId) return;
      if (!response.ok || !result.success) throw new Error(result.message || 'Unable to load slots.');
      status.textContent = `Reserved service time: ${result.duration_minutes} minutes. Choose a start time below.`;
      for (const slot of result.slots) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'booking-slot';
        button.disabled = !slot.available;
        button.setAttribute('aria-pressed', 'false');
        button.textContent = `${slot.label} · ${slot.available ? `${slot.remaining_capacity} mechanic${slot.remaining_capacity === 1 ? '' : 's'} available` : slot.reason}`;
        button.addEventListener('click', () => {
          time.value = slot.time;
          grid.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
          const selectedDate = new Date(`${date.value}T12:00:00`).toLocaleDateString('en-PH', {weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'});
          const [hour, minute] = slot.time.split(':').map(Number);
          const ends = new Date(2000, 0, 1, hour, minute + result.duration_minutes);
          const endLabel = ends.toLocaleTimeString('en-PH', {hour: 'numeric', minute: '2-digit'});
          summary.textContent = `Selected: ${selectedDate} · ${slot.label}–${endLabel}. Your slot is checked again when you submit.`;
          enable(true);
        });
        grid.appendChild(button);
        if (slot.available && slot.time === previous) button.click();
      }
      if (!result.slots.some(slot => slot.available)) status.textContent = 'No slots can fit these services on this date. Choose another date.';
    } catch (error) {
      if (id !== requestId || error.name === 'AbortError') return;
      status.textContent = `${error.message} Change the date or use Refresh slots to try again.`;
    }
  }
  date.addEventListener('change', () => load());
  form.addEventListener('booking-services-changed', () => load());
  form.querySelectorAll('input[name="services[]"]').forEach(input => input.addEventListener('change', () => load()));
  picker.querySelector('[data-refresh-slots]').addEventListener('click', () => load(true));
  form.addEventListener('submit', event => {
    if (!time.value || actions.some(button => button.disabled)) {
      event.preventDefault();
      status.textContent = 'Choose an available slot before continuing.';
      picker.scrollIntoView({block: 'center'});
    }
  });
  load(true);
});
