document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("mobileMenuButton");

  const menu = document.getElementById("publicNavLinks");

  if (!button || !menu) {
    return;
  }

  button.addEventListener("click", function () {
    const open = menu.classList.toggle("open");
    button.setAttribute("aria-expanded", String(open));
    button.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && menu.classList.contains('open')) {
      menu.classList.remove('open');
      button.setAttribute('aria-expanded', 'false');
      button.setAttribute('aria-label', 'Open navigation');
      button.focus();
    }
  });
  const links = menu.querySelectorAll("a");

  links.forEach(function (link) {
    link.addEventListener("click", function () {
      menu.classList.remove("open");
      button.setAttribute("aria-expanded", "false");
      button.setAttribute("aria-label", "Open navigation");
    });
  });
});
