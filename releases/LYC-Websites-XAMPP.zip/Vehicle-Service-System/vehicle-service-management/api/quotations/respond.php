<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__."/../../includes/payment_balance.php";
requireMethod("POST");
$user=requireCustomer($conn); $data=jsonInput();
$reservationId=intval($data["reservation_id"]??0); $action=$data["status"]??"";
if(!in_array($action,["Accepted","Rejected"],true)) { http_response_code(422); echo json_encode(["success"=>false,"message"=>"Choose Accepted or Rejected."]); exit; }
$userId=(int)$user["id"];
$conn->begin_transaction();
try {
  $stmt=$conn->prepare("UPDATE job_quotations q INNER JOIN reservations r ON q.reservation_id=r.id SET q.status=?,q.responded_at=NOW() WHERE q.reservation_id=? AND r.user_id=? AND q.status='Sent' AND r.status='Quotation Sent'");
  $stmt->bind_param("sii",$action,$reservationId,$userId); $stmt->execute(); $changed=$stmt->affected_rows; $stmt->close();
  if(!$changed) throw new Exception("This quotation cannot be changed.");
  if($action==='Accepted') {
    $stmt=$conn->prepare("UPDATE reservations SET status='Quotation Accepted' WHERE id=? AND user_id=?");
    $stmt->bind_param("ii",$reservationId,$userId); $stmt->execute(); $stmt->close();
    $quote=$conn->prepare('SELECT grand_total FROM job_quotations WHERE reservation_id=?');$quote->bind_param('i',$reservationId);$quote->execute();$gross=(float)$quote->get_result()->fetch_assoc()['grand_total'];$quote->close();
    createFinalBalance($conn,$reservationId,$gross);
  } else {
    $stmt=$conn->prepare("UPDATE reservations SET status='Cancelled',cancellation_reason='Quotation rejected',refund_eligibility='Full ₱200 reservation-fee refund requested.',reservation_fee_status='Refund Requested' WHERE id=? AND user_id=?");$stmt->bind_param('ii',$reservationId,$userId);$stmt->execute();$stmt->close();
    $stmt=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid'");$stmt->bind_param('i',$reservationId);$stmt->execute();$stmt->close();
  }
  $conn->commit();
} catch(Throwable $e) {
  $conn->rollback(); http_response_code(409); echo json_encode(["success"=>false,"message"=>"This quotation cannot be changed. Refresh and check its current status."]); exit;
}
echo json_encode(["success"=>true,"message"=>"Quotation ".strtolower($action)."."]);
