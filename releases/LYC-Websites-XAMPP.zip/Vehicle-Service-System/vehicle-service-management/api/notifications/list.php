<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("GET");
$user = requireCustomer($conn); $userId = (int) $user["id"];
$stmt = $conn->prepare("SELECT id, title, message, is_read, link_type, link_id, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->bind_param("i", $userId); $stmt->execute(); $result = $stmt->get_result(); $items = [];
while ($row = $result->fetch_assoc()) { $row["id"] = (int) $row["id"]; $row["is_read"] = (bool) $row["is_read"]; $items[] = $row; }
echo json_encode(["success" => true, "notifications" => $items]);
