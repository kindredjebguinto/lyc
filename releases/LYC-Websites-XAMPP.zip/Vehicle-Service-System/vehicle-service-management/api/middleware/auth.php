<?php

function authenticateUser($conn)
{
    /*
    |--------------------------------------------------------------------------
    | Read Authorization Header
    |--------------------------------------------------------------------------
    */

    $headers = getallheaders();

    $authorization = $headers["Authorization"]
        ?? $headers["authorization"]
        ?? "";

    if (
        !preg_match(
            '/Bearer\s+(\S+)/',
            $authorization,
            $matches
        )
    ) {

        http_response_code(401);

        echo json_encode([
            "success" => false,
            "message" => "Authentication token required."
        ]);

        exit;
    }

    $token = $matches[1];

    $tokenHash = hash(
        "sha256",
        $token
    );

    /*
    |--------------------------------------------------------------------------
    | Verify Token
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        SELECT
            u.id,
            u.fullname,
            u.email,
            u.role
        FROM api_tokens t

        INNER JOIN users u
            ON u.id = t.user_id

        WHERE t.token_hash = ?
        AND t.expires_at > NOW()

        LIMIT 1
    ");

    $stmt->bind_param(
        "s",
        $tokenHash
    );

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows !== 1) {

        http_response_code(401);

        echo json_encode([
            "success" => false,
            "message" => "Invalid or expired authentication token."
        ]);

        exit;
    }

    return $result->fetch_assoc();
}