<?php

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../middleware/auth.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Authenticate
|--------------------------------------------------------------------------
*/

$user = authenticateUser($conn);

/*
|--------------------------------------------------------------------------
| Customer Profile
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT *
    FROM customers
    WHERE user_id = ?
    LIMIT 1
");

$stmt->bind_param(
    "i",
    $user["id"]
);

$stmt->execute();

$result = $stmt->get_result();

$customer = null;

if ($result->num_rows === 1) {
    $customer = $result->fetch_assoc();
}

/*
|--------------------------------------------------------------------------
| Response
|--------------------------------------------------------------------------
*/

echo json_encode([
    "success" => true,

    "user" => [
        "id" => (int) $user["id"],
        "fullname" => $user["fullname"],
        "email" => $user["email"],
        "role" => $user["role"]
    ],

    "customer" => $customer
]);