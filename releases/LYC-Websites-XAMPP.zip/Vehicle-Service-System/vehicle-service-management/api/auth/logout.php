<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
$headers = getallheaders();
$authorization = $headers["Authorization"] ?? $headers["authorization"] ?? "";
if (preg_match('/Bearer\s+(\S+)/', $authorization, $matches)) {
    $hash = hash("sha256", $matches[1]);
    $stmt = $conn->prepare("DELETE FROM api_tokens WHERE token_hash = ?");
    $stmt->bind_param("s", $hash);
    $stmt->execute();
}
echo json_encode(["success" => true, "message" => "Logged out successfully."]);
