<?php

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

require_once __DIR__ . "/database.php";
require_once __DIR__ . "/../middleware/auth.php";

function requireCustomer($conn)
{
    $user = authenticateUser($conn);

    if (($user["role"] ?? "") !== "customer") {
        http_response_code(403);
        echo json_encode(["success" => false, "message" => "Customer access required."]);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, phone, address FROM customers WHERE user_id = ? LIMIT 1");
    $userId = (int) $user["id"];
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();

    if (!$customer) {
        http_response_code(404);
        echo json_encode(["success" => false, "message" => "Customer profile not found."]);
        exit;
    }

    $user["customer_id"] = (int) $customer["id"];
    $user["phone"] = $customer["phone"];
    $user["address"] = $customer["address"];
    return $user;
}

function jsonInput()
{
    $data = json_decode(file_get_contents("php://input"), true);
    return is_array($data) ? $data : [];
}

function requireMethod($method)
{
    if ($_SERVER["REQUEST_METHOD"] !== $method) {
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Method not allowed."]);
        exit;
    }
}

function databaseColumnExists($conn, $table, $column)
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) return $cache[$key];
    $stmt = $conn->prepare("SELECT COUNT(*) total FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->bind_param("ss", $table, $column);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $cache[$key] = ((int)($row['total'] ?? 0) > 0);
}

function optionalColumn($conn, $table, $alias, $column)
{
    return databaseColumnExists($conn, $table, $column)
        ? "$alias.$column"
        : "NULL AS $column";
}
