<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/bootstrap.php";
require_once __DIR__ . '/../../includes/service_categories.php';
requireCustomer($conn);

if ($_SERVER["REQUEST_METHOD"] !== "GET") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

try {

    $stmt = $conn->prepare("
        SELECT
            id,
            service_name,
            description,
            price,
            estimated_duration,
            status
        FROM services
        WHERE status = 'Active'
        ORDER BY service_name ASC
    ");

    $stmt->execute();

    $result = $stmt->get_result();

    $services = [];

    while ($row = $result->fetch_assoc()) {

        $services[] = [
            "id" =>
                (int) $row["id"],

            "service_name" =>
                $row["service_name"],

            "category" =>
                service_category($row["service_name"]),

            "description" =>
                $row["description"],

            "price" =>
                (float) $row["price"],

            "estimated_duration" =>
                $row["estimated_duration"] !== null
                    ? (int) $row["estimated_duration"]
                    : null,

            "status" =>
                $row["status"]
        ];
    }

    echo json_encode([
        "success" => true,
        "message" =>
            "Services retrieved successfully.",
        "services" => $services
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" =>
            "Unable to retrieve services."
    ]);
}
