<?php
require_once __DIR__.'/../config/bootstrap.php';
require_once __DIR__.'/../../includes/booking_slots.php';
requireMethod('POST');
requireCustomer($conn);
$data = jsonInput();
$date = trim($data['appointment_date'] ?? '');
$names = $data['service_types'] ?? [];
if (!is_array($names) || !$names || array_filter($names, fn($name) => !is_string($name))) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Choose a date and at least one service.']);
    exit;
}
$names = array_values(array_unique(array_filter(array_map('trim', $names))));
if (!$names) { http_response_code(422); echo json_encode(['success'=>false,'message'=>'Choose at least one service.']); exit; }
$escaped = array_map(fn($name) => "'".$conn->real_escape_string($name)."'", $names);
$result = $conn->query("SELECT estimated_duration FROM services WHERE status='Active' AND service_name IN (".implode(',', $escaped).")");
if ($result->num_rows !== count($names)) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'One or more selected services are unavailable.']);
    exit;
}
try {
    echo json_encode(bookingSlots($conn, $date, bookingDuration($result->fetch_all(MYSQLI_ASSOC))));
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
