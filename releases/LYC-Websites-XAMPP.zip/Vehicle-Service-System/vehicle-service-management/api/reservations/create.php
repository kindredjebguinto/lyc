<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__ . "/../../includes/booking_slots.php";
requireMethod("POST");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$customerId = (int) $user["customer_id"];
$data = jsonInput();
$vehicleId = (int) ($data["vehicle_id"] ?? 0);
$serviceTypes = $data["service_types"] ?? [];
if (!is_array($serviceTypes)) {
    $serviceTypes = [];
}
$serviceTypes = array_values(array_unique(array_filter(array_map("trim", $serviceTypes))));
$serviceType = implode(", ", $serviceTypes);
$date = trim($data["appointment_date"] ?? "");
$time = trim($data["appointment_time"] ?? "");
$remarks = trim($data["remarks"] ?? "");
$policyAccepted = filter_var($data["policy_accepted"] ?? false, FILTER_VALIDATE_BOOLEAN);
$policyVersion = trim($data["policy_version"] ?? "1.0-2026-10");

if (!$policyAccepted) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => "Accept the booking and refundable reservation-fee policy before continuing."]);
    exit;
}

if (!$vehicleId || count($serviceTypes) === 0 || !$date || !$time) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Please fill in all required fields."]);
    exit;
}
if (!bookingDateTime($date, $time)) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Choose a valid appointment date and slot.']);
    exit;
}
$check = $conn->prepare("SELECT id FROM vehicles WHERE id = ? AND user_id = ? LIMIT 1");
$check->bind_param("ii", $vehicleId, $userId);
$check->execute();
if ($check->get_result()->num_rows !== 1) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid vehicle selected."]);
    exit;
}
$escaped = array_map(fn($name) => "'" . $conn->real_escape_string($name) . "'", $serviceTypes);
$serviceResult = $conn->query("SELECT service_name,COALESCE(estimated_duration,30) estimated_duration FROM services WHERE status = 'Active' AND service_name IN (" . implode(",", $escaped) . ")");
if (!$serviceResult || $serviceResult->num_rows !== count($serviceTypes)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "One or more selected services are invalid or inactive."]);
    exit;
}
$durationMinutes = bookingDuration($serviceResult->fetch_all(MYSQLI_ASSOC));
try {
    bookingLock($conn, $date);
    bookingRequireSlot($conn, $date, $time, $durationMinutes);
} catch (Throwable $e) {
    bookingUnlock($conn, $date);
    http_response_code($e instanceof DomainException ? 409 : 503);
    echo json_encode(['success'=>false,'message'=>($e instanceof DomainException || $e instanceof BookingScheduleBusyException) ? $e->getMessage() : 'Unable to check the schedule. Please try again.']);
    exit;
}
$reference = 'VSMS-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
$source = trim($data['policy_source'] ?? 'Android');
if (!in_array($source, ['Android','iOS','Website'], true)) $source = 'Android';
$ip = $_SERVER['REMOTE_ADDR'] ?? null;
$conn->begin_transaction();
try {
$stmt = $conn->prepare("INSERT INTO reservations (reference_number,user_id,customer_id,vehicle_id,service_type,appointment_date,appointment_time,remarks,status,policy_version,policy_accepted_at,policy_source,policy_ip,scheduled_duration_minutes,reservation_fee_status) VALUES (?,?,?,?,?,?,?,?,'Pending',?,NOW(),?,?,?,'Awaiting Payment')");
$stmt->bind_param("siiisssssssi", $reference, $userId, $customerId, $vehicleId, $serviceType, $date, $time, $remarks, $policyVersion, $source, $ip, $durationMinutes);
$stmt->execute();
$reservationId = $stmt->insert_id;
$payment = $conn->prepare("INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount,reservation_fee_credit) VALUES(?,200.00,'GCash','Awaiting Proof','Reservation Fee',200.00,0.00)");
$payment->bind_param('i',$reservationId);$payment->execute();$paymentId=$payment->insert_id;
$conn->query("UPDATE reservations SET reservation_fee_payment_id=".(int)$paymentId." WHERE id=".(int)$reservationId);
$acceptance=$conn->prepare("INSERT INTO booking_policy_acceptances(user_id,reservation_id,policy_version,accepted_at,source,ip_address) VALUES(?,?,?,NOW(),?,?)");
$acceptance->bind_param('iisss',$userId,$reservationId,$policyVersion,$source,$ip);$acceptance->execute();
$title = "Booking submitted";
$notificationMessage = "Reservation #$reservationId is waiting for approval.";
$notification = $conn->prepare("INSERT INTO notifications (user_id, title, message,link_type,link_id) VALUES (?, ?, ?,'reservation',?)");
$notification->bind_param("issi", $userId, $title, $notificationMessage,$reservationId);
$notification->execute();
$conn->commit();
echo json_encode(["success" => true, "message" => "Booking created. Pay the refundable ₱200 reservation fee to submit it for approval.", "reservation_id" => $reservationId, "payment_id" => $paymentId, "reservation_fee" => 200]);
} catch (Throwable $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["success"=>false,"message"=>"Unable to create the booking. Please try again."]);
}
 finally {
    bookingUnlock($conn, $date);
}
