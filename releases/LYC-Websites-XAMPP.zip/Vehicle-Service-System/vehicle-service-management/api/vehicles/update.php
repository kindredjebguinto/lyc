<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/bootstrap.php";
$authUser = requireCustomer($conn);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$data = json_decode(
    file_get_contents("php://input"),
    true
);

if (!$data) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request data."
    ]);

    exit;
}

$id = isset($data["id"])
    ? intval($data["id"])
    : 0;

$customer_id = $authUser["customer_id"];

$brand = trim(
    $data["brand"] ?? ""
);

$model = trim(
    $data["model"] ?? ""
);

$year = trim(
    $data["year"] ?? ""
);

$plate_number = strtoupper(
    trim($data["plate_number"] ?? "")
);

$color = trim(
    $data["color"] ?? ""
);
$vehicle_type = trim($data["vehicle_type"] ?? "");
$transmission = trim($data["transmission"] ?? "");
$fuel_type = trim($data["fuel_type"] ?? "");
$mileage = isset($data["mileage"]) && $data["mileage"] !== null ? intval($data["mileage"]) : null;
$vin = trim($data["vin"] ?? "");


if ($id <= 0 || $customer_id <= 0) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid vehicle information."
    ]);

    exit;
}


if (
    $brand === "" ||
    $model === "" ||
    $year === "" ||
    $plate_number === ""
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" =>
            "Brand, model, year and plate number are required."
    ]);

    exit;
}


if (
    !ctype_digit($year) ||
    intval($year) < 1900 ||
    intval($year) > intval(date("Y")) + 1
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" =>
            "Please enter a valid vehicle year."
    ]);

    exit;
}


try {

    /*
     * Make sure this vehicle belongs
     * to the logged-in customer.
     */
    $vehicleStmt = $conn->prepare("
        SELECT id
        FROM vehicles
        WHERE id = ?
        AND customer_id = ?
        LIMIT 1
    ");

    $vehicleStmt->bind_param(
        "ii",
        $id,
        $customer_id
    );

    $vehicleStmt->execute();

    $vehicleResult =
        $vehicleStmt->get_result();


    if ($vehicleResult->num_rows === 0) {

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "message" => "Vehicle not found."
        ]);

        exit;
    }


    /*
     * Check whether another vehicle
     * already uses this plate number.
     */
    $plateStmt = $conn->prepare("
        SELECT id
        FROM vehicles
        WHERE plate_number = ?
        AND id != ?
        LIMIT 1
    ");

    $plateStmt->bind_param(
        "si",
        $plate_number,
        $id
    );

    $plateStmt->execute();

    $plateResult =
        $plateStmt->get_result();


    if ($plateResult->num_rows > 0) {

        http_response_code(409);

        echo json_encode([
            "success" => false,
            "message" =>
                "A vehicle with this plate number already exists."
        ]);

        exit;
    }


    /*
     * Update vehicle.
     */
    $stmt = $conn->prepare("
        UPDATE vehicles
        SET
            brand = ?,
            model = ?,
            year = ?,
            plate_number = ?,
            color = ?
            ,vehicle_type = ?, transmission = ?, fuel_type = ?, mileage = ?, vin = ?
        WHERE id = ?
        AND customer_id = ?
    ");

    $stmt->bind_param(
        "ssssssssisii",
        $brand,
        $model,
        $year,
        $plate_number,
        $color,
        $vehicle_type,
        $transmission,
        $fuel_type,
        $mileage,
        $vin,
        $id,
        $customer_id
    );

    $stmt->execute();


    echo json_encode([
        "success" => true,
        "message" =>
            "Vehicle updated successfully.",
        "vehicle" => [
            "id" => $id,
            "customer_id" => $customer_id,
            "brand" => $brand,
            "model" => $model,
            "year" => $year,
            "plate_number" => $plate_number,
            "color" => $color
        ]
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" =>
            "Unable to update vehicle."
    ]);
}
