<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once "../config/bootstrap.php";
$authUser = requireCustomer($conn);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed."
    ]);

    exit;
}

$data = json_decode(
    file_get_contents("php://input"),
    true
);

if (!$data) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request data."
    ]);

    exit;
}

$customer_id = $authUser["customer_id"];

$brand = trim(
    $data["brand"] ?? ""
);

$model = trim(
    $data["model"] ?? ""
);

$year = trim(
    $data["year"] ?? ""
);

$plate_number = trim(
    $data["plate_number"] ?? ""
);

$color = trim(
    $data["color"] ?? ""
);
$vehicle_type = trim($data["vehicle_type"] ?? "");
$transmission = trim($data["transmission"] ?? "");
$fuel_type = trim($data["fuel_type"] ?? "");
$mileage = isset($data["mileage"]) && $data["mileage"] !== null ? intval($data["mileage"]) : null;
$vin = trim($data["vin"] ?? "");


if (
    $brand === "" ||
    $model === "" ||
    $year === "" ||
    $plate_number === ""
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" =>
            "Brand, model, year and plate number are required."
    ]);

    exit;
}


if (
    !ctype_digit($year) ||
    intval($year) < 1900 ||
    intval($year) > intval(date("Y")) + 1
) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid vehicle year."
    ]);

    exit;
}


try {

    /*
     * Find the user_id connected to this customer.
     */
    $customerStmt = $conn->prepare("
        SELECT user_id
        FROM customers
        WHERE id = ?
        LIMIT 1
    ");

    $customerStmt->bind_param(
        "i",
        $customer_id
    );

    $customerStmt->execute();

    $customerResult =
        $customerStmt->get_result();

    $customer =
        $customerResult->fetch_assoc();


    if (!$customer) {

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "message" => "Customer not found."
        ]);

        exit;
    }


    $user_id = intval($authUser["id"]);


    /*
     * Prevent duplicate plate numbers.
     */
    $plateStmt = $conn->prepare("
        SELECT id
        FROM vehicles
        WHERE plate_number = ?
        LIMIT 1
    ");

    $plateStmt->bind_param(
        "s",
        $plate_number
    );

    $plateStmt->execute();

    $plateResult =
        $plateStmt->get_result();


    if ($plateResult->num_rows > 0) {

        http_response_code(409);

        echo json_encode([
            "success" => false,
            "message" =>
                "A vehicle with this plate number already exists."
        ]);

        exit;
    }


    /*
     * Insert the vehicle.
     */
    $stmt = $conn->prepare("
        INSERT INTO vehicles
        (
            user_id,
            customer_id,
            brand,
            model,
            year,
            plate_number,
            color
            ,vehicle_type, transmission, fuel_type, mileage, vin
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "iissssssssis",
        $user_id,
        $customer_id,
        $brand,
        $model,
        $year,
        $plate_number,
        $color,
        $vehicle_type,
        $transmission,
        $fuel_type,
        $mileage,
        $vin
    );

    $stmt->execute();


    $vehicle_id =
        $stmt->insert_id;


    echo json_encode([
        "success" => true,
        "message" =>
            "Vehicle added successfully.",
        "vehicle" => [
            "id" => $vehicle_id,
            "user_id" => $user_id,
            "customer_id" => $customer_id,
            "brand" => $brand,
            "model" => $model,
            "year" => $year,
            "plate_number" => $plate_number,
            "color" => $color
        ]
    ]);

} catch (Exception $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" =>
            "Unable to add vehicle."
    ]);
}
