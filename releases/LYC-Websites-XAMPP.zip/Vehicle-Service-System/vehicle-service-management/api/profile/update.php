<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$data = jsonInput();
$fullname = trim($data["fullname"] ?? "");
$email = trim($data["email"] ?? "");
$phone = trim($data["phone"] ?? "");
$address = trim($data["address"] ?? "");
if (!$fullname || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "A valid name and email are required."]);
    exit;
}
$check = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1");
$check->bind_param("si", $email, $userId);
$check->execute();
if ($check->get_result()->num_rows) {
    http_response_code(409);
    echo json_encode(["success" => false, "message" => "That email address is already being used."]);
    exit;
}
$conn->begin_transaction();
try {
    $stmt = $conn->prepare("UPDATE users SET fullname = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $fullname, $email, $userId);
    $stmt->execute();
    $stmt = $conn->prepare("UPDATE customers SET fullname = ?, email = ?, phone = ?, address = ? WHERE user_id = ?");
    $stmt->bind_param("ssssi", $fullname, $email, $phone, $address, $userId);
    $stmt->execute();
    $conn->commit();
    echo json_encode(["success" => true, "message" => "Profile updated successfully."]);
} catch (Throwable $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Unable to update your profile."]);
}
