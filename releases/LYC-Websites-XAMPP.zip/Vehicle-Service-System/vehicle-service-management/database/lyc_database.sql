-- Luck Yuna: the ONLY SQL file to import. XAMPP MariaDB 10.4+.
-- Fresh install: creates an empty database and service catalog.
-- Existing install: export a backup first; keeps existing records and passwords.
-- Repeatable. No DROP TABLE, TRUNCATE, or account/demo data.
CREATE DATABASE IF NOT EXISTS vehicle_service_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE vehicle_service_system;
/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `entity_lookup` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `api_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `booking_policy_acceptances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `policy_version` varchar(20) NOT NULL,
  `accepted_at` datetime NOT NULL,
  `source` enum('Website','Android','iOS') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_policy_per_reservation` (`reservation_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `legacy_user_id` int(11) DEFAULT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `legacy_user_id` (`legacy_user_id`),
  KEY `idx_customer_email` (`email`),
  KEY `idx_customer_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `job_quotation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `item_type` enum('Service','Part','Labor','Other') NOT NULL DEFAULT 'Service',
  `description` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_additional` tinyint(1) NOT NULL DEFAULT 0,
  `customer_decision` enum('Pending','Accepted','Rejected') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_id` (`quotation_id`),
  CONSTRAINT `job_quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `job_quotation_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL,
  `snapshot_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_version` (`quotation_id`,`version_number`),
  CONSTRAINT `job_quotation_versions_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `job_quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(40) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(1000) DEFAULT NULL,
  `status` enum('Draft','Sent','Accepted','Rejected') NOT NULL DEFAULT 'Draft',
  `valid_until` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `responded_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_number` (`quotation_number`),
  UNIQUE KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `job_quotations_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(190) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `success` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `lookup_attempts` (`identifier`,`ip_address`,`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `mechanics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `status` enum('Available','Busy','Inactive') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `link_type` varchar(40) DEFAULT NULL,
  `link_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `password_reset_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('Pending','Resolved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `password_reset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected',
  `status` enum('Pending','Awaiting Proof','Under Review','Rejected','Pay at Shop','Paid','Cancelled') NOT NULL DEFAULT 'Pending',
  `reference_number` varchar(100) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `proof_file` varchar(255) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `admin_notes` varchar(500) DEFAULT NULL,
  `payment_type` enum('Reservation Fee','Final Balance','Additional Work') NOT NULL DEFAULT 'Final Balance',
  `gross_amount` decimal(10,2) DEFAULT NULL,
  `reservation_fee_credit` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount_received` decimal(10,2) DEFAULT NULL,
  `received_by` varchar(100) DEFAULT NULL,
  `refund_status` enum('Not Applicable','Requested','Under Review','Approved','Refunded','Rejected') NOT NULL DEFAULT 'Not Applicable',
  `refund_reference` varchar(100) DEFAULT NULL,
  `refunded_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_reservation_fk_idx` (`reservation_id`),
  KEY `reservation_payment_type` (`reservation_id`,`payment_type`),
  CONSTRAINT `fk_payment_reservation` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `reservation_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) NOT NULL,
  `service_id` int(10) unsigned NOT NULL,
  `service_name_snapshot` varchar(150) NOT NULL,
  `price_snapshot` decimal(10,2) NOT NULL,
  `duration_snapshot` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_res_service` (`reservation_id`,`service_id`),
  KEY `fk_rs_service` (`service_id`),
  CONSTRAINT `fk_rs_reservation` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rs_service` FOREIGN KEY (`service_id`) REFERENCES `service_catalog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_number` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `vehicle_id` int(11) NOT NULL,
  `service_type` varchar(500) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  `mechanic_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `intake_mileage` int(11) DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `work_performed` text DEFAULT NULL,
  `completion_notes` text DEFAULT NULL,
  `next_service_date` date DEFAULT NULL,
  `cancellation_reason` varchar(100) DEFAULT NULL,
  `cancellation_details` varchar(500) DEFAULT NULL,
  `refund_eligibility` varchar(150) DEFAULT NULL,
  `policy_version` varchar(20) DEFAULT NULL,
  `policy_accepted_at` datetime DEFAULT NULL,
  `policy_source` enum('Website','Android','iOS') DEFAULT NULL,
  `policy_ip` varchar(45) DEFAULT NULL,
  `scheduled_duration_minutes` int(11) NOT NULL DEFAULT 60,
  `reservation_fee_status` enum('Awaiting Payment','Under Review','Paid','Refund Requested','Refunded','Rejected','Forfeited') NOT NULL DEFAULT 'Awaiting Payment',
  `reservation_fee_payment_id` int(11) DEFAULT NULL,
  `no_show_at` datetime DEFAULT NULL,
  `checked_in_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_number` (`reference_number`),
  KEY `user_id` (`user_id`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `fk_reservation_mechanic` (`mechanic_id`),
  KEY `fk_reservation_customer` (`customer_id`),
  CONSTRAINT `fk_reservation_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_reservation_mechanic` FOREIGN KEY (`mechanic_id`) REFERENCES `mechanics` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `service_catalog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `service_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estimated_duration` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_catalog_category` (`category_id`),
  CONSTRAINT `fk_catalog_category` FOREIGN KEY (`category_id`) REFERENCES `service_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `service_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `service_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `review` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_feedback_per_job` (`reservation_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estimated_duration` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `shop_closed_dates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `closed_date` date NOT NULL,
  `reason` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `closed_date` (`closed_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','staff') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `staff_level` enum('Manager','Service Adviser','Cashier','Mechanic','Staff') DEFAULT NULL,
  `mechanic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `staff_mechanic_unique` (`mechanic_id`),
  KEY `staff_mechanic_idx` (`mechanic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` year(4) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `color` varchar(30) DEFAULT NULL,
  `vehicle_type` varchar(50) DEFAULT NULL,
  `transmission` varchar(30) DEFAULT NULL,
  `fuel_type` varchar(30) DEFAULT NULL,
  `mileage` int(11) DEFAULT NULL,
  `vin` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `fk_vehicle_customer` (`customer_id`),
  CONSTRAINT `fk_vehicle_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;


-- EXISTING DATABASE REPAIR: select your existing database in phpMyAdmin first.
-- Export a backup first. This file does not drop tables or reset accounts.
-- Requires XAMPP MariaDB (ADD COLUMN IF NOT EXISTS).
ALTER TABLE customers ADD COLUMN IF NOT EXISTS user_id INT DEFAULT NULL;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS user_id INT DEFAULT NULL;
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS user_id INT DEFAULT NULL;
-- Restore ownership only through an unambiguous existing account email.
UPDATE customers c JOIN (
 SELECT email, MIN(id) AS id FROM users WHERE role='customer'
 GROUP BY email HAVING COUNT(*)=1
) u ON u.email=c.email SET c.user_id=u.id WHERE c.user_id IS NULL;
UPDATE vehicles v JOIN customers c ON c.id=v.customer_id
 SET v.user_id=c.user_id WHERE v.user_id IS NULL AND c.user_id IS NOT NULL;
UPDATE reservations r JOIN customers c ON c.id=r.customer_id
 SET r.user_id=c.user_id WHERE r.user_id IS NULL AND c.user_id IS NOT NULL;


-- mobile_api_migration.sql
-- Run this file in phpMyAdmin only when upgrading an existing database.


CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `api_tokens_ibfk_1`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `reservations`
  MODIFY `service_type` varchar(500) NOT NULL;

ALTER TABLE `vehicles`
  ADD COLUMN IF NOT EXISTS `vehicle_type` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `transmission` varchar(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `fuel_type` varchar(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `mileage` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `vin` varchar(50) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `password_reset_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('Pending','Resolved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `password_reset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(40) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(1000) DEFAULT NULL,
  `status` enum('Draft','Sent','Accepted','Rejected') NOT NULL DEFAULT 'Draft',
  `valid_until` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `quotation_number` (`quotation_number`),
  UNIQUE KEY `reservation_id` (`reservation_id`),
  CONSTRAINT `job_quotations_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `job_quotation_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `item_type` enum('Service','Part','Labor','Other') NOT NULL DEFAULT 'Service',
  `description` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`), KEY `quotation_id` (`quotation_id`),
  CONSTRAINT `job_quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `payments`
  MODIFY `payment_method` enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected',
  MODIFY `status` enum('Pending','Awaiting Proof','Pay at Shop','Under Review','Paid','Rejected','Cancelled') NOT NULL DEFAULT 'Awaiting Proof',
  ADD COLUMN IF NOT EXISTS `proof_file` varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `submitted_at` datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `admin_notes` varchar(500) DEFAULT NULL;

ALTER TABLE `reservations`
  MODIFY `status` enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') DEFAULT 'Pending',
  ADD COLUMN IF NOT EXISTS `intake_mileage` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `diagnosis` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `work_performed` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `completion_notes` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `next_service_date` date DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `action` varchar(120) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `entity_lookup` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `job_quotations` ADD COLUMN IF NOT EXISTS `responded_at` datetime DEFAULT NULL;
CREATE TABLE IF NOT EXISTS `job_quotation_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT, `quotation_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL, `snapshot_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_version` (`quotation_id`,`version_number`),
  CONSTRAINT `job_quotation_versions_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `job_quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- import_complete_service_catalog.sql
-- Adds the former 16-item service catalog to the current services table.
-- Existing services and reservations are not deleted or changed.

INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Basic', 'Basic preventive maintenance package including standard vehicle inspection.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Basic');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Standard', 'Preventive maintenance package with additional fluid and safety checks.', 2500.00, 120, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Standard');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'PMS Premium', 'Comprehensive preventive maintenance package for complete vehicle care.', 4500.00, 180, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'PMS Premium');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Regular Oil Change', 'Regular engine oil replacement with oil filter inspection.', 1200.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Regular Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Semi-Synthetic Oil Change', 'Semi-synthetic oil service suitable for regular driving conditions.', 1800.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Semi-Synthetic Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Fully Synthetic Oil Change', 'Premium fully synthetic engine oil replacement.', 2600.00, 60, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Fully Synthetic Oil Change');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Air Conditioning Check', 'Inspection of the air conditioning system and cooling performance.', 800.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Air Conditioning Check');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'AC Cleaning', 'Air conditioning cleaning service.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'AC Cleaning');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Brake Inspection', 'Inspection of brake pads, rotors and braking performance.', 500.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Brake Inspection');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Brake Cleaning and Adjustment', 'Brake cleaning and adjustment service.', 1200.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Brake Cleaning and Adjustment');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Tire Rotation', 'Rotate tires for more even tread wear.', 700.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Tire Rotation');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Tire Inspection', 'Inspection of tire condition, pressure and tread.', 350.00, 30, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Tire Inspection');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Engine Diagnostic', 'Basic engine diagnostic inspection.', 1500.00, 90, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Engine Diagnostic');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Engine Tune-Up', 'General engine tune-up service.', 2200.00, 120, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Engine Tune-Up');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Battery Check', 'Battery health and charging system inspection.', 400.00, 30, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Battery Check');
INSERT INTO services (service_name, description, price, estimated_duration, status)
SELECT 'Battery Replacement Service', 'Battery removal, replacement and charging-system check.', 800.00, 45, 'Active'
WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name = 'Battery Replacement Service');

-- Restore former general services that may currently be inactive.
UPDATE services SET status = 'Active' WHERE service_name IN ('Battery Service', 'Air Conditioning Service');


-- full_workflow_upgrade_20261011.sql
-- Select the correct hosting database before importing. No USE statement is included.

ALTER TABLE reservations
  ADD COLUMN IF NOT EXISTS cancellation_reason varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS cancellation_details varchar(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refund_eligibility varchar(150) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_version varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_accepted_at datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_source enum('Website','Android','iOS') DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS policy_ip varchar(45) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS scheduled_duration_minutes int NOT NULL DEFAULT 60,
  ADD COLUMN IF NOT EXISTS reservation_fee_status enum('Awaiting Payment','Under Review','Paid','Refund Requested','Refunded','Rejected','Forfeited') NOT NULL DEFAULT 'Awaiting Payment',
  ADD COLUMN IF NOT EXISTS reservation_fee_payment_id int DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS no_show_at datetime DEFAULT NULL;
ALTER TABLE reservations MODIFY status enum('Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed','Cancelled') NOT NULL DEFAULT 'Pending';

ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS proof_file varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS submitted_at datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS admin_notes text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS payment_type enum('Reservation Fee','Final Balance','Additional Work') NOT NULL DEFAULT 'Final Balance',
  ADD COLUMN IF NOT EXISTS gross_amount decimal(10,2) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS reservation_fee_credit decimal(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS amount_received decimal(10,2) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS received_by varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refund_status enum('Not Applicable','Requested','Under Review','Approved','Refunded','Rejected') NOT NULL DEFAULT 'Not Applicable',
  ADD COLUMN IF NOT EXISTS refund_reference varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS refunded_at datetime DEFAULT NULL;
ALTER TABLE payments MODIFY payment_method enum('Not Selected','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'Not Selected';
ALTER TABLE payments MODIFY status enum('Pending','Awaiting Proof','Under Review','Rejected','Pay at Shop','Paid','Cancelled') NOT NULL DEFAULT 'Pending';

ALTER TABLE payments ADD INDEX IF NOT EXISTS payment_reservation_fk_idx (reservation_id);
ALTER TABLE payments DROP INDEX IF EXISTS unique_reservation_payment;
ALTER TABLE payments ADD INDEX IF NOT EXISTS reservation_payment_type (reservation_id,payment_type);

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS staff_level enum('Manager','Service Adviser','Cashier','Mechanic','Staff') DEFAULT NULL;
ALTER TABLE users MODIFY staff_level enum('Manager','Service Adviser','Cashier','Mechanic','Staff') DEFAULT NULL;
UPDATE users SET staff_level='Manager' WHERE role='staff' AND staff_level IS NULL ORDER BY id LIMIT 1;
UPDATE users SET staff_level='Staff' WHERE role='staff' AND staff_level IS NULL;

CREATE TABLE IF NOT EXISTS booking_policy_acceptances (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  reservation_id int NOT NULL,
  policy_version varchar(20) NOT NULL,
  accepted_at datetime NOT NULL,
  source enum('Website','Android','iOS') NOT NULL,
  ip_address varchar(45) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY one_policy_per_reservation (reservation_id),
  KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS shop_closed_dates (
  id int NOT NULL AUTO_INCREMENT,
  closed_date date NOT NULL,
  reason varchar(150) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY closed_date (closed_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
  id bigint NOT NULL AUTO_INCREMENT,
  identifier varchar(190) NOT NULL,
  ip_address varchar(45) NOT NULL,
  attempted_at datetime NOT NULL DEFAULT current_timestamp(),
  success tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY lookup_attempts (identifier,ip_address,attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_feedback (
  id int NOT NULL AUTO_INCREMENT,
  reservation_id int NOT NULL,
  user_id int NOT NULL,
  rating tinyint NOT NULL,
  review varchar(1000) DEFAULT NULL,
  created_at datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY one_feedback_per_job (reservation_id,user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE notifications
  ADD COLUMN IF NOT EXISTS link_type varchar(40) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS link_id int DEFAULT NULL;

ALTER TABLE job_quotation_items
  ADD COLUMN IF NOT EXISTS is_additional tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS customer_decision enum('Pending','Accepted','Rejected') DEFAULT NULL;


-- service_selector_integration.sql
CREATE TABLE IF NOT EXISTS service_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  sort_order INT NOT NULL DEFAULT 0,
  status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_catalog (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  service_name VARCHAR(150) NOT NULL,
  description TEXT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  estimated_duration INT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_catalog_category FOREIGN KEY (category_id) REFERENCES service_categories(id)
);

CREATE TABLE IF NOT EXISTS reservation_services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT NOT NULL,
  service_id INT UNSIGNED NOT NULL,
  service_name_snapshot VARCHAR(150) NOT NULL,
  price_snapshot DECIMAL(10,2) NOT NULL,
  duration_snapshot INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_res_service (reservation_id, service_id),
  CONSTRAINT fk_rs_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE,
  CONSTRAINT fk_rs_service FOREIGN KEY (service_id) REFERENCES service_catalog(id)
);

INSERT IGNORE INTO service_categories (id,category_name,slug,sort_order,status) VALUES
(1,'PMS Package','pms-package',1,'Active'),(2,'Periodic Services','periodic-services',2,'Active'),(3,'AC Services & Repair','ac-services-repair',3,'Active'),(4,'Brake Services','brake-services',4,'Active'),(5,'Tire Services','tire-services',5,'Active'),(6,'Engine Services','engine-services',6,'Active'),(7,'Battery Services','battery-services',7,'Active');

INSERT IGNORE INTO service_catalog (id,category_id,service_name,description,price,estimated_duration,sort_order,status) VALUES
(1,1,'PMS Basic','Basic preventive maintenance package including standard vehicle inspection.',1500,90,1,'Active'),
(2,1,'PMS Standard','Preventive maintenance package with additional fluid and safety checks.',2500,120,2,'Active'),
(3,1,'PMS Premium','Comprehensive preventive maintenance package for complete vehicle care.',4500,180,3,'Active'),
(4,2,'Regular Oil Change','Regular engine oil replacement with oil filter inspection.',1200,60,1,'Active'),
(5,2,'Semi-Synthetic Oil Change','Semi-synthetic oil service suitable for regular driving conditions.',1800,60,2,'Active'),
(6,2,'Fully Synthetic Oil Change','Premium fully synthetic engine oil replacement.',2600,60,3,'Active'),
(7,3,'Air Conditioning Check','Inspection of the air conditioning system and cooling performance.',800,45,1,'Active'),
(8,3,'AC Cleaning','Air conditioning cleaning service.',1500,90,2,'Active'),
(9,4,'Brake Inspection','Inspection of brake pads, rotors and braking performance.',500,45,1,'Active'),
(10,4,'Brake Cleaning and Adjustment','Brake cleaning and adjustment service.',1200,90,2,'Active'),
(11,5,'Tire Rotation','Rotate tires for more even tread wear.',700,45,1,'Active'),
(12,5,'Tire Inspection','Inspection of tire condition, pressure and tread.',350,30,2,'Active'),
(13,6,'Engine Diagnostic','Basic engine diagnostic inspection.',1500,90,1,'Active'),
(14,6,'Engine Tune-Up','General engine tune-up service.',2200,120,2,'Active'),
(15,7,'Battery Check','Battery health and charging system inspection.',400,30,1,'Active'),
(16,7,'Battery Replacement Service','Battery removal, replacement and charging-system check.',800,45,2,'Active');


-- admin_workspace_upgrade.sql
-- Import after the existing website migrations. Compatible with XAMPP MariaDB.
ALTER TABLE users ADD COLUMN IF NOT EXISTS mechanic_id INT DEFAULT NULL;
ALTER TABLE users ADD INDEX IF NOT EXISTS staff_mechanic_idx (mechanic_id);
ALTER TABLE users ADD UNIQUE INDEX IF NOT EXISTS staff_mechanic_unique (mechanic_id);
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS checked_in_at DATETIME DEFAULT NULL;

-- Preserve the original base services without overwriting existing records.
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'General Maintenance','General inspection and preventive vehicle maintenance.',1500.00,120,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='General Maintenance');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Oil Change','Engine oil and oil filter replacement.',1200.00,60,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Oil Change');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Brake Service','Brake inspection, cleaning, adjustment, and repair.',1800.00,120,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Brake Service');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Engine Check','Engine inspection and diagnostic checking.',2000.00,120,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Engine Check');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Battery Service','Battery testing, charging, and terminal inspection.',800.00,45,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Battery Service');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Tire Service','Tire inspection, rotation, and basic tire service.',1000.00,60,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Tire Service');
INSERT INTO services (service_name,description,price,estimated_duration,status) SELECT 'Air Conditioning Service','Vehicle air-conditioning inspection and maintenance.',1800.00,120,'Active' WHERE NOT EXISTS (SELECT 1 FROM services WHERE service_name='Air Conditioning Service');
