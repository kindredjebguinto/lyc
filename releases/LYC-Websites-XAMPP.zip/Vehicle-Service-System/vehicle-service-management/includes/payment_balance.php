<?php
// Call inside the quotation transaction. Locking the job makes creation idempotent.
function createFinalBalance(mysqli $conn, int $reservationId, float $gross): int
{
    $stmt=$conn->prepare('SELECT id FROM reservations WHERE id=? FOR UPDATE');$stmt->bind_param('i',$reservationId);$stmt->execute();$exists=$stmt->get_result()->num_rows;$stmt->close();if(!$exists)throw new DomainException('Booking unavailable.');
    $stmt=$conn->prepare("SELECT id,status,amount,proof_file FROM payments WHERE reservation_id=? AND payment_type='Final Balance' LIMIT 1 FOR UPDATE");$stmt->bind_param('i',$reservationId);$stmt->execute();$existing=$stmt->get_result()->fetch_assoc();$stmt->close();
    $stmt=$conn->prepare("SELECT COALESCE(SUM(amount),0) credit FROM payments WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid' AND refund_status IN ('Not Applicable','Rejected')");$stmt->bind_param('i',$reservationId);$stmt->execute();$verified=(float)$stmt->get_result()->fetch_assoc()['credit'];$stmt->close();
    $gross=max(0,round($gross,2));$credit=min($gross,max(0,$verified));$balance=round($gross-$credit,2);$status=$balance>0?'Awaiting Proof':'Paid';$received=$balance>0?null:'System: no balance due after verified fee credit';$paidAt=$balance>0?null:date('Y-m-d H:i:s');$amountReceived=$balance>0?null:0.0;
    if($existing){
        if(in_array($existing['status'],['Pending','Awaiting Proof','Rejected'],true)&&empty($existing['proof_file'])){
            $existingId=(int)$existing['id'];
            $stmt=$conn->prepare('UPDATE payments SET amount=?,gross_amount=?,reservation_fee_credit=?,status=?,paid_at=?,received_by=?,amount_received=? WHERE id=?');
            $stmt->bind_param('dddsssdi',$balance,$gross,$credit,$status,$paidAt,$received,$amountReceived,$existingId);$stmt->execute();$stmt->close();return $existingId;
        }
        if(abs((float)$existing['amount']-$balance)>0.005)throw new DomainException('A payment is already submitted or verified for a different amount. Resolve it before recording this quotation decision.');
        return (int)$existing['id'];
    }
    $stmt=$conn->prepare("INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount,reservation_fee_credit,paid_at,received_by,amount_received) VALUES(?,?,'Not Selected',?,'Final Balance',?,?,?,?,?)");$stmt->bind_param('idsddssd',$reservationId,$balance,$status,$gross,$credit,$paidAt,$received,$amountReceived);$stmt->execute();$id=$conn->insert_id;$stmt->close();return $id;
}
