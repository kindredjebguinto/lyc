<?php
class BookingScheduleBusyException extends RuntimeException {}

// Shared by guest bookings, customer bookings and the mobile API.
// A Busy mechanic is still schedulable outside their assigned job's interval.
function bookingDuration(array $services): int
{
    return array_sum(array_map(fn($s) => max(30, (int)($s['estimated_duration'] ?? 30)), $services));
}

function bookingDateTime(string $date, string $time): ?DateTimeImmutable
{
    if (!preg_match('/^\d{2}:\d{2}(:00)?$/', $time)) return null;
    $value = $date . ' ' . substr($time, 0, 5);
    $dt = DateTimeImmutable::createFromFormat('!Y-m-d H:i', $value, new DateTimeZone('Asia/Manila'));
    return $dt && $dt->format('Y-m-d H:i') === $value ? $dt : null;
}

function bookingLock(mysqli $conn, string $date): void
{
    // One database-wide lock also protects overruns crossing midnight and date changes.
    $name = 'lyc-schedule-' . substr(hash('sha256', $conn->query('SELECT DATABASE()')->fetch_row()[0]), 0, 40);
    $stmt = $conn->prepare('SELECT GET_LOCK(?, 10) acquired');
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $acquired = $stmt->get_result()->fetch_assoc()['acquired'];
    $stmt->close();
    if ((int)$acquired !== 1) throw new BookingScheduleBusyException('Schedule is busy. Please try again.');
}

function bookingUnlock(mysqli $conn, string $date): void
{
    // One database-wide lock also protects overruns crossing midnight and date changes.
    $name = 'lyc-schedule-' . substr(hash('sha256', $conn->query('SELECT DATABASE()')->fetch_row()[0]), 0, 40);
    $stmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $stmt->close();
}


function bookingWindowRemaining(array $mechanics, array $reservations, DateTimeImmutable $start, int $duration): int
{
    $end = $start->modify("+$duration minutes");
    $free = $mechanics;
    $events = [];
    $assignedEvents = [];
    $startSql = $start->format('Y-m-d H:i:s');
    $endSql = $end->format('Y-m-d H:i:s');
    foreach ($reservations as $reservation) {
        if ($reservation['starts_at'] >= $endSql || $reservation['ends_at'] <= $startSql) continue;
        $id = (int)$reservation['mechanic_id'];
        if (isset($mechanics[$id])) {
            // Keep one mechanic free for the entire new appointment.
            unset($free[$id]);
            $a = max($startSql, $reservation['starts_at']);
            $b = min($endSql, $reservation['ends_at']);
            $assignedEvents[$id][$a] = ($assignedEvents[$id][$a] ?? 0) + 1;
            $assignedEvents[$id][$b] = ($assignedEvents[$id][$b] ?? 0) - 1;
        } else {
            // Pending/unassigned jobs reserve capacity too. Count their
            // peak concurrency, not every job that touches the window.
            $a = max($startSql, $reservation['starts_at']);
            $b = min($endSql, $reservation['ends_at']);
            $events[$a] = ($events[$a] ?? 0) + 1;
            $events[$b] = ($events[$b] ?? 0) - 1;
        }
    }
    // An overrun may displace a second job assigned to the same mechanic.
    // Keep capacity for that existing customer before offering new bookings.
    foreach ($assignedEvents as $mechanicEvents) {
        ksort($mechanicEvents);
        $assigned = 0;
        foreach ($mechanicEvents as $at => $change) {
            $before = max(0, $assigned - 1);
            $assigned += $change;
            $extra = max(0, $assigned - 1) - $before;
            $events[$at] = ($events[$at] ?? 0) + $extra;
        }
    }
    ksort($events);
    $used = $peak = 0;
    foreach ($events as $change) { $used += $change; $peak = max($peak, $used); }
    $remaining = max(0, count($free) - $peak);
    return $remaining;
}

function bookingRemainingAt(mysqli $conn, string $date, string $time, int $duration, int $excludeReservation = 0): int
{
    $start = bookingDateTime($date, $time);
    if (!$start) throw new InvalidArgumentException('Invalid job start.');
    $end = $start->modify("+$duration minutes")->format('Y-m-d H:i:s');
    $from = $start->format('Y-m-d H:i:s');
    $mechanics=[];
    $rows=$conn->query("SELECT id FROM mechanics WHERE status IN ('Available','Busy')");
    while($row=$rows->fetch_assoc())$mechanics[(int)$row['id']]=true;
    $stmt=$conn->prepare("SELECT mechanic_id,TIMESTAMP(appointment_date,appointment_time) starts_at,DATE_ADD(TIMESTAMP(appointment_date,appointment_time),INTERVAL GREATEST(scheduled_duration_minutes,30) MINUTE) ends_at FROM reservations WHERE id<>? AND status NOT IN ('Cancelled','Completed','Ready for Pickup') AND TIMESTAMP(appointment_date,appointment_time)<? AND DATE_ADD(TIMESTAMP(appointment_date,appointment_time),INTERVAL GREATEST(scheduled_duration_minutes,30) MINUTE)>?");
    $stmt->bind_param('iss',$excludeReservation,$end,$from);$stmt->execute();
    return bookingWindowRemaining($mechanics,$stmt->get_result()->fetch_all(MYSQLI_ASSOC),$start,$duration);
}

function bookingSlots(mysqli $conn, string $date, int $duration, int $excludeReservation = 0, bool $includeNow = false, ?DateTimeImmutable $clock = null): array
{
    $day = bookingDateTime($date, '08:00');
    if (!$day || $duration < 30) throw new InvalidArgumentException('Choose a valid date and at least one service.');
    $mechanics = [];
    $result = $conn->query("SELECT id FROM mechanics WHERE status IN ('Available','Busy')");
    while ($row = $result->fetch_assoc()) $mechanics[(int)$row['id']] = true;
    $nextDay = $day->modify('+1 day')->format('Y-m-d');
    $stmt = $conn->prepare("SELECT mechanic_id, TIMESTAMP(appointment_date,appointment_time) starts_at,
        DATE_ADD(TIMESTAMP(appointment_date,appointment_time), INTERVAL GREATEST(COALESCE(scheduled_duration_minutes,30),30) MINUTE) ends_at
        FROM reservations WHERE status NOT IN ('Cancelled','Completed','Ready for Pickup') AND id <> ?
        AND appointment_date < ?
        AND DATE_ADD(TIMESTAMP(appointment_date,appointment_time), INTERVAL GREATEST(COALESCE(scheduled_duration_minutes,30),30) MINUTE) > ?");
    $stmt->bind_param('iss', $excludeReservation, $nextDay, $date);
    $stmt->execute();
    $reservations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $stmt = $conn->prepare('SELECT id FROM shop_closed_dates WHERE closed_date=? LIMIT 1');
    $stmt->bind_param('s', $date);
    $stmt->execute();
    $closed = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    $now = ($clock ?? new DateTimeImmutable('now', new DateTimeZone('Asia/Manila')))->setTimezone(new DateTimeZone('Asia/Manila'));
    $starts = range(8 * 60, 17 * 60 - 30, 30);
    $nowMinute = (int)$now->format('H') * 60 + (int)$now->format('i');
    if ($includeNow && $date === $now->format('Y-m-d') && $nowMinute >= 480 && $nowMinute < 1020) {
        $starts[] = $nowMinute; $starts = array_unique($starts); sort($starts);
    }
    $slots = [];
    foreach ($starts as $minutes) {
        $start = $day->setTime(intdiv($minutes, 60), $minutes % 60);
        $end = $start->modify("+$duration minutes");
        $reason = '';
        $remaining = 0;
        if ($day->format('N') === '7') $reason = 'Closed on Sunday';
        elseif ($closed) $reason = 'Shop closed';
        elseif ($start <= $now && !($includeNow && $date === $now->format('Y-m-d') && $minutes === $nowMinute)) $reason = 'Past time';
        elseif ($end > $day->setTime(17, 0)) $reason = 'Service would finish after closing';
        else {
            $remaining = bookingWindowRemaining($mechanics, $reservations, $start, $duration);
            if (!$remaining) $reason = $mechanics ? 'Fully booked' : 'No active mechanics';
        }
        $slots[] = ['time' => $start->format('H:i'), 'label' => $start->format('g:i A'),
            'is_now' => $includeNow && $date === $now->format('Y-m-d') && $minutes === $nowMinute,
            'available' => $remaining > 0, 'remaining_capacity' => $remaining, 'reason' => $reason];
    }
    return ['success' => true, 'shop_today' => $now->format('Y-m-d'), 'timezone' => 'Asia/Manila', 'mechanic_capacity' => count($mechanics), 'duration_minutes' => $duration, 'slots' => $slots];
}

function bookingRequireSlot(mysqli $conn, string $date, string $time, int $duration, bool $includeNow = false, int $excludeReservation = 0): void
{
    $dt = bookingDateTime($date, $time);
    if ($dt) {
        foreach (bookingSlots($conn, $date, $duration, $excludeReservation, $includeNow)['slots'] as $slot) {
            if ($slot['time'] !== $dt->format('H:i')) continue;
            if ($slot['available']) return;
            throw new DomainException($slot['reason'] . '. Choose another available slot.');
        }
    }
    throw new DomainException('Choose a valid 30-minute slot between 8:00 AM and 5:00 PM.');
}
