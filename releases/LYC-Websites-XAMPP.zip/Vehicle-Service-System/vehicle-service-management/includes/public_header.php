<?php

include_once __DIR__ . "/config.php";
if (session_status() === PHP_SESSION_NONE) session_start();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        Luck Yuna Car Center
    </title>


    <!-- Bootstrap -->

    <link href="<?= BASE_URL ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Google Font -->

    


    <!-- Public CSS -->

    <link rel="stylesheet" href="<?= BASE_URL ?>/css/public.css?v=20261001-red">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/service-tabs.css?v=20261001">

<link rel="stylesheet" href="<?= BASE_URL ?>/css/public-polish.css?v=20261016">
</head>


<body>


    <nav class="public-navbar">

    <div class="container">

        <div class="navbar-content">

            <!-- LOGO + TITLE -->
            <a href="<?= BASE_URL ?>/index.php" class="public-logo">

                <img src="<?= BASE_URL ?>/images/logo.png"
                     alt="Luck Yuna Car Center logo"
                     style="width: 45px; height: 45px; object-fit: contain;">

                <span>
                    Luck Yuna Car Center
                </span>

            </a>


                <!-- MOBILE BUTTON -->

                <button class="mobile-menu-button" id="mobileMenuButton" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="publicNavLinks">

                    ☰

                </button>


                <!-- NAVIGATION -->

                <div class="public-nav-links" id="publicNavLinks" role="navigation" aria-label="Main navigation">

                    <a href="<?= BASE_URL ?>/index.php">
                        Home
                    </a>


                    <a href="<?= BASE_URL ?>/services.php">
                        Services
                    </a>


                    <a href="<?= BASE_URL ?>/about.php">
                        About Us
                    </a>


                    <a href="<?= BASE_URL ?>/contact.php">
                        Contact
                    </a>


                    <a href="<?= BASE_URL ?>/track.php">
                        Track Appointment
                    </a>


                    <a href="<?= BASE_URL ?>/<?= !empty($_SESSION['customer_id']) ? 'customer/dashboard.php' : 'login.php' ?>" class="account-nav-link">
                        <?= !empty($_SESSION['customer_id']) ? 'My Account' : 'Sign In' ?>
                    </a>
                    <a href="<?= BASE_URL ?>/appointment.php" class="book-nav-button">
                        BOOK NOW
                    </a>

                </div>

            </div>

        </div>

    </nav>
