<?php
// Check before page queries so an older database gets actionable instructions.
function requireCurrentSchema(mysqli $conn): void
{
    $required = [
        'customers' => ['user_id'], 'vehicles' => ['user_id'],
        'reservations' => ['user_id', 'checked_in_at', 'scheduled_duration_minutes'],
        'users' => ['staff_level', 'mechanic_id'],
        'service_categories' => ['id'], 'service_catalog' => ['id'],
        'reservation_services' => ['id'], 'payments' => ['payment_type'],
    ];
    $rows = mysqli_query($conn, 'SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE()');
    $found = [];
    while ($row = mysqli_fetch_assoc($rows)) { $found[$row['TABLE_NAME']][$row['COLUMN_NAME']] = true; }
    foreach ($required as $table => $columns) {
        foreach ($columns as $column) {
            if (!isset($found[$table][$column])) {
                http_response_code(503);
                header('Content-Type: text/html; charset=utf-8');
                echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Database update required</title><main style="max-width:680px;margin:10vh auto;padding:24px;font:18px/1.6 system-ui"><h1>Database update required</h1><p>The website files are newer than this database. Your existing records have not been changed.</p><p>On the XAMPP computer, export a database backup in phpMyAdmin, select your existing database, then import <strong>vehicle-service-management/database/lyc_database.sql</strong> from the latest website ZIP.</p><p>Keep your database. After importing, refresh this page.</p></main></html>';
                exit;
            }
        }
    }
}
