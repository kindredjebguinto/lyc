<?php
require_once __DIR__ . '/../includes/customer_auth.php';
$user_id = (int) $_SESSION['customer_id'];

$summaryStmt = mysqli_prepare($conn, "SELECT
    (SELECT COUNT(*) FROM vehicles WHERE user_id = ?) AS total_vehicles,
    (SELECT COUNT(*) FROM reservations WHERE user_id = ?) AS total_reservations,
    (SELECT COUNT(*) FROM reservations WHERE user_id = ? AND status = 'Pending') AS pending_reservations");
mysqli_stmt_bind_param($summaryStmt, 'iii', $user_id, $user_id, $user_id);
mysqli_stmt_execute($summaryStmt);
$summary = mysqli_fetch_assoc(mysqli_stmt_get_result($summaryStmt));
mysqli_stmt_close($summaryStmt);

$nextStmt = mysqli_prepare($conn, "SELECT r.id,r.service_type,r.appointment_date,r.appointment_time,r.status,
    v.brand,v.model,v.plate_number
    FROM reservations r INNER JOIN vehicles v ON v.id=r.vehicle_id
    WHERE r.user_id=? AND r.status NOT IN ('Completed','Cancelled')
    AND TIMESTAMP(r.appointment_date,r.appointment_time)>=NOW()
    ORDER BY r.appointment_date,r.appointment_time LIMIT 1");
mysqli_stmt_bind_param($nextStmt, 'i', $user_id);
mysqli_stmt_execute($nextStmt);
$nextAppointment = mysqli_fetch_assoc(mysqli_stmt_get_result($nextStmt));
mysqli_stmt_close($nextStmt);

$reminderStmt = mysqli_prepare($conn, "SELECT MAX(appointment_date) AS last_service FROM reservations WHERE user_id=? AND status='Completed' AND service_type LIKE '%Oil Change%'");
mysqli_stmt_bind_param($reminderStmt, 'i', $user_id);
mysqli_stmt_execute($reminderStmt);
$lastOilChange = mysqli_fetch_assoc(mysqli_stmt_get_result($reminderStmt))['last_service'] ?? null;
mysqli_stmt_close($reminderStmt);
$showMaintenanceReminder = $lastOilChange === null || strtotime($lastOilChange) < strtotime('-5 months');

require_once __DIR__ . '/../includes/customer_header.php';
$friendlyStatus = ['Pending'=>'Request Sent','Approved'=>'Appointment Confirmed','Diagnosing'=>'Vehicle Inspection','Quotation Sent'=>'Approval Needed','Quotation Accepted'=>'Service in Progress','In Progress'=>'Service in Progress'];
?>

<section class="customer-hero">
    <div>
        <small>WELCOME BACK</small>
        <h1>Hello, <?= htmlspecialchars($_SESSION['customer_name']) ?></h1>
        <p>How can we help your vehicle today?</p>
        <a class="customer-primary-action" href="<?= BASE_URL ?>/customer/services.php"><i class="bi bi-receipt-cutoff"></i> View Services & Estimate</a>
    </div>
    <div class="customer-hero-icon"><i class="bi bi-car-front-fill"></i></div>
</section>

<h2 class="customer-section-title">Next Appointment</h2>
<?php if ($nextAppointment): ?>
<article class="customer-card appointment-card">
    <div class="appointment-card-top">
        <div><h3><?= htmlspecialchars($nextAppointment['brand'].' '.$nextAppointment['model']) ?></h3><span class="plate"><?= htmlspecialchars($nextAppointment['plate_number']) ?></span></div>
        <?php $statusText = $friendlyStatus[$nextAppointment['status']] ?? $nextAppointment['status']; ?>
        <span class="status-pill status-<?= strtolower(str_replace(' ', '-', $nextAppointment['status'])) ?>"><?= htmlspecialchars($statusText) ?></span>
    </div>
    <p class="mt-3 mb-0"><?= htmlspecialchars($nextAppointment['service_type']) ?></p>
    <div class="appointment-meta">
        <span><i class="bi bi-calendar3"></i><?= date('M d, Y', strtotime($nextAppointment['appointment_date'])) ?></span>
        <span><i class="bi bi-clock"></i><?= date('g:i A', strtotime($nextAppointment['appointment_time'])) ?></span>
        <a href="<?= BASE_URL ?>/customer/reservations.php">Track booking <i class="bi bi-chevron-right"></i></a>
    </div>
</article>
<?php else: ?>
<div class="customer-card customer-empty"><i class="bi bi-calendar2-check"></i><h3 class="h5 mt-2">No upcoming appointment</h3><p class="text-muted">Choose the services your vehicle needs and book when you're ready.</p><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/book_service.php">Book Service</a></div>
<?php endif; ?>

<?php if ($showMaintenanceReminder): ?>
<a class="account-link mt-3" href="<?= BASE_URL ?>/customer/services.php">
    <i class="bi bi-bell"></i><div><strong>Maintenance Reminder</strong><small>Your vehicle may be due for an oil change. Check your mileage or book an inspection.</small></div><i class="bi bi-chevron-right"></i>
</a>
<?php endif; ?>

<h2 class="customer-section-title">Overview</h2>
<div class="customer-stats">
    <a class="customer-card customer-stat text-decoration-none text-dark" href="<?= BASE_URL ?>/customer/vehicles.php"><i class="bi bi-car-front"></i><strong><?= (int)$summary['total_vehicles'] ?></strong><span>Vehicles</span></a>
    <a class="customer-card customer-stat text-decoration-none text-dark" href="<?= BASE_URL ?>/customer/reservations.php"><i class="bi bi-calendar-event"></i><strong><?= (int)$summary['total_reservations'] ?></strong><span>Bookings</span></a>
    <a class="customer-card customer-stat text-decoration-none text-dark" href="<?= BASE_URL ?>/customer/reservations.php"><i class="bi bi-hourglass-split"></i><strong><?= (int)$summary['pending_reservations'] ?></strong><span>Pending</span></a>
</div>

<h2 class="customer-section-title">Quick Access</h2>
<div class="customer-grid">
    <a class="account-link" href="<?= BASE_URL ?>/customer/reservations.php"><i class="bi bi-crosshair"></i><div><strong>Track Service</strong><small>Check approval and repair progress</small></div><i class="bi bi-chevron-right"></i></a>
    <a class="account-link" href="<?= BASE_URL ?>/customer/payments.php"><i class="bi bi-wallet2"></i><div><strong>Payments & Receipts</strong><small>Review your payment records</small></div><i class="bi bi-chevron-right"></i></a>
</div>

<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
