<?php
require_once __DIR__ . '/../includes/customer_auth.php';
require_once __DIR__ . '/../includes/service_categories.php';
$services = [];
$result = mysqli_query($conn, "SELECT id,service_name,description,price,estimated_duration FROM services WHERE status='Active' ORDER BY service_name");
while ($result && $row = mysqli_fetch_assoc($result)) $services[] = $row;
$serviceCategories = service_categories_for($services);
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header">
    <div><h1>Services & Estimate</h1><p>Check everything your vehicle needs and see an estimated total before booking.</p></div>
</div>

<?php if ($services): ?>
<form id="serviceEstimateForm" action="<?= BASE_URL ?>/customer/book_service.php" method="get">
    <div class="service-category-tabs" role="tablist" aria-label="Service categories">
        <button class="service-category-tab active" type="button" data-category="all">All</button>
        <?php foreach ($serviceCategories as $category): ?>
        <button class="service-category-tab" type="button" data-category="<?= service_category_slug($category) ?>"><?= htmlspecialchars($category) ?></button>
        <?php endforeach; ?>
    </div>
    <div class="service-estimate-grid">
        <?php foreach ($services as $service): ?>
        <label class="service-choice" data-service-category="<?= service_category_slug(service_category($service['service_name'])) ?>">
            <input type="checkbox" name="services[]" value="<?= (int)$service['id'] ?>" data-price="<?= (float)$service['price'] ?>">
            <span class="service-choice-body"><span><h3><?= htmlspecialchars($service['service_name']) ?></h3><p><?= htmlspecialchars($service['description'] ?: 'Vehicle inspection and service.') ?></p><strong>₱<?= number_format((float)$service['price'], 2) ?></strong><?php if (!empty($service['estimated_duration'])): ?><small class="text-muted ms-2">• <?= (int)$service['estimated_duration'] ?> mins</small><?php endif; ?></span></span>
        </label>
        <?php endforeach; ?>
    </div>
    <div class="estimate-summary">
        <div><small><span id="estimateCount">0</span> service(s) selected</small><strong id="estimateTotal">₱0.00</strong></div>
        <button class="customer-primary-action" id="estimateBookButton" type="submit" disabled>Continue to Booking <i class="bi bi-arrow-right"></i></button>
    </div>
</form>
<script>
(() => {
  const boxes = [...document.querySelectorAll('#serviceEstimateForm input[type="checkbox"]')];
  const count = document.getElementById('estimateCount');
  const total = document.getElementById('estimateTotal');
  const button = document.getElementById('estimateBookButton');
  const tabs = [...document.querySelectorAll('.service-category-tab')];
  const cards = [...document.querySelectorAll('[data-service-category]')];
  const update = () => {
    const selected = boxes.filter(box => box.checked);
    const amount = selected.reduce((sum, box) => sum + Number(box.dataset.price || 0), 0);
    count.textContent = selected.length;
    total.textContent = '₱' + amount.toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    button.disabled = selected.length === 0;
  };
  boxes.forEach(box => box.addEventListener('change', update));
  tabs.forEach(tab => tab.addEventListener('click', () => {
    tabs.forEach(item => item.classList.toggle('active', item === tab));
    cards.forEach(card => card.hidden = tab.dataset.category !== 'all' && card.dataset.serviceCategory !== tab.dataset.category);
  }));
  update();
})();
</script>
<?php else: ?>
<div class="customer-card customer-empty"><i class="bi bi-tools"></i><h2 class="h5 mt-2">No services available</h2><p class="text-muted mb-0">Please check again later.</p></div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
