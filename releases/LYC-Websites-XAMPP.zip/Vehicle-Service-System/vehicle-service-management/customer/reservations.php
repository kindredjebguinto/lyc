<?php
require_once __DIR__ . '/../includes/customer_auth.php';
$user_id = (int)$_SESSION['customer_id'];
$stmt = mysqli_prepare($conn, "SELECT r.id,r.reference_number,r.service_type,r.appointment_date,r.appointment_time,r.remarks,r.status,
    v.brand,v.model,v.plate_number,m.fullname AS mechanic_name,
    p.id AS payment_id,p.status AS payment_status,p.amount AS payment_amount,
    q.id AS quotation_id,q.status AS quotation_status,q.grand_total
    FROM reservations r
    INNER JOIN vehicles v ON r.vehicle_id=v.id
    LEFT JOIN mechanics m ON r.mechanic_id=m.id
    LEFT JOIN payments p ON r.id=p.reservation_id
    LEFT JOIN job_quotations q ON r.id=q.reservation_id
    WHERE r.user_id=? ORDER BY r.appointment_date DESC,r.appointment_time DESC");
mysqli_stmt_bind_param($stmt,'i',$user_id); mysqli_stmt_execute($stmt); $result=mysqli_stmt_get_result($stmt);
$reservations=[]; while($row=mysqli_fetch_assoc($result)) $reservations[]=$row; mysqli_stmt_close($stmt);
$friendly=['Pending'=>'Request Sent','Approved'=>'Appointment Confirmed','Diagnosing'=>'Vehicle Inspection','Quotation Sent'=>'Approval Needed','Quotation Accepted'=>'Service in Progress','In Progress'=>'Service in Progress'];
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header"><div><h1>My Bookings</h1><p>Track appointments, quotations, service progress, and payment status.</p></div><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/book_service.php"><i class="bi bi-plus-lg"></i> Book Service</a></div>
<?php if (($_GET['booked'] ?? '') === '1'): ?><div class="alert alert-success">Your booking request was sent successfully. You can track it here.</div><?php endif; ?>
<?php if ($reservations): ?><div class="customer-list">
<?php foreach($reservations as $item): $status=$item['status']; $statusText=$friendly[$status]??$status; ?>
<article class="customer-card appointment-card">
    <div class="appointment-card-top"><div><small class="text-muted"><?= htmlspecialchars($item['reference_number'] ?: '#'.$item['id']) ?></small><h3><?= htmlspecialchars($item['brand'].' '.$item['model']) ?></h3><span class="plate"><?= htmlspecialchars($item['plate_number']) ?></span></div><span class="status-pill status-<?= strtolower(str_replace(' ','-',$status)) ?>"><?= htmlspecialchars($statusText) ?></span></div>
    <p class="mt-3 mb-1 fw-semibold"><?= htmlspecialchars($item['service_type']) ?></p>
    <?php if ($item['remarks']): ?><p class="small text-muted mb-0"><?= htmlspecialchars($item['remarks']) ?></p><?php endif; ?>
    <div class="appointment-meta"><span><i class="bi bi-calendar3"></i><?= date('M d, Y',strtotime($item['appointment_date'])) ?></span><span><i class="bi bi-clock"></i><?= date('g:i A',strtotime($item['appointment_time'])) ?></span><span><i class="bi bi-person-workspace"></i><?= htmlspecialchars($item['mechanic_name'] ?: 'Mechanic not assigned') ?></span></div>
    <div class="d-flex flex-wrap gap-2 mt-3 align-items-center">
        <?php if ($item['quotation_id']): ?><span class="status-pill"><i class="bi bi-receipt me-1"></i>Quote <?= htmlspecialchars($item['quotation_status']) ?> • ₱<?= number_format((float)$item['grand_total'],2) ?></span><?php else: ?><span class="status-pill">Quotation not available yet</span><?php endif; ?>
        <?php if ($item['payment_id']): ?><span class="status-pill status-<?= strtolower(str_replace(' ','-',$item['payment_status'])) ?>">Payment: <?= htmlspecialchars($item['payment_status']) ?></span><?php endif; ?>
        <?php if ($item['payment_id'] && $item['payment_status']==='Paid'): ?><a class="btn btn-sm btn-outline-success ms-auto" href="<?= BASE_URL ?>/customer/receipt.php?id=<?= (int)$item['payment_id'] ?>">View Receipt</a><?php endif; ?>
    </div>
</article>
<?php endforeach; ?></div>
<?php else: ?><div class="customer-card customer-empty"><i class="bi bi-calendar2"></i><h2 class="h5 mt-2">No bookings yet</h2><p class="text-muted">Select one or more services and book your first appointment.</p><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/services.php">View Services</a></div><?php endif; ?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
