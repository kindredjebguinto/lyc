<?php
require_once __DIR__ . '/../includes/customer_auth.php';
$userId = (int)$_SESSION['customer_id'];
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$error = '';
$iniBytes = static function ($value) {
    $value = trim($value);
    $number = (float)$value;
    $unit = strtoupper(substr($value, -1));
    return (int)($number * (['K'=>1024, 'M'=>1024**2, 'G'=>1024**3][$unit] ?? 1));
};
$proofLimit = 5 * 1024 * 1024;
$uploadLimit = $iniBytes(ini_get('upload_max_filesize'));
$postLimit = $iniBytes(ini_get('post_max_size'));
if ($uploadLimit > 0) $proofLimit = min($proofLimit, $uploadLimit);
if ($postLimit > 0) $proofLimit = min($proofLimit, max(0, $postLimit - 65536));
$proofLimitLabel = rtrim(rtrim(number_format($proofLimit / (1024 * 1024), 2, '.', ''), '0'), '.') . ' MB';

$method = is_string($_POST['payment_method'] ?? null) ? $_POST['payment_method'] : '';
$reference = is_string($_POST['reference_number'] ?? null) ? trim($_POST['reference_number']) : '';
$stmt = $conn->prepare("SELECT p.*,r.reference_number AS booking_reference,r.service_type,v.brand,v.model
    FROM payments p JOIN reservations r ON r.id=p.reservation_id JOIN vehicles v ON v.id=r.vehicle_id
    WHERE p.id=? AND r.user_id=? AND p.status IN ('Awaiting Proof','Rejected') AND p.amount>0 AND r.status<>'Cancelled'
    AND (p.payment_type='Reservation Fee' OR EXISTS (SELECT 1 FROM job_quotations q WHERE q.reservation_id=r.id AND q.status='Accepted')) LIMIT 1");
$stmt->bind_param('ii', $id, $userId);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$payment) { header('Location: ' . BASE_URL . '/customer/payments.php'); exit; }
$isFee = $payment['payment_type'] === 'Reservation Fee';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!is_string($csrf) || !hash_equals($_SESSION['csrf_token'], $csrf)) $error = 'Your form expired. Refresh this page and try again.';
    if (!$error && !in_array($method, ['GCash','Maya','Bank Transfer'], true)) $error = 'Choose a payment method.';
    if (!$error && ($reference === '' || strlen($reference) > 100)) $error = 'Enter a transaction reference of up to 100 characters.';
    if (!$error && (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK)) $error = 'Choose a payment proof image. If it is too large, try a smaller image.';
    if (!$error) {
        $file = $_FILES['proof'];
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if ($file['size'] <= 0 || $file['size'] > $proofLimit || !isset($extensions[$mime])) $error = 'Choose a JPG, PNG, or WEBP image up to ' . $proofLimitLabel . '.';
    }
    if (!$error) {
        $dir = __DIR__ . '/../uploads/payment_proofs';
        $destination = null;
        try {
            if (!is_dir($dir) && !mkdir($dir, 0755, true)) throw new RuntimeException('Upload directory unavailable');
            $name = 'proof_' . $id . '_' . bin2hex(random_bytes(6)) . '.' . $extensions[$mime];
            $destination = $dir . '/' . $name;
            if (!move_uploaded_file($file['tmp_name'], $destination)) throw new RuntimeException('Upload unavailable');
            $relative = 'uploads/payment_proofs/' . $name;
            $conn->begin_transaction();
            $stmt = $conn->prepare("UPDATE payments p JOIN reservations r ON r.id=p.reservation_id
                SET p.payment_method=?,p.reference_number=?,p.proof_file=?,p.status='Under Review',p.submitted_at=NOW(),p.paid_at=NULL,p.admin_notes=NULL
                WHERE p.id=? AND r.user_id=? AND p.status IN ('Awaiting Proof','Rejected') AND p.amount>0 AND r.status<>'Cancelled'
                AND (p.payment_type='Reservation Fee' OR EXISTS (SELECT 1 FROM job_quotations q WHERE q.reservation_id=r.id AND q.status='Accepted'))");
            $stmt->bind_param('sssii', $method, $reference, $relative, $id, $userId);
            $stmt->execute();
            $changed = $stmt->affected_rows;
            $stmt->close();
            if (!$changed) throw new DomainException('This payment has changed. Open Payments & Receipts to check its current status before uploading again.');
            if ($isFee) {
                $stmt = $conn->prepare("UPDATE reservations SET reservation_fee_status='Under Review' WHERE id=?");
                $stmt->bind_param('i', $payment['reservation_id']);
                $stmt->execute();
                $stmt->close();
            }
            $conn->commit();
            $oldProof = $payment['proof_file'] ?? '';
            if ($oldProof && $oldProof !== $relative && str_starts_with($oldProof, 'uploads/payment_proofs/')) {
                $oldPath = $dir . '/' . basename($oldProof);
                if (is_file($oldPath)) @unlink($oldPath);
            }
            $_SESSION['payment_submission_id'] = $id;
            header('Location: ' . BASE_URL . '/customer/payments.php');
            exit;
        } catch (Throwable $e) {
            $conn->rollback();
            if ($destination && is_file($destination)) @unlink($destination);
            $error = $e instanceof DomainException ? $e->getMessage() : 'We could not save your proof. Your payment was not marked as paid. Please try again.';
        }
    }
}
$amountLabel = '₱' . number_format((float)$payment['amount'], 2);
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header"><div><a class="payment-back" href="<?= BASE_URL ?>/customer/payments.php">← Payments & Receipts</a><h1><?= $isFee ? 'Reservation fee' : 'Service payment' ?></h1><p>Transfer the exact amount, then send your proof for verification.</p></div></div>
<?php if ($error): ?><div class="alert alert-danger" role="alert" tabindex="-1" id="paymentError"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<div class="payment-layout">
    <aside class="customer-card payment-summary" aria-labelledby="paymentSummaryTitle">
        <span class="payment-eyebrow"><?= $isFee ? 'REFUNDABLE RESERVATION FEE' : 'SERVICE BALANCE' ?></span>
        <h2 id="paymentSummaryTitle" class="payment-amount"><?= $amountLabel ?></h2>
        <p class="text-muted">Amount to transfer</p>
        <dl class="payment-facts"><div><dt>Booking</dt><dd><?= htmlspecialchars($payment['booking_reference'] ?: '#' . $payment['reservation_id']) ?></dd></div><div><dt>Vehicle</dt><dd><?= htmlspecialchars($payment['brand'] . ' ' . $payment['model']) ?></dd></div><div><dt>Services</dt><dd><?= htmlspecialchars($payment['service_type']) ?></dd></div></dl>
        <?php if ($isFee): ?><p class="payment-policy">This fee is credited to your final bill and is refundable if you or the shop cancels before inspection. A no-show may forfeit the fee.</p><?php else: ?><p class="payment-policy">This is the recorded amount due for your accepted service quotation. The reservation-fee refund policy does not describe this payment.</p><?php endif; ?>
        <?php if ($payment['status'] === 'Rejected'): ?><div class="alert alert-warning"><strong>Proof needs attention</strong><p class="mb-0"><?= htmlspecialchars($payment['admin_notes'] ?: 'Check your transaction details and upload a clearer proof image.') ?></p><small>If you already transferred the correct amount, correct the proof rather than paying again.</small></div><?php endif; ?>
    </aside>
    <section class="customer-card" aria-labelledby="proofFormTitle">
        <h2 id="proofFormTitle" class="h4">Send payment proof</h2>
        <ol class="payment-steps"><li>Use the recipient details supplied by Luck Yuna Car Center. Confirm the recipient name before sending.</li><li>Transfer exactly <strong><?= $amountLabel ?></strong> using your chosen method.</li><li>Upload the transaction reference and proof below. Staff will verify it before a receipt becomes available.</li></ol>
        <form method="post" enctype="multipart/form-data" id="paymentProofForm" data-proof-limit="<?= $proofLimit ?>" data-proof-limit-label="<?= htmlspecialchars($proofLimitLabel) ?>">
            <input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
            <div class="mb-3"><label class="form-label" for="paymentMethod">Payment method</label><select class="form-select" name="payment_method" id="paymentMethod" required><option value="">Choose the method you used</option><?php foreach (['GCash','Maya','Bank Transfer'] as $option): ?><option value="<?= $option ?>" <?= $method === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select></div>
            <div class="mb-3"><label class="form-label" for="paymentReference">Transaction reference</label><input class="form-control" id="paymentReference" name="reference_number" maxlength="100" value="<?= htmlspecialchars($reference) ?>" aria-describedby="referenceHint" required><p class="form-text" id="referenceHint">Use the reference from your completed transfer, not your booking number.</p></div>
            <div class="mb-3"><label class="form-label" for="paymentProof">Proof image</label><input class="form-control" id="paymentProof" type="file" name="proof" accept="image/jpeg,image/png,image/webp" aria-describedby="proofHint proofFeedback" required><p class="form-text" id="proofHint">JPG, PNG or WEBP, up to <?= htmlspecialchars($proofLimitLabel) ?>. Show the amount, recipient and transaction reference. Hide unrelated personal details.</p><p id="proofFeedback" role="status" class="form-text"></p><img id="proofPreview" class="payment-proof-preview" alt="Selected payment proof" hidden></div>
            <p class="payment-verification-note">Uploading proof does not mark this payment as paid. You can follow its verification status in Payments & Receipts.</p>
            <button class="customer-primary-action w-100" type="submit" id="proofSubmit">Submit proof for <?= $amountLabel ?></button>
        </form>
    </section>
</div>
<script src="<?= BASE_URL ?>/js/payment-proof.js"></script>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
