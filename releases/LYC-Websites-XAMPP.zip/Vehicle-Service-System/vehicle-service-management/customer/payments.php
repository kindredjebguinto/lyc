<?php
require_once __DIR__ . '/../includes/customer_auth.php';
$userId = (int)$_SESSION['customer_id'];
$stmt = $conn->prepare("SELECT p.*,r.id AS booking_id,r.reference_number AS booking_reference,r.service_type,r.appointment_date,r.status AS booking_status,
    v.brand,v.model,v.plate_number,
    EXISTS (SELECT 1 FROM job_quotations q WHERE q.reservation_id=r.id AND q.status='Accepted') AS quotation_accepted
    FROM payments p JOIN reservations r ON r.id=p.reservation_id JOIN vehicles v ON r.vehicle_id=v.id
    WHERE r.user_id=? ORDER BY p.created_at DESC,p.id DESC");
$stmt->bind_param('i', $userId);
$stmt->execute();
$payments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$submittedId = (int)($_SESSION['payment_submission_id'] ?? 0);
unset($_SESSION['payment_submission_id']);
$statusLabels = ['Awaiting Proof'=>'Proof needed','Under Review'=>'Being verified','Rejected'=>'Proof needs attention','Paid'=>'Payment verified','Pending'=>'Awaiting instructions','Pay at Shop'=>'Pay at the shop','Cancelled'=>'Cancelled'];
$statusHelp = [
    'Awaiting Proof'=>'Already transferred? Send your reference and proof. Do not pay twice.',
    'Under Review'=>'Your proof is with the shop for verification. You do not need to upload it again.',
    'Rejected'=>'Read the reason below and correct your proof. A rejected image does not mean you need to transfer again.',
    'Paid'=>'The shop has confirmed this payment. Your receipt is available below.',
    'Pending'=>'The shop will confirm the payment instructions for this booking.',
    'Pay at Shop'=>'Pay at the service counter. Staff will confirm receipt of your payment.',
    'Cancelled'=>'This payment is cancelled. Check any refund status below.'
];
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header"><div><h1>Payments & Receipts</h1><p>See what each payment covers, what happens next, and when your receipt is ready.</p></div></div>
<?php foreach ($payments as $payment): if ((int)$payment['id'] === $submittedId && $payment['status'] === 'Under Review'): ?>
<div class="alert alert-success" role="status"><strong>Proof uploaded successfully.</strong> Your payment is awaiting staff verification. This is not a payment confirmation.</div>
<?php endif; endforeach; ?>
<?php if ($payments): ?><div class="customer-list">
<?php foreach ($payments as $payment):
    $isFee = $payment['payment_type'] === 'Reservation Fee';
    $canSubmit = (float)$payment['amount'] > 0 && in_array($payment['status'], ['Awaiting Proof','Rejected'], true)
        && $payment['booking_status'] !== 'Cancelled' && ($isFee || $payment['quotation_accepted']);
?>
<article class="customer-card payment-record">
    <div class="appointment-card-top"><div><span class="payment-eyebrow"><?= htmlspecialchars($payment['payment_type']) ?></span><h2 class="h5 mt-2 mb-1"><?= htmlspecialchars($payment['brand'].' '.$payment['model']) ?></h2><p class="text-muted small mb-0"><?= htmlspecialchars($payment['booking_reference'] ?: '#'.$payment['booking_id']) ?> · <?= htmlspecialchars($payment['plate_number']) ?></p></div><span class="status-pill status-<?= htmlspecialchars(strtolower(str_replace(' ','-',$payment['status']))) ?>"><?= htmlspecialchars($statusLabels[$payment['status']] ?? $payment['status']) ?></span></div>
    <div class="payment-record-body"><div><p class="mt-3 mb-1 fw-semibold"><?= htmlspecialchars($payment['service_type']) ?></p><p class="small text-muted"><?= date('M d, Y', strtotime($payment['appointment_date'])) ?> · <?= htmlspecialchars($payment['payment_method'] ?: 'Not selected') ?></p></div><div class="payment-record-amount"><strong>₱<?= number_format((float)$payment['amount'],2) ?></strong><span><?= $payment['status'] === 'Paid' ? 'Verified payment' : ($payment['status'] === 'Cancelled' ? 'Cancelled amount' : 'Recorded amount') ?></span></div></div>
    <p class="payment-next-step"><?= htmlspecialchars(($payment['booking_status'] === 'Cancelled') ? 'This booking is cancelled. Do not send another payment. Check any refund status below.' : (((float)$payment['amount'] <= 0 && $payment['status'] !== 'Paid' && $payment['status'] !== 'Cancelled') ? 'No transfer is needed for this recorded balance. The shop can confirm settlement and receipt availability.' : ($statusHelp[$payment['status']] ?? 'Check this booking for the next payment action.'))) ?></p>
    <?php if (!$isFee && (float)$payment['reservation_fee_credit'] > 0): ?><p class="small text-muted">Recorded reservation-fee credit: ₱<?= number_format((float)$payment['reservation_fee_credit'],2) ?>. The displayed balance already includes this credit.</p><?php endif; ?>
    <?php if ($isFee): ?><p class="small text-muted">Reservation fee: credited to the final bill. Refundable on cancellation before inspection; no-show rules apply.</p><?php endif; ?>
    <?php if ($payment['status'] === 'Rejected' && $payment['admin_notes']): ?><div class="alert alert-warning"><strong>Reason from the shop</strong><p class="mb-0"><?= htmlspecialchars($payment['admin_notes']) ?></p></div><?php endif; ?>
    <?php if ($payment['reference_number']): ?><p class="small text-muted payment-reference">Transaction reference: <?= htmlspecialchars($payment['reference_number']) ?></p><?php endif; ?>
    <?php if ($payment['refund_status'] !== 'Not Applicable'): ?><p class="small"><strong>Refund: <?= htmlspecialchars($payment['refund_status']) ?></strong><?php if ($payment['refund_reference']): ?> · Reference <?= htmlspecialchars($payment['refund_reference']) ?><?php endif; ?></p><?php endif; ?>
    <div class="d-flex gap-2 flex-wrap mt-3">
        <?php if ($canSubmit): ?><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/payment_submit.php?id=<?= (int)$payment['id'] ?>"><?= $payment['status'] === 'Rejected' ? 'Correct payment proof' : 'Send payment proof' ?></a>
        <?php elseif ($payment['status'] === 'Paid'): ?><a class="btn btn-outline-success" href="<?= BASE_URL ?>/customer/receipt.php?id=<?= (int)$payment['id'] ?>">View receipt</a><?php endif; ?>
    </div>
</article>
<?php endforeach; ?></div>
<?php else: ?><div class="customer-card customer-empty"><h2 class="h5 mt-2">No payments yet</h2><p class="text-muted">Reservation fees and service balances will appear here when your booking requires payment.</p><a class="customer-primary-action" href="<?= BASE_URL ?>/customer/reservations.php">View my bookings</a></div><?php endif; ?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
