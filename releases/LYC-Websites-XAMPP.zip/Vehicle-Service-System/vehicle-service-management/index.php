<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (isset($_SESSION['customer_id']) && ($_SESSION['customer_role'] ?? '') === 'customer') {
    require_once __DIR__ . '/includes/config.php';
    header('Location: ' . BASE_URL . '/customer/dashboard.php');
    exit;
}
require __DIR__ . '/landing.php';
