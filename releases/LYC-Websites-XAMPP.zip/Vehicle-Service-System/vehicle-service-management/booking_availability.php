<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/booking_slots.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false, 'message'=>'Method not allowed.']);
    exit;
}
$data = json_decode(file_get_contents('php://input'), true);
$ids = $data['service_ids'] ?? [];
if (!is_array($ids)) $ids = [];
$ids = array_values(array_unique(array_filter(array_map(fn($id) => is_scalar($id) ? (int)$id : 0, $ids), fn($id) => $id > 0)));
if (!$ids) {
    http_response_code(422);
    echo json_encode(['success'=>false, 'message'=>'Choose at least one service.']);
    exit;
}
$table = ($data['catalog'] ?? '') === 'guest' ? 'service_catalog' : 'services';
$result = $conn->query("SELECT estimated_duration FROM $table WHERE status='Active' AND id IN (" . implode(',', $ids) . ')');
if ($result->num_rows !== count($ids)) {
    http_response_code(422);
    echo json_encode(['success'=>false, 'message'=>'One or more selected services are unavailable.']);
    exit;
}
try {
    echo json_encode(bookingSlots($conn, (string)($data['appointment_date'] ?? ''), bookingDuration($result->fetch_all(MYSQLI_ASSOC))));
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
