# Mechanic-based booking slots

Booking now reserves mechanic capacity instead of blocking the whole shop after one appointment. Website visitors, signed-in customers and the mobile API share the same scheduling rules. The website shows start-time buttons with the number of places remaining; Flutter shows capacity and specific unavailable-slot reasons.

Example: with three active mechanics and one overlapping, unassigned booking, the time has two places remaining. Once all places are reserved, the slot is disabled. Submission rechecks capacity under a database advisory lock, preventing simultaneous requests from taking the final place. Pending bookings reserve capacity; cancelled and completed bookings release it.

## Scheduling rules

- Starts every 30 minutes from 8:00 AM, using Asia/Manila shop time.
- The complete service must fit before 5:00 PM. Sundays and configured shop-closure dates are unavailable.
- Available and Busy mechanics count as active staff. Busy describes current work; assigned appointments determine whether they are free at the requested future time. Inactive mechanics do not add capacity.
- Assigned jobs require one active mechanic to be free throughout the new appointment. Unassigned jobs reserve pooled capacity based on peak overlap. This intentionally favors a feasible full-duration appointment over fragmented mechanic availability.
- The existing allowance is preserved: reserved time is twice each selected service's duration, with a 30-minute minimum per service before applying the multiplier. This is displayed alongside the slots.
- Mechanic assignment remains an administrator action. Assignment now checks the complete interval, rather than only an identical start time.
- No new database schema or migration is required beyond the package's existing setup migrations, including service_selector_integration.sql. Older bookings keep their stored scheduled durations.

## Files and installation

The repository's existing ZIP has been updated. Extract the updated archive into your development/deployment project and deploy the changed PHP, JavaScript and CSS together. Rebuild the Flutter client to use its new labels. The local extracted app under /workspace/lyc-dev/Vehicle-Service-System has also been updated. The hosted production app has not been deployed by this change.

The adjacent booking-slots.patch provides a text review of the changes relative to the original ZIP. Preserve local customizations when applying updates.

## Validation

- PHP scheduling suite: 19 passed checks, covering capacity, active/inactive mechanics, interval boundaries, assigned jobs, cancellation/completion, closures, invalid times, and simultaneous requests for the last place.
- Browser/API integration: guest mobile slot selection and submission, customer slot selection and submission, capacity exhaustion, off-grid and late appointments, disabled full slots, and admin overlap rejection/assignment to another mechanic passed. Test accounts and appointments were removed afterward.
- PHP syntax and JavaScript syntax checks passed. Existing backend smoke checks passed.
- Flutter source updated, but no Flutter build/analyzer or Android device test was run because the SDK is unavailable in this environment.

Run the isolated scheduling suite in the prepared environment:

```sh
docker exec lyc-web php -d mysqli.default_socket=/run/mysqld/mysqld.sock /srv/Vehicle-Service-System/tests/booking_slots_test.php
```

The suite creates and removes a temporary test database, leaving application data unchanged. It requires local development database privileges.

## Product feedback

Prototype rating: 7/10. Clear branding, service pricing and the booking/payment workflow provide a useful foundation. Original priorities after scheduling (homepage, hours and mobile-grid fixes are now included in WEBSITE_POLISH_UPDATE.md):

1. Fix mobile horizontal overflow in the car-brand logo grid.
2. Align published opening hours with booking rules; the footer currently advertises Sunday opening.
3. Make the public homepage the default entry point and keep account login easy to find.
4. Consolidate overlapping service offerings and clarify what each package includes.
5. Add mechanic working schedules, leave and service specializations before treating all active staff as interchangeable. Track actual service duration to replace the blanket time allowance with measured estimates.
