# Lucky Yuna Flutter Service Workflow Integration

Gamitin sa XAMPP test project na may Core at Admin Workflow packages at
na-import na ang dalawang service workflow migrations. Ang ZIP na ito ay
may Flutter customer files, PHP API updates, at PowerShell 5.1 merge script.

## I-merge sa XAMPP test copy

1. I-extract ang buong ZIP at buksan ang extracted folder sa PowerShell.
2. I-run ang script bilang isang command. Palitan ang ProjectRoot kung iba
   ang path ng test copy.

   ```powershell
   .\Apply-Flutter-Workflow.ps1 -ProjectRoot 'C:\xampp\htdocs\Vehicle-Service-System'
   ```

   Iche-check ng script ang ZIP files, iba-backup ang existing files na
   maaapektuhan, at ibe-verify ang 16 copied files. Ang success message
   ay may backup path. Manual merge option din ang dalawang folders sa ZIP
   sa corresponding folders ng project.
3. I-run ang Flutter mula sa vsm_customer folder gamit ang dati mong working
   XAMPP API URL at Google sign-in build settings.

## I-enable para sa combined XAMPP test

Kapag nasa parehong XAMPP test copy na ang Core, Admin at Flutter updates,
idagdag ang directive sa .htaccess ng project root na Vehicle-Service-System
kung ginagamit ng local Apache ang .htaccess.

```apache
SetEnv LYC_SERVICE_WORKFLOW_ENABLED 1
```

Kung may existing directive para sa parehong setting, i-update ang value.
I-refresh ang booking screen para ma-load ang bagong service catalog.
Ang confirmed-price workflow ay para sa bagong booking. Maaaring gamitin
ang value na 0 para i-pause ang enrollment habang nire-review ang test data.

## I-check sa phone

1. Sa bagong booking, i-review ang original scope at i-confirm ang prices.
   Dumadaan pa rin ang PHP 200 reservation fee sa existing payment flow.
2. Sa Admin Website, kumpletuhin ang inspection at simulan ang original
   work. Kung may findings, gumawa ng additional quotation.
3. Sa app, buksan ang My Bookings at i-review ang additional quotation.
   I-check ang approve, decline at pagbalik sa work status.
4. Sa Admin, i-finalize ang completed work. Balikan ang booking para
   makita ang finalized balance at receipt kapag na-verify ang payment.
   Ulitin sa original-only booking para ma-check ang no-quote path.

Pumasa ang 126 Flutter tests at ang PHP HTTP checks sa disposable MariaDB.
I-check ang actual XAMPP test installation at physical phone pagkatapos
ng merge.
