[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$required = @(
    'vsm_customer\pubspec.yaml',
    'vehicle-service-management\includes\service_workflow_staff.php',
    'vehicle-service-management-admin\includes\workflow_integration.php'
)
foreach ($relative in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $relative) -PathType Leaf)) {
        throw "Install the Core and Admin workflow updates in this test project first. Missing: $relative"
    }
}

$updates = [ordered]@{
    'vehicle-service-management\includes\service_workflow.php' = '19c3d8164f6a7ef7fe52d0d1ca8ff7be1df27a6d6655653b00aa6c32e71fa136'
    'vehicle-service-management\api\dashboard\summary.php' = '4667ad5ebe231102308c5efc8e3f7f320d8c00a26e22c85750247b6ea145e0ef'
    'vehicle-service-management\api\payments\list.php' = 'e93a8077f40cf85399a069713db9ba76d26cb5b4cdf47850bf3478842f6afd93'
    'vehicle-service-management\api\reservations\create.php' = '1033f83eea8fd90565d4fbb49831857b941346491c440f5ba9b8feae65adc17d'
    'vehicle-service-management\api\reservations\list.php' = '36e1781009767deffcfa1eadee896e3d936a0c3a7606be7524e76c85ceae30ca'
    'vehicle-service-management\api\services\list.php' = '8d7acc6e781a3a04da39a75ee038c841219986c10faadaaa371dcbbdf94edc13'
    'vsm_customer\lib\api\customer_api.dart' = '4b2b4d348b244d5b4aa7a9626e256d13730ad3d388bdf94a17c47a739504d182'
    'vsm_customer\lib\api\service_api.dart' = 'c97d95f4a5ebb1ddb29a85577d00de173e8efc274328c8128c07e60d17442dc5'
    'vsm_customer\lib\models\service.dart' = 'e7d8f8a4a6c7a3e6c044ff3410470fee17174898d5f8324058001f3ba0a4d7fe'
    'vsm_customer\lib\screens\dashboard\dashboard_screen.dart' = '16596b0d5ed98bad0e3c0e7bbfea7a1892fc87a018a6d092deb2c2e4557a3058'
    'vsm_customer\lib\screens\payments\receipt_screen.dart' = '8c404568bb7af710feb4b2967ce1dc979e96cab3c928fd80b95f862e114a5be8'
    'vsm_customer\lib\screens\quotations\job_quotation_screen.dart' = '4f02d2823d81d2bc348baeee1427a8769a9908cd6329590d368317fa3b4fd709'
    'vsm_customer\lib\screens\reservations\book_service_screen.dart' = '9cf457cb4eaf6a5af1e83219019c9bedc315641b5c59719c32a9f8d2d1de6539'
    'vsm_customer\lib\screens\reservations\reservation_details_screen.dart' = '35b57cf9bf233aeec58d28beb70d65a5ac1215b5862b15c0e0966bc86e571ed1'
    'vsm_customer\lib\screens\reservations\reservations_screen.dart' = '3e07626b3bd28a39c20a561ad445c0bc0c1bd566bc37b821fe447ee85adb59bd'
    'vsm_customer\lib\widgets\app_widgets.dart' = '538dbbd3eb1dee805d04dfdd4d062b09e1177a56de167bf041f5cbbd2492badf'
}
foreach ($relative in $updates.Keys) {
    $source = Join-Path $PSScriptRoot $relative
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "Extract the complete ZIP before running the script. Missing: $relative"
    }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $updates[$relative]) {
        throw "Package checksum failed for $relative. Extract a fresh copy of the ZIP."
    }
    if (Test-Path -LiteralPath (Join-Path $root $relative) -PathType Container) {
        throw "A folder occupies the destination file path: $relative"
    }
}

$documents = [Environment]::GetFolderPath('MyDocuments')
$backup = Join-Path $documents ('LuckyYuna-Flutter-Backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($relative in $updates.Keys) {
    $destination = Join-Path $root $relative
    if (Test-Path -LiteralPath $destination -PathType Leaf) {
        $saved = Join-Path $backup $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $saved) -Force | Out-Null
        Copy-Item -LiteralPath $destination -Destination $saved
    }
}

try {
    foreach ($relative in $updates.Keys) {
        $source = Join-Path $PSScriptRoot $relative
        $destination = Join-Path $root $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
        if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $updates[$relative]) {
            throw "Installed checksum failed for $relative."
        }
    }
} catch {
    throw "Merge stopped. Backups are in $backup. $($_.Exception.Message)"
}
Write-Host "Merge complete. Verified $($updates.Count) files. Backup saved to $backup"
