<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__ . "/../../includes/booking_slots.php";
require_once __DIR__ . "/../../includes/service_workflow.php";
requireMethod("POST");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$customerId = (int) $user["customer_id"];
$data = jsonInput();
$vehicleId = (int) ($data["vehicle_id"] ?? 0);
$serviceTypes = $data["service_types"] ?? [];
if (!is_array($serviceTypes) || count(array_filter($serviceTypes, 'is_string')) !== count($serviceTypes)) {
    $serviceTypes = [];
}
$serviceTypes = array_values(array_unique(array_filter(array_map("trim", $serviceTypes))));
$serviceType = implode(", ", $serviceTypes);
$date = trim($data["appointment_date"] ?? "");
$time = trim($data["appointment_time"] ?? "");
$remarks = trim($data["remarks"] ?? "");
$policyAccepted = filter_var($data["policy_accepted"] ?? false, FILTER_VALIDATE_BOOLEAN);
$policyVersion = trim($data["policy_version"] ?? "1.0-2026-10");

if (!$policyAccepted) {
    http_response_code(422);
    echo json_encode(["success" => false, "message" => "Accept the booking and refundable reservation-fee policy before continuing."]);
    exit;
}

if (!$vehicleId || count($serviceTypes) === 0 || !$date || !$time) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Please fill in all required fields."]);
    exit;
}
if (!bookingDateTime($date, $time)) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Choose a valid appointment date and slot.']);
    exit;
}
$check = $conn->prepare("SELECT id FROM vehicles WHERE id = ? AND user_id = ? LIMIT 1");
$check->bind_param("ii", $vehicleId, $userId);
$check->execute();
if ($check->get_result()->num_rows !== 1) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid vehicle selected."]);
    exit;
}
$confirmOriginalPrices = array_key_exists('authorized_services', $data);
$authorizedPrices = [];
$confirmedVersions = [];
if ($confirmOriginalPrices) {
    $confirmedServices = $data['authorized_services'];
    try {
        if (!is_array($confirmedServices) || !array_is_list($confirmedServices) || count($confirmedServices) !== count($serviceTypes)) {
            throw new DomainException('Confirm the price of each selected service.');
        }
        foreach ($confirmedServices as $confirmation) {
            $serviceId = is_array($confirmation) ? $confirmation['service_id'] ?? null : null;
            $price = is_array($confirmation) ? $confirmation['authorized_price'] ?? null : null;
            $version = is_array($confirmation) ? $confirmation['catalog_version'] ?? null : null;
            if (!is_int($serviceId) || $serviceId <= 0 || $serviceId > 2147483647 || isset($authorizedPrices[$serviceId]) || !is_string($price)) {
                throw new DomainException('Confirm the price of each selected service.');
            }
            if ($version !== null && (!is_string($version) || !preg_match('/\A[a-f0-9]{64}\z/', $version))) {
                throw new DomainException('Reload the service catalog and confirm the services again.');
            }
            $authorizedPrices[$serviceId] = serviceWorkflowMoneyToCents($price);
            $confirmedVersions[$serviceId] = $version;
        }
    } catch (DomainException $e) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Confirm the price of each selected service.']);
        exit;
    }
    if (!serviceWorkflowConfigured($conn)) {
        http_response_code(409);
        echo json_encode(['success' => false, 'code' => 'confirmed_price_unavailable',
            'message' => 'Confirmed-price booking is currently unavailable. Reload the service catalog.']);
        exit;
    }
}
$reference = 'VSMS-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
$source = trim($data['policy_source'] ?? 'Android');
if (!in_array($source, ['Android','iOS','Website'], true)) $source = 'Android';
$ip = $_SERVER['REMOTE_ADDR'] ?? null;
try {
    bookingLock($conn, $date);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => $e instanceof BookingScheduleBusyException
        ? $e->getMessage()
        : 'Unable to check the schedule. Please try again.']);
    exit;
}

try {
    $conn->begin_transaction();
    if ($confirmOriginalPrices) {
        // Only validated integer IDs are interpolated. Lock the prices until the booking commits.
        $ids = implode(',', array_keys($authorizedPrices));
        $services = $conn->query("SELECT id, service_name, description, price, COALESCE(estimated_duration, 30) AS estimated_duration
            FROM services WHERE status='Active' AND id IN ($ids) ORDER BY id FOR UPDATE")->fetch_all(MYSQLI_ASSOC);
        if (count($services) !== count($serviceTypes) || array_diff($serviceTypes, array_column($services, 'service_name')) !== []) {
            throw new ServiceWorkflowConflict('Selected services changed. Reload and confirm the current prices.');
        }
        $snapshot = [];
        foreach ($services as $service) {
            $id = (int)$service['id'];
            if ($authorizedPrices[$id] !== serviceWorkflowMoneyToCents((string)$service['price'])) {
                throw new ServiceWorkflowConflict('Service prices changed. Reload and confirm the current prices.');
            }
            if ($confirmedVersions[$id] !== null && !hash_equals(serviceWorkflowCatalogVersion($service), $confirmedVersions[$id])) {
                throw new ServiceWorkflowConflict('Service details changed. Reload and confirm the current services.');
            }
            $snapshot[] = [
                'source' => 'services',
                'id' => $id,
                'name' => $service['service_name'],
                'description' => (string)$service['description'],
                'price' => (string)$service['price'],
                'duration' => max(30, (int)$service['estimated_duration']),
            ];
        }
    } else {
        $escaped = array_map(fn($name) => "'" . $conn->real_escape_string($name) . "'", $serviceTypes);
        $services = $conn->query("SELECT service_name, COALESCE(estimated_duration,30) AS estimated_duration
            FROM services WHERE status='Active' AND service_name IN (" . implode(',', $escaped) . ")")->fetch_all(MYSQLI_ASSOC);
        if (count($services) !== count($serviceTypes)) {
            throw new InvalidArgumentException('One or more selected services are invalid or inactive.');
        }
    }
    $durationMinutes = bookingDuration($services);
    bookingRequireSlot($conn, $date, $time, $durationMinutes);

    $stmt = $conn->prepare("INSERT INTO reservations (reference_number,user_id,customer_id,vehicle_id,service_type,appointment_date,appointment_time,remarks,status,policy_version,policy_accepted_at,policy_source,policy_ip,scheduled_duration_minutes,reservation_fee_status) VALUES (?,?,?,?,?,?,?,?,'Pending',?,NOW(),?,?,?,'Awaiting Payment')");
    $stmt->bind_param("siiisssssssi", $reference, $userId, $customerId, $vehicleId, $serviceType, $date, $time, $remarks, $policyVersion, $source, $ip, $durationMinutes);
    $stmt->execute();
    $reservationId = (int)$stmt->insert_id;
    $stmt->close();
    if ($confirmOriginalPrices) {
        serviceWorkflowSnapshotBooking($conn, $reservationId, $snapshot);
    }
    $payment = $conn->prepare("INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount,reservation_fee_credit) VALUES(?,200.00,'GCash','Awaiting Proof','Reservation Fee',200.00,0.00)");
    $payment->bind_param('i', $reservationId);
    $payment->execute();
    $paymentId = (int)$payment->insert_id;
    $payment->close();
    $stmt = $conn->prepare('UPDATE reservations SET reservation_fee_payment_id=? WHERE id=?');
    $stmt->bind_param('ii', $paymentId, $reservationId);
    $stmt->execute();
    $stmt->close();
    $acceptance = $conn->prepare("INSERT INTO booking_policy_acceptances(user_id,reservation_id,policy_version,accepted_at,source,ip_address) VALUES(?,?,?,NOW(),?,?)");
    $acceptance->bind_param('iisss', $userId, $reservationId, $policyVersion, $source, $ip);
    $acceptance->execute();
    $acceptance->close();
    $title = "Booking submitted";
    $notificationMessage = "Reservation #$reservationId is waiting for approval.";
    $notification = $conn->prepare("INSERT INTO notifications (user_id, title, message,link_type,link_id) VALUES (?, ?, ?,'reservation',?)");
    $notification->bind_param("issi", $userId, $title, $notificationMessage, $reservationId);
    $notification->execute();
    $notification->close();
    $conn->commit();
    $response = ['success' => true, 'message' => 'Booking created. Pay the refundable ₱200 reservation fee to submit it for approval.',
        'reservation_id' => $reservationId, 'payment_id' => $paymentId, 'reservation_fee' => 200];
    if ($confirmOriginalPrices) {
        $response['service_workflow_version'] = 2;
    }
    echo json_encode($response);
} catch (InvalidArgumentException | DomainException $e) {
    $conn->rollback();
    http_response_code($e instanceof InvalidArgumentException ? 400 : 409);
    $error = ['success' => false, 'message' => $e->getMessage()];
    if ($e instanceof ServiceWorkflowConflict) {
        $error['code'] = 'confirmed_price_conflict';
    }
    echo json_encode($error);
} catch (Throwable $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["success"=>false,"message"=>"Unable to create the booking. Please try again."]);
} finally {
    bookingUnlock($conn, $date);
}
