<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__ . "/../../includes/service_workflow.php";
requireMethod("GET");
$user = requireCustomer($conn);
$userId = (int) $user["id"];

$stmt = $conn->prepare("SELECT
    (SELECT COUNT(*) FROM vehicles WHERE user_id = ?) AS total_vehicles,
    r.total_reservations, r.pending_reservations,
    (SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0) AS unread_notifications
    FROM (SELECT COUNT(*) AS total_reservations,
        COALESCE(SUM(status = 'Pending'), 0) AS pending_reservations
        FROM reservations WHERE user_id = ?) r");
$stmt->bind_param("iii", $userId, $userId, $userId);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

$nextStmt = $conn->prepare("SELECT r.id, r.service_type, r.appointment_date, r.appointment_time, r.status,
 v.brand, v.model, v.plate_number FROM reservations r
 INNER JOIN vehicles v ON v.id = r.vehicle_id
 WHERE r.user_id = ? AND r.status NOT IN ('Completed', 'Cancelled')
 AND TIMESTAMP(r.appointment_date, r.appointment_time) >= NOW()
 ORDER BY r.appointment_date ASC, r.appointment_time ASC LIMIT 1");
$nextStmt->bind_param("i", $userId);
$nextStmt->execute();
$next = $nextStmt->get_result()->fetch_assoc();
$nextStmt->close();
if ($next) {
    $next["id"] = (int) $next["id"];
    $workflow = serviceWorkflowSummary($conn, $next['id']);
    if ($workflow !== null) {
        $next['service_workflow'] = $workflow;
    }
}
$reminderStmt = $conn->prepare("SELECT MAX(appointment_date) AS last_service FROM reservations WHERE user_id = ? AND status = 'Completed' AND service_type LIKE '%Oil Change%'");
$reminderStmt->bind_param("i", $userId);
$reminderStmt->execute();
$lastOil = $reminderStmt->get_result()->fetch_assoc()["last_service"] ?? null;
$reminderStmt->close();
$maintenanceReminder = null;
if ($lastOil === null || strtotime($lastOil) < strtotime("-5 months")) {
    $maintenanceReminder = "Your vehicle may be due for an oil change. Check your mileage or book an inspection.";
}

echo json_encode(["success" => true, "summary" => [
    "total_vehicles" => (int) $row["total_vehicles"],
    "total_reservations" => (int) $row["total_reservations"],
    "pending_reservations" => (int) $row["pending_reservations"],
    "unread_notifications" => (int) $row["unread_notifications"]
], "next_appointment" => $next, "maintenance_reminder" => $maintenanceReminder]);
