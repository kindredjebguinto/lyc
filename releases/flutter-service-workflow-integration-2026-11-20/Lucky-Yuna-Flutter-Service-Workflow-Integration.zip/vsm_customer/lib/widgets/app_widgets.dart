import 'package:flutter/material.dart';

const primaryColor = Color(0xFF111111);
const accentColor = Color(0xFFD71920);
const appBackground = Color(0xFFF7F7F7);

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const PageHeader(this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(subtitle, style: TextStyle(color: Colors.grey.shade600)),
      ],
    ),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  const EmptyState({
    required this.icon,
    required this.title,
    required this.message,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 58, color: Colors.blueGrey.shade300),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade600),
          ),
        ],
      ),
    ),
  );
}

Color statusColor(String status) {
  switch (status.toLowerCase()) {
    case 'paid':
    case 'completed':
      return Colors.green;
    case 'pending':
    case 'awaiting proof':
    case 'pay at shop':
      return Colors.orange;
    case 'under review':
      return Colors.blueGrey;
    case 'rejected':
      return Colors.red;
    case 'approved':
    case 'appointment confirmed':
      return const Color(0xFFD71920);
    case 'in progress':
    case 'service in progress':
    case 'work in progress':
      return const Color(0xFF7B1FA2);
    case 'vehicle inspection':
    case 'approval needed':
      return Colors.deepOrange;
    case 'pending approval':
    case 'repairs pending approval':
    case 'work on hold':
    case 'work paused':
    case 'safety advisory':
    case 'service hold':
      return Colors.deepOrange.shade900;
    case 'additional repair declined':
      return Colors.red.shade800;
    case 'partially approved':
    case 'repairs partially approved':
    case 'repairs approved':
    case 'work finished':
      return Colors.teal.shade700;
    case 'ready for pickup':
      return Colors.teal;
    case 'cancelled':
      return Colors.red;
    default:
      return Colors.grey;
  }
}

String customerStatus(String status) {
  switch (status) {
    case 'Pending':
      return 'Request Sent';
    case 'Approved':
      return 'Appointment Confirmed';
    case 'Diagnosing':
      return 'Vehicle Inspection';
    case 'Quotation Sent':
      return 'Approval Needed';
    case 'Quotation Accepted':
    case 'In Progress':
      return 'Service in Progress';
    case 'Ready for Pickup':
      return 'Ready for Pickup';
    default:
      return status;
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Chip(
    label: Text(
      status,
      style: const TextStyle(color: Colors.white, fontSize: 12),
    ),
    backgroundColor: statusColor(status),
    visualDensity: VisualDensity.compact,
  );
}

Map<String, dynamic>? workflowObject(Object? value) =>
    value is Map<String, dynamic> ? value : null;

Iterable<Map<String, dynamic>> workflowRows(Object? value) =>
    value is List ? value.whereType<Map<String, dynamic>>() : const [];

Map<String, dynamic>? serviceWorkflowFor(Map<String, dynamic> reservation) =>
    workflowObject(reservation['service_workflow']);

String bookingStatus(Map<String, dynamic> reservation) {
  final workStatus = serviceWorkflowFor(reservation)?['work_status'];
  return workStatus is String && workStatus.isNotEmpty
      ? workStatus
      : customerStatus(reservation['status']?.toString() ?? '');
}

int? bookingFinalPaymentId(Map<String, dynamic> reservation) {
  final workflow = serviceWorkflowFor(reservation);
  final payment = workflow == null
      ? reservation['payment_id']
      : workflowObject(workflow['bill'])?['payment_id'];
  final id = int.tryParse(payment?.toString() ?? '');
  return id != null && id > 0 ? id : null;
}

String? bookingFinalPaymentStatus(Map<String, dynamic> reservation) {
  final paymentId = bookingFinalPaymentId(reservation);
  if (paymentId == null ||
      reservation['payment_id']?.toString() != '$paymentId') {
    return null;
  }
  return reservation['payment_status']?.toString();
}

class ServiceWorkflowIndicators extends StatelessWidget {
  final Map<String, dynamic> workflow;

  const ServiceWorkflowIndicators(this.workflow, {super.key});

  @override
  Widget build(BuildContext context) {
    final decision = workflowObject(workflow['quotation'])?['decision_status'];
    final hasAdvisory = workflowRows(workflow['safety_advisories'])
        .any((advisory) => advisory['resolved_at'] == null);
    final hasHold =
        workflow['full_hold_active'] == true ||
        workflowRows(workflow['service_holds'])
            .any((hold) => hold['released_at'] == null);
    final statuses = [
      if (decision is String && decision.isNotEmpty)
        switch (decision) {
          'Approved' => 'Repairs Approved',
          'Partially Approved' => 'Repairs Partially Approved',
          'Pending Approval' => 'Repairs Pending Approval',
          'Closed' => 'Quotation Closed',
          _ => decision,
        },
      if (hasAdvisory) 'Safety Advisory',
      if (hasHold) 'Service Hold',
    ];
    if (statuses.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 4,
        children: [for (final status in statuses) StatusChip(status)],
      ),
    );
  }
}

String money(dynamic value) {
  final amount = double.tryParse(value?.toString() ?? '') ?? 0;
  return '₱${amount.toStringAsFixed(2)}';
}
