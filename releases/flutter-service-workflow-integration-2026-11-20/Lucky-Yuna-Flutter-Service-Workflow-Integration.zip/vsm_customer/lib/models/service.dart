class Service {
  final int id;
  final String serviceName;
  final String category;
  final String description;
  final double price;
  final String? authorizedPrice;
  final String? catalogVersion;
  final int? estimatedDuration;
  final String status;

  const Service({
    required this.id,
    required this.serviceName,
    required this.category,
    required this.description,
    required this.price,
    this.authorizedPrice,
    this.catalogVersion,
    this.estimatedDuration,
    required this.status,
  });

  factory Service.fromJson(Map<String, dynamic> json) {
    final authorizedPrice = json['authorized_price'];
    final catalogVersion = json['catalog_version'];
    return Service(
      id: int.parse(json['id'].toString()),
      serviceName: json['service_name']?.toString() ?? '',
      category:
          json['category']?.toString() ??
          _categoryFor(json['service_name']?.toString() ?? ''),
      description: json['description']?.toString() ?? '',
      price: double.tryParse(json['price'].toString()) ?? 0,
      authorizedPrice:
          authorizedPrice is String &&
              _authorizedPriceFormat.hasMatch(authorizedPrice)
          ? authorizedPrice
          : null,
      catalogVersion: catalogVersion is String && catalogVersion.isNotEmpty
          ? catalogVersion
          : null,
      estimatedDuration: json['estimated_duration'] == null
          ? null
          : int.tryParse(json['estimated_duration'].toString()),
      status: json['status']?.toString() ?? '',
    );
  }

  static final _authorizedPriceFormat = RegExp(r'^\d{1,8}(?:\.\d{1,2})?$');

  int? get authorizedPriceCents {
    final price = authorizedPrice;
    if (price == null) return null;
    final parts = price.split('.');
    final whole = int.parse(parts.first);
    final fraction = parts.length == 1
        ? 0
        : int.parse(parts.last.padRight(2, '0'));
    return whole * 100 + fraction;
  }

  static String _categoryFor(String serviceName) {
    final name = serviceName.toLowerCase();
    if (name.contains('pms') || name.contains('maintenance')) {
      return 'PMS Packages';
    }
    if (name.contains('oil') || name.contains('periodic')) {
      return 'Oil & Periodic';
    }
    if (name.contains('air conditioning') || name.contains('ac ')) {
      return 'Air Conditioning';
    }
    if (name.contains('brake')) return 'Brakes';
    if (name.contains('tire')) return 'Tires';
    if (name.contains('engine')) return 'Engine';
    if (name.contains('battery')) return 'Battery';
    return 'Other';
  }
}
