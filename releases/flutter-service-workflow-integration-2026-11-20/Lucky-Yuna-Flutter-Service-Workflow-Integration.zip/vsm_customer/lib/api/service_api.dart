import '../models/service.dart';
import 'api_client.dart';
import 'api_config.dart';

class ServiceCatalog {
  const ServiceCatalog({
    required this.services,
    required this.confirmedPriceBooking,
  });

  final List<Service> services;
  final bool confirmedPriceBooking;
}

class ServiceApi {
  static Future<List<Service>> getServices() async =>
      (await getCatalog()).services;

  static Future<ServiceCatalog> getCatalog() async {
    final payload = await ApiClient.get(ApiConfig.servicesListUrl);
    if (payload['success'] != true) {
      throw Exception(payload['message'] ?? 'Unable to retrieve services.');
    }
    final serviceData = payload['services'];
    final services = serviceData is List
        ? serviceData
              .whereType<Map<String, dynamic>>()
              .map(Service.fromJson)
              .toList()
        : <Service>[];
    final confirmedPriceBooking = payload['confirmed_price_booking'] == true;
    if (confirmedPriceBooking &&
        (serviceData is! List ||
            services.length != serviceData.length ||
            services.any((service) => service.authorizedPrice == null))) {
      throw Exception('Unable to load confirmed service prices. Try again.');
    }
    return ServiceCatalog(
      services: services,
      confirmedPriceBooking: confirmedPriceBooking,
    );
  }
}
