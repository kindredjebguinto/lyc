import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../api/service_api.dart';
import '../../api/vehicle_api.dart';
import '../../models/service.dart';
import '../../models/vehicle.dart';
import '../../services/session_service.dart';
import '../../widgets/app_widgets.dart';
import '../payments/booking_payment_screen.dart';
import '../vehicles/add_vehicle_screen.dart';

class BookServiceScreen extends StatefulWidget {
  final List<int> initialServiceIds;
  const BookServiceScreen({this.initialServiceIds = const [], super.key});

  @override
  State<BookServiceScreen> createState() => _BookServiceScreenState();
}

class _BookServiceScreenState extends State<BookServiceScreen> {
  final _remarksController = TextEditingController();
  List<Vehicle> _vehicles = [];
  List<Service> _services = [];
  final Set<int> _selectedServiceIds = {};
  int _step = 0;
  int? _vehicleId;
  // Shop dates follow Manila, even when the phone uses a different timezone.
  DateTime get _shopToday {
    final now = DateTime.now().toUtc().add(const Duration(hours: 8));
    return DateTime(now.year, now.month, now.day);
  }
  late DateTime? _date = _shopToday;
  TimeOfDay? _time;
  bool _loading = true;
  bool _saving = false;
  bool _refreshingVehicles = false;
  String? _error;
  String _serviceCategory = 'All';
  bool _policyAccepted = false;
  bool _confirmedPriceBooking = false;
  bool _confirmedPricesAccepted = false;
  bool _loadingSlots=false;
  int _slotRequestId = 0;
  int? _reservedMinutes;
  List<Map<String,dynamic>> _slots=[];

  List<String> get _serviceCategories => ['All', ...{for (final service in _services) service.category}];
  List<Service> get _visibleServices => _serviceCategory == 'All' ? _services : _services.where((service) => service.category == _serviceCategory).toList();

  List<Service> get _selectedServices => _services
      .where((service) => _selectedServiceIds.contains(service.id))
      .toList();

  double get _totalPrice {
    final selected = _selectedServices;
    if (_confirmedPriceBooking) {
      return selected.fold<int>(
        0,
        (total, service) => total + service.authorizedPriceCents!,
      ) / 100;
    }
    return selected.fold<double>(0, (total, service) => total + service.price);
  }

  bool get _readyToSubmit =>
      _policyAccepted && (!_confirmedPriceBooking || _confirmedPricesAccepted);

  String _servicePrice(Service service) => money(
    _confirmedPriceBooking ? service.authorizedPrice : service.price,
  );

  int get _totalMinutes => _selectedServices.fold(
        0,
        (total, service) => total + (service.estimatedDuration ?? 0),
      );

  Vehicle? get _selectedVehicle {
    for (final vehicle in _vehicles) {
      if (vehicle.id == _vehicleId) return vehicle;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _remarksController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final customerId = await SessionService.getCustomerId();
      if (customerId == null) throw Exception('Customer session was not found.');
      final results = await Future.wait([
        VehicleApi.getVehicles(customerId: customerId),
        ServiceApi.getCatalog(),
      ]);
      if (!mounted) return;
      final catalog = results[1] as ServiceCatalog;
      setState(() {
        _vehicles = results[0] as List<Vehicle>;
        _services = catalog.services;
        _confirmedPriceBooking = catalog.confirmedPriceBooking;
        _selectedServiceIds.addAll(widget.initialServiceIds.where((id) => _services.any((service) => service.id == id)));
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  Future<void> _refreshVehicles({Set<int>? previousIds}) async {
    if (_refreshingVehicles) return;
    setState(() => _refreshingVehicles = true);
    try {
      final customerId = await SessionService.getCustomerId();
      if (customerId == null) throw Exception('Customer session was not found.');
      final vehicles = await VehicleApi.getVehicles(customerId: customerId);
      if (!mounted) return;
      setState(() {
        _vehicles = vehicles;
        final added = previousIds == null
            ? <Vehicle>[]
            : vehicles.where((vehicle) => !previousIds.contains(vehicle.id)).toList();
        if (added.isNotEmpty) {
          _vehicleId = added.last.id;
        } else if (!vehicles.any((vehicle) => vehicle.id == _vehicleId)) {
          _vehicleId = vehicles.isEmpty ? null : vehicles.first.id;
        }
      });
    } catch (error) {
      if (mounted) _message('Unable to refresh vehicles. Tap Refresh vehicles to try again.');
    } finally {
      if (mounted) setState(() => _refreshingVehicles = false);
    }
  }

  Future<void> _addVehicle() async {
    final previousIds = _vehicles.map((vehicle) => vehicle.id).toSet();
    final added = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const AddVehicleScreen()),
    );
    if (!mounted || added != true) return;
    await _refreshVehicles(previousIds: previousIds);
  }

  Widget _vehicleActions() => Wrap(
    spacing: 8,
    runSpacing: 8,
    crossAxisAlignment: WrapCrossAlignment.center,
    children: [
      FilledButton.icon(
        onPressed: _saving || _refreshingVehicles ? null : _addVehicle,
        icon: const Icon(Icons.add),
        label: const Text('Add a vehicle'),
      ),
      TextButton.icon(
        onPressed: _saving || _refreshingVehicles ? null : () => _refreshVehicles(),
        icon: const Icon(Icons.refresh),
        label: Text(_refreshingVehicles ? 'Refreshing…' : 'Refresh vehicles'),
      ),
    ],
  );

  bool _canContinue() {
    if (_step == 0 && _vehicleId == null) {
      _message('Choose your vehicle.');
      return false;
    }
    if (_step == 1 && _selectedServiceIds.isEmpty) {
      _message('Select at least one service.');
      return false;
    }
    if(_step==2&&(_date==null||_time==null)){_message('Choose an available appointment date and time.');return false;}
    return true;
  }

  void _continue() {
    if (!_canContinue()) return;
    if (_step < 3) {
      setState(() => _step++);
      if (_step == 2) _loadSlots();
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<bool> _refreshConfirmedCatalog({String? conflictMessage}) async {
    final catalog = await ServiceApi.getCatalog();
    if (!mounted) return false;
    final byId = {for (final service in catalog.services) service.id: service};
    final selected = _selectedServices;
    final scheduleChanged = selected.any((service) {
      final latest = byId[service.id];
      return latest == null ||
          latest.serviceName != service.serviceName ||
          latest.estimatedDuration != service.estimatedDuration;
    });
    final capabilityChanged =
        _confirmedPriceBooking != catalog.confirmedPriceBooking;
    final priceOrScopeChanged = selected.any((service) {
      final latest = byId[service.id];
      return latest?.authorizedPriceCents != service.authorizedPriceCents ||
          latest?.description != service.description ||
          latest?.catalogVersion != service.catalogVersion;
    });
    if (!scheduleChanged &&
        !capabilityChanged &&
        !priceOrScopeChanged &&
        conflictMessage == null) {
      return true;
    }

    setState(() {
      _services = catalog.services;
      _confirmedPriceBooking = catalog.confirmedPriceBooking;
      _confirmedPricesAccepted = false;
      if (capabilityChanged) _policyAccepted = false;
      if (!_serviceCategories.contains(_serviceCategory)) _serviceCategory = 'All';
      _selectedServiceIds.removeWhere((id) => !byId.containsKey(id));
      if (scheduleChanged) {
        _time = null;
        _slots = [];
        _loadingSlots = false;
        _reservedMinutes = null;
        _slotRequestId++;
        _step = 1;
      }
    });
    _message(
      scheduleChanged
          ? 'Your selected services changed. Review the services and choose a schedule again.'
          : conflictMessage ??
                'Booking details changed. Review the updated prices before submitting.',
    );
    return false;
  }

  Future<void> _submit() async {
    if (_saving || !_readyToSubmit) return;
    final selectedDate = _date;
    final selectedTime = _time;
    final selectedVehicleId = _vehicleId;
    final selectedServices = _selectedServices;
    if (selectedDate == null ||
        selectedTime == null ||
        selectedVehicleId == null ||
        selectedServices.isEmpty) {
      _message('Please complete all booking steps first.');
      return;
    }
    setState(() => _saving = true);
    final date = '${selectedDate.year.toString().padLeft(4, '0')}-'
        '${selectedDate.month.toString().padLeft(2, '0')}-'
        '${selectedDate.day.toString().padLeft(2, '0')}';
    final time = '${selectedTime.hour.toString().padLeft(2, '0')}:'
        '${selectedTime.minute.toString().padLeft(2, '0')}:00';
    final confirmedPriceBooking = _confirmedPriceBooking;

    try {
      if (confirmedPriceBooking && !await _refreshConfirmedCatalog()) return;
      final result = await CustomerApi.createReservation(
        vehicleId: selectedVehicleId,
        serviceTypes: selectedServices.map((item) => item.serviceName).toList(),
        date: date,
        time: time,
        remarks: _remarksController.text.trim(),
        policyAccepted: _policyAccepted,
        authorizedServices: confirmedPriceBooking
            ? [
                for (final service in selectedServices)
                  {
                    'service_id': service.id,
                    'authorized_price': service.authorizedPrice!,
                    if (service.catalogVersion != null)
                      'catalog_version': service.catalogVersion,
                  },
              ]
            : null,
      );
      if (!mounted) return;
      if (result['success'] == true) {
        final paymentId=int.tryParse(result['payment_id']?.toString()??'');
        if(paymentId!=null) await Navigator.push(context,MaterialPageRoute(builder:(_)=>BookingPaymentScreen(paymentId:paymentId)));
        if (mounted) Navigator.pop(context, true);
      } else if (confirmedPriceBooking &&
          (result['code'] == 'confirmed_price_conflict' ||
              result['code'] == 'confirmed_price_unavailable')) {
        setState(() => _confirmedPricesAccepted = false);
        await _refreshConfirmedCatalog(
          conflictMessage:
              result['message']?.toString() ??
              'Review the current service prices before submitting again.',
        );
      } else {
        _message(result['message']?.toString() ?? 'Unable to book service.');
      }
    } catch (error) {
      if (mounted) _message(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Book a Service')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? EmptyState(
                  icon: Icons.cloud_off,
                  title: 'Unable to Load',
                  message: _error!,
                )
              : _vehicles.isEmpty
                  ? SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(children: [
                        const EmptyState(
                          icon: Icons.directions_car,
                          title: 'Add your first vehicle',
                          message: 'Add your vehicle here, then continue booking your service.',
                        ),
                        _vehicleActions(),
                      ]),
                    )
                  : Stepper(
                      currentStep: _step,
                      onStepTapped: (value) {
                        if (!_saving && value <= _step) setState(() => _step = value);
                      },
                      onStepContinue: _step == 3 ? _submit : _continue,
                      onStepCancel: _step == 0 || _saving
                          ? null
                          : () => setState(() => _step--),
                      controlsBuilder: (context, details) => Padding(
                        padding: const EdgeInsets.only(top: 18),
                        child: Row(
                          children: [
                            FilledButton(
                              onPressed: _saving || (_step == 3 && !_readyToSubmit)
                                  ? null
                                  : details.onStepContinue,
                              child: Text(
                                _saving
                                    ? 'SUBMITTING...'
                                    : _step == 3
                                        ? 'PAY ₱200 & SUBMIT'
                                        : 'CONTINUE',
                              ),
                            ),
                            if (_step > 0)
                              TextButton(
                                onPressed: details.onStepCancel,
                                child: const Text('BACK'),
                              ),
                          ],
                        ),
                      ),
                      steps: [
                        Step(
                          title: const Text('My Vehicle'),
                          isActive: _step >= 0,
                          state: _vehicleId == null
                              ? StepState.indexed
                              : StepState.complete,
                          content: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Choose your vehicle', style: TextStyle(fontWeight: FontWeight.bold)), _vehicleChoices(), const SizedBox(height: 12), _vehicleActions()]),
                        ),
                        Step(
                          title: const Text('Services'),
                          subtitle: const Text('Select one or more'),
                          isActive: _step >= 1,
                          state: _selectedServiceIds.isEmpty ? StepState.indexed : StepState.complete,
                          content: _serviceChecklist(),
                        ),
                        Step(title:const Text('Available Schedule'),isActive:_step>=2,state:_date==null||_time==null?StepState.indexed:StepState.complete,content:_schedule()),
                        Step(
                          title: const Text('Review & Submit'),
                          isActive: _step >= 3,
                          content: _confirmation(),
                        ),
                      ],
                    ),
    );
  }

  Widget _vehicleChoices() => Column(
        children: _vehicles.map((vehicle) {
          return RadioListTile<int>(
            value: vehicle.id,
            groupValue: _vehicleId,
            onChanged: (value) => setState(() => _vehicleId = value),
            title: Text('${vehicle.brand} ${vehicle.model}'),
            subtitle: Text('${vehicle.year} • ${vehicle.plateNumber}'),
            secondary: const Icon(Icons.directions_car),
          );
        }).toList(),
      );

  Widget _serviceChecklist() => Column(
        children: [
          SizedBox(height: 38, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _serviceCategories.length, separatorBuilder: (_, __) => const SizedBox(width: 7), itemBuilder: (_, index) { final category = _serviceCategories[index]; return ChoiceChip(label: Text(category), selected: _serviceCategory == category, onSelected: (_) => setState(() => _serviceCategory = category)); })),
          const SizedBox(height: 10),
          ..._visibleServices.map((service) {
            final selected = _selectedServiceIds.contains(service.id);
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: CheckboxListTile(
                value: selected,
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      _selectedServiceIds.add(service.id);
                    } else {
                      _selectedServiceIds.remove(service.id);
                    }
                    _confirmedPricesAccepted = false;
                    _date=_shopToday;_time=null;_slots=[];_loadingSlots=false;_reservedMinutes=null;_slotRequestId++;
                  });
                },
                title: Text(service.serviceName),
                subtitle: Text(
                  '${_servicePrice(service)} • ${service.estimatedDuration ?? 0} minutes\n'
                  '${service.description}',
                ),
                controlAffinity: ListTileControlAffinity.leading,
                secondary: Icon(_serviceIcon(service.serviceName), color: primaryColor),
              ),
            );
          }),
          if (_selectedServiceIds.isNotEmpty)
            ListTile(
              title: Text('${_selectedServiceIds.length} services selected'),
              subtitle: Text('Estimated $_totalMinutes minutes'),
              trailing: Text(
                money(_totalPrice),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),
            ),
        ],
      );

  Future<void> _loadSlots() async {
    final requestId = ++_slotRequestId;
    if (_date == null || _selectedServices.isEmpty) return;
    setState(() { _loadingSlots = true; _slots = []; _time = null; _reservedMinutes = null; });
    final date = '${_date!.year.toString().padLeft(4, '0')}-${_date!.month.toString().padLeft(2, '0')}-${_date!.day.toString().padLeft(2, '0')}';
    try {
      final result = await CustomerApi.reservationAvailability(date, _selectedServices.map((s) => s.serviceName).toList());
      if (!mounted || requestId != _slotRequestId) return;
      setState(() {
        _slots = (result['slots'] as List? ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
        _reservedMinutes = int.tryParse(result['duration_minutes']?.toString() ?? '');
        _loadingSlots = false;
      });
    } catch (e) {
      if (!mounted || requestId != _slotRequestId) return;
      setState(() => _loadingSlots = false);
      _message(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Widget _schedule() => Column(
        children: [
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: Text(
              _date == null
                  ? 'Choose appointment date'
                  : '${_date!.month}/${_date!.day}/${_date!.year}',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final value = await showDatePicker(
                context: context,
                firstDate: _shopToday,
                lastDate: _shopToday.add(const Duration(days: 365)),
                initialDate: _date != null && !_date!.isBefore(_shopToday) ? _date! : _shopToday,
              );
              if (value != null) {setState(() => _date = value);_loadSlots();}
            },
          ),
          TextButton(onPressed: () { setState(() => _date = _shopToday); _loadSlots(); }, child: const Text('Today · check remaining slots')),
          if (_date != null) TextButton.icon(onPressed: _loadingSlots ? null : _loadSlots, icon: const Icon(Icons.refresh), label: const Text('Refresh slots')),
          if (_reservedMinutes != null) Text('Reserved time: $_reservedMinutes minutes based on the selected services.'),
          if(_loadingSlots)const Padding(padding:EdgeInsets.all(16),child:LinearProgressIndicator())
          else if(_date!=null&&_slots.isEmpty)const Padding(padding:EdgeInsets.all(12),child:Text('No schedule information is available. Choose another date.'))
          else if (_slots.isNotEmpty) ...[
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(top: 10, bottom: 8),
                child: Text('Choose an available time', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            LayoutBuilder(builder: (context, constraints) {
              final width = (constraints.maxWidth - 8) / 2;
              return Wrap(spacing: 8, runSpacing: 8, children: _slots.map((slot) {
                final available = slot['available'] == true;
                final parts = slot['time'].toString().split(':');
                final value = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
                final selected = _time?.hour == value.hour && _time?.minute == value.minute;
                final count = slot['remaining_capacity'] ?? 0;
                final detail = available ? '$count mechanic${count == 1 ? "" : "s"} available' : (slot['reason'] ?? 'Unavailable').toString();
                return SizedBox(width: width, child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 84), padding: const EdgeInsets.all(8),
                    backgroundColor: selected ? Theme.of(context).colorScheme.primaryContainer : null,
                    side: BorderSide(color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outline),
                  ),
                  onPressed: available ? () => setState(() => _time = value) : null,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text('${slot['label']}', textAlign: TextAlign.center),
                    const SizedBox(height: 4),
                    Text(detail, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                  ]),
                ));
              }).toList());
            }),
            const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Row(children: [
                Icon(Icons.info_outline, size: 17),
                SizedBox(width: 6),
                Expanded(child: Text(
                  'Slots reflect mechanic capacity for the full service time, based on your selected services. Availability is checked again when you book.',
                  style: TextStyle(fontSize: 12),
                )),
              ]),
            ),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _remarksController,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Additional remarks (optional)',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      );

  Widget _confirmation() {
    final vehicle = _selectedVehicle;
    final selectedDate = _date;
    final selectedTime = _time;
    final scheduleText = selectedDate == null || selectedTime == null
        ? 'Complete the schedule step first'
        : '${selectedDate.month}/${selectedDate.day}/${selectedDate.year} • '
            '${selectedTime.format(context)}';
    final vehicleText = vehicle == null
        ? 'Select a vehicle first'
        : '${vehicle.brand} ${vehicle.model}';
    final servicesText = _selectedServices.isEmpty
        ? 'Select at least one service'
        : _selectedServices.map((item) => item.serviceName).join(', ');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _summary('Vehicle', vehicleText),
            _summary('Plate', vehicle?.plateNumber ?? ''),
            if (_confirmedPriceBooking) ...[
              const Text(
                'Original booked services',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              for (final service in _selectedServices)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(service.serviceName),
                  subtitle: service.description.isEmpty
                      ? null
                      : Text(service.description),
                  trailing: Text(_servicePrice(service)),
                ),
              _summary('Original services total', money(_totalPrice)),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: _confirmedPricesAccepted,
                onChanged: _saving
                    ? null
                    : (value) => setState(
                          () => _confirmedPricesAccepted = value ?? false,
                        ),
                title: const Text(
                  'I authorize these original services at the displayed prices.',
                ),
                subtitle: const Text(
                  'The shop will ask for approval before performing additional repairs.',
                ),
              ),
            ] else ...[
              _summary('Services', servicesText),
              _summary('Estimated total', money(_totalPrice)),
            ],
            _summary('Estimated duration', '$_totalMinutes minutes'),
            if (_reservedMinutes != null) _summary('Reserved slot duration', '$_reservedMinutes minutes'),
            _summary('Schedule', scheduleText),
            const Divider(height: 24),
            const Text('Refundable reservation fee',style:TextStyle(fontWeight:FontWeight.bold)),
            const SizedBox(height:4),
            const Text('₱200 is required to reserve this schedule. It will be credited to your final bill and fully refunded if you or the service center cancels before inspection begins.'),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: _policyAccepted,
              onChanged: _saving
                  ? null
                  : (value) => setState(() => _policyAccepted = value ?? false),
              title: const Text(
                'I accept the booking, cancellation, refund, payment, and privacy policy.',
              ),
              subtitle: const Text(
                'No-show appointments may forfeit the reservation fee.',
              ),
            ),
            if (!_confirmedPriceBooking)
              Text(
                'Final charges may change after vehicle inspection.',
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
              ),
          ],
        ),
      ),
    );
  }

  Widget _summary(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 120,
              child: Text(label, style: TextStyle(color: Colors.grey.shade600)),
            ),
            Expanded(
              child: Text(
                value,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      );

  IconData _serviceIcon(String name) {
    final value = name.toLowerCase();
    if (value.contains('oil')) return Icons.oil_barrel;
    if (value.contains('brake')) return Icons.car_crash;
    if (value.contains('battery')) return Icons.battery_charging_full;
    if (value.contains('tire')) return Icons.tire_repair;
    if (value.contains('air')) return Icons.ac_unit;
    if (value.contains('engine')) return Icons.settings;
    return Icons.build_circle;
  }
}
