import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';

class ReceiptScreen extends StatefulWidget {
  final int paymentId;

  const ReceiptScreen({required this.paymentId, super.key});

  @override
  State<ReceiptScreen> createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  late Future<Map<String, dynamic>> _receipt;
  int get paymentId => widget.paymentId;

  @override
  void initState() {
    super.initState();
    _receipt = CustomerApi.receipt(paymentId);
  }

  @override
  void didUpdateWidget(covariant ReceiptScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.paymentId != paymentId) {
      _receipt = CustomerApi.receipt(paymentId);
    }
  }

  void _refreshReceipt() {
    setState(() => _receipt = CustomerApi.receipt(paymentId));
  }

  String _bookingReference(Map<String, dynamic> receipt) =>
      receipt['reservation_reference']?.toString() ??
      '#${receipt['reservation_id'] ?? ''}';

  String _referenceLabel(Map<String, dynamic> receipt) =>
      receipt['payment_method'] == 'Cash'
      ? 'Official Receipt'
      : 'Transaction Reference';

  String _referenceNumber(Map<String, dynamic> receipt) {
    final reference = receipt['reference_number']?.toString() ?? '';
    return reference.isEmpty ? 'N/A' : reference;
  }

  List<Map<String, dynamic>> _completedServices(Map<String, dynamic> bill) =>
      (bill['lines'] as List? ?? []).whereType<Map<String, dynamic>>().toList();

  String _receiptServiceName(Map<String, dynamic> line) =>
      '${line['name'] ?? 'Service'} × ${line['quantity'] ?? '1'}';

  Future<void> _share(Map<String, dynamic> receipt) async {
    final bill = receipt['billing'] as Map<String, dynamic>?;
    final document = pw.Document();
    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (_) => [
          pw.Center(
            child: pw.Text(
              'VEHICLE SERVICE MANAGEMENT',
              style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.Center(child: pw.Text('Official Payment Receipt')),
          pw.SizedBox(height: 24),
          pw.Text('Receipt No.: #$paymentId'),
          pw.Text('Booking: ${_bookingReference(receipt)}'),
          pw.Text('Customer: ${receipt['fullname'] ?? ''}'),
          pw.Text('Email: ${receipt['email'] ?? ''}'),
          pw.Divider(),
          pw.Text(
            'Vehicle: ${receipt['brand'] ?? ''} ${receipt['model'] ?? ''}',
          ),
          pw.Text('Plate Number: ${receipt['plate_number'] ?? ''}'),
          pw.Text(
            'Appointment: ${receipt['appointment_date'] ?? ''} '
            '${receipt['appointment_time'] ?? ''}',
          ),
          pw.Divider(),
          pw.Text('Payment Method: ${receipt['payment_method'] ?? ''}'),
          pw.Text('${_referenceLabel(receipt)}: ${_referenceNumber(receipt)}'),
          if (bill != null) ...[
            pw.Divider(),
            pw.Text(
              'Completed services',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            for (final line in _completedServices(bill))
              pw.Text('${_receiptServiceName(line)} · PHP ${line['amount']}'),
            pw.SizedBox(height: 8),
            pw.Text('Completed services total: PHP ${bill['gross_amount']}'),
            pw.Text(
              'Reservation fee credit: PHP ${bill['reservation_fee_credit']}',
            ),
            pw.Text('Final balance: PHP ${bill['amount_due']}'),
          ] else ...[
            pw.Text('Services: ${receipt['service_type'] ?? ''}'),
            if (receipt['subtotal'] != null)
              pw.Text('Quotation Subtotal: PHP ${receipt['subtotal']}'),
            if ((double.tryParse(receipt['discount']?.toString() ?? '') ?? 0) >
                0)
              pw.Text('Discount: PHP ${receipt['discount']}'),
            if ((double.tryParse(receipt['tax']?.toString() ?? '') ?? 0) > 0)
              pw.Text('Tax: PHP ${receipt['tax']}'),
          ],
          pw.SizedBox(height: 8),
          pw.Text(
            'Amount Paid: PHP ${receipt['amount'] ?? '0.00'}',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
          ),
        ],
      ),
    );
    await Printing.sharePdf(
      bytes: await document.save(),
      filename: 'receipt-$paymentId.pdf',
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Receipt #$paymentId'),
      actions: [
        IconButton(
          tooltip: 'Refresh receipt',
          onPressed: _refreshReceipt,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: FutureBuilder<Map<String, dynamic>>(
      future: _receipt,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError || snapshot.data == null) {
          return EmptyState(
            icon: Icons.error_outline,
            title: 'Unable to Load Receipt',
            message: snapshot.error?.toString() ?? 'Receipt was not found.',
          );
        }
        final receipt = snapshot.requireData;
        final bill = receipt['billing'] as Map<String, dynamic>?;
        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Icon(Icons.verified, color: Colors.green, size: 52),
                    const Text(
                      'Luck Yuna Car Center',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text('Official Payment Receipt'),
                    const Divider(height: 32),
                    _info('Receipt No.', '#$paymentId'),
                    _info('Booking', _bookingReference(receipt)),
                    _info('Payment Date', receipt['paid_at'] ?? ''),
                    const Divider(),
                    _info('Customer', receipt['fullname'] ?? ''),
                    _info('Email', receipt['email'] ?? ''),
                    const Divider(),
                    _info('Vehicle', '${receipt['brand']} ${receipt['model']}'),
                    _info('Plate', receipt['plate_number'] ?? ''),
                    _info(
                      'Appointment',
                      '${receipt['appointment_date']} ${receipt['appointment_time']}',
                    ),
                    const Divider(),
                    _info('Method', receipt['payment_method'] ?? ''),
                    _info(_referenceLabel(receipt), _referenceNumber(receipt)),
                    const Divider(),
                    if (bill == null)
                      _info('Services', receipt['service_type'] ?? '')
                    else ...[
                      const Text(
                        'Completed services',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      for (final line in _completedServices(bill))
                        _info(_receiptServiceName(line), money(line['amount'])),
                      const Divider(),
                      _info('Services total', money(bill['gross_amount'])),
                      _info(
                        'Reservation fee credit',
                        money(bill['reservation_fee_credit']),
                      ),
                      _info('Final balance', money(bill['amount_due'])),
                    ],
                    const SizedBox(height: 12),
                    const Text('Amount paid'),
                    Text(
                      money(receipt['amount']),
                      style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => _share(receipt),
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('SAVE OR SHARE PDF'),
            ),
          ],
        );
      },
    ),
  );

  Widget _info(String label, dynamic value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: Text(label, style: const TextStyle(color: Colors.grey)),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 3,
          child: Text(
            value.toString(),
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ),
      ],
    ),
  );
}
