import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';

class JobQuotationScreen extends StatefulWidget {
  final int reservationId;
  const JobQuotationScreen({required this.reservationId, super.key});

  @override
  State<JobQuotationScreen> createState() => _JobQuotationScreenState();
}

class _JobQuotationScreenState extends State<JobQuotationScreen> {
  Map<String, dynamic>? quotation;
  Map<String, dynamic>? serviceWorkflow;
  bool loading = true;
  String? error;
  bool _submitting = false;
  final _selectedDecisions = <int, String>{};

  static const _workflowTotals = {
    'original_authorized': 'Original Authorized Total',
    'proposed_additional': 'Proposed Additional Total',
    'approved_additional': 'Approved Additional Total',
    'updated_authorized': 'Updated Authorized Service Total',
  };

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final result = await CustomerApi.quotationDetails(widget.reservationId);
      if (mounted) {
        setState(() {
          quotation = _asMap(result['quotation']);
          serviceWorkflow = _asMap(result['service_workflow']);
          _selectedDecisions.clear();
          loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e.toString().replaceFirst('Exception: ', '');
          loading = false;
        });
      }
    }
  }

  Map<String, dynamic>? _asMap(Object? value) =>
      value is Map<String, dynamic> ? value : null;

  List<Map<String, dynamic>> _workflowItems(Object? value) =>
      value is List ? value.whereType<Map<String, dynamic>>().toList() : [];

  List<String> _activeAdvisories(Map<String, dynamic> workflow) =>
      _workflowItems(workflow['safety_advisories'])
          .where((advisory) => advisory['resolved_at'] == null)
          .map((advisory) => (advisory['message'] ?? '').toString().trim())
          .where((message) => message.isNotEmpty)
          .toSet()
          .toList();

  String _repairDecisionLabel(Object? decision) => switch (decision) {
    'Accepted' => 'Approved',
    'Rejected' => 'Declined',
    'Withdrawn' => 'Withdrawn',
    _ => 'Pending',
  };

  bool _isRespondable(Map<String, dynamic> item, int revisionId) =>
      item['respondable'] == true &&
      item['decision'] == 'Pending' &&
      item['revision_id'].toString() == revisionId.toString();

  Future<void> _submitWorkflowDecision(int revisionId, {String? status}) async {
    if (_submitting || (status == null && _selectedDecisions.isEmpty)) return;
    final decisions = status == null
        ? Map<int, String>.of(_selectedDecisions)
        : const <int, String>{};
    final approved = decisions.values
        .where((value) => value == 'Accepted')
        .length;
    final declined = decisions.length - approved;
    final title = switch (status) {
      'Accepted' => 'Approve all pending repairs?',
      'Rejected' => 'Decline all pending repairs?',
      _ => 'Save selected repair decisions?',
    };
    final selectedCounts = [
      if (approved > 0) '$approved to approve',
      if (declined > 0) '$declined to decline',
    ];
    final selection = selectedCounts.isEmpty
        ? ''
        : '${selectedCounts.join(', ')}. ';

    setState(() => _submitting = true);
    try {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(title),
          content: Text(
            '${selection}Your originally booked services can continue where safe. '
            'Staff will prepare the bill for completed authorized work.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Confirm'),
            ),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;
      final result = await CustomerApi.respondToWorkflowQuotation(
        widget.reservationId,
        revisionId,
        status: status,
        decisions: decisions,
      );
      if (!mounted) return;
      final succeeded = result['success'] == true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['message']?.toString() ??
                (succeeded
                    ? 'Additional repair decisions saved.'
                    : 'Unable to save the repair decisions.'),
          ),
          backgroundColor: succeeded
              ? null
              : Theme.of(context).colorScheme.error,
        ),
      );
      await load();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to confirm the result. Checking the latest quotation.',
          ),
        ),
      );
      await load();
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Future<void> respond(String status) async {
    final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text('$status Quotation?'),
      content: Text(status == 'Accepted' ? 'You confirm that you approve this itemized cost.' : 'The service center will be informed that you rejected this quotation.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(status))],
    ));
    if (confirmed != true) return;
    try {
      final result = await CustomerApi.respondQuotation(widget.reservationId, status);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message']?.toString() ?? 'Quotation updated.')));
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')), backgroundColor: Colors.red));
    }
  }

  Future<void> respondItem(int itemId,String decision) async {
    try { final result=await CustomerApi.respondQuotationItem(itemId,decision); if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result['message']?.toString()??'Item updated.')));await load(); }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ','')),backgroundColor:Colors.red));}
  }

  Future<void> printQuotation() async {
    final q = quotation!;
    final items = (q['items'] as List? ?? []).whereType<Map>().toList();
    final document = pw.Document();
    document.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, build: (_) => [
      pw.Text('JOB QUOTATION', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.Text(q['quotation_number']?.toString() ?? ''), pw.SizedBox(height: 16),
      pw.Text('${q['brand'] ?? ''} ${q['model'] ?? ''} • ${q['plate_number'] ?? ''}'), pw.SizedBox(height: 14),
      pw.TableHelper.fromTextArray(headers: ['Type','Description','Qty','Unit Price','Amount'], data: items.map((raw) { final item=Map<String,dynamic>.from(raw); return [item['item_type'],item['description'],item['quantity'],money(item['unit_price']),money(item['amount'])]; }).toList()),
      pw.SizedBox(height: 18), pw.Align(alignment: pw.Alignment.centerRight, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [pw.Text('Subtotal: ${money(q['subtotal'])}'),pw.Text('Discount: ${money(q['discount'])}'),pw.Text('Tax: ${money(q['tax'])}'),pw.Divider(),pw.Text('TOTAL TO PAY: ${money(q['grand_total'])}', style: pw.TextStyle(fontSize: 18,fontWeight: pw.FontWeight.bold))])),
      if((q['notes']??'').toString().isNotEmpty)...[pw.SizedBox(height:16),pw.Text('Notes: ${q['notes']}')],
    ]));
    await Printing.layoutPdf(onLayout: (_) => document.save(), name: '${q['quotation_number'] ?? 'job-quotation'}.pdf');
  }

  Future<void> _printWorkflowQuotation(Map<String, dynamic> workflow) async {
    final revision = _asMap(workflow['quotation']);
    final totals = _asMap(workflow['totals']) ?? {};
    final original = _workflowItems(workflow['original_services']);
    final additional = _workflowItems(workflow['additional_repairs']);
    final advisories = _activeAdvisories(workflow);
    final reference = workflow['booking_reference']?.toString() ?? '';
    final heading = revision == null
        ? 'Booking Service Summary'
        : 'Final Quotation';
    final document = pw.Document();
    final sectionStyle = pw.TextStyle(
      fontSize: 14,
      fontWeight: pw.FontWeight.bold,
    );
    final itemStyle = pw.TextStyle(fontWeight: pw.FontWeight.bold);

    List<pw.Widget> items(
      List<Map<String, dynamic>> lines, {
      required bool extras,
    }) => [
      for (final item in lines) ...[
        pw.Text('${item['name']}  |  PHP ${item['amount']}', style: itemStyle),
        if (double.tryParse(item['quantity'].toString()) != 1 &&
            item['quantity'] != null)
          pw.Text('${item['quantity']} × PHP ${item['unit_price']} each'),
        if (extras) pw.Text(_repairDecisionLabel(item['decision'])),
        if ((item['description'] ?? '').toString().isNotEmpty)
          pw.Text(
            item['description'].toString(),
            overflow: pw.TextOverflow.span,
          ),
        if (extras &&
            (item['finding'] ?? '').toString().isNotEmpty &&
            item['finding'] != item['description'])
          pw.Text(
            'Finding: ${item['finding']}',
            overflow: pw.TextOverflow.span,
          ),
        if (extras && (item['advisory'] ?? '').toString().isNotEmpty)
          pw.Text(
            'Safety advisory: ${item['advisory']}',
            overflow: pw.TextOverflow.span,
          ),
        pw.SizedBox(height: 9),
      ],
    ];

    try {
      document.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          build: (_) => [
            pw.Text(
              heading,
              style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold),
            ),
            pw.Text('Booking reference: $reference'),
            if (revision != null)
              pw.Text(
                'Version ${revision['version']}  |  ${revision['decision_status']}',
              ),
            if ((revision?['valid_until'] ?? '').toString().isNotEmpty)
              pw.Text('Valid through ${revision!['valid_until']}'),
            pw.SizedBox(height: 18),
            pw.Text('Original Booked Services', style: sectionStyle),
            pw.Text('Previously authorized'),
            pw.SizedBox(height: 8),
            ...items(original, extras: false),
            pw.SizedBox(height: 12),
            pw.Text('Additional Recommended Repairs', style: sectionStyle),
            pw.SizedBox(height: 8),
            if (additional.isEmpty) pw.Text('No additional repairs proposed.'),
            ...items(additional, extras: true),
            if (advisories.isNotEmpty) ...[
              pw.SizedBox(height: 8),
              pw.Text('Safety Advisories', style: sectionStyle),
              for (final advisory in advisories)
                pw.Text(advisory, overflow: pw.TextOverflow.span),
            ],
            pw.Divider(),
            for (final entry in _workflowTotals.entries)
              pw.Text('${entry.value}: PHP ${totals[entry.key] ?? '0.00'}'),
            pw.SizedBox(height: 10),
            pw.Text('The final bill covers completed authorized work.'),
          ],
        ),
      );
      final suffix = revision == null
          ? 'service-summary'
          : 'quotation-v${revision['version']}';
      await Printing.layoutPdf(
        onLayout: (_) => document.save(),
        name: '$reference-$suffix.pdf',
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to prepare the PDF.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        serviceWorkflow == null
            ? 'Job Quotation'
            : serviceWorkflow?['quotation'] == null
            ? 'Service Summary'
            : 'Final Quotation',
      ),
    ),
    body: RefreshIndicator(
      onRefresh: () async {
        if (!_submitting) await load();
      },
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                EmptyState(
                  icon: Icons.error_outline,
                  title: 'Unable to Load',
                  message: error!,
                ),
              ],
            )
          : serviceWorkflow != null
          ? _workflowContent(serviceWorkflow!)
          : quotation == null
          ? ListView(
              children: const [
                EmptyState(
                  icon: Icons.request_quote_outlined,
                  title: 'Quotation Not Ready',
                  message: 'The service center has not sent a quotation for this reservation yet.',
                ),
              ],
            )
          : _content(),
    ),
  );

  Widget _workflowContent(Map<String, dynamic> workflow) {
    final revision = _asMap(workflow['quotation']);
    final revisionId = int.tryParse(revision?['id']?.toString() ?? '');
    final original = _workflowItems(workflow['original_services']);
    final additional = _workflowItems(workflow['additional_repairs']);
    final advisories = _activeAdvisories(workflow);
    final totals = _asMap(workflow['totals']) ?? {};
    final canRespond =
        revisionId != null &&
        revision?['can_respond'] == true &&
        additional.any((item) => _isRespondable(item, revisionId));
    final sectionStyle = Theme.of(context).textTheme.titleMedium;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'Booking ${workflow['booking_reference'] ?? ''}',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        if (revision != null) ...[
          const SizedBox(height: 4),
          Text(
            'Version ${revision['version']} · ${revision['decision_status']}',
          ),
          if ((revision['valid_until'] ?? '').toString().isNotEmpty)
            Text('Valid through ${revision['valid_until']}'),
        ],
        const SizedBox(height: 20),
        Text('Original Booked Services', style: sectionStyle),
        const Text('Previously authorized'),
        const SizedBox(height: 8),
        for (final item in original) _workflowItem(item),
        const SizedBox(height: 20),
        Text('Additional Recommended Repairs', style: sectionStyle),
        const SizedBox(height: 8),
        if (additional.isEmpty) const Text('No additional repairs proposed.'),
        for (final item in additional)
          _workflowItem(
            item,
            extra: true,
            currentRevisionId: canRespond ? revisionId : null,
          ),
        if (advisories.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text('Safety Advisories', style: sectionStyle),
          for (final advisory in advisories)
            Card(
              child: ListTile(
                leading: const Icon(Icons.warning_amber),
                title: Text(advisory),
              ),
            ),
        ],
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                for (final entry in _workflowTotals.entries)
                  _total(entry.value, totals[entry.key]),
                const SizedBox(height: 8),
                const Text('The final bill covers completed authorized work.'),
              ],
            ),
          ),
        ),
        if (canRespond) ...[
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _submitting || _selectedDecisions.isEmpty
                ? null
                : () => _submitWorkflowDecision(revisionId),
            child: Text(
              'Save selected decisions (${_selectedDecisions.length})',
            ),
          ),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              OutlinedButton(
                onPressed: _submitting
                    ? null
                    : () => _submitWorkflowDecision(
                        revisionId,
                        status: 'Rejected',
                      ),
                child: const Text('Decline all pending'),
              ),
              OutlinedButton(
                onPressed: _submitting
                    ? null
                    : () => _submitWorkflowDecision(
                        revisionId,
                        status: 'Accepted',
                      ),
                child: const Text('Approve all pending'),
              ),
            ],
          ),
        ],
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _submitting
              ? null
              : () => _printWorkflowQuotation(workflow),
          icon: const Icon(Icons.picture_as_pdf),
          label: const Text('Print / Save PDF'),
        ),
      ],
    );
  }

  Widget _workflowItem(
    Map<String, dynamic> item, {
    bool extra = false,
    int? currentRevisionId,
  }) {
    final id = int.tryParse(item['id']?.toString() ?? '');
    final decision = item['decision'];
    final description = (item['description'] ?? '').toString();
    final finding = (item['finding'] ?? '').toString();
    final advisory = (item['advisory'] ?? '').toString();
    final workStatus = (item['work_status'] ?? '').toString();
    final quantity = double.tryParse(item['quantity'].toString());
    final canRespond =
        id != null &&
        currentRevisionId != null &&
        _isRespondable(item, currentRevisionId);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    item['name']?.toString() ?? '',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ),
                const SizedBox(width: 8),
                Text(money(item['amount'])),
              ],
            ),
            if (quantity != null && quantity != 1)
              Text('${item['quantity']} × ${money(item['unit_price'])} each'),
            if (description.isNotEmpty) Text(description),
            if (extra && finding.isNotEmpty && finding != description) ...[
              const SizedBox(height: 6),
              Text('Finding: $finding'),
            ],
            if (extra && advisory.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text('Safety advisory: $advisory'),
            ],
            if (extra) ...[
              const SizedBox(height: 6),
              Text(
                _repairDecisionLabel(decision),
                style: Theme.of(context).textTheme.labelLarge,
              ),
            ],
            if (workStatus.isNotEmpty && (!extra || decision == 'Accepted'))
              Text(workStatus, style: Theme.of(context).textTheme.bodySmall),
            if (canRespond)
              Wrap(
                spacing: 8,
                children: [
                  for (final option in const {
                    'Accepted': 'Approve',
                    'Rejected': 'Decline',
                  }.entries)
                    ChoiceChip(
                      label: Text(option.value),
                      selected: _selectedDecisions[id] == option.key,
                      onSelected: _submitting
                          ? null
                          : (selected) => setState(() {
                              if (selected) {
                                _selectedDecisions[id] = option.key;
                              } else {
                                _selectedDecisions.remove(id);
                              }
                            }),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _content() {
    final q = quotation!;
    final items = (q['items'] as List? ?? []).whereType<Map>().toList();
    final status = q['status']?.toString() ?? '';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(q['quotation_number']?.toString() ?? 'Job Quotation', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), StatusChip(status)]),
        const SizedBox(height: 8),
        Text('${q['brand'] ?? ''} ${q['model'] ?? ''} • ${q['plate_number'] ?? ''}'),
        if ((q['valid_until']?.toString() ?? '').isNotEmpty) Text('Valid until: ${q['valid_until']}', style: TextStyle(color: Colors.grey.shade600)),
      ]))),
      const SizedBox(height: 12),
      const Text('Quotation Items', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...items.map((raw) { final item = Map<String,dynamic>.from(raw);final additional=item['is_additional']==true;final decision=item['customer_decision']?.toString(); return Card(child: Padding(padding:const EdgeInsets.all(12),child:Column(children:[ListTile(contentPadding:EdgeInsets.zero,
        leading: CircleAvatar(child: Icon(_icon(item['item_type']?.toString()))),title: Text(item['description']?.toString() ?? ''),
        subtitle: Text('${item['item_type']} • ${item['quantity']} × ${money(item['unit_price'])}${additional?'\nAdditional work':''}'),trailing: Text(money(item['amount']), style: const TextStyle(fontWeight: FontWeight.bold))),
        if(additional&&decision=='Pending')Row(children:[Expanded(child:OutlinedButton(onPressed:()=>respondItem(item['id'] as int,'Rejected'),child:const Text('Reject'))),const SizedBox(width:10),Expanded(child:FilledButton(onPressed:()=>respondItem(item['id'] as int,'Accepted'),child:const Text('Accept')))])
        else if(additional)Align(alignment:Alignment.centerRight,child:StatusChip(decision??'Pending'))]))); }),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        _total('Subtotal', q['subtotal']),
        if ((q['discount'] as num? ?? 0) > 0) _total('Discount', -((q['discount'] as num?) ?? 0)),
        if ((q['tax'] as num? ?? 0) > 0) _total('Tax', q['tax']),
        const Divider(height: 24),
        Row(children: [const Expanded(child: Text('TOTAL TO PAY', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), Text(money(q['grand_total']), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: primaryColor))]),
      ]))),
      if ((q['notes']?.toString() ?? '').isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.notes), title: const Text('Notes'), subtitle: Text(q['notes'].toString()))),
      OutlinedButton.icon(onPressed: printQuotation, icon: const Icon(Icons.picture_as_pdf), label: const Text('Print / Save Quotation PDF')),
      if (status == 'Sent') Padding(padding: const EdgeInsets.only(top: 16), child: Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => respond('Rejected'), style: OutlinedButton.styleFrom(foregroundColor: Colors.red), child: const Text('Reject'))),
        const SizedBox(width: 12), Expanded(child: FilledButton(onPressed: () => respond('Accepted'), child: const Text('Accept Quotation'))),
      ])),
      const SizedBox(height: 24),
    ]);
  }

  Widget _total(String label, dynamic value) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Expanded(child: Text(label)), Text(money(value))]));
  IconData _icon(String? type) => switch (type) { 'Part' => Icons.settings, 'Labor' => Icons.engineering, 'Other' => Icons.add_box_outlined, _ => Icons.build_outlined };
}
