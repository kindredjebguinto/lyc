import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vsm_customer/models/manual_wallet_details.dart';
import 'package:vsm_customer/screens/payments/payment_proof_dialog.dart';
import 'package:vsm_customer/services/receipt_ocr_service.dart';

import 'receipt_rules_test.dart' show validText;

class FakeOcr implements ReceiptOcr {
  final Future<String> Function() callback;
  FakeOcr(this.callback);
  @override
  Future<String> read(String path) => callback();
  @override
  Future<void> close() async {}
}

void main() {
  late Directory tmp;
  late XFile image;
  late Uint8List bytes;
  setUpAll(() async {
    tmp = await Directory.systemTemp.createTemp('wallet-ui-');
    final recorder = ui.PictureRecorder();
    Canvas(recorder).drawRect(
      const Rect.fromLTWH(0, 0, 80, 80),
      Paint()..color = Colors.white,
    );
    final picture = recorder.endRecording();
    final bitmap = await picture.toImage(80, 80);
    final data = await bitmap.toByteData(format: ui.ImageByteFormat.png);
    bytes = data!.buffer.asUint8List();
    final f = File('${tmp.path}/receipt.png');
    await f.writeAsBytes(bytes);
    image = XFile.fromData(bytes, path: f.path, mimeType: 'image/png');
    bitmap.dispose();
    picture.dispose();
  });
  tearDownAll(() => tmp.delete(recursive: true));
  Future<void> open(
    WidgetTester t, {
    String text = validText,
    ReceiptOcr? ocr,
    Future<ManualWalletDetails> Function(String)? loader,
    ValueChanged<PaymentProofSubmission?>? result,
    Future<void> Function(ManualWalletDetails)? save,
  }) async {
    t.view.physicalSize = const Size(390, 900);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Builder(
            builder: (context) => TextButton(
              onPressed: () async {
                final r = await showDialog<PaymentProofSubmission>(
                  context: context,
                  builder: (_) => PaymentProofDialog(
                    isReservationFee: true,
                    pickImage: () async => image,
                    ocr: ocr ?? FakeOcr(() async => text),
                    saveQr: save,
                    walletLoader:
                        loader ??
                        (method) async => ManualWalletDetails(
                          method: method,
                          configured: true,
                          accountName: 'TEDDY GIL LICO',
                          accountNumber: '09068624144',
                          version: 'test-v1',
                          qrBytes: bytes,
                        ),
                  ),
                );
                result?.call(r);
              },
              child: const Text('Open'),
            ),
          ),
        ),
      ),
    );
    await t.tap(find.text('Open'));
    await t.pumpAndSettle();
  }

  FilledButton submit(WidgetTester t) =>
      t.widget<FilledButton>(find.byKey(const Key('submitPayment')));
  Future<void> pick(WidgetTester t, {bool pending = false}) async {
    await t.ensureVisible(find.byKey(const Key('choosePaymentProof')));
    await t.tap(find.byKey(const Key('choosePaymentProof')));
    await t.pump();
    if (pending) {
      await t.pump();
    } else {
      await t.pumpAndSettle();
    }
  }

  testWidgets(
    'GCash/Maya offered, Bank Transfer absent, submit initially disabled',
    (t) async {
      await open(t);
      expect(submit(t).onPressed, isNull);
      await t.tap(find.byType(DropdownButtonFormField<String>));
      await t.pumpAndSettle();
      expect(find.text('Maya'), findsOneWidget);
      expect(find.text('Bank Transfer'), findsNothing);
    },
  );
  testWidgets('valid receipt enables submission, never labels it paid', (
    t,
  ) async {
    PaymentProofSubmission? result;
    await open(t, result: (r) => result = r);
    await pick(t);
    expect(submit(t).onPressed, isNotNull);
    expect(find.text('Ready for submission'), findsOneWidget);
    expect(find.text('Payment successful'), findsNothing);
    await t.tap(find.byKey(const Key('submitPayment')));
    await t.pumpAndSettle();
    expect(result?.method, 'GCash');
    expect(result?.reference, '1234567890123');
    expect(result?.manualReviewRequested, false);
    expect(result?.shopConfigurationVersion, 'test-v1');
  });
  testWidgets('amount and phone pass without name logo or OCR reference', (
    t,
  ) async {
    PaymentProofSubmission? result;
    await open(
      t,
      text: 'Amount: PHP 200.00\nMobile No: 09068624144',
      result: (r) => result = r,
    );
    await pick(t);
    expect(find.text('Ready for submission'), findsOneWidget);
    expect(find.text('Request manual review'), findsNothing);
    expect(submit(t).onPressed, isNull);
    await t.ensureVisible(find.byKey(const Key('paymentReference')));
    await t.enterText(
      find.byKey(const Key('paymentReference')),
      'MANUAL-REF-123',
    );
    await t.pump();
    expect(submit(t).onPressed, isNotNull);
    await t.tap(find.byKey(const Key('submitPayment')));
    await t.pumpAndSettle();
    expect(result?.manualReviewRequested, false);
  });
  testWidgets('wrong amount stays disabled and cannot use fallback', (t) async {
    await open(t, text: validText.replaceFirst('200.00', '250.00'));
    await pick(t);
    expect(submit(t).onPressed, isNull);
    expect(find.text('Receipt needs replacement'), findsOneWidget);
    expect(find.text('Request manual review'), findsNothing);
  });
  testWidgets('OCR failure requires explicit review and actual reference', (
    t,
  ) async {
    PaymentProofSubmission? result;
    await open(
      t,
      ocr: FakeOcr(() async => throw StateError('native OCR failure')),
      result: (r) => result = r,
    );
    await pick(t);
    expect(submit(t).onPressed, isNull);
    await t.ensureVisible(find.byType(CheckboxListTile));
    await t.tap(find.byType(CheckboxListTile));
    await t.pump();
    expect(submit(t).onPressed, isNull);
    await t.ensureVisible(find.byKey(const Key('paymentReference')));
    await t.enterText(
      find.byKey(const Key('paymentReference')),
      'ACTUAL-REF-123',
    );
    await t.pump();
    expect(submit(t).onPressed, isNotNull);
    await t.tap(find.byKey(const Key('submitPayment')));
    await t.pumpAndSettle();
    expect(result?.manualReviewRequested, true);
  });
  testWidgets(
    'checking indicator disables submit and stale OCR cannot cross methods',
    (t) async {
      final pending = Completer<String>();
      await open(t, ocr: FakeOcr(() => pending.future));
      await pick(t, pending: true);
      expect(find.text('Checking receipt...'), findsOneWidget);
      expect(submit(t).onPressed, isNull);
      await t.ensureVisible(find.byType(DropdownButtonFormField<String>));
      await t.tap(find.byType(DropdownButtonFormField<String>));
      await t.pump(const Duration(milliseconds: 350));
      await t.tap(find.text('Maya').last);
      await t.pumpAndSettle();
      pending.complete(validText);
      await t.runAsync(
        () async => Future<void>.delayed(const Duration(milliseconds: 20)),
      );
      await t.pumpAndSettle();
      expect(submit(t).onPressed, isNull);
      expect(find.text('Ready for submission'), findsNothing);
    },
  );
  testWidgets(
    'network failure while loading wallet disables receipt submission',
    (t) async {
      await open(
        t,
        loader: (_) async => throw const SocketException('offline'),
      );
      expect(find.text('Retry shop details'), findsOneWidget);
      expect(submit(t).onPressed, isNull);
      expect(find.byKey(const Key('choosePaymentProof')), findsNothing);
    },
  );
  testWidgets('missing QR configuration cannot display a fake live QR', (
    t,
  ) async {
    await open(
      t,
      loader: (m) async => ManualWalletDetails(
        method: m,
        configured: false,
        message: 'Not configured',
      ),
    );
    expect(find.text('Save QR Code'), findsNothing);
    expect(submit(t).onPressed, isNull);
  });
  testWidgets('Save QR passes original bytes and Copy uses approved number', (
    t,
  ) async {
    Uint8List? saved;
    String? copied;
    t.binding.defaultBinaryMessenger.setMockMethodCallHandler(
      SystemChannels.platform,
      (call) async {
        if (call.method == 'Clipboard.setData') {
          copied = (call.arguments as Map)['text'] as String;
        }
        return null;
      },
    );
    addTearDown(
      () => t.binding.defaultBinaryMessenger.setMockMethodCallHandler(
        SystemChannels.platform,
        null,
      ),
    );
    await open(
      t,
      save: (w) async {
        saved = w.qrBytes;
      },
    );
    await t.ensureVisible(find.text('Save QR Code'));
    await t.tap(find.text('Save QR Code'));
    await t.pumpAndSettle();
    expect(saved, orderedEquals(bytes));
    await t.ensureVisible(find.byTooltip('Copy mobile number'));
    await t.tap(find.byTooltip('Copy mobile number'));
    await t.pumpAndSettle();
    expect(copied, '09068624144');
  });
  testWidgets('QR for 200 cannot be offered for another amount', (t) async {
    await t.pumpWidget(
      MaterialApp(
        home: PaymentProofDialog(
          isReservationFee: false,
          expectedAmountMinor: 50000,
          walletLoader: (m) async => ManualWalletDetails(
            method: m,
            configured: true,
            qrAmountMinor: 20000,
            qrBytes: bytes,
          ),
        ),
      ),
    );
    await t.pumpAndSettle();
    expect(find.textContaining('₱200 only'), findsOneWidget);
    expect(submit(t).onPressed, isNull);
  });
}
