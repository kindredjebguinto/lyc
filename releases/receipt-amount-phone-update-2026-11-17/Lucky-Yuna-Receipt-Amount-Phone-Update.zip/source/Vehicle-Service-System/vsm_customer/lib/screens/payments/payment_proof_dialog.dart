import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:image_picker/image_picker.dart';

import '../../api/customer_api.dart';
import '../../models/manual_wallet_details.dart';
import '../../models/receipt_screening.dart';
import '../../services/receipt_classifier.dart';
import '../../services/receipt_ocr_service.dart';
import '../../services/receipt_validation_rules.dart';

class PaymentProofSubmission {
  final String method;
  final String reference;
  final XFile? proof;
  final String? shopConfigurationVersion;
  final bool manualReviewRequested;
  const PaymentProofSubmission({
    required this.method,
    required this.reference,
    this.proof,
    this.shopConfigurationVersion,
    this.manualReviewRequested = false,
  });
}

class PaymentProofDialog extends StatefulWidget {
  final bool isReservationFee;
  final int expectedAmountMinor;
  final Future<XFile?> Function()? pickImage;
  final Future<ManualWalletDetails> Function(String method)? walletLoader;
  final ReceiptOcr? ocr;
  final Future<void> Function(ManualWalletDetails wallet)? saveQr;
  const PaymentProofDialog({
    required this.isReservationFee,
    this.expectedAmountMinor = 20000,
    this.pickImage,
    this.walletLoader,
    this.ocr,
    this.saveQr,
    super.key,
  });
  @override
  State<PaymentProofDialog> createState() => _PaymentProofDialogState();
}

class _PaymentProofDialogState extends State<PaymentProofDialog> {
  final _reference = TextEditingController();
  String _method = 'GCash';
  XFile? _proof;
  ManualWalletDetails? _wallet;
  ReceiptScreening? _screening;
  String? _error;
  bool _loadingWallet = true,
      _picking = false,
      _checking = false,
      _saving = false,
      _manualReview = false;
  int _epoch = 0, _walletEpoch = 0;
  ReceiptOcr? _ownedOcr;
  Future<void> _lastRead = Future<void>.value();
  bool get _isWallet => _method == 'GCash' || _method == 'Maya';
  bool get _isCash => _method == 'Cash';
  bool get _walletReady =>
      _wallet?.configured == true &&
      _wallet!.qrAmountMinor == widget.expectedAmountMinor;
  ReceiptValidationState? get _effectiveState => _screening?.state;

  bool get _canSubmit {
    if (_picking || _checking) return false;
    if (_isCash) return true;
    if (_proof == null || _reference.text.trim().isEmpty) return false;
    if (!_isWallet) return true;
    if (!_walletReady ||
        !RegExp(r'^[A-Za-z0-9\s-]{1,100}$').hasMatch(_reference.text.trim()) ||
        ReceiptClassifier.normalizeReference(_reference.text).isEmpty) {
      return false;
    }
    return _effectiveState == ReceiptValidationState.validForSubmission ||
        (_effectiveState == ReceiptValidationState.needsReview &&
            _manualReview);
  }

  @override
  void initState() {
    super.initState();
    _reference.addListener(_referenceChanged);
    _loadWallet();
  }

  void _referenceChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _epoch++;
    _walletEpoch++;
    _reference.removeListener(_referenceChanged);
    _reference.dispose();
    // Do not close native ML Kit while a recognition request is still running.
    unawaited(
      _lastRead
          .then((_) async {
            await _ownedOcr?.close();
          })
          .catchError((Object _) {}),
    );
    super.dispose();
  }

  Future<void> _loadWallet() async {
    final generation = ++_walletEpoch;
    final method = _method;
    setState(() {
      _loadingWallet = true;
      _wallet = null;
      _error = null;
    });
    try {
      final ManualWalletDetails wallet;
      if (widget.walletLoader != null) {
        wallet = await widget.walletLoader!(method);
      } else {
        final response = await CustomerApi.manualWalletDetails(method);
        if (response['success'] != true) {
          throw Exception(
            response['message'] ?? 'Unable to load shop payment details.',
          );
        }
        wallet = ManualWalletDetails.fromMap(
          Map<String, dynamic>.from(response['wallet'] as Map),
        );
      }
      if (!mounted || generation != _walletEpoch || method != _method) return;
      if (wallet.method != method) {
        throw Exception('Payment details do not match the selected wallet.');
      }
      setState(() {
        _wallet = wallet;
        _loadingWallet = false;
      });
    } catch (_) {
      if (mounted && generation == _walletEpoch) {
        setState(() {
          _loadingWallet = false;
          _error = 'Unable to load shop QR. Check your connection and retry.';
        });
      }
    }
  }

  void _changeMethod(String value) {
    _epoch++;
    _walletEpoch++;
    setState(() {
      _method = value;
      _proof = null;
      _screening = null;
      _manualReview = false;
      _error = null;
      _checking = false;
      _wallet = null;
      _loadingWallet = false;
      _reference.clear();
    });
    if (_isWallet) _loadWallet();
  }

  Future<void> _chooseImage() async {
    final generation = ++_epoch;
    final method = _method;
    setState(() {
      _picking = true;
      _error = null;
      _proof = null;
      _screening = null;
      _manualReview = false;
      _reference.clear();
    });
    try {
      final picked =
          await (widget.pickImage?.call() ??
              ImagePicker().pickImage(source: ImageSource.gallery));
      if (!mounted || generation != _epoch || picked == null) return;
      final extension = picked.name.split('.').last.toLowerCase();
      if (!['jpg', 'jpeg', 'png', 'webp'].contains(extension)) {
        throw Exception('Choose a JPG, PNG or WEBP image.');
      }
      final size = await picked.length();
      if (size <= 0 || size > 5 * 1024 * 1024) {
        throw Exception('Choose a nonempty image no larger than 5 MB.');
      }
      if (!mounted || generation != _epoch) return;
      setState(() {
        _proof = picked;
        _picking = false;
        _checking = _isWallet;
      });
      if (!_isWallet) return;
      await _screen(picked.path, generation, method);
    } catch (e) {
      if (mounted && generation == _epoch) {
        setState(() {
          _error = e.toString().replaceFirst('Exception: ', '');
        });
      }
    } finally {
      if (mounted && generation == _epoch) {
        setState(() {
          _picking = false;
          _checking = false;
        });
      }
    }
  }

  Future<void> _screen(String path, int generation, String method) async {
    ReceiptScreening screening;
    try {
      final task = _lastRead.then(
        (_) => (widget.ocr ?? (_ownedOcr ??= MlKitReceiptOcr())).read(path),
      );
      _lastRead = task.then<void>((_) {}, onError: (Object _) {});
      final text = await task.timeout(const Duration(seconds: 20));
      if (!mounted || generation != _epoch || method != _method) return;
      final fields = ReceiptClassifier().classify(text);
      screening = ReceiptValidationRules().validate(
        fields,
        expectedAmountMinor: widget.expectedAmountMinor,
        accountName: _wallet!.accountName,
        accountNumber: _wallet!.accountNumber,
        approvedNames: _wallet!.approvedNames,
      );
    } catch (_) {
      screening = ReceiptScreening.unreadable();
    }
    if (!mounted || generation != _epoch || method != _method) return;
    setState(() {
      _screening = screening;
      _checking = false;
      _manualReview = false;
      if (screening.fields.reference != null) {
        _reference.text = screening.fields.reference!;
      }
    });
  }

  Future<void> _saveQr() async {
    final wallet = _wallet;
    if (wallet == null || wallet.qrBytes == null || _saving) return;
    setState(() => _saving = true);
    try {
      if (widget.saveQr != null) {
        await widget.saveQr!(wallet);
      } else {
        await Gal.putImageBytes(
          wallet.qrBytes!,
          name: 'LuckyYuna_${wallet.method}_QR',
        );
      }
      if (mounted) {
        setState(
          () => _error = 'QR saved to your photos. Confirm the recipient in your wallet before paying.',
        );
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'Unable to save QR. Check photo permissions and available storage.',
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _copy(String value, String label) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$label copied.')));
    }
  }

  void _submit() {
    if (!_canSubmit) return;
    Navigator.of(context).pop(
      PaymentProofSubmission(
        method: _method,
        reference: _isCash ? '' : _reference.text.trim(),
        proof: _isCash ? null : _proof,
        shopConfigurationVersion: _isWallet ? _wallet!.version : null,
        manualReviewRequested:
            _isWallet && _effectiveState == ReceiptValidationState.needsReview,
      ),
    );
  }

  Widget _walletPanel() {
    if (_loadingWallet) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (_wallet?.configured != true) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _wallet?.message ?? 'Shop QR is unavailable. Do not transfer to an unconfirmed account.',
          ),
          TextButton(
            onPressed: _loadWallet,
            child: const Text('Retry shop details'),
          ),
        ],
      );
    }
    if (!_walletReady) {
      return const Text(
        'This shop QR is for ₱200 only. Contact the service center for a different amount.',
      );
    }
    final wallet = _wallet!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (wallet.qrBytes != null)
          Center(
            child: InkWell(
              onTap: () => showDialog<void>(
                context: context,
                builder: (_) => Dialog(
                  child: InteractiveViewer(
                    minScale: 1,
                    maxScale: 6,
                    child: Image.memory(wallet.qrBytes!, fit: BoxFit.contain),
                  ),
                ),
              ),
              child: Image.memory(
                wallet.qrBytes!,
                height: 240,
                fit: BoxFit.contain,
                semanticLabel: '${wallet.method} shop QR',
              ),
            ),
          ),
        const Text('Tap to enlarge or save the original QR image.'),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(wallet.accountName),
          subtitle: const Text('Approved account name'),
          trailing: IconButton(
            tooltip: 'Copy account name',
            onPressed: () => _copy(wallet.accountName, 'Account name'),
            icon: const Icon(Icons.copy),
          ),
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(wallet.accountNumber),
          subtitle: const Text('Approved mobile number'),
          trailing: IconButton(
            tooltip: 'Copy mobile number',
            onPressed: () => _copy(wallet.accountNumber, 'Mobile number'),
            icon: const Icon(Icons.copy),
          ),
        ),
        OutlinedButton.icon(
          onPressed: _saving ? null : _saveQr,
          icon: const Icon(Icons.download),
          label: Text(_saving ? 'Saving QR...' : 'Save QR Code'),
        ),
        const Text(
          'Confirm the name, number and ₱200 amount in your wallet before transferring. Transfer fees may apply.',
        ),
      ],
    );
  }

  Widget _screeningPanel() {
    if (_checking) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            SizedBox.square(
              dimension: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            SizedBox(width: 10),
            Text('Checking receipt...'),
          ],
        ),
      );
    }
    final result = _screening;
    if (result == null) return const SizedBox.shrink();
    final state = _effectiveState;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(switch (state) {
          ReceiptValidationState.validForSubmission => 'Ready for submission',
          ReceiptValidationState.invalid => 'Receipt needs replacement',
          _ => 'Receipt needs manual review',
        }, style: const TextStyle(fontWeight: FontWeight.bold)),
        for (final reason in result.reasons) Text(reason),
        if (state == ReceiptValidationState.needsReview) ...[
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: _manualReview,
            onChanged: (value) =>
                setState(() => _manualReview = value ?? false),
            title: const Text('Request manual review'),
            subtitle: const Text(
              'Enter the actual transaction reference. Staff must verify the receipt and funds received.',
            ),
          ),
        ],
        const Text(
          'Screening cannot prove a screenshot is genuine. Payment stays unverified until staff confirms it.',
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
    title: const Text('Payment Method'),
    content: SizedBox(
      width: 360,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              initialValue: _method,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Choose method',
                border: OutlineInputBorder(),
              ),
              items:
                  [
                        'GCash',
                        'Maya',
                        'Card',
                        if (!widget.isReservationFee) 'Cash',
                      ]
                      .map(
                        (method) => DropdownMenuItem(
                          value: method,
                          child: Text(
                            method == 'Cash' ? 'Cash at Shop' : method,
                          ),
                        ),
                      )
                      .toList(),
              onChanged: _picking
                  ? null
                  : (value) {
                      if (value != null) _changeMethod(value);
                    },
            ),
            const SizedBox(height: 14),
            if (_isWallet) _walletPanel(),
            if (_isCash)
              const Text(
                'Pay the exact amount at the service counter. No receipt image or reference is required.',
              ),
            if (!_isCash && (!_isWallet || _walletReady)) ...[
              const SizedBox(height: 14),
              if (_proof != null)
                Image.file(
                  File(_proof!.path),
                  key: const Key('paymentProofPreview'),
                  height: 150,
                  width: double.infinity,
                  fit: BoxFit.contain,
                  cacheWidth: 1024,
                  errorBuilder: (_, _, _) => const Text(
                    'Preview unavailable. Choose another image if this file cannot be opened.',
                  ),
                ),
              OutlinedButton.icon(
                key: const Key('choosePaymentProof'),
                onPressed: _picking ? null : _chooseImage,
                icon: const Icon(Icons.image_outlined),
                label: Text(
                  _picking ? 'Opening gallery...' : 'Choose Receipt Image',
                ),
              ),
              const Text(
                'JPG, PNG or WEBP · maximum 5 MB. Keep the amount, recipient and reference readable.',
              ),
              if (_isWallet) _screeningPanel(),
              const SizedBox(height: 12),
              TextField(
                key: const Key('paymentReference'),
                controller: _reference,
                maxLength: 100,
                decoration: const InputDecoration(
                  labelText: 'Transaction Reference Number',
                  helperText: 'Type the reference from your wallet if it was not detected.',
                  helperMaxLines: 2,
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_error!, key: const Key('paymentMessage')),
              ),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.of(context).pop(),
        child: const Text('Cancel'),
      ),
      FilledButton(
        key: const Key('submitPayment'),
        onPressed: _canSubmit ? _submit : null,
        child: Text(
          _isCash ? 'SELECT CASH' : 'Submit Payment for Verification',
        ),
      ),
    ],
  );
}
