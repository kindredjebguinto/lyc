<?php
// CLI-only, read-only local schema check. Never includes/evaluates the config files.
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
if(!function_exists('token_get_all')||!class_exists('mysqli')){fwrite(STDERR,"Use XAMPP PHP with mysqli and tokenizer enabled. No files or database records were changed.\n");exit(1);}
$root=$argv[1]??'';
if(!is_dir($root)){fwrite(STDERR,"Provide the existing Vehicle-Service-System directory.\n");exit(1);}
$required=[
 'job_schedule_events'=>['id'],'customers'=>['user_id'],'vehicles'=>['user_id'],
 'reservations'=>['user_id','checked_in_at','scheduled_duration_minutes','booking_channel','original_duration_minutes','original_appointment_at'],
 'users'=>['staff_level','mechanic_id'],'service_categories'=>['id'],'service_catalog'=>['id'],
 'reservation_services'=>['id'],'payments'=>['payment_type'],
];
function configLiterals(string $file):array{
 $tokens=token_get_all(file_get_contents($file));$values=[];$wanted=['host','user','username','password','database'];
 for($i=0;$i<count($tokens);$i++){
  $t=$tokens[$i];if(!is_array($t)||$t[0]!==T_VARIABLE)continue;$name=substr($t[1],1);if(!in_array($name,$wanted,true))continue;
  $j=$i+1;while(isset($tokens[$j])&&is_array($tokens[$j])&&$tokens[$j][0]===T_WHITESPACE)$j++;
  if(($tokens[$j]??null)!=='=')continue;$j++;
  while(isset($tokens[$j])&&is_array($tokens[$j])&&$tokens[$j][0]===T_WHITESPACE)$j++;
  $v=$tokens[$j]??null;if(!is_array($v)||$v[0]!==T_CONSTANT_ENCAPSED_STRING)continue;
  $raw=$v[1];$inside=substr($raw,1,-1);
  $values[$name]=$raw[0]==="'"?str_replace(["\\\\","\\'"],["\\","'"],$inside):stripcslashes($inside);
 }
 return $values;
}
echo "READ-ONLY CHECK: config database names and schema columns only. No account records/passwords are printed.\n";
foreach(['vehicle-service-management/includes/config.php','vehicle-service-management/api/config/database.php','vehicle-service-management-admin/includes/config.php'] as $relative){
 echo "\n[$relative]\n";$file=rtrim($root,'/\\').'/'.$relative;
 if(!is_file($file)){echo "Config file missing.\n";continue;}
 $v=configLiterals($file);
 if(!isset($v['host'],$v['database'],$v['password'])||!isset($v['username'])&&!isset($v['user'])){echo "Config uses settings that this literal-only checker cannot read. Inspect its database name locally. Do not send the full config file.\n";continue;}
 echo 'Database: '.$v['database']."\n";
 if(!in_array(strtolower($v['host']),['localhost','127.0.0.1','::1'],true)){echo "Remote host skipped; this tool checks local XAMPP only.\n";continue;}
 try{
  $conn=new mysqli($v['host'],$v['username']??$v['user'],$v['password'],$v['database']);
  $r=$conn->query('SELECT TABLE_NAME,COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE()');$found=[];
  while($row=$r->fetch_assoc())$found[$row['TABLE_NAME']][$row['COLUMN_NAME']]=true;
  $missing=[];foreach($required as $table=>$columns)foreach($columns as $column)if(!isset($found[$table][$column]))$missing[]=$table.'.'.$column;
  if(!$missing)echo "Schema check: READY (all columns required by the website guard exist).\n";
  else{echo 'Schema check: MISSING '.count($missing)." required columns/table fields:\n";foreach($missing as $name)echo ' - '.$name."\n";}
  $conn->close();
 }catch(Throwable $e){echo "Could not connect/read the configured local database. Check MySQL and your local settings. Credentials were not printed.\n";}
}
echo "\nNo database changes were performed.\n";
