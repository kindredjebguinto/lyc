from pathlib import Path
import os,subprocess,json
b=Path('/workspace/work/manual-wallet-update');fixture=b/'diagnostic-fixture';fixture.mkdir(exist_ok=True)
php='/workspace/work/runtime/root/usr/bin/php8.4';env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/runtime/root/usr/lib/x86_64-linux-gnu'
def php_run(code):
 return subprocess.run([php,'-c','/workspace/work/php.ini','-d','extension=tokenizer','-r',code],env=env,capture_output=True,text=True,check=True).stdout
php_run("$c=new mysqli('localhost','root','',null,0,'/workspace/work/db/mysql.sock');$c->query('CREATE DATABASE IF NOT EXISTS lyc_diag_empty_test');")
files=['vehicle-service-management/includes/config.php','vehicle-service-management/api/config/database.php','vehicle-service-management-admin/includes/config.php']
sentinel=b/'must-not-execute'
if sentinel.exists():sentinel.unlink()
for i,n in enumerate(files):
 p=fixture/n;p.parent.mkdir(parents=True,exist_ok=True)
 db='lyc_diag_empty_test' if i==2 else 'manual_wallet_test';user='username' if i==1 else 'user'
 p.write_text("<?php\n$host='localhost';$"+user+"='root';$password='';$database='"+db+"';\nfile_put_contents("+repr(str(sentinel))+", 'should never execute');")
state="SELECT COUNT(*) n FROM payments"
# Record the data count around this read-only diagnostic.
def count():return php_run("$c=new mysqli('localhost','root','','manual_wallet_test',0,'/workspace/work/db/mysql.sock');echo $c->query('SELECT COUNT(*) n FROM payments')->fetch_assoc()['n'];")
before=count()
r=subprocess.run([php,'-c','/workspace/work/php.ini','-d','extension=tokenizer',str(b/'Check-Local-Database.php'),str(fixture)],env=env,capture_output=True,text=True)
checks=[{'name':'diagnostic process succeeds','passed':r.returncode==0},{'name':'ready schema recognized for both user/username config variants','passed':r.stdout.count('Schema check: READY')==2},{'name':'incomplete schema identifies all 15 required fields','passed':'MISSING 15' in r.stdout},{'name':'config PHP is not executed','passed':not sentinel.exists()},{'name':'database payment count unchanged','passed':before==count()},{'name':'config credentials not printed','passed':"root" not in r.stdout and "$password" not in r.stdout}]
assert all(x['passed'] for x in checks),(checks,r.stdout,r.stderr)
(b/'diagnostic-tests.json').write_text(json.dumps({'checks':checks,'passed':len(checks)},indent=2));print(r.stdout);print(len(checks),'read-only diagnostic assertions passed')
