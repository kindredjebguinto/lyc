import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import 'receipt_text_layout.dart';

abstract class ReceiptOcr {
  Future<String> read(String filePath);
  Future<void> close();
}

class MlKitReceiptOcr implements ReceiptOcr {
  final TextRecognizer _recognizer = TextRecognizer(
    script: TextRecognitionScript.latin,
  );
  @override
  Future<String> read(String filePath) async {
    final result = await _recognizer.processImage(
      InputImage.fromFilePath(filePath),
    );
    final lines = [
      for (final block in result.blocks)
        for (final line in block.lines)
          ReceiptTextLine(
            line.text,
            line.boundingBox.left,
            line.boundingBox.top,
            line.boundingBox.right,
            line.boundingBox.bottom,
          ),
    ];
    return lines.isEmpty ? result.text : receiptTextInReadingOrder(lines);
  }

  @override
  Future<void> close() => _recognizer.close();
}
