// Pure layout adapter: ML Kit blocks can be column-first rather than row-first.
// Keep the recognized characters; never fill digits from expected shop details.
class ReceiptTextLine {
  final String text;
  final double left, top, right, bottom;
  const ReceiptTextLine(
    this.text,
    this.left,
    this.top,
    this.right,
    this.bottom,
  );
  double get height => bottom - top;
  double get centerY => (top + bottom) / 2;
}

String receiptTextInReadingOrder(List<ReceiptTextLine> input) {
  final lines = input.where((line) => line.text.trim().isNotEmpty).toList()
    ..sort((a, b) {
      final y = a.centerY.compareTo(b.centerY);
      return y != 0 ? y : a.left.compareTo(b.left);
    });
  final rows = <List<ReceiptTextLine>>[];
  for (final line in lines) {
    if (rows.isEmpty) {
      rows.add([line]);
      continue;
    }
    final row = rows.last;
    final anchor = row.first;
    final minHeight = line.height < anchor.height ? line.height : anchor.height;
    final sameRow =
        minHeight > 0 &&
        (line.centerY - anchor.centerY).abs() <= minHeight * 0.45 &&
        row.every(
          (other) => line.left >= other.right || line.right <= other.left,
        );
    if (sameRow) {
      row.add(line);
    } else {
      rows.add([line]);
    }
  }
  return rows
      .map((row) {
        row.sort((a, b) => a.left.compareTo(b.left));
        return row.map((line) => line.text.trim()).join(' ');
      })
      .join('\n');
}
