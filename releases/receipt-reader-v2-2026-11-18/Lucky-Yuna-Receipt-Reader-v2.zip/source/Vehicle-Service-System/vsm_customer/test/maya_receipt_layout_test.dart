import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/models/receipt_screening.dart';
import 'package:vsm_customer/services/receipt_classifier.dart';

import 'receipt_rules_test.dart' show screen;

// Synthetic OCR-text layouts based on the supplied examples. Sender and reference
// values are test data; original private screenshots are not distributed.
const mayaOverlay =
    "Confirm transaction\n₱200.00\nSource\nMy Wallet\n+63 912 345 6789\nDestination\nM***T S***\n+639990000001\nYou've successfully sent\n₱200.00\nFrom your wallet to M***T S***\nView receipt\nDone";
const mayaCompact =
    'Sent money to\n- ₱200.00\n+639990000001\nCompleted\nReference ID\nAB12 CD34 EF56\nmaya';
const mayaExpanded =
    'Sent money\nM***T S***\n+639990000001\n- ₱200.00\nCompleted\nSource\nMy Wallet\n+63 912 345 6789\nDestination\nM***T S***\n+639990000001\nTransaction details\nReference ID\nAB12 CD34 EF56\nmaya';
void main() {
  test('Maya success overlay chooses Destination rather than Source', () {
    expect(
      screen(mayaOverlay).state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('Maya compact completed debit means 200 sent', () {
    final r = screen(mayaCompact);
    expect(r.state, ReceiptValidationState.validForSubmission);
    expect(r.fields.amountsMinor, [20000]);
    expect(r.fields.reference, 'AB12CD34EF56');
  });
  test('Maya expanded receipt chooses Destination despite sender number', () {
    expect(
      screen(mayaExpanded).state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('Maya wrong debit amount is rejected', () {
    expect(
      screen(mayaCompact.replaceFirst('200.00', '250.00')).state,
      ReceiptValidationState.invalid,
    );
  });
  test(
    'Maya wrong Destination is not overridden by matching Source/header',
    () {
      final text = mayaExpanded.replaceFirst(
        'Destination\nM***T S***\n+639990000001',
        'Destination\nOTHER PERSON\n+639198765432',
      );
      expect(screen(text).state, ReceiptValidationState.invalid);
    },
  );
  test('Maya masked Destination cannot borrow the Source number', () {
    final text =
        "Sent money\n- ₱200.00\nCompleted\nSource\nMy Wallet\n+639990000001\nDestination\nM***T S***\n+63 *** *** 0001";
    expect(screen(text).state, ReceiptValidationState.needsReview);
  });
  test('Maya no-name Destination number on next line is readable', () {
    expect(
      screen('Sent money\n-₱200.00\nCompleted\nDestination\n+639990000001')
          .state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('Unicode minus is supported for completed outgoing transfer', () {
    expect(
      screen(mayaCompact.replaceFirst('- ₱', '− ₱')).state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('Pending debit is not normalized into completed transfer amount', () {
    expect(
      screen(mayaCompact.replaceFirst('Completed', 'Pending')).state,
      ReceiptValidationState.needsReview,
    );
  });
  test('Refund debit is not normalized into outgoing transfer amount', () {
    expect(
      screen('$mayaCompact\nRefunded').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('Source-only phone never becomes a recipient', () {
    expect(
      screen(
        'Sent money\n-₱200.00\nCompleted\nSource\nMy Wallet\n+639990000001',
      ).state,
      ReceiptValidationState.needsReview,
    );
  });
  test(
    'Destination wrong number is extracted independently of expected number',
    () {
      expect(
        ReceiptClassifier()
            .classify(mayaExpanded.replaceAll('+639990000001', '+639198765432'))
            .recipientPhone,
        '09198765432',
      );
    },
  );
}
