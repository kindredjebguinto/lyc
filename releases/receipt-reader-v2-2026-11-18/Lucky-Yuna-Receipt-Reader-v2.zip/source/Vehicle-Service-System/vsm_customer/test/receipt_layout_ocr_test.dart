import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/services/receipt_text_layout.dart';
import 'package:vsm_customer/models/receipt_screening.dart';

import 'receipt_rules_test.dart' show screen;

void main() {
  const header = 'Sent money\nCompleted\n';
  const phone = '\nDestination\nTEST MERCHANT\n+639990000001';
  test(
    'column-first ML Kit lines become visual rows with correct recipient',
    () {
      final text = receiptTextInReadingOrder(const [
        ReceiptTextLine('Source', 10, 100, 80, 120),
        ReceiptTextLine('Destination', 10, 200, 90, 220),
        ReceiptTextLine('My Wallet', 200, 101, 300, 121),
        ReceiptTextLine('+63 912 345 6789', 200, 140, 340, 160),
        ReceiptTextLine('M***T S***', 200, 201, 300, 221),
        ReceiptTextLine('+639990000001', 200, 240, 330, 260),
        ReceiptTextLine('Completed', 20, 60, 120, 80),
        ReceiptTextLine('- P200.00', 20, 30, 120, 50),
        ReceiptTextLine('Sent money', 20, 0, 120, 20),
      ]);
      expect(
        text,
        contains(
          'Source My Wallet\n+63 912 345 6789\nDestination M***T S***\n+639990000001',
        ),
      );
      expect(screen(text).state, ReceiptValidationState.validForSubmission);
    },
  );
  test('split peso glyph is reunited on the same visual row', () {
    final text = receiptTextInReadingOrder(const [
      ReceiptTextLine('200.00', 70, 10, 150, 40),
      ReceiptTextLine('₱', 40, 12, 65, 38),
      ReceiptTextLine('-', 10, 13, 30, 37),
    ]);
    expect(text, '- ₱ 200.00');
    expect(
      screen('$header$text$phone').state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('overlapping boxes are not merged into one row', () {
    final text = receiptTextInReadingOrder(const [
      ReceiptTextLine('first', 0, 0, 80, 20),
      ReceiptTextLine('second', 10, 3, 90, 23),
    ]);
    expect(text, 'first\nsecond');
  });
  test('currency glyph and amount on adjacent lines', () {
    expect(
      screen('$header₱\n200.00$phone').state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('em dash and narrow no-break space from OCR', () {
    expect(
      screen('$header—\u202fP200.00$phone').state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('decimal spacing from separate OCR tokens', () {
    expect(
      screen('$header- ₱200 . 00$phone').state,
      ReceiptValidationState.validForSubmission,
    );
  });
  test('missed currency glyph needs completed outgoing context', () {
    expect(
      screen('${header}200.00$phone').state,
      ReceiptValidationState.validForSubmission,
    );
    expect(screen('200.00$phone').state, ReceiptValidationState.needsReview);
  });
  test('wrong bare decimal amount is not replaced with expected value', () {
    expect(
      screen('${header}250.00$phone').state,
      ReceiptValidationState.invalid,
    );
  });
  test('two distinct money candidates remain ambiguous', () {
    expect(
      screen('${header}200.00\n250.00$phone').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('split currency after fee heading is not the transfer amount', () {
    expect(
      screen('${header}Transfer fee\n₱\n200.00$phone').state,
      ReceiptValidationState.needsReview,
    );
  });
  test('missing recipient digits are never filled from configuration', () {
    expect(
      screen('${header}P200.00\nDestination\n+63 *** *** 0001').state,
      ReceiptValidationState.needsReview,
    );
  });
}
