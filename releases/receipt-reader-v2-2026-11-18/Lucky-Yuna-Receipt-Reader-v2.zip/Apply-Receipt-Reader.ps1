param(
    [Parameter(Mandatory=$true)][string]$ProjectRoot,
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) { throw 'ProjectRoot must be your existing Vehicle-Service-System folder.' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$changes = @()
$conflicts = @()
foreach ($entry in $manifest.files) {
    $relative = $entry.path.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $source = Join-Path (Join-Path $PSScriptRoot 'source/Vehicle-Service-System') $relative
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.after_sha256) { throw "Package file hash mismatch: $($entry.path)" }
    $target = Join-Path $ProjectRoot $relative
    if (Test-Path -LiteralPath $target) {
        $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -eq $entry.after_sha256) { continue }
        if (@($entry.accepted_before_sha256) -notcontains $actual) { $conflicts += $entry.path; continue }
    } elseif ($entry.before_sha256) { $conflicts += "$($entry.path) (expected existing file is missing)"; continue }
    $changes += [PSCustomObject]@{ Relative=$relative; Source=$source; Target=$target }
}
if ($conflicts.Count -gt 0) {
    $conflicts | ForEach-Object { Write-Host "CONFLICT: $_" -ForegroundColor Yellow }
    throw 'No files were changed. Review and merge these differences before applying this patch.'
}
Write-Host "Preflight passed. $($changes.Count) file(s) to copy."
if (-not $Apply) { Write-Host 'Check-only run. Re-run with -Apply to back up and copy source. SQL is never run by this script.'; return }
if ($changes.Count -eq 0) { Write-Host 'All source files are already present.'; return }
$backup = Join-Path (Join-Path $env:USERPROFILE 'LuckyYunaBackups') (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
# Back up all existing affected files before the first source write.
foreach ($item in $changes) {
    if (Test-Path -LiteralPath $item.Target) {
        $saved = Join-Path $backup $item.Relative
        New-Item -ItemType Directory -Force -Path (Split-Path $saved -Parent) | Out-Null
        Copy-Item -LiteralPath $item.Target -Destination $saved
    }
}
foreach ($item in $changes) {
    New-Item -ItemType Directory -Force -Path (Split-Path $item.Target -Parent) | Out-Null
    Copy-Item -LiteralPath $item.Source -Destination $item.Target -Force
}
Write-Host "Source patch applied. Backups: $backup"
Write-Host 'Receipt screening updated. Re-run on your Android phone using your working API_BASE_URL. No SQL, gateway setup or new dependencies are required.'
