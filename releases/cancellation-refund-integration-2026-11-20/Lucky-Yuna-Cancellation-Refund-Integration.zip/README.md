# Lucky Yuna Cancellation and Refund Integration

This package adds reservation creation time sorting, backend-controlled 24-hour cancellation eligibility, manual refund management, customer refund status, and gross/refund/net reporting.

## Safe installation order

1. Back up the current XAMPP project and database.
2. Merge the `Vehicle-Service-System` overlay into the current project. Do not delete unrelated files.
   The installer deliberately preserves the existing Bootstrap `.htaccess` security/access fix.
3. In phpMyAdmin, select the active Lucky Yuna database and import only:
   `vehicle-service-management/database/migrations/20261120_cancellation_refunds.sql`.
4. Confirm that `reservation_refunds` and `reservation_refund_events` exist and `reservations` has the three new cancellation columns.
5. Restart Apache, hard-refresh the Admin site, then run Flutter using the existing physical-phone command.

The migration is additive. It does not delete bookings, payments, or the legacy refund fields. Do not import `lyc_database.sql` over an existing database.

## Required test sequence

- Create a new future appointment and verify Admin shows `Date & Time Reserved` oldest-first.
- Test cancellation more than 24 hours, exactly 24 hours, and 23 hours 59 minutes before appointment.
- Verify unverified payment creates no refund payout.
- Verify paid eligible cancellation appears in Admin → Refunds.
- Confirm Pending → Processing → Refunded requires a successful-transfer checkbox and GCash reference.
- Verify duplicate cancellation and duplicate refund attempts are rejected.
- Verify Reports separates gross verified collections, completed refunds, net collections, and pending obligations.

No customer website UI was changed. No GCash gateway was added.
