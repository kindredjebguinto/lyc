[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = 'Stop'
$sourceRoot = Join-Path $PSScriptRoot 'Vehicle-Service-System'
$ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRoot)

$baselineHashes = @{
    'vehicle-service-management-admin/dashboard.php' = 'cfb64b53262b2845c056d6b74e65c7785376623bcbed2a4eebb9205740cc61d5'
    'vehicle-service-management-admin/includes/admin_auth.php' = 'e2b245e6eb9e0a686fef9997021810d677e3463cd859ee1921d46d92171915e9'
    'vehicle-service-management-admin/includes/admin_header.php' = '2f7a991323517deeedb1c914fa531d46a0fb0d9121a690407ebe5257542741ee'
    'vehicle-service-management-admin/payment_view.php' = 'a594ca120a136e80ddabc78f414c8eb5b62738ab20665486cbbd37740e624096'
    'vehicle-service-management-admin/report_export.php' = '87fd8dab30a0e456ba4d081a806adf6d6968f8ab783385eb1c17d3ad82587beb'
    'vehicle-service-management-admin/reports.php' = 'b022dbf752152008ded2c7339f4ad1b5e7b262de11dc600600b718c76abdd156'
    'vehicle-service-management-admin/reservations.php' = 'a49da4ec5e58c3c22c82f0250a08fe816cb298d5c9ea1973c5ac0e592a86aecf'
    'vehicle-service-management/api/reservations/cancel.php' = 'b51d6fe03c1f7f8a1088c5507fc282abaf85b67a46d371713c5cb633d51ae3ce'
    'vehicle-service-management/api/reservations/list.php' = '36e1781009767deffcfa1eadee896e3d936a0c3a7606be7524e76c85ceae30ca'
    'vsm_customer/lib/api/api_config.dart' = '7156713cf8400edfa429149a94ccdaf3274c4bbd36bf5dea24459166bdcbd03c'
    'vsm_customer/lib/api/customer_api.dart' = '4b2b4d348b244d5b4aa7a9626e256d13730ad3d388bdf94a17c47a739504d182'
    'vsm_customer/lib/screens/reservations/reservation_details_screen.dart' = '35b57cf9bf233aeec58d28beb70d65a5ac1215b5862b15c0e0966bc86e571ed1'
}

if (-not (Test-Path -LiteralPath $sourceRoot -PathType Container)) {
    throw "Package source is missing: $sourceRoot"
}
if (-not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) {
    throw "Project root does not exist: $ProjectRoot"
}
foreach ($required in @('vehicle-service-management', 'vehicle-service-management-admin', 'vsm_customer')) {
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot $required) -PathType Container)) {
        throw "Wrong project root. Missing folder: $required"
    }
}

$files = Get-ChildItem -LiteralPath $sourceRoot -File -Recurse
if ($files.Count -eq 0) { throw 'The package contains no integration files.' }

# Validate PHP before touching the project when XAMPP PHP is available.
$php = 'C:\xampp\php\php.exe'
if (Test-Path -LiteralPath $php -PathType Leaf) {
    foreach ($file in $files | Where-Object Extension -eq '.php') {
        & $php -l $file.FullName | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "PHP syntax validation failed: $($file.FullName)" }
    }
}

$conflicts = New-Object System.Collections.Generic.List[string]
foreach ($file in $files) {
    $relative = $file.FullName.Substring($sourceRoot.Length).TrimStart('\', '/').Replace('\', '/')
    $target = Join-Path $ProjectRoot ($relative.Replace('/', '\'))
    $sourceHash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $targetHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        $baseline = $baselineHashes[$relative]
        if ($targetHash -ne $sourceHash -and (!$baseline -or $targetHash -ne $baseline)) {
            $conflicts.Add($relative)
        }
    }
}

if ($conflicts.Count -gt 0) {
    Write-Host 'CONFLICT: these local files differ from both the expected baseline and this package:' -ForegroundColor Red
    $conflicts | ForEach-Object { Write-Host " - $_" -ForegroundColor Red }
    throw 'No files were changed. Review and merge the conflicts first.'
}

$backupRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) ('LuckyYuna-Backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$changed = 0
foreach ($file in $files) {
    $relative = $file.FullName.Substring($sourceRoot.Length).TrimStart('\', '/').Replace('\', '/')
    $target = Join-Path $ProjectRoot ($relative.Replace('/', '\'))
    $sourceHash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()

    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $targetHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($targetHash -eq $sourceHash) { continue }
        $backupFile = Join-Path $backupRoot ($relative.Replace('/', '\'))
        New-Item -ItemType Directory -Path (Split-Path $backupFile -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $backupFile -Force
    }

    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    $copiedHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($copiedHash -ne $sourceHash) { throw "Copy verification failed: $relative" }
    $changed++
}

Write-Host "Merge complete. Files changed: $changed" -ForegroundColor Green
if (Test-Path -LiteralPath $backupRoot) {
    Write-Host "Backup saved to: $backupRoot"
} else {
    Write-Host 'No backup was needed because all target files were already current or new.'
}
Write-Host 'Database was NOT changed.' -ForegroundColor Yellow
Write-Host ('Next: back up the active database, then import: ' + (Join-Path $ProjectRoot 'vehicle-service-management\database\migrations\20261120_cancellation_refunds.sql'))
