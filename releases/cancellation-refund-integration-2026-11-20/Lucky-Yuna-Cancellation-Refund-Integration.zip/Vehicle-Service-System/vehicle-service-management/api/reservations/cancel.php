<?php
require_once __DIR__.'/../config/bootstrap.php';
require_once __DIR__.'/../../includes/cancellation_refunds.php';
cancellationApplyManilaTime($conn);
requireMethod('POST');
$user=requireCustomer($conn);$userId=(int)$user['id'];$data=jsonInput();$id=(int)($data['reservation_id']??0);
$reason=trim((string)($data['reason']??''));$details=trim((string)($data['details']??''));
$reasons=['Service no longer needed','Change of mind','Schedule conflict','Price concern','Found another service provider','Vehicle unavailable','Emergency / unexpected situation','Other'];
if($reason!==''&&!in_array($reason,$reasons,true)){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Choose a valid cancellation reason.']);exit;}
if($reason==='Other'&&$details===''){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Explain the cancellation reason.']);exit;}
if(mb_strlen($details)>500){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Keep the cancellation details within 500 characters.']);exit;}
if(!cancellationRefundSchemaReady($conn)){http_response_code(503);echo json_encode(['success'=>false,'code'=>'refund_schema_required','message'=>'Cancellation is temporarily unavailable while the refund update is being installed.']);exit;}
$conn->begin_transaction();
try{
    $row=cancellationLoadForCustomer($conn,$id,$userId,true);
    if(!$row)throw new DomainException('Appointment not found.');
    cancellationAssertAllowed($row);$facts=cancellationFacts($row);
    $label=$facts['within_refund_window']
        ? ($facts['payment_verified']?'Eligible — verified fee pending refund':'Within 24-hour policy — awaiting payment verification')
        : 'Not eligible — late cancellation';
    $feeState=$facts['within_refund_window']&&$facts['payment_verified']?'Refund Requested':
        (($row['payment_status']??'')==='Paid'?'Forfeited':'Awaiting Payment');
    $reasonValue=$reason!==''?$reason:'Customer cancellation';$within=$facts['within_refund_window']?1:0;
    $stmt=$conn->prepare("UPDATE reservations SET status='Cancelled',cancellation_reason=?,cancellation_details=?,
        cancelled_at=?,cancellation_appointment_at=?,cancellation_within_refund_window=?,refund_eligibility=?,reservation_fee_status=?
        WHERE id=? AND user_id=? AND status IN ('Pending','Approved')");
    $stmt->bind_param('ssssissii',$reasonValue,$details,$facts['server_time'],$facts['appointment_at'],$within,$label,$feeState,$id,$userId);
    $stmt->execute();if($stmt->affected_rows!==1)throw new DomainException('This appointment was already changed. Refresh and try again.');$stmt->close();
    $refundId=cancellationCreateRefund($conn,$row,$facts,$id);
    $title='Appointment cancelled';$message=cancellationCustomerMessage($facts);
    $notice=$conn->prepare("INSERT INTO notifications(user_id,title,message,link_type,link_id) VALUES(?,?,?,'reservation',?)");
    $notice->bind_param('issi',$userId,$title,$message,$id);$notice->execute();$notice->close();
    $conn->commit();
    echo json_encode(['success'=>true,'message'=>$message,'status'=>'Cancelled','refund_status'=>$refundId?'Pending Refund':
        ($facts['within_refund_window']?'Awaiting Payment Verification':'Not Eligible'),
        'refund_deadline'=>$refundId?$facts['refund_deadline']:null]);
}catch(DomainException $e){$conn->rollback();http_response_code(409);echo json_encode(['success'=>false,'message'=>$e->getMessage()]);}
catch(Throwable $e){$conn->rollback();http_response_code(500);echo json_encode(['success'=>false,'message'=>'Unable to cancel this appointment. Please try again.']);}
