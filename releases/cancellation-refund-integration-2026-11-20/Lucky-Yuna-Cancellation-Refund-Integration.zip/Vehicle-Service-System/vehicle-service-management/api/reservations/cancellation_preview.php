<?php
require_once __DIR__.'/../config/bootstrap.php';
require_once __DIR__.'/../../includes/cancellation_refunds.php';
cancellationApplyManilaTime($conn);
requireMethod('POST');
$user=requireCustomer($conn);$data=jsonInput();$id=(int)($data['reservation_id']??0);
if(!cancellationRefundSchemaReady($conn)){http_response_code(503);echo json_encode(['success'=>false,'code'=>'refund_schema_required','message'=>'Cancellation is temporarily unavailable while the refund update is being installed.']);exit;}
$row=cancellationLoadForCustomer($conn,$id,(int)$user['id']);
if(!$row){http_response_code(404);echo json_encode(['success'=>false,'message'=>'Appointment not found.']);exit;}
try{cancellationAssertAllowed($row);$facts=cancellationFacts($row);}catch(DomainException $e){http_response_code(409);echo json_encode(['success'=>false,'message'=>$e->getMessage()]);exit;}
$mode=$facts['within_refund_window']?'within_window':'late';if(!$facts['payment_verified'])$mode='payment_unverified';
echo json_encode(['success'=>true,'mode'=>$mode,'within_refund_window'=>$facts['within_refund_window'],
    'payment_verified'=>$facts['payment_verified'],'refundable_amount'=>$facts['refundable_amount'],
    'appointment_at'=>$facts['appointment_at'],'server_time'=>$facts['server_time'],
    'refund_deadline'=>$facts['within_refund_window']?$facts['refund_deadline']:null]);
