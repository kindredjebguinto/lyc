<?php

const LYC_REFUND_LIMIT_CENTS = 20000;

function cancellationApplyManilaTime(mysqli $conn): void
{
    date_default_timezone_set('Asia/Manila');
    $conn->query("SET time_zone = '+08:00'");
}

function cancellationRefundSchemaReady(mysqli $conn): bool
{
    foreach (['reservation_refunds', 'reservation_refund_events'] as $table) {
        $stmt = $conn->prepare('SELECT COUNT(*) n FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
        $stmt->bind_param('s', $table); $stmt->execute();
        $ready = (int)$stmt->get_result()->fetch_assoc()['n'] === 1; $stmt->close();
        if (!$ready) return false;
    }
    foreach (['cancelled_at','cancellation_appointment_at','cancellation_within_refund_window'] as $column) {
        $stmt=$conn->prepare('SELECT COUNT(*) n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=\'reservations\' AND COLUMN_NAME=?');
        $stmt->bind_param('s',$column);$stmt->execute();$ready=(int)$stmt->get_result()->fetch_assoc()['n']===1;$stmt->close();
        if(!$ready)return false;
    }
    return true;
}

function cancellationManilaNow(): DateTimeImmutable
{
    return new DateTimeImmutable('now', new DateTimeZone('Asia/Manila'));
}

function cancellationFacts(array $row, ?DateTimeImmutable $clock = null): array
{
    $timezone = new DateTimeZone('Asia/Manila');
    $appointment = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $row['appointment_date'].' '.$row['appointment_time'], $timezone);
    if (!$appointment) throw new DomainException('The appointment schedule is invalid.');
    $now = ($clock ?? cancellationManilaNow())->setTimezone($timezone);
    $seconds = $appointment->getTimestamp() - $now->getTimestamp();
    $within = $seconds >= 86400;
    $paid = ($row['payment_status'] ?? '') === 'Paid'
        && stripos((string)($row['received_by'] ?? ''), 'sandbox') === false;
    $amount = (float)($row['amount_received'] ?? $row['payment_amount'] ?? 0);
    $refundable = min(200.00, max(0.00, $amount));
    $activeRefund = !empty($row['refund_id']) && ($row['refund_record_status'] ?? '') !== 'Refund Failed';
    $legacyRefunded = ($row['legacy_refund_status'] ?? '') === 'Refunded';
    return [
        'server_time' => $now->format('Y-m-d H:i:s'), 'appointment_at' => $appointment->format('Y-m-d H:i:s'),
        'seconds_before_appointment' => $seconds, 'within_refund_window' => $within,
        'payment_verified' => $paid, 'refundable_amount' => $paid ? $refundable : 0.00,
        'active_refund_exists' => $activeRefund, 'already_refunded' => $legacyRefunded || ($row['refund_record_status'] ?? '') === 'Refunded',
        'refund_deadline' => $now->modify('+24 hours')->format('Y-m-d H:i:s'),
    ];
}

function cancellationLoadForCustomer(mysqli $conn, int $reservationId, int $userId, bool $lock = false): ?array
{
    $suffix = $lock ? ' FOR UPDATE' : '';
    $stmt = $conn->prepare("SELECT r.id,r.status,r.appointment_date,r.appointment_time,r.checked_in_at,
        r.reservation_fee_payment_id,p.status payment_status,p.amount payment_amount,p.amount_received,
        p.received_by,p.refund_status legacy_refund_status,rf.id refund_id,rf.status refund_record_status
        FROM reservations r LEFT JOIN payments p ON p.id=r.reservation_fee_payment_id AND p.payment_type='Reservation Fee'
        LEFT JOIN reservation_refunds rf ON rf.payment_id=p.id WHERE r.id=? AND r.user_id=? LIMIT 1$suffix");
    $stmt->bind_param('ii', $reservationId, $userId); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close(); return $row ?: null;
}

function cancellationAssertAllowed(array $row): void
{
    if (!in_array($row['status'], ['Pending','Approved'], true)) throw new DomainException('Only pending or approved appointments can be cancelled.');
    if (!empty($row['checked_in_at'])) throw new DomainException('This vehicle has already been checked in. Contact Lucky Yuna for assistance.');
}

function cancellationCreateRefund(mysqli $conn, array $row, array $facts, int $reservationId): ?int
{
    if (!$facts['within_refund_window'] || !$facts['payment_verified'] || $facts['refundable_amount'] <= 0
        || $facts['active_refund_exists'] || $facts['already_refunded']) return null;
    $paymentId = (int)$row['reservation_fee_payment_id']; $amount = $facts['refundable_amount'];
    $key = hash('sha256', "standard-refund:$reservationId:$paymentId");
    $stmt = $conn->prepare("INSERT INTO reservation_refunds
        (reservation_id,payment_id,amount,status,cancellation_at,appointment_at,refund_deadline,idempotency_key)
        VALUES(?,?,?,'Pending Refund',?,?,?,?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)");
    $stmt->bind_param('iidssss', $reservationId, $paymentId, $amount, $facts['server_time'], $facts['appointment_at'], $facts['refund_deadline'], $key);
    $stmt->execute(); $refundId = (int)$stmt->insert_id; $stmt->close();
    if (!$refundId) { $lookup=$conn->prepare('SELECT id FROM reservation_refunds WHERE payment_id=?');$lookup->bind_param('i',$paymentId);$lookup->execute();$refundId=(int)$lookup->get_result()->fetch_assoc()['id'];$lookup->close(); }
    $eventKey=hash('sha256',"created:$refundId");
    $event=$conn->prepare("INSERT IGNORE INTO reservation_refund_events (refund_id,to_status,actor_type,details,request_key)
        VALUES(?,'Pending Refund','System','Eligible cancellation refund created.',?)");
    $event->bind_param('is',$refundId,$eventKey);$event->execute();$event->close();
    $staffMessage='Refund #'.$refundId.' is pending and due by '.$facts['refund_deadline'].'.';
    $staff=$conn->prepare("INSERT INTO notifications(user_id,title,message,link_type,link_id)
        SELECT id,'Refund requires processing',?,'reservation',? FROM users WHERE role='staff' AND staff_level IN ('Manager','Cashier')");
    $staff->bind_param('si',$staffMessage,$reservationId);$staff->execute();$staff->close();
    $stmt=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE id=? AND refund_status<>'Refunded'");
    $stmt->bind_param('i',$paymentId);$stmt->execute();$stmt->close(); return $refundId;
}

function cancellationCustomerMessage(array $facts): string
{
    if (!$facts['within_refund_window']) return 'Your appointment was cancelled outside the 24-hour refund window. The reservation fee is not automatically refundable.';
    if (!$facts['payment_verified']) return 'Your appointment was cancelled. The reservation payment is not yet verified; eligibility will be checked using this cancellation time if payment is later confirmed.';
    return 'Your appointment was cancelled. Your verified reservation-fee refund is pending and must be processed within 24 hours.';
}

function cancellationCreateRefundAfterPaymentVerification(mysqli $conn, int $paymentId): ?int
{
    if (!cancellationRefundSchemaReady($conn)) return null;
    $stmt=$conn->prepare("SELECT r.id,r.status,r.appointment_date,r.appointment_time,r.cancelled_at,
        r.cancellation_appointment_at,r.cancellation_within_refund_window,r.reservation_fee_payment_id,
        p.status payment_status,p.amount payment_amount,p.amount_received,p.received_by,p.refund_status legacy_refund_status,
        rf.id refund_id,rf.status refund_record_status
        FROM payments p JOIN reservations r ON r.id=p.reservation_id
        LEFT JOIN reservation_refunds rf ON rf.payment_id=p.id
        WHERE p.id=? AND p.payment_type='Reservation Fee' LIMIT 1 FOR UPDATE");
    $stmt->bind_param('i',$paymentId);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    if(!$row||$row['status']!=='Cancelled'||empty($row['cancelled_at'])||(int)$row['cancellation_within_refund_window']!==1)return null;
    $cancelled=new DateTimeImmutable($row['cancelled_at'],new DateTimeZone('Asia/Manila'));
    $appointment=new DateTimeImmutable($row['cancellation_appointment_at']?:$row['appointment_date'].' '.$row['appointment_time'],new DateTimeZone('Asia/Manila'));
    $paid=$row['payment_status']==='Paid'&&stripos((string)$row['received_by'],'sandbox')===false;
    $amount=min(200.00,max(0.00,(float)($row['amount_received']??$row['payment_amount'])));
    $facts=['server_time'=>$cancelled->format('Y-m-d H:i:s'),'appointment_at'=>$appointment->format('Y-m-d H:i:s'),
        'within_refund_window'=>true,'payment_verified'=>$paid,'refundable_amount'=>$paid?$amount:0.00,
        'active_refund_exists'=>!empty($row['refund_id'])&&$row['refund_record_status']!=='Refund Failed',
        'already_refunded'=>$row['legacy_refund_status']==='Refunded'||$row['refund_record_status']==='Refunded',
        'refund_deadline'=>$cancelled->modify('+24 hours')->format('Y-m-d H:i:s')];
    $refundId=cancellationCreateRefund($conn,$row,$facts,(int)$row['id']);
    if($refundId){$stmt=$conn->prepare("UPDATE reservations SET reservation_fee_status='Refund Requested' WHERE id=?");$stmt->bind_param('i',$row['id']);$stmt->execute();$stmt->close();}
    return $refundId;
}
