-- Lucky Yuna cancellation/refund workflow. Back up the database before import.
-- This migration is additive and keeps the legacy payments.refund_* fields.

ALTER TABLE reservations
    ADD COLUMN IF NOT EXISTS cancelled_at DATETIME NULL AFTER cancellation_details,
    ADD COLUMN IF NOT EXISTS cancellation_appointment_at DATETIME NULL AFTER cancelled_at,
    ADD COLUMN IF NOT EXISTS cancellation_within_refund_window TINYINT(1) NULL AFTER cancellation_appointment_at,
    ADD INDEX IF NOT EXISTS idx_reservation_created (created_at, id),
    ADD INDEX IF NOT EXISTS idx_reservation_cancelled (cancelled_at, id);

CREATE TABLE IF NOT EXISTS reservation_refunds (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    reservation_id INT NOT NULL,
    payment_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending Refund','Processing','Refunded','Refund Failed') NOT NULL DEFAULT 'Pending Refund',
    cancellation_at DATETIME NOT NULL,
    appointment_at DATETIME NOT NULL,
    refund_deadline DATETIME NOT NULL,
    transaction_reference VARCHAR(100) NULL,
    processing_started_at DATETIME NULL,
    completed_at DATETIME NULL,
    processed_by_user_id INT NULL,
    processed_by_name VARCHAR(100) NULL,
    failure_reason VARCHAR(500) NULL,
    notes VARCHAR(500) NULL,
    is_exception TINYINT(1) NOT NULL DEFAULT 0,
    exception_reason VARCHAR(500) NULL,
    exception_approved_by_user_id INT NULL,
    idempotency_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_refund_payment (payment_id),
    UNIQUE KEY uq_refund_reservation (reservation_id),
    UNIQUE KEY uq_refund_idempotency (idempotency_key),
    KEY idx_refund_queue (status, refund_deadline),
    CONSTRAINT fk_refund_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(id),
    CONSTRAINT fk_refund_payment FOREIGN KEY (payment_id) REFERENCES payments(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS reservation_refund_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    refund_id BIGINT UNSIGNED NOT NULL,
    from_status VARCHAR(32) NULL,
    to_status VARCHAR(32) NOT NULL,
    actor_type ENUM('System','Customer','Admin') NOT NULL,
    actor_id INT NULL,
    actor_name VARCHAR(100) NULL,
    details VARCHAR(500) NULL,
    request_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_refund_event_request (refund_id, request_key),
    KEY idx_refund_event_time (refund_id, created_at),
    CONSTRAINT fk_refund_event_refund FOREIGN KEY (refund_id) REFERENCES reservation_refunds(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
