<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/../vehicle-service-management/includes/cancellation_refunds.php';
cancellationApplyManilaTime($conn);
if(!cancellationRefundSchemaReady($conn))adminDeny('Import the approved cancellation/refund migration before opening this queue.');
$status=trim($_GET['status']??'');$allowed=['Pending Refund','Processing','Refunded','Refund Failed'];
$where=$status!==''&&in_array($status,$allowed,true)?' WHERE rf.status=?':'';
$sql="SELECT rf.*,r.reference_number booking_reference,c.fullname customer_name,
    p.reference_number payment_reference,p.payment_method
    FROM reservation_refunds rf JOIN reservations r ON r.id=rf.reservation_id
    JOIN payments p ON p.id=rf.payment_id LEFT JOIN customers c ON c.id=r.customer_id$where
    ORDER BY CASE rf.status WHEN 'Pending Refund' THEN 0 WHEN 'Processing' THEN 1 WHEN 'Refund Failed' THEN 2 ELSE 3 END,
    rf.refund_deadline ASC,rf.id ASC";
$stmt=$conn->prepare($sql);if($where!=='')$stmt->bind_param('s',$status);$stmt->execute();$refunds=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
$counts=$conn->query("SELECT status,COUNT(*) n FROM reservation_refunds GROUP BY status")->fetch_all(MYSQLI_ASSOC);
$byStatus=[];foreach($counts as $count)$byStatus[$count['status']]=(int)$count['n'];
include __DIR__.'/includes/admin_header.php';
?>
<?php if(!empty($_SESSION['admin_flash'])):$flash=$_SESSION['admin_flash'];unset($_SESSION['admin_flash']);?><div class="alert alert-<?=adminH($flash['type'])?>"><?=adminH($flash['message'])?></div><?php endif;?>
<div class="page-heading"><div><span class="eyebrow">MANUAL GCASH REFUNDS</span><h1>Refunds</h1><p>Complete only after confirming the actual transfer. Pending and overdue obligations remain visible.</p></div></div>
<nav class="queue-tabs" aria-label="Refund filters"><a href="refunds.php" <?= $status===''?'aria-current="page"':'' ?>>All</a><?php foreach($allowed as $option):?><a href="?status=<?=urlencode($option)?>" <?= $status===$option?'aria-current="page"':'' ?>><?=adminH($option)?> (<?=($byStatus[$option]??0)?>)</a><?php endforeach;?></nav>
<div class="payment-queue-list"><?php foreach($refunds as $refund):$deadline=strtotime($refund['refund_deadline']);$overdue=!in_array($refund['status'],['Refunded'],true)&&$deadline<time();$remaining=$deadline-time();?>
<article class="clean-card payment-queue-card"><div><span class="eyebrow"><?=adminH($refund['status'])?></span><h2 class="h5 mt-2"><?=adminH($refund['customer_name']?:'Customer')?> · <?=adminH($refund['booking_reference']?:'#'.$refund['reservation_id'])?></h2>
<p>Appointment: <?=adminH(date('M j, Y — g:i A',strtotime($refund['appointment_at'])))?><br>Cancelled: <?=adminH(date('M j, Y — g:i A',strtotime($refund['cancellation_at'])))?><br>Original payment: <?=adminH($refund['payment_reference']?:'#'.$refund['payment_id'])?></p>
<p class="<?= $overdue?'text-danger fw-bold':'text-muted' ?>">Deadline: <?=adminH(date('M j, Y — g:i A',$deadline))?> · <?= $overdue?'OVERDUE':($refund['status']==='Refunded'?'Completed':max(0,(int)ceil($remaining/3600)).' hour(s) remaining') ?></p>
<?php if($refund['transaction_reference']):?><p>GCash refund reference: <?=adminH($refund['transaction_reference'])?></p><?php endif;?>
<?php if($refund['failure_reason']):?><div class="alert alert-danger"><?=adminH($refund['failure_reason'])?></div><?php endif;?></div>
<div><div class="amount">₱<?=number_format((float)$refund['amount'],2)?></div>
<?php if($refund['status']==='Pending Refund'):?><form method="post" action="refund_action.php"><input type="hidden" name="refund_id" value="<?=(int)$refund['id']?>"><button class="btn btn-primary" name="action" value="start">Start Processing</button></form>
<?php elseif($refund['status']==='Processing'):?><form method="post" action="refund_action.php" class="mt-2"><input type="hidden" name="refund_id" value="<?=(int)$refund['id']?>"><input class="form-control mb-2" name="transaction_reference" maxlength="100" required placeholder="GCash refund reference"><label class="form-check mb-2"><input class="form-check-input" type="checkbox" name="transfer_confirmed" value="1" required><span class="form-check-label">I confirmed the transfer succeeded.</span></label><button class="btn btn-success w-100" name="action" value="complete">Mark Refunded</button><textarea class="form-control mt-3" name="failure_reason" maxlength="500" placeholder="Failure reason"></textarea><button class="btn btn-outline-danger w-100 mt-2" name="action" value="fail" formnovalidate>Record Failed Attempt</button></form>
<?php elseif($refund['status']==='Refund Failed'):?><form method="post" action="refund_action.php"><input type="hidden" name="refund_id" value="<?=(int)$refund['id']?>"><textarea class="form-control mb-2" name="reconciliation_note" required maxlength="500" placeholder="Describe reconciliation before retry"></textarea><button class="btn btn-warning" name="action" value="retry">Reconcile &amp; Retry</button></form><?php endif;?></div></article>
<?php endforeach;if(!$refunds):?><div class="clean-card workspace-empty">No refunds match this filter.</div><?php endif;?></div>
<?php include __DIR__.'/includes/admin_footer.php';?>
