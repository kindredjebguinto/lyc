import 'package:flutter/material.dart';

import '../../api/customer_api.dart';
import '../../widgets/app_widgets.dart';
import '../payments/booking_payment_screen.dart';
import '../quotations/job_quotation_screen.dart';

class ReservationDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> reservation;

  const ReservationDetailsScreen({required this.reservation, super.key});

  @override
  State<ReservationDetailsScreen> createState() =>
      _ReservationDetailsScreenState();
}

class _ReservationDetailsScreenState extends State<ReservationDetailsScreen> {
  late Map<String, dynamic> item;
  Map<String, dynamic>? legacyQuotation;
  bool loadingQuote = true;
  bool refreshing = false;
  bool cancelling = false;

  int get id => int.parse(item['id'].toString());
  String get status => item['status']?.toString() ?? '';
  Map<String, dynamic>? get workflow => serviceWorkflowFor(item);
  Map<String, dynamic>? get bill => workflowObject(workflow?['bill']);
  Map<String, dynamic>? get repairQuote =>
      workflowObject(workflow?['quotation']);

  @override
  void initState() {
    super.initState();
    item = Map<String, dynamic>.from(widget.reservation);
    _refreshBooking();
  }

  Future<void> _refreshBooking() async {
    if (refreshing) return;
    refreshing = true;
    try {
      try {
        final reservations = await CustomerApi.reservations();
        if (!mounted) return;
        for (final reservation in reservations) {
          if (reservation['id'].toString() == id.toString()) {
            setState(() => item = Map<String, dynamic>.from(reservation));
            break;
          }
        }
      } catch (_) {
        // Keep the booking already loaded if the refresh is interrupted.
      }

      if (mounted && workflow == null) {
        final quotation = await CustomerApi.quotation(id);
        if (mounted) setState(() => legacyQuotation = quotation);
      }
    } catch (_) {
      // A quotation refresh can be retried from the booking.
    } finally {
      refreshing = false;
      if (mounted && loadingQuote) setState(() => loadingQuote = false);
    }
  }

  Future<void> _cancel() async {
    const reasons = [
      'Service no longer needed',
      'Change of mind',
      'Schedule conflict',
      'Price concern',
      'Found another service provider',
      'Vehicle unavailable',
      'Emergency / unexpected situation',
      'Other',
    ];
    String? reason;
    var details = '';
    if (cancelling) return;
    setState(() => cancelling = true);
    try {
      final preview = await CustomerApi.cancellationPreview(id);
      if (preview['success'] != true) {
        throw Exception(
          preview['message'] ?? 'Unable to check cancellation eligibility.',
        );
      }
      if (!mounted) return;
      final withinWindow = preview['within_refund_window'] == true;
      final paymentVerified = preview['payment_verified'] == true;
      final policyMessage = withinWindow && paymentVerified
          ? 'Dahil nag-cancel ka nang hindi bababa sa 24 oras bago ang iyong appointment, eligible kang maibalik ang buong ₱200 reservation fee dahil verified ang iyong payment.\n\nAng iyong refund ay ipoproseso sa loob ng 24 oras pagkatapos makumpirma ang cancellation.'
          : withinWindow
          ? 'Nasa loob ka ng 24-hour cancellation policy, ngunit hindi pa verified ang reservation payment. Kapag nakumpirmang natanggap ang payment, muling susuriin ang refund gamit ang oras ng cancellation na ito.'
          : 'Wala nang 24 oras bago ang iyong nakatakdang appointment. Ayon sa cancellation policy ng Lucky Yuna, hindi na eligible sa automatic refund ang iyong ₱200 reservation fee.';
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Cancel Appointment'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Sigurado ka bang gusto mong kanselahin ang iyong appointment?',
                  ),
                  const SizedBox(height: 12),
                  Text(policyMessage),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: reason,
                    decoration: const InputDecoration(
                      labelText: 'Cancellation reason (optional)',
                      border: OutlineInputBorder(),
                    ),
                    items: reasons
                        .map(
                          (value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ),
                        )
                        .toList(),
                    onChanged: (selected) =>
                        setDialogState(() => reason = selected),
                  ),
                  if (reason == 'Other')
                    TextField(
                      maxLines: 2,
                      onChanged: (value) =>
                          setDialogState(() => details = value),
                      decoration: const InputDecoration(
                        labelText: 'Please specify',
                        border: OutlineInputBorder(),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Keep Appointment'),
              ),
              FilledButton(
                onPressed: reason == 'Other' && details.trim().isEmpty
                    ? null
                    : () => Navigator.pop(dialogContext, true),
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                child: Text(
                  withinWindow
                      ? 'Confirm Cancellation'
                      : 'Cancel Without Refund',
                ),
              ),
            ],
          ),
        ),
      );
      if (confirmed != true || !mounted) return;
      final result = await CustomerApi.cancelReservation(
        id,
        reason: reason ?? '',
        details: reason == 'Other' ? details.trim() : '',
      );
      if (!mounted) return;
      final cancelled = result['success'] == true;
      final message =
          result['message']?.toString() ??
          (cancelled
              ? 'Appointment cancelled.'
              : 'Unable to cancel this appointment.');
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(message)));
      if (cancelled) {
        final currentWorkflow = workflow;
        setState(() {
          item['status'] = 'Cancelled';
          item['refund_status'] = result['refund_status'];
          item['refund_deadline'] = result['refund_deadline'];
          if (currentWorkflow != null) {
            item['service_workflow'] = {
              ...currentWorkflow,
              'reservation_status': 'Cancelled',
              'work_status': 'Cancelled',
            };
          }
        });
      }
      await _refreshBooking();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error.toString().replaceFirst('Exception: ', '')),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => cancelling = false);
    }
  }

  String _refundStatusText() {
    final status = item['refund_status']?.toString() ?? '';
    final deadline = item['refund_deadline']?.toString();
    final message = switch (status) {
      'Pending Refund' => 'Nakumpirma na ang cancellation ng iyong appointment. Nakapila na para sa pagproseso ang iyong ₱200 refund.',
      'Processing' => 'Kasalukuyang pinoproseso ang iyong ₱200 refund.',
      'Refunded' => 'Matagumpay nang naibalik ang iyong ₱200 reservation fee.',
      'Refund Failed' => 'Hindi matagumpay ang pagproseso ng iyong refund. Mangyaring makipag-ugnayan sa Lucky Yuna para sa tulong.',
      'Not Eligible' => 'Ang iyong appointment ay nakansela nang wala na sa pinapayagang 24-hour refund window.',
      'Awaiting Payment Verification' => 'Kinansela ang appointment sa loob ng policy window. Hinihintay pa ang verification ng reservation payment.',
      _ => status,
    };
    return deadline == null || deadline.isEmpty
        ? message
        : '$message\nRefund deadline: $deadline';
  }

  @override
  Widget build(BuildContext context) {
    final serviceWorkflow = workflow;
    final feeId = int.tryParse(
      item['reservation_fee_payment_id']?.toString() ?? '',
    );
    return Scaffold(
      appBar: AppBar(title: const Text('Booking Details')),
      body: RefreshIndicator(
        onRefresh: _refreshBooking,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            _overview(serviceWorkflow),
            const SizedBox(height: 12),
            _nextAction(serviceWorkflow),
            const SizedBox(height: 12),
            _section(
              item['reservation_fee_status'] == 'Not Required'
                  ? 'Walk-in · no reservation fee'
                  : '₱200 Reservation Fee',
              Icons.verified_outlined,
              item['reservation_fee_status']?.toString() ?? 'Awaiting Payment',
              feeId == null ? null : () => _viewPayment(feeId),
            ),
            if (item['refund_status'] != null)
              _section(
                'Refund Status',
                Icons.currency_exchange,
                _refundStatusText(),
                null,
              ),
            if (serviceWorkflow != null) ...[
              ..._workflowSections(serviceWorkflow),
              _finalBillSection(),
            ] else ...[
              _section(
                'Final Job Quotation',
                Icons.request_quote_outlined,
                loadingQuote
                    ? 'Checking quotation…'
                    : legacyQuotation == null
                    ? 'Not issued yet'
                    : '${money(legacyQuotation!['grand_total'])} • ${legacyQuotation!['status']}',
                legacyQuotation == null ? null : _openQuotation,
              ),
              _section(
                'Payment & Receipt',
                Icons.payments_outlined,
                item['payment_status'] == null
                    ? 'Available after quotation acceptance'
                    : '${money(item['payment_amount'])} • ${item['payment_status']}',
                bookingFinalPaymentId(item) == null ? null : _openPayment,
              ),
            ],
            if ((item['diagnosis'] ?? '').toString().isNotEmpty ||
                (item['work_performed'] ?? '').toString().isNotEmpty)
              _serviceReport(),
            if (status == 'Pending' || status == 'Approved')
              TextButton.icon(
                onPressed: cancelling ? null : _cancel,
                icon: const Icon(Icons.cancel_outlined),
                label: Text(
                  cancelling ? 'Checking cancellation…' : 'Cancel Appointment',
                ),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
              ),
            if (status == 'Completed')
              FilledButton.icon(
                onPressed: _feedback,
                icon: const Icon(Icons.star_outline),
                label: const Text('RATE THIS SERVICE'),
              ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _overview(Map<String, dynamic>? serviceWorkflow) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${item['brand'] ?? ''} ${item['model'] ?? ''}',
                    style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Flexible(child: StatusChip(bookingStatus(item))),
              ],
            ),
            Text(
              item['plate_number']?.toString() ?? '',
              style: TextStyle(color: Colors.grey.shade600),
            ),
            if (serviceWorkflow != null)
              ServiceWorkflowIndicators(serviceWorkflow),
            const SizedBox(height: 12),
            _row(
              Icons.calendar_today,
              '${item['appointment_date'] ?? ''} • ${item['appointment_time'] ?? ''}',
            ),
            if ((item['original_appointment_at'] ?? '').toString().isNotEmpty)
              _row(
                Icons.history,
                'Original booking: ${item['original_appointment_at']} (Manila time)',
              ),
            if ((item['expected_finish_at'] ?? '').toString().isNotEmpty)
              _row(
                Icons.update,
                'Updated expected finish: ${item['expected_finish_at']} (Manila time)',
              ),
            if (serviceWorkflow == null)
              _row(
                Icons.build_outlined,
                item['service_type']?.toString() ?? '',
              ),
            if ((item['mechanic_name'] ?? '').toString().isNotEmpty)
              _row(Icons.engineering, 'Mechanic: ${item['mechanic_name']}'),
          ],
        ),
      ),
    );
  }

  List<Widget> _workflowSections(Map<String, dynamic> serviceWorkflow) {
    final originals = workflowRows(serviceWorkflow['original_services']);
    final authorizedRepairs = workflowRows(
      serviceWorkflow['additional_repairs'],
    ).where((task) => task['decision'] == 'Accepted');
    final advisories = workflowRows(serviceWorkflow['safety_advisories']);
    final holds = workflowRows(serviceWorkflow['service_holds']);
    final tasks = {
      for (final task in [...originals, ...authorizedRepairs])
        task['id'].toString(): task,
    };
    final totals = workflowObject(serviceWorkflow['totals']);
    final reference =
        serviceWorkflow['booking_reference'] ?? item['reference_number'];
    final quote = repairQuote;

    return [
      if (quote != null)
        _section(
          'Additional Repair Quotation',
          Icons.request_quote_outlined,
          'Revision ${quote['version']} • ${quote['decision_status']}',
          _openQuotation,
        ),
      _detailsCard('Original Booked Services', [
        if (reference != null) _info('Booking reference', reference.toString()),
        if (serviceWorkflow['inspection_completed'] == true)
          _row(Icons.fact_check_outlined, 'Vehicle inspection completed'),
        for (final task in originals) _authorizedService(task),
        if (totals?['original_authorized'] != null)
          _info(
            'Original authorized total',
            money(totals!['original_authorized']),
          ),
      ]),
      if (authorizedRepairs.isNotEmpty)
        _detailsCard('Approved Additional Repairs', [
          for (final task in authorizedRepairs) _authorizedService(task),
        ]),
      if (advisories.isNotEmpty)
        _detailsCard('Safety Advisories', [
          for (final advisory in advisories)
            _info(
              advisory['resolved_at'] == null
                  ? 'Active advisory'
                  : 'Resolved advisory',
              advisory['message']?.toString() ?? '',
            ),
        ]),
      if (holds.isNotEmpty)
        _detailsCard('Service Holds', [
          for (final hold in holds) ...[
            _info(
              '${hold['released_at'] == null ? 'On hold' : 'Hold closed'} • '
              '${tasks[hold['task_id'].toString()]?['name'] ?? 'Service work'}',
              hold['reason']?.toString() ?? '',
            ),
            if (hold['released_at'] == null &&
                hold['resume_conditions'] != null)
              _info(
                'Conditions for resuming',
                hold['resume_conditions'].toString(),
              ),
          ],
        ]),
    ];
  }

  Widget _authorizedService(Map<String, dynamic> task) {
    final status = task['work_status']?.toString() ?? '';
    final description = task['description']?.toString() ?? '';
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            task['name']?.toString() ?? 'Service',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          if (description.isNotEmpty) Text(description),
          Text(
            [
              if (task['amount'] != null) money(task['amount']),
              if (status.isNotEmpty) status,
            ].join(' • '),
          ),
        ],
      ),
    );
  }

  Widget _finalBillSection() {
    final finalizedBill = bill;
    if (finalizedBill == null) {
      return _section(
        'Final Bill & Receipt',
        Icons.payments_outlined,
        'Available after service work is finalized',
        null,
      );
    }
    final paymentStatus = bookingFinalPaymentStatus(item);
    return _detailsCard('Final Bill & Receipt', [
      _info('Completed service charges', money(finalizedBill['gross_amount'])),
      _info(
        'Reservation fee credit',
        money(finalizedBill['reservation_fee_credit']),
      ),
      _info(
        'Final balance',
        '${money(finalizedBill['amount_due'])}${paymentStatus == null ? '' : ' • $paymentStatus'}',
      ),
      if (bookingFinalPaymentId(item) != null) ...[
        const SizedBox(height: 12),
        FilledButton.tonalIcon(
          onPressed: _openPayment,
          icon: const Icon(Icons.payments_outlined),
          label: Text(
            paymentStatus == 'Paid'
                ? 'View Payment & Receipt'
                : 'Open Final Payment',
          ),
        ),
      ],
    ]);
  }

  Widget _serviceReport() {
    return _detailsCard('Service Report', [
      if ((item['diagnosis'] ?? '').toString().isNotEmpty)
        _info('Diagnosis', item['diagnosis'].toString()),
      if ((item['work_performed'] ?? '').toString().isNotEmpty)
        _info('Work performed', item['work_performed'].toString()),
      if (item['intake_mileage'] != null)
        _info('Mileage', '${item['intake_mileage']} km'),
      if ((item['next_service_date'] ?? '').toString().isNotEmpty)
        _info('Next service', item['next_service_date'].toString()),
    ]);
  }

  Widget _nextAction(Map<String, dynamic>? serviceWorkflow) {
    final structured = serviceWorkflow != null;
    final paymentStatus = bookingFinalPaymentStatus(item);
    if (structured && repairQuote?['can_respond'] == true) {
      return _actionCard(
        'Additional repairs for your review',
        serviceWorkflow['full_hold_active'] == true
            ? 'Review the recommended repairs. The service center will review the safety hold before work resumes.'
            : 'Review the recommended repairs. Safe authorized services can continue while you decide.',
        Icons.request_quote_outlined,
        label: 'Review Additional Repairs',
        action: _openQuotation,
      );
    }
    if (!structured && status == 'Quotation Sent') {
      if (legacyQuotation?['status'] == 'Rejected') {
        return _actionCard(
          'Quotation revision requested',
          'The service center will send an updated quotation.',
          Icons.edit_note,
        );
      }
      return _actionCard(
        'Your approval is needed',
        'Review the final quotation before the service begins.',
        Icons.priority_high,
        label: 'Review Quotation',
        action: _openQuotation,
      );
    }
    if ((structured ? bill != null : status == 'Quotation Accepted') &&
        (paymentStatus == 'Awaiting Proof' || paymentStatus == 'Rejected')) {
      return _actionCard(
        'Submit your payment',
        'Pay for this booking and upload its proof.',
        Icons.upload_file,
        label: 'Pay This Booking',
        action: _openPayment,
      );
    }
    if (paymentStatus == 'Pay at Shop') {
      return _actionCard(
        'Pay cash at the shop',
        'Staff will issue your receipt after confirming the cash payment.',
        Icons.storefront,
        label: 'View Payment',
        action: _openPayment,
      );
    }
    if (paymentStatus == 'Under Review') {
      return _actionCard(
        'Payment under review',
        'The service center is checking your submitted proof.',
        Icons.hourglass_top,
      );
    }
    if (serviceWorkflow?['full_hold_active'] == true) {
      return _actionCard(
        'Service work is on hold',
        'Review the affected services and conditions for resuming below.',
        Icons.pause_circle_outline,
      );
    }
    if (status == 'Ready for Pickup') {
      return _actionCard(
        'Your vehicle is ready',
        'Please coordinate with the service center for pickup.',
        Icons.directions_car,
      );
    }
    if (status == 'Completed') {
      return _actionCard(
        'Service completed',
        'Your service report and receipt are available below.',
        Icons.check_circle,
      );
    }
    return _actionCard(
      'No action required',
      'We will notify you when there is an update.',
      Icons.schedule,
    );
  }

  Widget _actionCard(
    String title,
    String message,
    IconData icon, {
    String? label,
    VoidCallback? action,
  }) {
    return Card(
      color: const Color(0xFFFFF1F2),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: primaryColor),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(message),
            if (action != null && label != null) ...[
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: action, child: Text(label)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _openQuotation() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => JobQuotationScreen(reservationId: id)),
    );
    if (mounted) await _refreshBooking();
  }

  Future<void> _openPayment() async {
    final paymentId = bookingFinalPaymentId(item);
    if (paymentId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'The payment record is not ready yet. Please refresh this booking.',
          ),
        ),
      );
      return;
    }
    await _viewPayment(paymentId);
  }

  Future<void> _viewPayment(int paymentId) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BookingPaymentScreen(paymentId: paymentId),
      ),
    );
    if (mounted) await _refreshBooking();
  }

  Future<void> _feedback() async {
    int rating = 5;
    final review = TextEditingController();
    try {
      final send = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Rate your service'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Wrap(
                  alignment: WrapAlignment.center,
                  children: [
                    for (int i = 0; i < 5; i++)
                      IconButton(
                        tooltip: '${i + 1} stars',
                        onPressed: () => setDialogState(() => rating = i + 1),
                        icon: Icon(
                          i < rating ? Icons.star : Icons.star_border,
                          color: Colors.amber,
                        ),
                      ),
                  ],
                ),
                TextField(
                  controller: review,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Review (optional)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      );
      if (send == true && mounted) {
        final result = await CustomerApi.submitFeedback(
          id,
          rating,
          review.text.trim(),
        );
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result['message']?.toString() ?? 'Thank you.'),
            ),
          );
        }
      }
    } finally {
      review.dispose();
    }
  }

  Widget _detailsCard(String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          ...children,
        ],
      ),
    ),
  );

  Widget _section(
    String title,
    IconData icon,
    String subtitle,
    VoidCallback? onTap,
  ) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.all(16),
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: onTap == null ? null : const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );

  Widget _row(IconData icon, String value) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 18, color: Colors.blueGrey),
        const SizedBox(width: 8),
        Expanded(child: Text(value)),
      ],
    ),
  );

  Widget _info(String label, String value) => Padding(
    padding: const EdgeInsets.only(top: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
        ),
        Text(value),
      ],
    ),
  );
}
