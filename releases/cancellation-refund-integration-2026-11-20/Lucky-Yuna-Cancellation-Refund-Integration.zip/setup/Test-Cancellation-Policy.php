<?php
require_once __DIR__.'/../Vehicle-Service-System/vehicle-service-management/includes/cancellation_refunds.php';

$appointment=['appointment_date'=>'2026-11-25','appointment_time'=>'10:00:00','payment_status'=>'Paid',
    'received_by'=>'Manager (#1)','amount_received'=>'200.00','payment_amount'=>'200.00',
    'refund_id'=>null,'refund_record_status'=>null,'legacy_refund_status'=>'Not Applicable'];
$zone=new DateTimeZone('Asia/Manila');
$cases=[
    ['more than 24 hours','2026-11-24 09:00:00',true],
    ['exactly 24 hours','2026-11-24 10:00:00',true],
    ['23 hours 59 minutes','2026-11-24 10:01:00',false],
    ['after appointment','2026-11-25 10:01:00',false],
];
$failed=0;
foreach($cases as [$label,$clock,$expected]){
    $actual=cancellationFacts($appointment,new DateTimeImmutable($clock,$zone))['within_refund_window'];
    echo ($actual===$expected?'PASS':'FAIL')." $label\n";
    if($actual!==$expected)$failed++;
}
$sandbox=$appointment;$sandbox['received_by']='PayMongo sandbox (server verified)';
$facts=cancellationFacts($sandbox,new DateTimeImmutable('2026-11-24 09:00:00',$zone));
$sandboxPass=$facts['payment_verified']===false&&$facts['refundable_amount']===0.0;
echo ($sandboxPass?'PASS':'FAIL')." sandbox is not refundable real cash\n";
exit($failed+($sandboxPass?0:1));
