# Lucky Yuna Service Workflow Core

Ihanda ang package sa staging copy ng kasalukuyang project. Ang folder na
vehicle-service-management/ sa ZIP ay tumutugma sa Customer Website folder
at kasama na ang PHP API nito. Kailangan ng PHP 8.2 o mas bago na may mysqli
at mbstring.

1. I-backup ang files at database ng staging project. I-merge ang laman ng
   vehicle-service-management/ sa katumbas na folder sa project.
2. Sa existing staging database, i-import ang migration na
   vehicle-service-management/database/migrations/20261120_service_workflow.sql.
   Additive ang migration. Ang kasalukuyang records ay mananatili sa
   kanilang existing workflow.
3. Panatilihing disabled ang LYC_SERVICE_WORKFLOW_ENABLED hanggang maisama
   at ma-test ang Admin Website at Flutter integration. Default off ito.
   Kapag handa ang integrated staging pilot, ang value na 1 ang nag-e-enable
   ng revised flow para sa bagong confirmed-price bookings.

Para i-pause ang pilot, alisin ang setting o gawing 0. Mananatiling
mababasa ang enrolled bookings at dapat i-reconcile ang in-flight work bago
mag-rollback ng code. I-preserve ang bagong decisions, holds at payments
habang nagre-recover.

Na-verify sa disposable MariaDB 11.8 ang dalawang migration import,
legacy record preservation, original-only at approved-additional billing,
decline at safety holds, guest decision evidence, notification retry,
at concurrent duplicate approval. Na-check din ang website at PHP API
gamit ang synthetic accounts. Pending ang testing sa aktuwal na XAMPP,
Hostinger, at physical phone.
