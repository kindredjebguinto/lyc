-- Apply to the existing application database. Existing bookings remain on their current workflow.
CREATE TABLE IF NOT EXISTS service_workflow_jobs (
    reservation_id INT NOT NULL PRIMARY KEY,
    captured_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    inspection_completed_at DATETIME DEFAULT NULL,
    inspection_completed_by INT DEFAULT NULL,
    full_hold_at DATETIME DEFAULT NULL,
    CONSTRAINT sw_job_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_findings (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    description VARCHAR(1000) NOT NULL,
    recorded_by INT NOT NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY sw_finding_job_id (reservation_id, id),
    CONSTRAINT sw_finding_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_revisions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    version INT UNSIGNED NOT NULL,
    request_key VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    request_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    valid_until DATE DEFAULT NULL,
    sent_by INT NOT NULL,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY sw_revision_version (reservation_id, version),
    UNIQUE KEY sw_revision_request (reservation_id, request_key),
    UNIQUE KEY sw_revision_job_id (reservation_id, id),
    CONSTRAINT sw_revision_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_tasks (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    revision_id INT UNSIGNED DEFAULT NULL,
    finding_id INT UNSIGNED DEFAULT NULL,
    source_catalog ENUM('services','service_catalog') DEFAULT NULL,
    source_id INT UNSIGNED DEFAULT NULL,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(1000) NOT NULL,
    advisory VARCHAR(1000) DEFAULT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(10,2) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    duration_minutes INT UNSIGNED DEFAULT NULL,
    decision ENUM('Pending','Accepted','Rejected','Withdrawn') NOT NULL,
    decided_by INT DEFAULT NULL,
    decided_at DATETIME DEFAULT NULL,
    work_status ENUM('Awaiting Work','In Progress','Completed','Not Performed') NOT NULL DEFAULT 'Awaiting Work',
    UNIQUE KEY sw_task_snapshot (reservation_id, source_catalog, source_id),
    UNIQUE KEY sw_task_job_id (reservation_id, id),
    KEY sw_task_revision (reservation_id, revision_id, decision),
    CONSTRAINT sw_task_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE,
    CONSTRAINT sw_task_quotation FOREIGN KEY (reservation_id, revision_id) REFERENCES service_workflow_revisions(reservation_id, id) ON DELETE CASCADE,
    CONSTRAINT sw_task_finding FOREIGN KEY (reservation_id, finding_id) REFERENCES service_workflow_findings(reservation_id, id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_advisories (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    message VARCHAR(1000) NOT NULL,
    recorded_by INT NOT NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_by INT DEFAULT NULL,
    resolved_at DATETIME DEFAULT NULL,
    resolution_reason VARCHAR(500) DEFAULT NULL,
    CONSTRAINT sw_advisory_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_holds (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    task_id INT UNSIGNED NOT NULL,
    reason VARCHAR(500) NOT NULL,
    resume_conditions VARCHAR(500) NOT NULL,
    recorded_by INT NOT NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    released_by INT DEFAULT NULL,
    released_at DATETIME DEFAULT NULL,
    release_reason VARCHAR(500) DEFAULT NULL,
    KEY sw_active_hold (reservation_id, task_id, released_at),
    CONSTRAINT sw_hold_task FOREIGN KEY (reservation_id, task_id) REFERENCES service_workflow_tasks(reservation_id, id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    event_type VARCHAR(40) NOT NULL,
    actor_id INT NOT NULL,
    request_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
    details LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY sw_event_request (reservation_id, request_key),
    CONSTRAINT sw_event_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_workflow_bills (
    reservation_id INT NOT NULL PRIMARY KEY,
    payment_id INT NOT NULL UNIQUE,
    gross_amount DECIMAL(10,2) NOT NULL,
    reservation_fee_credit DECIMAL(10,2) NOT NULL,
    amount_due DECIMAL(10,2) NOT NULL,
    lines_json LONGTEXT NOT NULL,
    finalized_by INT NOT NULL,
    finalized_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sw_bill_job FOREIGN KEY (reservation_id) REFERENCES service_workflow_jobs(reservation_id) ON DELETE CASCADE,
    CONSTRAINT sw_bill_payment FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
