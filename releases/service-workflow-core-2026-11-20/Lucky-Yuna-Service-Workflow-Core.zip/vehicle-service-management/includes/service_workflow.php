<?php

class ServiceWorkflowConflict extends DomainException {}

function serviceWorkflowSchemaReady(mysqli $conn): bool
{
    static $connections = new WeakMap();
    if (!isset($connections[$conn])) {
        $row = $conn->query("SELECT COUNT(*) AS total FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (
                'service_workflow_jobs', 'service_workflow_tasks', 'service_workflow_findings',
                'service_workflow_revisions', 'service_workflow_advisories', 'service_workflow_holds',
                'service_workflow_events', 'service_workflow_bills'
            )")->fetch_assoc();
        $connections[$conn] = (int) $row['total'] === 8;
    }
    return $connections[$conn];
}

function serviceWorkflowConfigured(mysqli $conn): bool
{
    return getenv('LYC_SERVICE_WORKFLOW_ENABLED') === '1' && serviceWorkflowSchemaReady($conn);
}

function serviceWorkflowMoneyToCents(mixed $value): int
{
    if ((!is_string($value) && !is_int($value)) || !preg_match('/\A(\d{1,8})(?:\.(\d{1,2}))?\z/', (string) $value, $parts)) {
        throw new DomainException('Use a valid amount with up to two decimal places.');
    }

    return (int) $parts[1] * 100 + (int) str_pad($parts[2] ?? '', 2, '0');
}

function serviceWorkflowCentsToMoney(int $cents): string
{
    return sprintf('%d.%02d', intdiv($cents, 100), $cents % 100);
}

// The booking transaction must also validate the prices the customer confirmed.
function serviceWorkflowSnapshotBooking(mysqli $conn, int $reservationId, array $services): void
{
    if (!serviceWorkflowConfigured($conn)) {
        throw new ServiceWorkflowConflict('Service price confirmation is unavailable. Reload the booking form.');
    }
    if (!$services) {
        throw new DomainException('Choose at least one original service.');
    }

    $conn->execute_query('INSERT INTO service_workflow_jobs (reservation_id) VALUES (?)', [$reservationId]);
    foreach ($services as $service) {
        $price = serviceWorkflowCentsToMoney(serviceWorkflowMoneyToCents($service['price']));
        $conn->execute_query("INSERT INTO service_workflow_tasks
            (reservation_id, source_catalog, source_id, name, description, unit_price, amount, duration_minutes, decision)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Accepted')", [
                $reservationId, $service['source'], $service['id'], $service['name'], $service['description'],
                $price, $price, $service['duration'],
            ]);
    }
}

// Mutations use the reservation as the first lock for work, decisions and billing.
function serviceWorkflowLock(mysqli $conn, int $reservationId): array
{
    if (!serviceWorkflowSchemaReady($conn)) {
        throw new ServiceWorkflowConflict('The service workflow is unavailable.');
    }
    $job = $conn->execute_query('SELECT r.*, w.inspection_completed_at, w.inspection_completed_by, w.full_hold_at
        FROM reservations r INNER JOIN service_workflow_jobs w ON w.reservation_id = r.id
        WHERE r.id = ? FOR UPDATE', [$reservationId])->fetch_assoc();
    if (!$job) {
        throw new DomainException('Booking unavailable.');
    }

    return $job;
}

function serviceWorkflowEvent(
    mysqli $conn,
    array $job,
    int $actor,
    string $type,
    array $detail,
    ?string $title = null,
    ?string $message = null,
    ?string $requestKey = null
): void {
    $conn->execute_query('INSERT INTO service_workflow_events (reservation_id, event_type, actor_id, request_key, details)
        VALUES (?, ?, ?, ?, ?)', [$job['id'], $type, $actor, $requestKey, json_encode($detail, JSON_THROW_ON_ERROR)]);

    if ($title !== null && $message !== null && !empty($job['user_id'])) {
        $conn->execute_query("INSERT INTO notifications (user_id, title, message, link_type, link_id)
            VALUES (?, ?, ?, 'reservation', ?)", [$job['user_id'], $title, $message, $job['id']]);
    }
}

function serviceWorkflowPaymentEligibleSql(mysqli $conn, string $reservationAlias, string $paymentAlias): string
{
    $r = $reservationAlias;
    $p = $paymentAlias;
    $fee = "$p.payment_type = 'Reservation Fee'";
    $legacy = "EXISTS (SELECT 1 FROM job_quotations legacy_quote WHERE legacy_quote.reservation_id = $r.id AND legacy_quote.status = 'Accepted')";
    if (!serviceWorkflowSchemaReady($conn)) {
        return "($fee OR $legacy)";
    }

    return "($fee OR (
        NOT EXISTS (SELECT 1 FROM service_workflow_jobs workflow_job WHERE workflow_job.reservation_id = $r.id)
        AND $legacy
    ) OR (
        $p.payment_type = 'Final Balance'
        AND EXISTS (SELECT 1 FROM service_workflow_bills finalized_bill
            WHERE finalized_bill.reservation_id = $r.id AND finalized_bill.payment_id = $p.id AND finalized_bill.amount_due = $p.amount)
    ))";
}

function serviceWorkflowBillData(array $bill): array
{
    return [
        'id' => (int) $bill['reservation_id'],
        'payment_id' => (int) $bill['payment_id'],
        'gross_amount' => $bill['gross_amount'],
        'reservation_fee_credit' => $bill['reservation_fee_credit'],
        'amount_due' => $bill['amount_due'],
        'lines' => json_decode($bill['lines_json'], true, 512, JSON_THROW_ON_ERROR),
        'finalized_at' => $bill['finalized_at'],
    ];
}

function serviceWorkflowBillForPayment(mysqli $conn, int $paymentId): ?array
{
    if (!serviceWorkflowSchemaReady($conn)) {
        return null;
    }
    $bill = $conn->execute_query('SELECT * FROM service_workflow_bills WHERE payment_id = ?', [$paymentId])->fetch_assoc();
    return $bill ? serviceWorkflowBillData($bill) : null;
}

function serviceWorkflowLatestRevision(mysqli $conn, int $reservationId): ?array
{
    return $conn->execute_query('SELECT id, version, valid_until FROM service_workflow_revisions
        WHERE reservation_id = ? ORDER BY version DESC LIMIT 1', [$reservationId])->fetch_assoc();
}

function serviceWorkflowQuoteOpen(array $job, array $revision): bool
{
    return in_array($job['status'], ['Diagnosing', 'In Progress'], true)
        && ($revision['valid_until'] === null
            || $revision['valid_until'] >= (new DateTimeImmutable('now', new DateTimeZone('Asia/Manila')))->format('Y-m-d'));
}

function serviceWorkflowDisplayStatus(string $status, int $working, int $outstanding, int $held): string
{
    if ($held > 0 && $working === 0 && $held === $outstanding && in_array($status, ['Diagnosing', 'In Progress'], true)) {
        return 'Work on Hold';
    }
    if ($status === 'In Progress' && $working === 0) {
        return $held > 0 ? 'Work Paused' : ($outstanding > 0 ? 'Awaiting Service' : 'Work Finished');
    }
    return match ($status) {
        'Pending' => 'Awaiting Confirmation',
        'Approved' => 'Appointment Confirmed',
        'Diagnosing' => 'Vehicle Inspection',
        'In Progress' => 'Work in Progress',
        default => $status,
    };
}

function serviceWorkflowSummary(mysqli $conn, int $reservationId): ?array
{
    if (!serviceWorkflowSchemaReady($conn)) {
        return null;
    }
    $job = $conn->execute_query('SELECT r.reference_number, r.status, w.inspection_completed_at, w.full_hold_at
        FROM service_workflow_jobs w JOIN reservations r ON r.id = w.reservation_id
        WHERE w.reservation_id = ?', [$reservationId])->fetch_assoc();
    if (!$job) {
        return null;
    }

    $revision = serviceWorkflowLatestRevision($conn, $reservationId);
    $revisionId = $revision ? (int) $revision['id'] : null;
    $bill = $conn->execute_query('SELECT * FROM service_workflow_bills WHERE reservation_id = ?', [$reservationId])->fetch_assoc();
    $quoteOpen = $revision && !$bill && serviceWorkflowQuoteOpen($job, $revision);
    $holds = $conn->execute_query('SELECT id, task_id, reason, resume_conditions, recorded_at, released_at
        FROM service_workflow_holds WHERE reservation_id = ? ORDER BY id', [$reservationId])->fetch_all(MYSQLI_ASSOC);
    $activeHolds = [];
    foreach ($holds as &$hold) {
        $hold['id'] = (int) $hold['id'];
        $hold['task_id'] = (int) $hold['task_id'];
        if ($hold['released_at'] === null) {
            $activeHolds[$hold['task_id']] = true;
        }
    }
    unset($hold);

    $original = [];
    $additional = [];
    $originalTotal = $proposedTotal = $approvedTotal = $outstanding = $working = $held = 0;
    $counts = array_fill_keys(['Pending', 'Accepted', 'Rejected', 'Withdrawn'], 0);
    $tasks = $conn->execute_query('SELECT t.id, t.revision_id, t.name, t.description, t.advisory,
        t.quantity, t.unit_price, t.amount, t.decision, t.work_status, f.description AS finding
        FROM service_workflow_tasks t LEFT JOIN service_workflow_findings f
            ON f.reservation_id = t.reservation_id AND f.id = t.finding_id
        WHERE t.reservation_id = ? AND (t.revision_id IS NULL OR t.revision_id = ? OR t.decision = \'Accepted\')
        ORDER BY t.id', [$reservationId, $revisionId]);
    while ($task = $tasks->fetch_assoc()) {
        $task['id'] = (int) $task['id'];
        $task['revision_id'] = $task['revision_id'] === null ? null : (int) $task['revision_id'];
        $isCurrent = $revisionId !== null && $task['revision_id'] === $revisionId;
        $task['respondable'] = $quoteOpen && $isCurrent && $task['decision'] === 'Pending';
        $isHeld = isset($activeHolds[$task['id']]);
        $amount = serviceWorkflowMoneyToCents($task['amount']);

        if ($task['decision'] === 'Accepted' && in_array($task['work_status'], ['Awaiting Work', 'In Progress'], true)) {
            $outstanding++;
            $held += (int) $isHeld;
            $working += (int) (!$isHeld && $task['work_status'] === 'In Progress');
        }
        if ($isHeld) {
            $task['work_status'] = 'On Hold';
        }
        if ($task['revision_id'] === null) {
            $original[] = $task;
            $originalTotal += $amount;
            continue;
        }

        $additional[] = $task;
        if ($isCurrent) {
            $counts[$task['decision']]++;
            $proposedTotal += $amount;
        }
        if ($task['decision'] === 'Accepted') {
            $approvedTotal += $amount;
        }
    }

    $decisionStatus = match (true) {
        $counts['Accepted'] > 0 && ($counts['Pending'] + $counts['Rejected'] + $counts['Withdrawn']) > 0 => 'Partially Approved',
        $counts['Accepted'] > 0 => 'Approved',
        $counts['Pending'] > 0 && $quoteOpen => 'Pending Approval',
        $counts['Rejected'] > 0 => 'Additional Repair Declined',
        default => 'Closed',
    };
    if ($revision) {
        $revision['id'] = $revisionId;
        $revision['version'] = (int) $revision['version'];
        $revision['can_respond'] = $quoteOpen && $counts['Pending'] > 0;
        $revision['decision_status'] = $decisionStatus;
    }

    return [
        'reservation_id' => $reservationId,
        'booking_reference' => $job['reference_number'],
        'reservation_status' => $job['status'],
        'work_status' => $job['full_hold_at'] ? 'Work on Hold' : serviceWorkflowDisplayStatus($job['status'], $working, $outstanding, $held),
        'full_hold_active' => $job['full_hold_at'] !== null,
        'inspection_completed' => $job['inspection_completed_at'] !== null,
        'original_services' => $original,
        'additional_repairs' => $additional,
        'quotation' => $revision,
        'totals' => [
            'original_authorized' => serviceWorkflowCentsToMoney($originalTotal),
            'proposed_additional' => serviceWorkflowCentsToMoney($proposedTotal),
            'approved_additional' => serviceWorkflowCentsToMoney($approvedTotal),
            'updated_authorized' => serviceWorkflowCentsToMoney($originalTotal + $approvedTotal),
        ],
        'safety_advisories' => $conn->execute_query('SELECT id, message, recorded_at, resolved_at
            FROM service_workflow_advisories WHERE reservation_id = ? ORDER BY id', [$reservationId])->fetch_all(MYSQLI_ASSOC),
        'service_holds' => $holds,
        'bill' => $bill ? serviceWorkflowBillData($bill) : null,
    ];
}

function serviceWorkflowRespond(
    mysqli $conn,
    int $reservationId,
    int $userId,
    int $revisionId,
    ?string $allDecision,
    array $decisions
): array {
    $requestKey = serviceWorkflowDecisionKey($userId, $revisionId, $allDecision, $decisions);

    $conn->begin_transaction();
    try {
        $job = serviceWorkflowLock($conn, $reservationId);
        if ((int) $job['user_id'] !== $userId) {
            throw new DomainException('Booking unavailable.');
        }
        $revision = serviceWorkflowLatestRevision($conn, $reservationId);
        if (!$revision || (int) $revision['id'] !== $revisionId) {
            throw new ServiceWorkflowConflict('This quotation has changed. Reload it before deciding.');
        }

        $retry = $conn->execute_query('SELECT id FROM service_workflow_events WHERE reservation_id = ? AND request_key = ?',
            [$reservationId, $requestKey])->fetch_assoc();
        if (!$retry) {
            serviceWorkflowApplyDecision($conn, $job, $revision, $userId, $allDecision, $decisions, $requestKey);
        }
        $summary = serviceWorkflowSummary($conn, $reservationId);
        $conn->commit();
        return $summary;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function serviceWorkflowDecisionKey(int $actor, int $revisionId, ?string $allDecision, array $decisions, ?array $context = null): string
{
    if ($actor < 1 || $revisionId < 1 || ($allDecision === null && !$decisions)
        || ($allDecision !== null && ($decisions || !in_array($allDecision, ['Accepted', 'Rejected'], true)))) {
        throw new DomainException('Choose a valid decision for the additional repairs.');
    }
    foreach ($decisions as $id => $decision) {
        if (!is_int($id) || $id < 1 || !in_array($decision, ['Accepted', 'Rejected'], true)) {
            throw new DomainException('Choose a valid decision for each additional repair.');
        }
    }
    ksort($decisions, SORT_NUMERIC);
    return hash('sha256', json_encode([$revisionId, $actor, $allDecision, $decisions, $context], JSON_THROW_ON_ERROR));
}

function serviceWorkflowApplyDecision(
    mysqli $conn,
    array $job,
    array $revision,
    int $actor,
    ?string $allDecision,
    array $decisions,
    string $requestKey,
    ?array $context = null
): void {
    $reservationId = (int) $job['id'];
    $revisionId = (int) $revision['id'];
    $hasBill = $conn->execute_query('SELECT 1 FROM service_workflow_bills WHERE reservation_id = ?', [$reservationId])->fetch_row();
    if ($hasBill || !serviceWorkflowQuoteOpen($job, $revision)) {
        throw new ServiceWorkflowConflict('This quotation is closed.');
    }
    $tasks = $conn->execute_query('SELECT id, decision FROM service_workflow_tasks WHERE reservation_id = ? AND revision_id = ?',
        [$reservationId, $revisionId])->fetch_all(MYSQLI_ASSOC);
    $current = array_column($tasks, 'decision', 'id');
    if ($allDecision !== null) {
        $decisions = array_fill_keys(array_keys(array_filter($current, static fn ($decision) => $decision === 'Pending')), $allDecision);
        if (!$decisions) {
            throw new ServiceWorkflowConflict('There are no pending additional repairs in this quotation.');
        }
    }

    $changed = ['Accepted' => [], 'Rejected' => []];
    foreach ($decisions as $id => $decision) {
        if (($current[$id] ?? null) === $decision) {
            continue;
        }
        if (($current[$id] ?? null) !== 'Pending') {
            throw new ServiceWorkflowConflict('An additional repair is no longer awaiting this decision. Reload the quotation.');
        }
        $conn->execute_query('UPDATE service_workflow_tasks SET decision = ?, decided_by = ?, decided_at = NOW()
            WHERE id = ?', [$decision, $actor, $id]);
        $changed[$decision][] = $id;
    }

    serviceWorkflowEvent($conn, $job, $actor, 'Quotation response', ['revision_id' => $revisionId, 'decisions' => $decisions, 'context' => $context],
        null, null, $requestKey);
    if ($changed['Accepted']) {
        serviceWorkflowEvent($conn, $job, $actor, 'Additional repairs approved', ['tasks' => $changed['Accepted']],
            'Additional repairs approved', 'Your additional repairs have been approved and added to your authorized services.');
    }
    if ($changed['Rejected']) {
        serviceWorkflowEvent($conn, $job, $actor, 'Additional repairs declined', ['tasks' => $changed['Rejected']],
            'Additional Repair Declined', 'You declined the additional recommended repairs. We will continue your originally booked services where safe.');
    }
}
