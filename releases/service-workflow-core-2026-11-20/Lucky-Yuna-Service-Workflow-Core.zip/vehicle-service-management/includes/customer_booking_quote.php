<?php

// Bind the displayed catalog to the current session and booking channel.
function customerBookingCatalogToken(string $source, array $services): string
{
    $_SESSION['booking_catalog_key'] ??= random_bytes(32);
    $catalog = [];
    foreach ($services as $service) {
        $catalog[(int)$service['id']] = [
            $service['service_name'],
            $service['description'],
            (string)$service['price'],
            (int)$service['estimated_duration'],
        ];
    }
    ksort($catalog, SORT_NUMERIC);
    $contents = json_encode([$source, $catalog], JSON_THROW_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
    return hash_hmac('sha256', $contents, $_SESSION['booking_catalog_key']);
}

function customerBookingQuoteError(string $catalogToken, array $submission): string
{
    $displayedToken = $submission['booking_catalog_token'] ?? null;
    if (!is_string($displayedToken) || !hash_equals($catalogToken, $displayedToken)) {
        return 'The service catalog changed or the form expired. Review the current services and prices before confirming again.';
    }
    if (($submission['authorize_original_services'] ?? null) !== '1') {
        return 'Confirm the selected original services and displayed prices to continue.';
    }
    return '';
}

function customerBookingSnapshotRows(string $source, array $services): array
{
    return array_map(static function (array $service) use ($source): array {
        return [
            'source' => $source,
            'id' => (int)$service['id'],
            'name' => $service['service_name'],
            'description' => (string)$service['description'],
            'price' => (string)$service['price'],
            'duration' => (int)$service['estimated_duration'],
        ];
    }, $services);
}
