<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__ . "/../../includes/service_workflow.php";
requireMethod("GET");
$user = requireCustomer($conn);
$userId = (int) $user["id"];
$completedOnly = ($_GET["completed"] ?? "") === "1";

$optionalReservationFields = implode(', ', [
 optionalColumn($conn, 'reservations', 'r', 'original_appointment_at'),
 optionalColumn($conn, 'reservations', 'r', 'original_duration_minutes'),
 optionalColumn($conn, 'reservations', 'r', 'scheduled_duration_minutes'),
 optionalColumn($conn, 'reservations', 'r', 'intake_mileage'),
 optionalColumn($conn, 'reservations', 'r', 'diagnosis'),
 optionalColumn($conn, 'reservations', 'r', 'work_performed'),
 optionalColumn($conn, 'reservations', 'r', 'completion_notes'),
 optionalColumn($conn, 'reservations', 'r', 'next_service_date'),
]);

$workflowReady = serviceWorkflowSchemaReady($conn);
$workflowColumn = $workflowReady ? ', workflow_job.reservation_id AS workflow_booking_id' : '';
$workflowJoin = $workflowReady ? 'LEFT JOIN service_workflow_jobs workflow_job ON workflow_job.reservation_id=r.id' : '';

$sql = "SELECT r.id, r.vehicle_id, r.reference_number, r.service_type, r.appointment_date, r.appointment_time,
 r.remarks, r.status, r.created_at, $optionalReservationFields, v.brand, v.model, v.year, v.plate_number, v.color,
 m.fullname AS mechanic_name,
 p.id AS payment_id, p.status AS payment_status, p.amount AS payment_amount,
 r.reservation_fee_status,r.reservation_fee_payment_id,r.policy_version,r.policy_accepted_at $workflowColumn
 FROM reservations r INNER JOIN vehicles v ON r.vehicle_id = v.id
 LEFT JOIN mechanics m ON r.mechanic_id = m.id
 LEFT JOIN payments p ON p.id=(SELECT p2.id FROM payments p2 WHERE p2.reservation_id=r.id AND p2.payment_type='Final Balance' ORDER BY p2.id DESC LIMIT 1)
 $workflowJoin
 WHERE r.user_id = ?" . ($completedOnly ? " AND r.status = 'Completed'" : "") .
 " ORDER BY r.appointment_date DESC, r.appointment_time DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$items = [];
while ($row = $result->fetch_assoc()) {
    $row["id"] = (int) $row["id"];
    $row["vehicle_id"] = (int) $row["vehicle_id"];
    $row["payment_id"] = $row["payment_id"] === null ? null : (int) $row["payment_id"];
    $row["payment_amount"] = $row["payment_amount"] === null ? null : (float) $row["payment_amount"];
    $row['expected_finish_at'] = null;
    if ($row['original_duration_minutes'] !== null && !in_array($row['status'], ['Ready for Pickup','Completed','Cancelled'], true)) {
        $row['expected_finish_at'] = (new DateTimeImmutable($row['appointment_date'].' '.$row['appointment_time'], new DateTimeZone('Asia/Manila')))->modify('+'.max(30,(int)$row['scheduled_duration_minutes']).' minutes')->format('Y-m-d H:i:s');
    }
    if (isset($row['workflow_booking_id'])) {
        $row['service_workflow'] = serviceWorkflowSummary($conn, $row['id']);
    }
    unset($row['workflow_booking_id']);
    $items[] = $row;
}
echo json_encode(["success" => true, "reservations" => $items]);
