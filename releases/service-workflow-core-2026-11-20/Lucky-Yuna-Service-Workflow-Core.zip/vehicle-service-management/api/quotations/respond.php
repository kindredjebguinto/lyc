<?php
require_once __DIR__ . "/../config/bootstrap.php";
require_once __DIR__."/../../includes/payment_balance.php";
require_once __DIR__."/../../includes/service_workflow.php";
requireMethod("POST");
$user=requireCustomer($conn); $data=jsonInput();
$reservationId = (int)filter_var($data['reservation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$action = $data['status'] ?? null;
$userId=(int)$user["id"];
$isWorkflowBooking = false;
$workflowReady = serviceWorkflowSchemaReady($conn);
if ($workflowReady) {
    $stmt = $conn->prepare('SELECT j.reservation_id FROM service_workflow_jobs j
        INNER JOIN reservations r ON r.id=j.reservation_id WHERE j.reservation_id=? AND r.user_id=?');
    $stmt->bind_param('ii', $reservationId, $userId);
    $stmt->execute();
    $isWorkflowBooking = $stmt->get_result()->num_rows === 1;
    $stmt->close();
}

if ($isWorkflowBooking || array_key_exists('revision_id', $data) || array_key_exists('decisions', $data)) {
    $revisionId = $data['revision_id'] ?? null;
    if (!$isWorkflowBooking) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'This quotation is unavailable. Refresh the booking.']);
        exit;
    }
    if (!is_int($revisionId) || $revisionId < 1) {
        http_response_code(409);
        echo json_encode(['success' => false, 'code' => 'quote_update_required',
            'message' => 'Open the current recommended repairs in the customer website to respond.']);
        exit;
    }
    try {
        $decisions = $data['decisions'] ?? [];
        if (!is_array($decisions) || ($action === null ? !$decisions : $decisions || !in_array($action, ['Accepted', 'Rejected'], true))) {
            throw new DomainException('Choose Accepted or Rejected for the pending additional repairs.');
        }
        foreach ($decisions as $taskId => $decision) {
            if (!is_int($taskId) || $taskId < 1 || !in_array($decision, ['Accepted', 'Rejected'], true)) {
                throw new DomainException('Choose Accepted or Rejected for each selected additional repair.');
            }
        }
        $summary = serviceWorkflowRespond($conn, $reservationId, $userId, $revisionId, $action, $decisions);
        echo json_encode(['success' => true, 'message' => 'Additional repair decisions saved.', 'service_workflow' => $summary]);
    } catch (ServiceWorkflowConflict $e) {
        http_response_code(409);
        echo json_encode(['success' => false, 'code' => 'quotation_conflict', 'message' => $e->getMessage()]);
    } catch (DomainException $e) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Unable to save the additional repair decisions.']);
    }
    exit;
}

if(!in_array($action,["Accepted","Rejected"],true)) { http_response_code(422); echo json_encode(["success"=>false,"message"=>"Choose Accepted or Rejected."]); exit; }
$legacyGuard = $workflowReady ? 'AND NOT EXISTS (SELECT 1 FROM service_workflow_jobs j WHERE j.reservation_id=r.id)' : '';
$conn->begin_transaction();
try {
  $stmt=$conn->prepare("UPDATE job_quotations q INNER JOIN reservations r ON q.reservation_id=r.id SET q.status=?,q.responded_at=NOW() WHERE q.reservation_id=? AND r.user_id=? AND q.status='Sent' AND r.status='Quotation Sent' $legacyGuard");
  $stmt->bind_param("sii",$action,$reservationId,$userId); $stmt->execute(); $changed=$stmt->affected_rows; $stmt->close();
  if(!$changed) throw new Exception("This quotation cannot be changed.");
  if($action==='Accepted') {
    $stmt=$conn->prepare("UPDATE reservations SET status='Quotation Accepted' WHERE id=? AND user_id=?");
    $stmt->bind_param("ii",$reservationId,$userId); $stmt->execute(); $stmt->close();
    $quote=$conn->prepare('SELECT grand_total FROM job_quotations WHERE reservation_id=?');$quote->bind_param('i',$reservationId);$quote->execute();$gross=(float)$quote->get_result()->fetch_assoc()['grand_total'];$quote->close();
    createFinalBalance($conn,$reservationId,$gross);
  } else {
    $stmt=$conn->prepare("UPDATE reservations SET status='Cancelled',cancellation_reason='Quotation rejected',refund_eligibility='Full ₱200 reservation-fee refund requested.',reservation_fee_status='Refund Requested' WHERE id=? AND user_id=?");$stmt->bind_param('ii',$reservationId,$userId);$stmt->execute();$stmt->close();
    $stmt=$conn->prepare("UPDATE payments SET refund_status='Requested' WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid'");$stmt->bind_param('i',$reservationId);$stmt->execute();$stmt->close();
  }
  $conn->commit();
} catch(Throwable $e) {
  $conn->rollback(); http_response_code(409); echo json_encode(["success"=>false,"message"=>"This quotation cannot be changed. Refresh and check its current status."]); exit;
}
echo json_encode(["success"=>true,"message"=>"Quotation ".strtolower($action)."."]);
