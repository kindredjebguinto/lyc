<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_once __DIR__ . '/../../includes/service_workflow.php';
requireMethod('POST');
$user = requireCustomer($conn);
$data = jsonInput();
$itemId = (int)filter_var($data['item_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$decision = $data['decision'] ?? '';
if (!in_array($decision, ['Accepted','Rejected'], true)) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Choose Accepted or Rejected.']);
    exit;
}
$userId = (int)$user['id'];
$workflowReady = serviceWorkflowSchemaReady($conn);
if (array_key_exists('reservation_id', $data) || array_key_exists('revision_id', $data)) {
    $reservationId = $data['reservation_id'] ?? null;
    $revisionId = $data['revision_id'] ?? null;
    if (!$workflowReady || !is_int($reservationId) || $reservationId < 1 || !is_int($revisionId) || $revisionId < 1 || $itemId < 1) {
        http_response_code(409);
        echo json_encode(['success' => false, 'code' => 'quote_update_required',
            'message' => 'Open the current recommended repairs in the customer website to respond.']);
        exit;
    }
    try {
        $summary = serviceWorkflowRespond($conn, $reservationId, $userId, $revisionId, null, [$itemId => $decision]);
        echo json_encode(['success' => true, 'message' => 'Additional repair decision saved.', 'service_workflow' => $summary]);
    } catch (ServiceWorkflowConflict $e) {
        http_response_code(409);
        echo json_encode(['success' => false, 'code' => 'quotation_conflict', 'message' => $e->getMessage()]);
    } catch (DomainException $e) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Unable to save the additional repair decision.']);
    }
    exit;
}
$legacyGuard = $workflowReady ? 'AND NOT EXISTS (SELECT 1 FROM service_workflow_jobs j WHERE j.reservation_id=r.id)' : '';
$stmt = $conn->prepare("UPDATE job_quotation_items i INNER JOIN job_quotations q ON q.id=i.quotation_id INNER JOIN reservations r ON r.id=q.reservation_id SET i.customer_decision=? WHERE i.id=? AND i.is_additional=1 AND i.customer_decision='Pending' AND r.user_id=? AND r.status NOT IN ('Cancelled','Completed') $legacyGuard");
$stmt->bind_param('sii', $decision, $itemId, $userId);
$stmt->execute();
if ($stmt->affected_rows < 1) {
    http_response_code(409);
    echo json_encode(['success'=>false,'message'=>'This additional-work item can no longer be changed.']);
    exit;
}
echo json_encode(['success'=>true,'message'=>'Additional work '.strtolower($decision).'. The original approved work will continue.']);
