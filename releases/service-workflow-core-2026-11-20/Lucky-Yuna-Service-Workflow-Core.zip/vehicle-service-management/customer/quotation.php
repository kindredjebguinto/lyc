<?php
require_once __DIR__ . '/../includes/customer_auth.php';
require_once __DIR__ . '/../includes/service_workflow.php';

$userId = (int)$_SESSION['customer_id'];
$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 0;
$stmt = $conn->prepare('SELECT r.id,v.brand,v.model,v.plate_number FROM reservations r JOIN vehicles v ON v.id=r.vehicle_id WHERE r.id=? AND r.user_id=?');
$stmt->bind_param('ii', $id, $userId);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();
$summary = $booking ? serviceWorkflowSummary($conn, $id) : null;
$pageUrl = BASE_URL . '/customer/quotation.php?id=' . $id;
$error = '';
$success = '';

if (!$summary) {
    http_response_code(404);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? null;
    $revisionId = filter_var($_POST['revision_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $allDecision = $_POST['all_decision'] ?? null;
    $choices = $_POST['decisions'] ?? [];

    try {
        if (!is_string($csrf) || !hash_equals($_SESSION['csrf_token'] ?? '', $csrf) || empty($_SESSION['csrf_token'])) {
            throw new DomainException('The form expired. Refresh this page and try again.');
        }
        if ($revisionId === false || !is_array($choices) || ($allDecision !== null && !in_array($allDecision, ['Accepted', 'Rejected'], true))) {
            throw new DomainException('Choose a valid decision for the additional repairs.');
        }

        $decisions = [];
        foreach ($choices as $taskId => $decision) {
            if ($decision === '') continue;
            $taskId = filter_var($taskId, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($taskId === false || !in_array($decision, ['Accepted', 'Rejected'], true)) {
                throw new DomainException('Choose a valid decision for the additional repairs.');
            }
            $decisions[$taskId] = $decision;
        }
        if (($allDecision === null) === ($decisions === [])) {
            throw new DomainException('Choose decisions for individual repairs or use one of the actions for all pending repairs.');
        }

        serviceWorkflowRespond($conn, $id, $userId, $revisionId, $allDecision, $decisions);
        $_SESSION['service_workflow_decision_booking'] = $id;
        header('Location: ' . $pageUrl, true, 303);
        exit;
    } catch (ServiceWorkflowConflict $e) {
        http_response_code(409);
        $error = $e->getMessage();
        $summary = serviceWorkflowSummary($conn, $id);
    } catch (DomainException $e) {
        http_response_code(422);
        $error = $e->getMessage();
    } catch (Throwable $e) {
        http_response_code(500);
        $error = 'The shop could not record your decision. Check the latest status and try again.';
    }
} elseif (($_SESSION['service_workflow_decision_booking'] ?? null) === $id) {
    $success = 'Your decision was recorded.';
    unset($_SESSION['service_workflow_decision_booking']);
}

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$escape = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$money = static fn($value): string => '₱' . number_format((float)$value, 2);
$quotation = $summary['quotation'] ?? null;
$decisionLabels = ['Pending' => 'Pending Approval', 'Accepted' => 'Approved', 'Rejected' => 'Additional Repair Declined', 'Withdrawn' => 'Withdrawn'];
$canRespond = !empty($quotation['can_respond']);
$bill = $summary['bill'] ?? null;
$taskNames = $summary ? array_column(array_merge($summary['original_services'], $summary['additional_repairs']), 'name', 'id') : [];
require_once __DIR__ . '/../includes/customer_header.php';
?>
<div class="customer-page-header">
    <div>
        <a class="payment-back" href="<?= BASE_URL ?>/customer/reservations.php">← My Bookings</a>
        <h1><?= $quotation ? 'Final Quotation' : 'Service Summary' ?></h1>
        <?php if ($summary): ?><p><?= $escape($summary['booking_reference'] ?: '#' . $id) ?> · <?= $escape($booking['brand'] . ' ' . $booking['model'] . ' · ' . $booking['plate_number']) ?></p><?php endif; ?>
    </div>
</div>

<?php if ($error): ?><div class="alert alert-danger" role="alert"><?= $escape($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success" role="status"><?= $escape($success) ?></div><?php endif; ?>

<?php if (!$summary): ?>
    <div class="customer-card">Service summary unavailable.</div>
<?php else: ?>
    <div class="d-flex flex-wrap gap-2 mb-3">
        <span class="status-pill"><?= $escape($summary['work_status']) ?></span>
        <?php if ($quotation): ?><span class="status-pill">Additional repairs: <?= $escape($quotation['decision_status']) ?></span><?php endif; ?>
    </div>
    <?php if ($summary['inspection_completed']): ?><p>Vehicle inspection completed.</p><?php endif; ?>
    <section class="customer-card mb-3" aria-labelledby="originalHeading">
        <h2 class="h5" id="originalHeading">Original booked services</h2>
        <p>These services were authorized when you booked.</p>
        <dl>
            <?php foreach ($summary['original_services'] as $item): ?>
                <dt><?= $escape($item['name']) ?> <span class="fw-normal">· <?= $money($item['amount']) ?></span></dt>
                <dd class="mb-3"><?= $escape($item['description']) ?><?= $item['description'] !== '' ? '<br>' : '' ?><small class="text-muted"><?= $escape($item['work_status']) ?></small></dd>
            <?php endforeach; ?>
        </dl>
        <strong>Original authorized total <?= $money($summary['totals']['original_authorized']) ?></strong>
    </section>

    <?php if ($quotation): ?>
    <section class="customer-card mb-3" aria-labelledby="additionalHeading">
        <h2 class="h5" id="additionalHeading">Additional recommended repairs</h2>
        <p>Revision <?= (int)$quotation['version'] ?><?= $quotation['valid_until'] ? ' · Valid through ' . $escape($quotation['valid_until']) : '' ?></p>
        <?php if ($canRespond): ?>
        <p>Choose which additional repairs you authorize. The shop can continue your original services where safe.</p>
        <form method="post" action="<?= $escape($pageUrl) ?>" id="additional-repair-decisions">
            <input type="hidden" name="csrf_token" value="<?= $escape($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="revision_id" value="<?= (int)$quotation['id'] ?>">
        </form>
        <?php endif; ?>
        <?php foreach ($summary['additional_repairs'] as $item): ?>
            <div class="mb-3 border-bottom pb-3">
                <h3 class="h6"><?= $escape($item['name']) ?> · <?= $money($item['amount']) ?></h3>
                <?php if ($item['description']): ?><p class="mb-1"><?= $escape($item['description']) ?></p><?php endif; ?>
                <?php if ($item['finding']): ?><p class="mb-1"><strong>Mechanic’s finding</strong> <?= $escape($item['finding']) ?></p><?php endif; ?>
                <?php if ($item['advisory']): ?><p class="mb-1"><strong>Safety advisory</strong> <?= $escape($item['advisory']) ?></p><?php endif; ?>
                <p class="mb-1"><small><?= $escape($decisionLabels[$item['decision']] ?? $item['decision']) ?> · <?= $escape($item['work_status']) ?></small></p>
                <?php if ($item['respondable']): ?>
                    <label class="form-label" for="choice-<?= (int)$item['id'] ?>">Decision for <?= $escape($item['name']) ?></label>
                    <select class="form-select w-auto" id="choice-<?= (int)$item['id'] ?>" name="decisions[<?= (int)$item['id'] ?>]" form="additional-repair-decisions">
                        <option value="">Leave pending</option>
                        <option value="Accepted">Approve</option>
                        <option value="Rejected">Decline</option>
                    </select>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <dl class="row mb-3">
            <dt class="col-sm-8">Proposed additional total</dt><dd class="col-sm-4"><?= $money($summary['totals']['proposed_additional']) ?></dd>
            <dt class="col-sm-8">Approved additional total</dt><dd class="col-sm-4"><?= $money($summary['totals']['approved_additional']) ?></dd>
            <dt class="col-sm-8">Updated authorized service total</dt><dd class="col-sm-4"><?= $money($summary['totals']['updated_authorized']) ?></dd>
        </dl>
        <?php if ($canRespond): ?>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <button type="submit" class="btn btn-primary" form="additional-repair-decisions">Save selected decisions</button>
            <form method="post" action="<?= $escape($pageUrl) ?>" class="d-flex flex-wrap gap-2">
                <input type="hidden" name="csrf_token" value="<?= $escape($_SESSION['csrf_token']) ?>">
                <input type="hidden" name="revision_id" value="<?= (int)$quotation['id'] ?>">
                <button type="submit" name="all_decision" value="Accepted" class="btn btn-outline-primary">Approve all pending repairs</button>
                <button type="submit" name="all_decision" value="Rejected" class="btn btn-outline-secondary">Decline all pending repairs</button>
            </form>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if ($summary['safety_advisories']): ?>
        <section class="customer-card mb-3" aria-labelledby="advisoriesHeading">
            <h2 class="h5" id="advisoriesHeading">Safety Advisories</h2>
            <ul class="mb-0">
                <?php foreach ($summary['safety_advisories'] as $advisory): ?>
                    <li><?= $escape($advisory['message']) ?><?php if ($advisory['resolved_at']): ?> <small class="text-muted">Resolved</small><?php endif; ?></li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>
    <?php if ($summary['service_holds']): ?>
        <section class="customer-card mb-3" aria-labelledby="holdsHeading">
            <h2 class="h5" id="holdsHeading">Service Hold — Affected Work</h2>
            <dl class="mb-0">
                <?php foreach ($summary['service_holds'] as $hold): ?>
                    <dt><?= $escape($taskNames[$hold['task_id']] ?? 'Affected service') ?><?php if ($hold['released_at']): ?> <small class="text-muted fw-normal">Released</small><?php endif; ?></dt>
                    <dd><?= $escape($hold['reason']) ?><?php if (!$hold['released_at']): ?><br><strong>To resume</strong> <?= $escape($hold['resume_conditions']) ?><?php endif; ?></dd>
                <?php endforeach; ?>
            </dl>
        </section>
    <?php endif; ?>

    <section class="customer-card mb-3" aria-labelledby="billingHeading">
        <h2 class="h5" id="billingHeading">Billing</h2>
        <?php if ($bill): ?>
            <dl class="row">
                <dt class="col-sm-8">Completed services</dt><dd class="col-sm-4"><?= $money($bill['gross_amount']) ?></dd>
                <dt class="col-sm-8">Reservation fee credit</dt><dd class="col-sm-4"><?= $money($bill['reservation_fee_credit']) ?></dd>
                <dt class="col-sm-8">Final balance</dt><dd class="col-sm-4"><?= $money($bill['amount_due']) ?></dd>
            </dl>
            <a href="<?= BASE_URL ?>/customer/payments.php">View payment status</a>
        <?php else: ?>
            <p class="mb-0">The shop will prepare your final bill after confirming the authorized services performed.</p>
        <?php endif; ?>
    </section>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/customer_footer.php'; ?>
