<?php
declare(strict_types=1);

require_once __DIR__ . '/service_workflow.php';
require_once __DIR__ . '/payment_balance.php';

function serviceWorkflowStaffTransaction(
    mysqli $conn,
    int $reservationId,
    int $actor,
    bool $adviserOnly,
    callable $operation
): mixed {
    $conn->begin_transaction();
    try {
        $job = serviceWorkflowLock($conn, $reservationId);
        $staff = $conn->execute_query(
            "SELECT staff_level, mechanic_id FROM users WHERE id=? AND role='staff' FOR UPDATE",
            [$actor]
        )->fetch_assoc();
        $adviser = in_array($staff['staff_level'] ?? null, ['Manager', 'Service Adviser'], true);
        $mechanic = ($staff['staff_level'] ?? null) === 'Mechanic' &&
            (int) $staff['mechanic_id'] > 0 && (int) $staff['mechanic_id'] === (int) $job['mechanic_id'];
        if (!$adviser && ($adviserOnly || !$mechanic)) {
            throw new DomainException('This staff account cannot perform this action for the booking.');
        }
        $result = $operation($job, $adviser);
        $conn->commit();
        return $result;
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function serviceWorkflowStaffText(mixed $value, int $limit, string $label): string
{
    if (!is_string($value) || !mb_check_encoding($value, 'UTF-8')) {
        throw new DomainException('Enter ' . $label . '.');
    }
    $value = trim($value);
    if ($value === '' || mb_strlen($value, 'UTF-8') > $limit) {
        throw new DomainException('Enter ' . $label . ' within ' . $limit . ' characters.');
    }
    return $value;
}

function serviceWorkflowRequireActiveWork(array $job, bool $requireInspection = true): void
{
    if (!in_array($job['status'], ['Diagnosing', 'In Progress'], true)) {
        throw new ServiceWorkflowConflict('The booking is outside the inspection and work stages.');
    }
    if (empty($job['checked_in_at']) || !(int) $job['mechanic_id']) {
        throw new ServiceWorkflowConflict('Check in the vehicle and assign a mechanic before recording service work.');
    }
    $appointment = new DateTimeImmutable(
        $job['appointment_date'] . ' ' . $job['appointment_time'],
        new DateTimeZone('Asia/Manila')
    );
    if ($appointment->getTimestamp() > time()) {
        throw new ServiceWorkflowConflict('Inspection and work open at the reserved appointment time.');
    }
    if ($requireInspection && empty($job['inspection_completed_at'])) {
        throw new ServiceWorkflowConflict('Complete the inspection before recording service work.');
    }
}

function serviceWorkflowCompleteInspection(
    mysqli $conn,
    int $reservationId,
    int $actor,
    string $notes
): void {
    $notes = serviceWorkflowStaffText($notes, 4000, 'the inspection result');
    serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $notes
    ): void {
        serviceWorkflowRequireActiveWork($job, false);
        if (!empty($job['inspection_completed_at'])) {
            throw new ServiceWorkflowConflict('Inspection completion has already been recorded.');
        }
        $conn->execute_query(
            'UPDATE service_workflow_jobs SET inspection_completed_at=NOW(), inspection_completed_by=? WHERE reservation_id=?',
            [$actor, $reservationId]
        );
        $conn->execute_query('UPDATE reservations SET diagnosis=? WHERE id=?', [$notes, $reservationId]);
        serviceWorkflowEvent($conn, $job, $actor, 'inspection_completed', ['notes' => $notes]);
    });
}

function serviceWorkflowRecordFinding(mysqli $conn, int $reservationId, int $actor, string $description): int
{
    $description = serviceWorkflowStaffText($description, 1000, 'the inspection finding');
    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $description
    ): int {
        serviceWorkflowRequireActiveWork($job, false);
        $conn->execute_query(
            'INSERT INTO service_workflow_findings (reservation_id,description,recorded_by) VALUES (?,?,?)',
            [$reservationId, $description, $actor]
        );
        $findingId = (int) $conn->insert_id;
        serviceWorkflowEvent($conn, $job, $actor, 'finding_recorded', ['finding_id' => $findingId]);
        return $findingId;
    });
}

function serviceWorkflowRecordGuestResponse(
    mysqli $conn,
    int $reservationId,
    int $actor,
    int $revisionId,
    ?string $allDecision,
    array $decisions,
    string $evidence
): array {
    $context = [
        'source' => 'Staff documented guest response',
        'confirmation' => serviceWorkflowStaffText($evidence, 500, 'the reference to the guest’s documented confirmation'),
    ];
    $requestKey = serviceWorkflowDecisionKey($actor, $revisionId, $allDecision, $decisions, $context);

    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, true, function (array $job) use (
        $conn, $reservationId, $actor, $revisionId, $allDecision, $decisions, $requestKey, $context
    ): array {
        if ($job['user_id'] !== null) {
            throw new DomainException('The linked customer must respond to this quotation.');
        }
        $revision = serviceWorkflowLatestRevision($conn, $reservationId);
        if (!$revision || (int) $revision['id'] !== $revisionId) {
            throw new ServiceWorkflowConflict('This quotation has changed. Confirm the latest quotation with the guest.');
        }
        $retry = $conn->execute_query('SELECT id FROM service_workflow_events WHERE reservation_id = ? AND request_key = ?',
            [$reservationId, $requestKey])->fetch_assoc();
        if (!$retry) {
            serviceWorkflowApplyDecision($conn, $job, $revision, $actor, $allDecision, $decisions, $requestKey, $context);
        }
        return serviceWorkflowSummary($conn, $reservationId);
    });
}

function serviceWorkflowSendQuote(
    mysqli $conn,
    int $reservationId,
    int $actor,
    string $requestKey,
    array $items,
    ?string $validUntil = null,
    ?int $expectedRevisionId = null
): array {
    if (!preg_match('/\A[a-zA-Z0-9_.:-]{16,64}\z/D', $requestKey) || !array_is_list($items) ||
        !$items || count($items) > 50 || ($expectedRevisionId !== null && $expectedRevisionId < 0)) {
        throw new DomainException('Send a valid request key and one to fifty additional repairs.');
    }
    if ($validUntil !== null) {
        $expiry = DateTimeImmutable::createFromFormat('!Y-m-d', $validUntil);
        if (!$expiry || $expiry->format('Y-m-d') !== $validUntil) {
            throw new DomainException('Use a valid quotation expiry date.');
        }
    }
    $normalized = [];
    $keys = [];
    $maxCents = 9_999_999_999;
    $quoteTotal = 0;
    foreach ($items as $item) {
        if (!is_array($item) || (!is_int($item['finding_id'] ?? null) && !is_string($item['finding_id'] ?? null))) {
            throw new DomainException('Select a recorded finding for each additional repair.');
        }
        $findingId = filter_var($item['finding_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($findingId === false) {
            throw new DomainException('Select a recorded finding for each additional repair.');
        }
        $name = serviceWorkflowStaffText($item['name'] ?? null, 255, 'the repair name');
        $description = serviceWorkflowStaffText($item['description'] ?? null, 1000, 'the repair explanation');
        $advisory = $item['advisory'] ?? null;
        if ($advisory !== null && $advisory !== '') {
            $advisory = serviceWorkflowStaffText($advisory, 1000, 'the safety advisory');
        } else {
            $advisory = null;
        }
        $quantity = serviceWorkflowMoneyToCents($item['quantity'] ?? 1);
        $price = serviceWorkflowMoneyToCents($item['unit_price'] ?? null);
        if ($quantity < 1 || $quantity > $maxCents || $price < 0 || $price > $maxCents ||
            ($price > 0 && $quantity > intdiv($maxCents * 100 + 49, $price))) {
            throw new DomainException('Enter a valid quantity and price for each additional repair.');
        }
        $amount = intdiv($quantity * $price + 50, 100);
        $quoteTotal += $amount;
        if ($quoteTotal > $maxCents) {
            throw new DomainException('The total additional repair price exceeds the supported amount.');
        }
        $lineKey = $findingId . ':' . mb_strtolower($name, 'UTF-8');
        if (isset($keys[$lineKey])) {
            throw new DomainException('Each repair name must be distinct within its recorded finding.');
        }
        $keys[$lineKey] = true;
        $normalized[] = [
            $findingId, $name, $description, $advisory, serviceWorkflowCentsToMoney($quantity),
            serviceWorkflowCentsToMoney($price), serviceWorkflowCentsToMoney($amount),
        ];
    }
    $payload = [$validUntil, $normalized];
    if ($expectedRevisionId !== null) {
        $payload[] = $expectedRevisionId;
    }
    $hash = hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR));

    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, true, function (array $job) use (
        $conn, $reservationId, $actor, $requestKey, $validUntil, $normalized, $hash, $quoteTotal, $maxCents, $expectedRevisionId
    ): array {
        $previous = $conn->execute_query(
            'SELECT id,version,request_hash FROM service_workflow_revisions WHERE reservation_id=? AND request_key=?',
            [$reservationId, $requestKey]
        )->fetch_assoc();
        if ($previous) {
            if (!hash_equals($previous['request_hash'], $hash)) {
                throw new ServiceWorkflowConflict('This publication request already has different quotation details.');
            }
            return ['id' => (int) $previous['id'], 'version' => (int) $previous['version']];
        }
        serviceWorkflowRequireActiveWork($job);
        if ($expectedRevisionId !== null) {
            $currentRevision = serviceWorkflowLatestRevision($conn, $reservationId);
            if ((int) ($currentRevision['id'] ?? 0) !== $expectedRevisionId) {
                throw new ServiceWorkflowConflict('The quotation changed while you were editing. Review the latest revision before sending.');
            }
        }
        if ($validUntil !== null && $validUntil < (new DateTimeImmutable('today', new DateTimeZone('Asia/Manila')))->format('Y-m-d')) {
            throw new DomainException('The quotation expiry date has passed.');
        }
        $authorized = $conn->execute_query(
            "SELECT COALESCE(SUM(amount),0) AS total FROM service_workflow_tasks WHERE reservation_id=? AND decision='Accepted'",
            [$reservationId]
        )->fetch_assoc()['total'];
        if (serviceWorkflowMoneyToCents($authorized) + $quoteTotal > $maxCents) {
            throw new DomainException('The proposed total exceeds the supported billing amount.');
        }
        foreach ($normalized as [$findingId, $name]) {
            $finding = $conn->execute_query(
                'SELECT id FROM service_workflow_findings WHERE reservation_id=? AND id=?',
                [$reservationId, $findingId]
            )->fetch_assoc();
            if (!$finding) {
                throw new DomainException('Select a recorded finding from this booking for each repair.');
            }
            $alreadyAuthorized = $conn->execute_query(
                "SELECT id FROM service_workflow_tasks WHERE reservation_id=? AND finding_id=? AND name=? AND decision='Accepted' LIMIT 1",
                [$reservationId, $findingId, $name]
            )->fetch_assoc();
            if ($alreadyAuthorized) {
                throw new ServiceWorkflowConflict('An additional repair for this finding is already authorized under that name.');
            }
        }
        $version = (int) $conn->execute_query(
            'SELECT COALESCE(MAX(version),0)+1 AS next_version FROM service_workflow_revisions WHERE reservation_id=?',
            [$reservationId]
        )->fetch_assoc()['next_version'];
        $conn->execute_query(
            'INSERT INTO service_workflow_revisions (reservation_id,version,request_key,request_hash,valid_until,sent_by) VALUES (?,?,?,?,?,?)',
            [$reservationId, $version, $requestKey, $hash, $validUntil, $actor]
        );
        $revisionId = (int) $conn->insert_id;
        $conn->execute_query(
            "UPDATE service_workflow_tasks SET decision='Withdrawn',decided_by=?,decided_at=NOW()
             WHERE reservation_id=? AND revision_id IS NOT NULL AND decision='Pending'",
            [$actor, $reservationId]
        );
        $superseded = $conn->affected_rows;
        foreach ($normalized as $row) {
            $conn->execute_query(
                "INSERT INTO service_workflow_tasks
                 (reservation_id,revision_id,finding_id,name,description,advisory,quantity,unit_price,amount,decision)
                 VALUES (?,?,?,?,?,?,?,?,?,'Pending')",
                [$reservationId, $revisionId, ...$row]
            );
        }
        serviceWorkflowEvent(
            $conn, $job, $actor, 'quotation_sent',
            ['revision_id' => $revisionId, 'version' => $version, 'withdrawn_items' => $superseded],
            'Additional repairs for your review',
            'Additional vehicle issues were identified. Please review the recommended repairs and quotation.'
        );
        return ['id' => $revisionId, 'version' => $version];
    });
}

function serviceWorkflowStaffRemainingWork(mysqli $conn, int $reservationId): array
{
    $rows = $conn->execute_query(
        "SELECT t.id, EXISTS(
             SELECT 1 FROM service_workflow_holds h WHERE h.reservation_id=t.reservation_id AND h.task_id=t.id AND h.released_at IS NULL
         ) AS held
         FROM service_workflow_tasks t
         WHERE t.reservation_id=? AND t.decision='Accepted' AND t.work_status IN ('Awaiting Work','In Progress')
         ORDER BY t.id",
        [$reservationId]
    )->fetch_all(MYSQLI_ASSOC);
    return array_column($rows, 'held', 'id');
}

function serviceWorkflowDocumentFullHold(
    mysqli $conn,
    array $job,
    int $actor,
    array $remaining,
    ?string $review
): void {
    if (!empty($job['full_hold_at']) || !$remaining || in_array(false, array_map('boolval', $remaining), true)) {
        return;
    }
    $review = serviceWorkflowStaffText($review, 500, 'the review of why all remaining work is on hold');
    $conn->execute_query(
        'UPDATE service_workflow_jobs SET full_hold_at=NOW() WHERE reservation_id=?',
        [(int) $job['id']]
    );
    serviceWorkflowEvent(
        $conn, $job, $actor, 'all_remaining_work_held',
        ['task_ids' => array_keys($remaining), 'review' => $review]
    );
}

function serviceWorkflowSetTaskStatus(
    mysqli $conn,
    int $reservationId,
    int $actor,
    int $taskId,
    string $status,
    ?string $reason = null,
    ?string $fullHoldReview = null
): void {
    if (!in_array($status, ['In Progress', 'Completed', 'Not Performed'], true)) {
        throw new DomainException('Choose a valid work action.');
    }
    if ($status === 'Not Performed') {
        $reason = serviceWorkflowStaffText($reason, 500, 'the reason this authorized service will not be performed');
    }
    serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job, bool $adviser) use (
        $conn, $reservationId, $actor, $taskId, $status, $reason, $fullHoldReview
    ): void {
        serviceWorkflowRequireActiveWork($job);
        $task = $conn->execute_query(
            'SELECT id,revision_id,decision,work_status FROM service_workflow_tasks WHERE reservation_id=? AND id=?',
            [$reservationId, $taskId]
        )->fetch_assoc();
        if (!$task || $task['decision'] !== 'Accepted') {
            throw new ServiceWorkflowConflict('Only an authorized service may be worked on.');
        }
        $remaining = serviceWorkflowStaffRemainingWork($conn, $reservationId);
        if ($task['work_status'] === $status && $status !== 'In Progress') {
            return;
        }
        if (!isset($remaining[$taskId])) {
            throw new ServiceWorkflowConflict('This service already has a final work outcome.');
        }
        $held = (bool) $remaining[$taskId];
        if ($status === 'Not Performed' && $held && !$adviser) {
            throw new DomainException('A service adviser or manager must record the disposition of work held for safety.');
        }
        if (($status !== 'Not Performed' && $held) ||
            ($status === 'Completed' && $task['work_status'] !== 'In Progress')) {
            throw new ServiceWorkflowConflict('Only work started safely can be marked complete. Resolve any active hold first.');
        }
        if ($status === 'In Progress' && !empty($job['full_hold_at'])) {
            $review = serviceWorkflowStaffText($fullHoldReview, 500, 'the review confirming this service can proceed safely');
            $conn->execute_query('UPDATE service_workflow_jobs SET full_hold_at=NULL WHERE reservation_id=?', [$reservationId]);
            serviceWorkflowEvent($conn, $job, $actor, 'full_hold_reviewed', ['task_id' => $taskId, 'review' => $review]);
        }
        if ($task['work_status'] === $status) {
            return;
        }
        if ($status !== 'In Progress' && !$held) {
            unset($remaining[$taskId]);
            serviceWorkflowDocumentFullHold($conn, $job, $actor, $remaining, $fullHoldReview);
        }
        $conn->execute_query(
            'UPDATE service_workflow_tasks SET work_status=? WHERE reservation_id=? AND id=?',
            [$status, $reservationId, $taskId]
        );
        serviceWorkflowEvent($conn, $job, $actor, 'work_status_changed', [
            'task_id' => $taskId, 'previous_status' => $task['work_status'], 'status' => $status,
            'reason' => $status === 'Not Performed' ? $reason : null,
        ]);
        if ($status !== 'In Progress') {
            return;
        }
        if ($job['status'] === 'Diagnosing') {
            $conn->execute_query("UPDATE reservations SET status='In Progress' WHERE id=?", [$reservationId]);
        }
        $mayNotify = $task['revision_id'] === null && !$conn->execute_query(
            "SELECT id FROM service_workflow_events WHERE reservation_id=? AND event_type='original_work_started' LIMIT 1",
            [$reservationId]
        )->fetch_assoc();
        if ($mayNotify) {
            $hasFindings = (bool) $conn->execute_query(
                'SELECT id FROM service_workflow_findings WHERE reservation_id=? LIMIT 1',
                [$reservationId]
            )->fetch_assoc();
            serviceWorkflowEvent(
                $conn, $job, $actor, 'original_work_started', ['task_id' => $taskId],
                $hasFindings ? null : 'Original services underway',
                $hasFindings ? null : 'Vehicle inspection completed. Your originally booked services are now being performed.'
            );
        }
    });
}

function serviceWorkflowAddAdvisory(mysqli $conn, int $reservationId, int $actor, string $message): int
{
    $message = serviceWorkflowStaffText($message, 1000, 'the safety advisory');
    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $message
    ): int {
        serviceWorkflowRequireActiveWork($job, false);
        $conn->execute_query(
            'INSERT INTO service_workflow_advisories (reservation_id,message,recorded_by) VALUES (?,?,?)',
            [$reservationId, $message, $actor]
        );
        $advisoryId = (int) $conn->insert_id;
        $hasDeclinedRepair = (bool) $conn->execute_query(
            "SELECT id FROM service_workflow_tasks WHERE reservation_id=? AND revision_id IS NOT NULL AND decision='Rejected' LIMIT 1",
            [$reservationId]
        )->fetch_assoc();
        serviceWorkflowEvent(
            $conn, $job, $actor, 'advisory_recorded', ['advisory_id' => $advisoryId],
            'Safety advisory',
            $hasDeclinedRepair
                ? 'An additional vehicle concern was identified. Your declined repair has been recorded. Please review the safety advisory.'
                : 'An additional vehicle concern was identified. Please review the safety advisory.'
        );
        return $advisoryId;
    });
}

function serviceWorkflowResolveAdvisory(
    mysqli $conn,
    int $reservationId,
    int $actor,
    int $advisoryId,
    string $reason
): void {
    $reason = serviceWorkflowStaffText($reason, 500, 'why the safety advisory was resolved');
    serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $advisoryId, $reason
    ): void {
        serviceWorkflowRequireActiveWork($job, false);
        $conn->execute_query(
            'UPDATE service_workflow_advisories SET resolved_at=NOW(),resolved_by=?,resolution_reason=?
             WHERE reservation_id=? AND id=? AND resolved_at IS NULL',
            [$actor, $reason, $reservationId, $advisoryId]
        );
        if (!$conn->affected_rows) {
            throw new ServiceWorkflowConflict('This booking has no open advisory with that reference.');
        }
        serviceWorkflowEvent($conn, $job, $actor, 'advisory_resolved', ['advisory_id' => $advisoryId, 'reason' => $reason]);
    });
}

function serviceWorkflowAddHolds(
    mysqli $conn,
    int $reservationId,
    int $actor,
    array $taskIds,
    string $reason,
    string $resumeConditions,
    ?string $fullHoldReview = null
): array {
    $reason = serviceWorkflowStaffText($reason, 500, 'the reason work is on hold');
    $resumeConditions = serviceWorkflowStaffText($resumeConditions, 500, 'the conditions for safely continuing work');
    if (!array_is_list($taskIds) || !$taskIds || count($taskIds) !== count(array_unique($taskIds, SORT_REGULAR))) {
        throw new DomainException('Select the affected authorized services.');
    }
    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $taskIds, $reason, $resumeConditions, $fullHoldReview
    ): array {
        serviceWorkflowRequireActiveWork($job, false);
        $remaining = serviceWorkflowStaffRemainingWork($conn, $reservationId);
        foreach ($taskIds as $id) {
            if (!is_int($id) || !isset($remaining[$id]) || (bool) $remaining[$id]) {
                throw new ServiceWorkflowConflict('Service holds require an authorized unfinished task without an active hold.');
            }
            $remaining[$id] = true;
        }
        serviceWorkflowDocumentFullHold($conn, $job, $actor, $remaining, $fullHoldReview);
        $holdIds = [];
        foreach ($taskIds as $id) {
            $conn->execute_query(
                'INSERT INTO service_workflow_holds (reservation_id,task_id,reason,resume_conditions,recorded_by) VALUES (?,?,?,?,?)',
                [$reservationId, $id, $reason, $resumeConditions, $actor]
            );
            $holdIds[] = (int) $conn->insert_id;
        }
        serviceWorkflowEvent(
            $conn, $job, $actor, 'service_hold_recorded',
            ['hold_ids' => $holdIds, 'task_ids' => $taskIds, 'reason' => $reason],
            'Service hold',
            'Some service work is temporarily on hold due to a documented safety concern.'
        );
        return $holdIds;
    });
}

function serviceWorkflowReleaseHold(
    mysqli $conn,
    int $reservationId,
    int $actor,
    int $holdId,
    string $reason
): void {
    $reason = serviceWorkflowStaffText($reason, 500, 'why the service hold can be closed safely');
    serviceWorkflowStaffTransaction($conn, $reservationId, $actor, false, function (array $job) use (
        $conn, $reservationId, $actor, $holdId, $reason
    ): void {
        serviceWorkflowRequireActiveWork($job, false);
        $hold = $conn->execute_query(
            'SELECT task_id FROM service_workflow_holds WHERE reservation_id=? AND id=? AND released_at IS NULL',
            [$reservationId, $holdId]
        )->fetch_assoc();
        if (!$hold) {
            throw new ServiceWorkflowConflict('This booking has no open service hold with that reference.');
        }
        $remaining = serviceWorkflowStaffRemainingWork($conn, $reservationId);
        $conn->execute_query(
            'UPDATE service_workflow_holds SET released_at=NOW(),released_by=?,release_reason=?
             WHERE reservation_id=? AND id=? AND released_at IS NULL',
            [$actor, $reason, $reservationId, $holdId]
        );
        if (!empty($job['full_hold_at']) && (!$remaining || isset($remaining[(int) $hold['task_id']]))) {
            $conn->execute_query('UPDATE service_workflow_jobs SET full_hold_at=NULL WHERE reservation_id=?', [$reservationId]);
            serviceWorkflowEvent($conn, $job, $actor, 'full_hold_reviewed', ['hold_id' => $holdId, 'review' => $reason]);
        }
        serviceWorkflowEvent($conn, $job, $actor, 'service_hold_released', ['hold_id' => $holdId, 'reason' => $reason]);
    });
}

function serviceWorkflowFinalizeBill(mysqli $conn, int $reservationId, int $actor): array
{
    return serviceWorkflowStaffTransaction($conn, $reservationId, $actor, true, function (array $job) use (
        $conn, $reservationId, $actor
    ): array {
        $prior = $conn->execute_query(
            'SELECT payment_id FROM service_workflow_bills WHERE reservation_id=?',
            [$reservationId]
        )->fetch_assoc();
        if ($prior) {
            return serviceWorkflowBillForPayment($conn, (int) $prior['payment_id']);
        }
        serviceWorkflowRequireActiveWork($job);
        if (!empty($job['full_hold_at']) || serviceWorkflowStaffRemainingWork($conn, $reservationId) || $conn->execute_query(
            'SELECT id FROM service_workflow_holds WHERE reservation_id=? AND released_at IS NULL LIMIT 1',
            [$reservationId]
        )->fetch_assoc()) {
            throw new ServiceWorkflowConflict('Record a final outcome for authorized services and resolve active holds before finalizing the bill.');
        }
        $verifiedFees = $conn->execute_query(
            "SELECT id FROM payments WHERE reservation_id=? AND payment_type='Reservation Fee'
             AND status='Paid' AND refund_status IN ('Not Applicable','Rejected') FOR UPDATE",
            [$reservationId]
        );
        if ($verifiedFees->num_rows > 1) {
            throw new ServiceWorkflowConflict('Reconcile the duplicate verified reservation fees before finalizing the bill.');
        }

        $payments = $conn->execute_query(
            "SELECT id,payment_type,status,amount FROM payments
             WHERE reservation_id=? AND payment_type IN ('Final Balance','Additional Work') ORDER BY id FOR UPDATE",
            [$reservationId]
        )->fetch_all(MYSQLI_ASSOC);
        $finalBalanceCount = 0;
        foreach ($payments as $payment) {
            if ($payment['payment_type'] === 'Final Balance') {
                $finalBalanceCount++;
            } elseif ($payment['status'] !== 'Cancelled' && serviceWorkflowMoneyToCents($payment['amount']) > 0) {
                throw new ServiceWorkflowConflict('Reconcile the existing additional-work payment before finalizing the bill.');
            }
        }
        if ($finalBalanceCount > 1) {
            throw new ServiceWorkflowConflict('Reconcile the existing final balance records before finalizing the bill.');
        }
        $services = $conn->execute_query(
            "SELECT id,revision_id,name,description,quantity,unit_price,amount
             FROM service_workflow_tasks
             WHERE reservation_id=? AND decision='Accepted' AND work_status='Completed' ORDER BY id",
            [$reservationId]
        )->fetch_all(MYSQLI_ASSOC);
        $gross = 0;
        foreach ($services as $service) {
            $gross += serviceWorkflowMoneyToCents($service['amount']);
        }
        if ($gross > 9_999_999_999) {
            throw new ServiceWorkflowConflict('The completed service total exceeds the supported billing amount.');
        }
        $paymentId = createFinalBalance($conn, $reservationId, (float) serviceWorkflowCentsToMoney($gross));
        $payment = $conn->execute_query(
            'SELECT status,amount,gross_amount,reservation_fee_credit FROM payments WHERE id=? FOR UPDATE',
            [$paymentId]
        )->fetch_assoc();
        if (!$payment || $payment['status'] === 'Cancelled' ||
            serviceWorkflowMoneyToCents($payment['gross_amount']) !== $gross ||
            serviceWorkflowMoneyToCents($payment['amount']) + serviceWorkflowMoneyToCents($payment['reservation_fee_credit']) !== $gross) {
            throw new ServiceWorkflowConflict('The final balance does not match the completed services. Reconcile the payment before proceeding.');
        }
        $conn->execute_query(
            'INSERT INTO service_workflow_bills
             (reservation_id,payment_id,gross_amount,reservation_fee_credit,amount_due,lines_json,finalized_by) VALUES (?,?,?,?,?,?,?)',
            [
                $reservationId, $paymentId, $payment['gross_amount'], $payment['reservation_fee_credit'], $payment['amount'],
                json_encode($services, JSON_THROW_ON_ERROR), $actor,
            ]
        );
        $conn->execute_query(
            "UPDATE service_workflow_tasks SET decision='Withdrawn',decided_by=?,decided_at=NOW()
             WHERE reservation_id=? AND revision_id IS NOT NULL AND decision='Pending'",
            [$actor, $reservationId]
        );
        $withdrawn = $conn->affected_rows;
        $conn->execute_query("UPDATE reservations SET status='Ready for Pickup' WHERE id=?", [$reservationId]);
        serviceWorkflowEvent(
            $conn, $job, $actor, 'bill_finalized',
            ['payment_id' => $paymentId, 'charged_tasks' => array_column($services, 'id'), 'withdrawn_items' => $withdrawn],
            'Vehicle ready for pickup',
            'Your vehicle is ready for pickup. Review your service summary and final balance.'
        );
        return serviceWorkflowBillForPayment($conn, $paymentId);
    });
}
