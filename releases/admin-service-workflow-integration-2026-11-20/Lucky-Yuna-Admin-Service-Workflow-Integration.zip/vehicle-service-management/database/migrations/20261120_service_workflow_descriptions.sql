-- Apply after 20261120_service_workflow.sql. Preserve full original catalog descriptions.
ALTER TABLE service_workflow_tasks MODIFY COLUMN description TEXT NOT NULL;
