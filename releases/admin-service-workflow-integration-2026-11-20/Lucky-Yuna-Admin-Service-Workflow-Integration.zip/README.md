# Lucky Yuna Admin Service Workflow Integration

Para sa XAMPP test copy na may Lucky Yuna Service Workflow Core update at
na-import na ang core migration na 20261120_service_workflow.sql. Kailangan
ng PHP 8.2 o mas bago na may mysqli at mbstring.

## I-merge sa test project

1. I-backup ang existing project files at test database.
2. Sa File Explorer, i-merge ang laman ng bawat folder sa ZIP sa katumbas
   na existing folder ng project. Parehong folder ang kailangang ma-update.
   - vehicle-service-management-admin
   - vehicle-service-management
3. Sa phpMyAdmin, piliin ang database ng test project at i-import ang
   vehicle-service-management/database/migrations/20261120_service_workflow_descriptions.sql.
   Pinapalawak nito ang storage para sa buong original service description.
4. Buksan ang Admin Website at i-check na nabubuksan ang existing jobs.
   Panatilihing off ang LYC_SERVICE_WORKFLOW_ENABLED hanggang handa ang
   Flutter integration at ang integrated pilot sa test environment.

## Staff workflow

1. Confirm appointment, check in at assign ang mechanic gamit ang existing
   controls. Simulan ang inspection at i-save ang resulta sa job workspace.
2. Simulan ang safe original services. Kapag may bagong finding, i-record
   iyon para makagawa ang service adviser o manager ng additional quotation.
3. Approved additional repairs lang ang puwedeng simulan. May sariling
   actions ang safety advisories at holds para sa mga apektadong task.
4. Tapusin o i-document ang disposition ng bawat authorized task.
   Ang adviser o manager ang magfi-finalize ng bill. I-verify ng cashier
   ang balance bago gamitin ang Release & complete.
5. Sa walk-in, kapag enabled ang workflow, puwedeng i-record ng adviser
   ang customer authorization ng nakalistang serbisyo at presyo.

Gumagana pa rin ang legacy editor para sa existing bookings. Ang updated
core helper sa package ay nagba-block ng pagpapadala mula sa lumang
quotation revision habang may mas bagong revision na.

## Verification

Na-test sa disposable MariaDB at PHP HTTP fixtures ang confirmation,
check-in, inspection, role at CSRF checks, original work na walang quote,
partial at full holds, stale at duplicate quotation requests, documented
guest decision, walk-in authorization, exact billing, cashier verification
at release. Sinubukan din ang legacy jobs, wallet proof at refunds.
