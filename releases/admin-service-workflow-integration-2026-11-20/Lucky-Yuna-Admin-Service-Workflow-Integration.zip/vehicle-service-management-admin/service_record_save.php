<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/workflow_integration.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('POST required.');}
$id=(int)($_POST['reservation_id']??0);$job=adminRequireJob($conn,$id);
if(in_array($job['status'],['Completed','Cancelled'],true)){$_SESSION['admin_flash']=['type'=>'warning','message'=>'This job is closed. Its service record is read-only.'];header('Location: reservation_view.php?id='.$id);exit;}
$data = [];
foreach (['intake_mileage', 'completion_notes', 'next_service_date'] as $field) {
    $data[$field] = $_POST[$field] ?? '';
    if (!is_string($data[$field])) {
        http_response_code(422);
        exit('Check the submitted service record.');
    }
}
$mileage = $data['intake_mileage'] === '' ? null : max(0, (int) $data['intake_mileage']);
$notes = trim($data['completion_notes']);
$next = trim($data['next_service_date']) ?: null;
if($next){$dt=DateTimeImmutable::createFromFormat('!Y-m-d',$next);if(!$dt||$dt->format('Y-m-d')!==$next){http_response_code(422);exit('Choose a valid next service date.');}}
$scope = " WHERE id=? AND status NOT IN ('Completed','Cancelled')" . adminJobScope('r');
$workflowBooking = adminWorkflowIsBooking($conn, $id);
if ($workflowBooking) {
    $stmt = $conn->prepare('UPDATE reservations r SET intake_mileage=?, completion_notes=?, next_service_date=?' . $scope);
    $stmt->bind_param('issi', $mileage, $notes, $next, $id);
    $description = 'Mileage, completion notes and maintenance date saved.';
} else {
    $diagnosis = $_POST['diagnosis'] ?? '';
    $work = $_POST['work_performed'] ?? '';
    if (!is_string($diagnosis) || !is_string($work)) {
        http_response_code(422);
        exit('Check the submitted service record.');
    }
    $diagnosis = trim($diagnosis);
    $work = trim($work);
    $stmt = $conn->prepare('UPDATE reservations r SET intake_mileage=?, diagnosis=?, work_performed=?, completion_notes=?, next_service_date=?' . $scope);
    $stmt->bind_param('issssi', $mileage, $diagnosis, $work, $notes, $next, $id);
    $description = 'Diagnosis, work, mileage, completion notes and maintenance date saved.';
}
$stmt->execute();
$stmt->close();
adminAudit($conn, 'Updated service record', 'reservation', $id, $description);
$_SESSION['admin_flash']=['type'=>'success','message'=>'Service record saved.'];
header('Location: reservation_view.php?id=' . $id . ($workflowBooking ? '#job-workflow' : '#job-record'), true, 303);
exit;
