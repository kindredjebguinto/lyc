<?php
$workflow = adminWorkflowSummary($conn, $reservation_id);
if (!$workflow) {
    http_response_code(503);
    exit('The service workflow is unavailable. Reopen the reservation and try again.');
}

$actor = (int)$_SESSION['admin_id'];
$linkedCustomer = $reservation['user_id'] !== null;
$pageUrl = ADMIN_BASE_URL . '/job_quotation.php?id=' . $reservation_id;
$jobUrl = ADMIN_BASE_URL . '/reservation_view.php?id=' . $reservation_id;
$error = '';
$submittedItems = [];
$submittedExpiry = null;
$submittedRequestKey = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!adminCan('quotes') || !adminCan('jobs.manage')) adminDeny();
        $action = $_POST['workflow_quote_action'] ?? null;
        if ($action === 'send') {
            $requestKey = $_POST['request_key'] ?? null;
            $items = $_POST['items'] ?? null;
            $expiry = $_POST['valid_until'] ?? '';
            $expectedRevisionId = filter_var($_POST['expected_revision_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
            if (!is_string($requestKey) || !is_array($items) || !is_string($expiry) || $expectedRevisionId === false) {
                throw new DomainException('Enter the quotation details and refresh the form if it expired.');
            }
            $items = array_values($items);
            $result = serviceWorkflowSendQuote(
                $conn, $reservation_id, $actor, $requestKey, $items, $expiry === '' ? null : $expiry,
                expectedRevisionId: $expectedRevisionId
            );
            $_SESSION['admin_flash'] = ['type' => 'success', 'message' => 'Quotation revision ' . $result['version'] . ' was published.'];
        } elseif ($action === 'guest_response') {
            if ($linkedCustomer) adminDeny('The linked customer must respond to this quotation.');
            $revisionId = filter_var($_POST['revision_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $evidence = $_POST['guest_evidence'] ?? null;
            $scope = $_POST['decision_scope'] ?? null;
            $choices = $_POST['decisions'] ?? [];
            if ($revisionId === false || !is_string($evidence) || !in_array($scope, ['selected', 'Accepted', 'Rejected'], true) || !is_array($choices)) {
                throw new DomainException('Select the guest’s documented decision.');
            }
            $decisions = [];
            foreach ($choices as $id => $choice) {
                if ($choice === '') continue;
                $id = filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($id === false || !in_array($choice, ['Accepted', 'Rejected'], true)) {
                    throw new DomainException('Select the documented guest decision for each chosen repair.');
                }
                $decisions[$id] = $choice;
            }
            if (($scope === 'selected') === ($decisions === [])) {
                throw new DomainException('Record decisions for selected repairs or choose a decision for all pending repairs.');
            }
            serviceWorkflowRecordGuestResponse($conn, $reservation_id, $actor, $revisionId, $scope === 'selected' ? null : $scope, $decisions, $evidence);
            $_SESSION['admin_flash'] = ['type' => 'success', 'message' => 'The guest’s documented decision was recorded.'];
        } else {
            throw new DomainException('Choose a valid quotation action.');
        }
        header('Location: ' . $jobUrl, true, 303);
        exit;
    } catch (ServiceWorkflowConflict $exception) {
        http_response_code(409);
        $error = $exception->getMessage();
        $workflow = adminWorkflowSummary($conn, $reservation_id);
    } catch (DomainException $exception) {
        http_response_code(422);
        $error = $exception->getMessage();
        if (($action ?? null) === 'send' && isset($items) && is_array($items) && count($items) <= 50) {
            $submittedItems = array_values(array_filter($items, 'is_array'));
            $submittedExpiry = is_string($expiry ?? null) ? $expiry : null;
            if (is_string($requestKey ?? null) && preg_match('/\A[a-zA-Z0-9_.:-]{16,64}\z/', $requestKey)) {
                $submittedRequestKey = $requestKey;
            }
        }
    } catch (Throwable $exception) {
        http_response_code(500);
        $error = 'The quotation action could not be saved. Refresh and check the booking before trying again.';
    }
}

$quotation = $workflow['quotation'];
$revisionId = (int)($quotation['id'] ?? 0);
$findings = $conn->execute_query('SELECT id,description FROM service_workflow_findings WHERE reservation_id=? ORDER BY id', [$reservation_id])->fetch_all(MYSQLI_ASSOC);
$pendingItems = $revisionId > 0 ? $conn->execute_query("SELECT finding_id,name,description,advisory,quantity,unit_price
    FROM service_workflow_tasks WHERE reservation_id=? AND revision_id=? AND decision='Pending' ORDER BY id", [$reservation_id, $revisionId])->fetch_all(MYSQLI_ASSOC) : [];
$formItems = $submittedItems ?: ($pendingItems ?: [[]]);
$requestKey = $submittedRequestKey ?? bin2hex(random_bytes(16));
$validUntil = $submittedExpiry ?? $quotation['valid_until'] ?? '';
$canPublish = $workflow['inspection_completed'] && !$workflow['bill'] && in_array($workflow['reservation_status'], ['Diagnosing','In Progress'], true) && $findings;
$canRecordGuest = !$linkedCustomer && !empty($quotation['can_respond']);
$money = static fn ($amount): string => '₱' . number_format((float)$amount, 2);
$decisionLabels = ['Pending' => 'Pending Approval', 'Accepted' => 'Approved', 'Rejected' => 'Additional Repair Declined', 'Withdrawn' => 'Withdrawn'];

function adminWorkflowQuotationRepairRow(array $findings, array $item, int|string $index): void
{
    $field = static fn (string $key, string $default = ''): string => is_scalar($item[$key] ?? null) ? (string)$item[$key] : $default;
    $prefix = 'items[' . $index . ']';
    ?>
    <fieldset class="border rounded p-3 mb-3" data-repair-row>
        <legend class="h6">Additional repair</legend>
        <div class="row g-3">
            <label class="col-12">Recorded finding
                <select class="form-select" name="<?= $prefix ?>[finding_id]" required>
                    <option value="">Select a finding</option>
                    <?php foreach ($findings as $finding): ?>
                        <option value="<?= (int)$finding['id'] ?>" <?= $field('finding_id') === (string)$finding['id'] ? 'selected' : '' ?>><?= adminH($finding['description']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="col-md-6">Recommended repair <input class="form-control" name="<?= $prefix ?>[name]" value="<?= adminH($field('name')) ?>" maxlength="255" required></label>
            <label class="col-md-3">Quantity <input class="form-control" type="number" name="<?= $prefix ?>[quantity]" value="<?= adminH($field('quantity', '1')) ?>" min="0.01" max="99999999.99" step="0.01" required></label>
            <label class="col-md-3">Unit price (PHP) <input class="form-control" type="number" name="<?= $prefix ?>[unit_price]" value="<?= adminH($field('unit_price')) ?>" min="0" max="99999999.99" step="0.01" required></label>
            <label class="col-md-6">Repair explanation <textarea class="form-control" name="<?= $prefix ?>[description]" rows="2" maxlength="1000" required><?= adminH($field('description')) ?></textarea></label>
            <label class="col-md-6">Safety advisory, if applicable <textarea class="form-control" name="<?= $prefix ?>[advisory]" rows="2" maxlength="1000"><?= adminH($field('advisory')) ?></textarea></label>
        </div>
        <button class="btn btn-sm btn-outline-secondary mt-3" type="button" data-remove-repair>Remove from this proposal</button>
    </fieldset>
    <?php
}

require __DIR__ . '/admin_header.php';
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h2><?= $quotation ? 'Final Quotation' : 'Additional Quotation' ?></h2>
            <p class="mb-0 text-muted"><?= adminH($workflow['booking_reference'] ?: '#' . $reservation_id) ?> · <?= adminH($reservation['customer_name']) ?> · <?= adminH($reservation['brand'] . ' ' . $reservation['model'] . ' (' . $reservation['plate_number'] . ')') ?></p>
        </div>
        <div class="d-flex flex-wrap gap-2 d-print-none">
            <?php if ($quotation): ?><button type="button" onclick="window.print()" class="btn btn-outline-secondary">Print / Save PDF</button><?php endif; ?>
            <a class="btn btn-secondary" href="<?= adminH($jobUrl) ?>">← Reservation</a>
        </div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger" role="alert"><?= adminH($error) ?></div><?php endif; ?>
    <div class="d-flex flex-wrap gap-2 mb-3">
        <span class="badge rounded-pill text-bg-info"><?= adminH($workflow['work_status']) ?></span>
        <?php if ($quotation): ?><span class="badge rounded-pill text-bg-light">Additional repairs: <?= adminH($quotation['decision_status']) ?></span><?php endif; ?>
    </div>

    <section class="clean-card p-4 mb-3" aria-labelledby="original-quotation-heading">
        <h3 class="h5" id="original-quotation-heading">Original booked services</h3>
        <p class="text-muted">The customer authorized these services at booking.</p>
        <dl class="mb-3">
            <?php foreach ($workflow['original_services'] as $item): ?>
                <dt><?= adminH($item['name']) ?> · <?= $money($item['amount']) ?></dt>
                <dd><?= adminH($item['description']) ?></dd>
            <?php endforeach; ?>
        </dl>
        <strong>Original authorized total <?= $money($workflow['totals']['original_authorized']) ?></strong>
    </section>

    <section class="clean-card p-4 mb-3" aria-labelledby="additional-quotation-heading">
        <h3 class="h5" id="additional-quotation-heading">Additional recommended repairs</h3>
        <?php if ($quotation): ?>
            <p>Revision <?= (int)$quotation['version'] ?><?= $quotation['valid_until'] ? ' · Valid through ' . adminH($quotation['valid_until']) : '' ?></p>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th scope="col">Repair and finding</th><th scope="col">Quantity</th><th scope="col">Unit price</th><th scope="col">Amount</th><th scope="col">Decision</th></tr></thead>
                    <tbody>
                        <?php foreach ($workflow['additional_repairs'] as $item): ?>
                        <tr>
                            <th scope="row">
                                <?= adminH($item['name']) ?>
                                <small class="d-block fw-normal"><?= adminH($item['description']) ?></small>
                                <small class="d-block fw-normal text-muted"><?= adminH($item['finding']) ?></small>
                                <?php if ($item['advisory']): ?><small class="d-block fw-normal">Safety advisory · <?= adminH($item['advisory']) ?></small><?php endif; ?>
                            </th>
                            <td><?= adminH($item['quantity']) ?></td><td><?= $money($item['unit_price']) ?></td><td><?= $money($item['amount']) ?></td>
                            <td><?= adminH($decisionLabels[$item['decision']]) ?><?php if ($item['revision_id'] !== $revisionId): ?><small class="d-block text-muted">Earlier revision</small><?php endif; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>No additional quotation has been published.</p>
        <?php endif; ?>
        <dl class="row mb-0">
            <dt class="col-sm-8">Proposed additional total</dt><dd class="col-sm-4"><?= $money($workflow['totals']['proposed_additional']) ?></dd>
            <dt class="col-sm-8">Approved additional total</dt><dd class="col-sm-4"><?= $money($workflow['totals']['approved_additional']) ?></dd>
            <dt class="col-sm-8">Updated authorized service total</dt><dd class="col-sm-4"><?= $money($workflow['totals']['updated_authorized']) ?></dd>
        </dl>
    </section>

    <?php if ($canRecordGuest): ?>
    <section class="clean-card p-4 mb-3 d-print-none" aria-labelledby="guest-response-heading">
        <h3 class="h5" id="guest-response-heading">Record guest decision</h3>
        <p>Confirm the guest’s decision for revision <?= (int)$quotation['version'] ?> before recording it.</p>
        <form method="post" action="<?= adminH($pageUrl) ?>">
            <?= adminCsrfInput() ?>
            <input type="hidden" name="workflow_quote_action" value="guest_response">
            <input type="hidden" name="revision_id" value="<?= $revisionId ?>">
            <label class="form-label">Decision scope
                <select class="form-select" name="decision_scope" required>
                    <option value="selected">Selected repairs</option>
                    <option value="Accepted">Approve all pending repairs</option>
                    <option value="Rejected">Decline all pending repairs</option>
                </select>
            </label>
            <div class="row g-3 mb-3">
                <?php foreach ($workflow['additional_repairs'] as $item): if (!$item['respondable']) continue; ?>
                    <label class="col-md-6"><?= adminH($item['name']) ?>
                        <select class="form-select" name="decisions[<?= (int)$item['id'] ?>]">
                            <option value="">Leave pending</option>
                            <option value="Accepted">Approve</option>
                            <option value="Rejected">Decline</option>
                        </select>
                    </label>
                <?php endforeach; ?>
            </div>
            <label class="form-label d-block">Documented confirmation reference
                <textarea class="form-control" name="guest_evidence" maxlength="500" rows="2" required></textarea>
            </label>
            <button class="btn btn-primary mt-2">Record guest decision</button>
        </form>
    </section>
    <?php elseif ($linkedCustomer && !empty($quotation['can_respond'])): ?>
        <p class="alert alert-info d-print-none">The linked customer can respond from My Bookings.</p>
    <?php endif; ?>

    <?php if ($canPublish): ?>
    <section class="clean-card p-4 mb-3 d-print-none" aria-labelledby="publish-quotation-heading">
        <h3 class="h5" id="publish-quotation-heading"><?= $quotation ? 'Prepare a new quotation revision' : 'Prepare an additional quotation' ?></h3>
        <?php if ($quotation): ?><p>Include only outstanding additional repairs. A new revision replaces the pending proposal and preserves recorded approvals.</p><?php endif; ?>
        <form method="post" action="<?= adminH($pageUrl) ?>" id="service-workflow-quotation">
            <?= adminCsrfInput() ?>
            <input type="hidden" name="workflow_quote_action" value="send">
            <input type="hidden" name="request_key" value="<?= adminH($requestKey) ?>">
            <input type="hidden" name="expected_revision_id" value="<?= $revisionId ?>">
            <div id="service-workflow-repairs">
                <?php foreach ($formItems as $index => $item) adminWorkflowQuotationRepairRow($findings, $item, $index); ?>
            </div>
            <template id="service-workflow-repair-template"><?php adminWorkflowQuotationRepairRow($findings, [], 'INDEX'); ?></template>
            <div class="d-flex flex-wrap align-items-end gap-3">
                <button type="button" class="btn btn-outline-primary" id="service-workflow-add-repair">Add repair</button>
                <label>Valid through <input class="form-control" type="date" name="valid_until" min="<?= date('Y-m-d') ?>" value="<?= adminH($validUntil) ?>"></label>
                <button class="btn btn-primary"><?= $quotation ? 'Publish new revision' : 'Publish quotation' ?></button>
            </div>
        </form>
    </section>
    <script>
    (() => {
        const items = document.getElementById('service-workflow-repairs');
        const template = document.getElementById('service-workflow-repair-template');
        const add = document.getElementById('service-workflow-add-repair');
        let index = items.children.length;
        const refresh = () => {
            add.disabled = items.children.length >= 50;
            for (const button of items.querySelectorAll('[data-remove-repair]')) {
                button.disabled = items.children.length === 1;
            }
        };
        add.addEventListener('click', () => {
            const row = template.content.cloneNode(true);
            for (const control of row.querySelectorAll('[name]')) {
                control.name = control.name.replace('INDEX', index);
            }
            index += 1;
            items.append(row);
            refresh();
        });
        items.addEventListener('click', event => {
            if (event.target.matches('[data-remove-repair]') && items.children.length > 1) {
                event.target.closest('[data-repair-row]').remove();
                refresh();
            }
        });
        refresh();
    })();
    </script>
    <?php elseif (!$quotation && !$workflow['bill']): ?>
        <p class="alert alert-light border">Complete the inspection and record a finding before preparing an additional quotation.</p>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/admin_footer.php'; ?>
