<?php

function adminWorkflowLoadCore(): bool
{
    $core = __DIR__ . '/../../vehicle-service-management/includes/service_workflow.php';
    if (!is_file($core)) {
        return false;
    }
    require_once $core;
    return true;
}

function adminWorkflowAvailable(mysqli $conn): bool
{
    return adminWorkflowLoadCore() && serviceWorkflowSchemaReady($conn);
}

function adminWorkflowRequireCore(): void
{
    $staff = __DIR__ . '/../../vehicle-service-management/includes/service_workflow_staff.php';
    if (!adminWorkflowLoadCore() || !is_file($staff)) {
        throw new DomainException('Install the Customer Website and PHP API workflow update before using these actions.');
    }
    require_once $staff;
}

function adminWorkflowMarkerExists(mysqli $conn): bool
{
    static $connections = new WeakMap();
    if (!isset($connections[$conn])) {
        $connections[$conn] = (bool) $conn->query("SELECT 1 FROM information_schema.TABLES
            WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='service_workflow_jobs'")->fetch_row();
    }
    return $connections[$conn];
}

function adminWorkflowIsBooking(mysqli $conn, int $id): bool
{
    return adminWorkflowMarkerExists($conn) && (bool) $conn->execute_query(
        'SELECT 1 FROM service_workflow_jobs WHERE reservation_id=?', [$id]
    )->fetch_row();
}

function adminWorkflowSummary(mysqli $conn, int $id): ?array
{
    return adminWorkflowAvailable($conn) ? serviceWorkflowSummary($conn, $id) : null;
}

function adminWorkflowStateLabel(array $job, ?array $workflow): string
{
    return $workflow['work_status'] ?? adminStatus($job['status']);
}

function adminWorkflowBadges(array $job, ?array $workflow): string
{
    if (!$workflow) {
        return adminBadge($job['status']);
    }
    $label = adminWorkflowStateLabel($job, $workflow);
    $html = '<span class="badge rounded-pill text-bg-' . (!empty($workflow['full_hold_active']) ? 'warning' : 'light') . '">' . adminH($label) . '</span>';
    if ($workflow['quotation']) {
        $html .= ' <span class="badge rounded-pill text-bg-light">' . adminH($workflow['quotation']['decision_status']) . '</span>';
    }
    foreach ($workflow['safety_advisories'] as $advisory) {
        if ($advisory['resolved_at'] === null) {
            $html .= ' <span class="badge rounded-pill text-bg-warning">Safety advisory</span>';
            break;
        }
    }
    foreach ($workflow['service_holds'] as $hold) {
        if ($hold['released_at'] === null) {
            $html .= ' <span class="badge rounded-pill text-bg-warning">Affected work on hold</span>';
            break;
        }
    }
    return $html;
}

function adminWorkflowQuotationNeedsAttentionSql(mysqli $conn): string
{
    if (!adminWorkflowAvailable($conn)) {
        return "r.status='Diagnosing'";
    }
    return "((r.status='Diagnosing' AND NOT EXISTS (
            SELECT 1 FROM service_workflow_jobs w WHERE w.reservation_id=r.id
        )) OR (r.status IN ('Diagnosing','In Progress') AND EXISTS (
            SELECT 1 FROM service_workflow_findings f WHERE f.reservation_id=r.id
            AND NOT EXISTS (SELECT 1 FROM service_workflow_tasks t WHERE t.finding_id=f.id)
        )))";
}

function adminWorkflowReleaseServices(mysqli $conn, int $id): array
{
    $bill = $conn->execute_query("SELECT b.lines_json FROM service_workflow_bills b
        JOIN payments p ON p.id=b.payment_id AND p.reservation_id=b.reservation_id
        WHERE b.reservation_id=? AND p.payment_type='Final Balance' AND p.amount=b.amount_due
        AND p.status='Paid' AND p.refund_status IN ('Not Applicable','Rejected') FOR UPDATE", [$id])->fetch_assoc();
    if (!$bill) {
        throw new DomainException('Finalize the bill and verify the outstanding balance before releasing the vehicle.');
    }

    $blocked = $conn->execute_query("SELECT 1 FROM service_workflow_jobs w WHERE w.reservation_id=? AND (
        w.full_hold_at IS NOT NULL OR EXISTS (
            SELECT 1 FROM service_workflow_holds h WHERE h.reservation_id=w.reservation_id AND h.released_at IS NULL
        ) OR EXISTS (
            SELECT 1 FROM service_workflow_tasks t WHERE t.reservation_id=w.reservation_id AND t.decision='Accepted'
            AND t.work_status IN ('Awaiting Work','In Progress')
        ))", [$id])->fetch_row();
    if ($blocked) {
        throw new DomainException('Resolve active holds and record the outcome of the remaining work before releasing the vehicle.');
    }

    return array_column(json_decode($bill['lines_json'], true, 512, JSON_THROW_ON_ERROR), 'name');
}
