<?php
$workflowFindings = $conn->execute_query(
    'SELECT f.*, u.fullname AS recorded_name FROM service_workflow_findings f
     LEFT JOIN users u ON u.id=f.recorded_by WHERE f.reservation_id=? ORDER BY f.id',
    [$id]
)->fetch_all(MYSQLI_ASSOC);
$workflowHolds = $conn->execute_query(
    'SELECT h.*, u.fullname AS recorded_name FROM service_workflow_holds h
     LEFT JOIN users u ON u.id=h.recorded_by WHERE h.reservation_id=? ORDER BY h.id DESC',
    [$id]
)->fetch_all(MYSQLI_ASSOC);
$workflowAdvisories = $conn->execute_query(
    'SELECT a.*, u.fullname AS recorded_name FROM service_workflow_advisories a
     LEFT JOIN users u ON u.id=a.recorded_by WHERE a.reservation_id=? ORDER BY a.id DESC',
    [$id]
)->fetch_all(MYSQLI_ASSOC);
$workflowActivity = $conn->execute_query(
    'SELECT e.event_type, e.details, e.actor_id, e.created_at, u.fullname AS actor_name
     FROM service_workflow_events e LEFT JOIN users u ON u.id=e.actor_id
     WHERE e.reservation_id=? ORDER BY e.id DESC LIMIT 15',
    [$id]
)->fetch_all(MYSQLI_ASSOC);

$workflowTasks = array_column(array_merge($workflow['original_services'], array_values(array_filter(
    $workflow['additional_repairs'], static fn (array $task): bool => $task['decision'] === 'Accepted'
))), null, 'id');
$workflowByTask = array_column($conn->execute_query(
    "SELECT id, work_status FROM service_workflow_tasks WHERE reservation_id=? AND decision='Accepted'",
    [$id]
)->fetch_all(MYSQLI_ASSOC), 'work_status', 'id');
$workflowOpenHolds = array_column(array_filter(
    $workflowHolds, static fn (array $hold): bool => $hold['released_at'] === null
), null, 'task_id');
$workflowRemaining = array_intersect_key($workflowTasks, array_filter(
    $workflowByTask, static fn (string $status): bool => in_array($status, ['Awaiting Work', 'In Progress'], true)
));
$workflowSafeRemaining = array_diff_key($workflowRemaining, $workflowOpenHolds);
$workflowCanFinalize = $workflowCanWork && adminCan('jobs.manage') && $workflow['inspection_completed']
    && !$workflow['full_hold_active'] && !$workflowRemaining && !$workflowOpenHolds && !$workflow['bill'];
$workflowPendingRepairs = (bool) array_filter(
    $workflow['additional_repairs'], static fn (array $task): bool => $task['decision'] === 'Pending'
);

$workflowForm = static function (string $action, array $ids = []) use ($id): void {
    echo adminCsrfInput();
    echo '<input type="hidden" name="reservation_id" value="' . $id . '">';
    echo '<input type="hidden" name="action" value="' . adminH($action) . '">';
    foreach ($ids as $field => $value) {
        echo '<input type="hidden" name="' . adminH($field) . '" value="' . (int) $value . '">';
    }
};
$staffLabel = static fn (array $record): string => ($record['recorded_name'] ?? null) ?: 'Staff #' . (int) $record['recorded_by'];
?>
<section id="job-workflow" class="clean-card p-4 job-section">
  <h2 class="h5">Inspection and service work</h2>
  <?php if (($job['booking_channel'] ?? '') === 'Walk-in'): ?>
    <p class="staff-notice">Walk-in · arrival recorded · no advance reservation fee</p>
  <?php endif; ?>
  <?php if ($workflow['full_hold_active']): ?>
    <p class="alert alert-warning">All remaining work was placed on hold. Record a safety review before starting an independent service, or close its hold when it is safe to proceed.</p>
  <?php endif; ?>

  <div id="job-inspection">
    <h3 class="h6 mt-3">Vehicle inspection</h3>
    <?php if ($workflow['inspection_completed']): ?>
      <p><strong>Inspection completed</strong><br><?= nl2br(adminH($job['diagnosis'])) ?></p>
    <?php elseif ($workflowCanWork): ?>
      <form method="post" action="service_workflow_action.php" class="mb-3">
        <?php $workflowForm('inspection_complete'); ?>
        <label for="workflowInspection" class="form-label">Inspection result</label>
        <textarea id="workflowInspection" name="notes" class="form-control mb-2" rows="3" maxlength="4000" required></textarea>
        <button class="btn btn-primary">Complete inspection</button>
      </form>
    <?php else: ?>
      <p class="text-muted">Inspection is awaiting completion.</p>
    <?php endif; ?>
    <?php if ($workflowFindings): ?>
      <h4 class="h6">Additional findings</h4>
      <ul class="workspace-list">
        <?php foreach ($workflowFindings as $finding): ?>
          <li><?= nl2br(adminH($finding['description'])) ?><small><?= adminH($staffLabel($finding) . ' · ' . $finding['recorded_at']) ?></small></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <?php if ($workflowCanWork): ?>
      <details class="mt-3">
        <summary>Record an additional finding</summary>
        <form method="post" action="service_workflow_action.php" class="mt-2">
          <?php $workflowForm('finding_add'); ?>
          <label for="workflowFinding" class="form-label">Vehicle issue discovered</label>
          <textarea id="workflowFinding" name="description" class="form-control mb-2" rows="2" maxlength="1000" required></textarea>
          <button class="btn btn-outline-primary">Save finding</button>
        </form>
      </details>
    <?php endif; ?>
  </div>

  <hr>
  <h3 class="h6" id="job-authorized-work">Authorized work</h3>
  <ul class="workspace-list">
    <?php foreach ($workflowTasks as $taskId => $task):
      $taskId = (int) $taskId;
      $workStatus = $workflowByTask[$taskId];
      $isHeld = isset($workflowOpenHolds[$taskId]);
      $unfinished = isset($workflowRemaining[$taskId]);
      $reviewAfter = $unfinished && !$workflow['full_hold_active'] && isset($workflowSafeRemaining[$taskId])
          && count($workflowSafeRemaining) === 1 && count($workflowRemaining) > 1;
    ?>
      <li class="py-3">
        <div class="d-flex justify-content-between flex-wrap gap-2">
          <strong><?= adminH($task['name']) ?></strong>
          <span class="badge <?= $isHeld ? 'text-bg-warning' : 'text-bg-light' ?>"><?= adminH($isHeld && $unfinished ? 'Service Hold' : $workStatus) ?></span>
        </div>
        <small><?= $task['revision_id'] === null ? 'Original booked service' : 'Approved additional repair' ?></small>
        <p class="my-2"><?= nl2br(adminH($task['description'])) ?></p>
        <?php if (!empty($task['advisory'])): ?><small><?= nl2br(adminH($task['advisory'])) ?></small><?php endif; ?>
        <?php if ($workflowCanWork && $workflow['inspection_completed'] && $unfinished): ?>
          <?php if (!$isHeld): ?>
            <?php $taskAction = $workStatus === 'In Progress' ? 'task_complete' : 'task_start'; ?>
            <form method="post" action="service_workflow_action.php" class="mt-2">
              <?php $workflowForm($taskAction, ['task_id' => $taskId]); ?>
              <?php if ($taskAction === 'task_start' && $workflow['full_hold_active']): ?>
                <label for="reviewStart<?= $taskId ?>" class="form-label">Review confirming this service can proceed safely</label>
                <textarea id="reviewStart<?= $taskId ?>" name="full_hold_review" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
              <?php elseif ($taskAction === 'task_complete' && $reviewAfter): ?>
                <label for="reviewComplete<?= $taskId ?>" class="form-label">Safety review of the remaining work on hold</label>
                <textarea id="reviewComplete<?= $taskId ?>" name="full_hold_review" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
              <?php endif; ?>
              <button class="btn btn-primary btn-sm"><?= $taskAction === 'task_complete' ? 'Mark service completed' : 'Start service' ?></button>
            </form>
          <?php endif; ?>
          <?php if (!$isHeld || adminCan('jobs.manage')): ?>
            <details class="mt-2">
              <summary>Mark not performed</summary>
              <form method="post" action="service_workflow_action.php" class="mt-2">
                <?php $workflowForm('task_not_performed', ['task_id' => $taskId]); ?>
                <label for="notPerformed<?= $taskId ?>" class="form-label">Reason this service was omitted</label>
                <textarea id="notPerformed<?= $taskId ?>" name="reason" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
                <?php if ($reviewAfter): ?>
                  <label for="reviewOmitted<?= $taskId ?>" class="form-label">Safety review of the remaining work on hold</label>
                  <textarea id="reviewOmitted<?= $taskId ?>" name="full_hold_review" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
                <?php endif; ?>
                <button class="btn btn-outline-danger btn-sm">Save as not performed</button>
              </form>
            </details>
          <?php endif; ?>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>

  <hr>
  <h3 class="h6" id="job-safety">Safety advisories and service holds</h3>
  <?php if (!$workflowAdvisories && !$workflowHolds): ?><p class="text-muted">No advisories or service holds recorded.</p><?php endif; ?>
  <?php foreach ($workflowAdvisories as $advisory): $advisoryId = (int) $advisory['id']; ?>
    <div class="border rounded p-3 mt-2">
      <strong><?= $advisory['resolved_at'] ? 'Resolved safety advisory' : 'Safety advisory' ?></strong>
      <p class="mb-1"><?= nl2br(adminH($advisory['message'])) ?></p>
      <small><?= adminH($staffLabel($advisory) . ' · ' . $advisory['recorded_at']) ?></small>
      <?php if ($advisory['resolved_at']): ?>
        <p class="mb-0 small"><?= adminH($advisory['resolved_at'] . ' · ' . $advisory['resolution_reason']) ?></p>
      <?php elseif ($workflowCanWork): ?>
        <details class="mt-2">
          <summary>Resolve advisory</summary>
          <form method="post" action="service_workflow_action.php" class="mt-2">
            <?php $workflowForm('advisory_resolve', ['advisory_id' => $advisoryId]); ?>
            <label for="resolveAdvisory<?= $advisoryId ?>" class="form-label">Resolution reason</label>
            <textarea id="resolveAdvisory<?= $advisoryId ?>" name="reason" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
            <button class="btn btn-outline-primary btn-sm">Save resolution</button>
          </form>
        </details>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <?php foreach ($workflowHolds as $hold): $holdId = (int) $hold['id']; ?>
    <div class="border rounded p-3 mt-2">
      <strong><?= $hold['released_at'] ? 'Closed service hold' : 'Active service hold' ?> · <?= adminH($workflowTasks[(int) $hold['task_id']]['name'] ?? 'Service') ?></strong>
      <p class="mb-1"><?= nl2br(adminH($hold['reason'])) ?></p>
      <p class="mb-1"><strong>Resume conditions</strong> <?= nl2br(adminH($hold['resume_conditions'])) ?></p>
      <small><?= adminH($staffLabel($hold) . ' · ' . $hold['recorded_at']) ?></small>
      <?php if ($hold['released_at']): ?>
        <p class="mb-0 small"><?= adminH($hold['released_at'] . ' · ' . $hold['release_reason']) ?></p>
      <?php elseif ($workflowCanWork): ?>
        <details class="mt-2">
          <summary>Close service hold</summary>
          <form method="post" action="service_workflow_action.php" class="mt-2">
            <?php $workflowForm('hold_release', ['hold_id' => $holdId]); ?>
            <label for="closeHold<?= $holdId ?>" class="form-label">Why the hold can be closed safely</label>
            <textarea id="closeHold<?= $holdId ?>" name="reason" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
            <button class="btn btn-outline-primary btn-sm">Close hold</button>
          </form>
        </details>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <?php if ($workflowCanWork): ?>
    <details class="mt-3">
      <summary>Add a safety advisory</summary>
      <form method="post" action="service_workflow_action.php" class="mt-2">
        <?php $workflowForm('advisory_add'); ?>
        <label for="workflowAdvisory" class="form-label">Safety concern to share with the customer</label>
        <textarea id="workflowAdvisory" name="message" class="form-control mb-2" rows="2" maxlength="1000" required></textarea>
        <button class="btn btn-outline-primary">Save advisory</button>
      </form>
    </details>
    <?php if ($workflowSafeRemaining): ?>
      <details class="mt-3">
        <summary>Place affected work on hold</summary>
        <form method="post" action="service_workflow_action.php" class="mt-2">
          <?php $workflowForm('hold_add'); ?>
          <fieldset class="mb-2">
            <legend class="h6">Affected authorized services</legend>
            <?php foreach ($workflowSafeRemaining as $taskId => $task): ?>
              <label class="form-check">
                <input type="checkbox" class="form-check-input" name="task_ids[]" value="<?= (int) $taskId ?>">
                <span class="form-check-label"><?= adminH($task['name']) ?></span>
              </label>
            <?php endforeach; ?>
          </fieldset>
          <label for="holdReason" class="form-label">Safety reason</label>
          <textarea id="holdReason" name="reason" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
          <label for="holdConditions" class="form-label">Conditions for resuming safely</label>
          <textarea id="holdConditions" name="resume_conditions" class="form-control mb-2" rows="2" maxlength="500" required></textarea>
          <?php if (!$workflow['full_hold_active']): ?>
            <label for="fullHoldReview" class="form-label">Review if every remaining service will be held</label>
            <textarea id="fullHoldReview" name="full_hold_review" class="form-control mb-2" rows="2" maxlength="500" <?= count($workflowSafeRemaining) === 1 ? 'required' : '' ?>></textarea>
          <?php endif; ?>
          <button class="btn btn-outline-primary">Record service hold</button>
        </form>
      </details>
    <?php endif; ?>
  <?php endif; ?>

  <hr>
  <h3 class="h6">Mileage and service notes</h3>
  <?php if (adminCan('jobs.work') && !$closed): ?>
    <form method="post" action="service_record_save.php">
      <?= adminCsrfInput() ?>
      <input type="hidden" name="reservation_id" value="<?= $id ?>">
      <div class="record-grid">
        <div><label for="workflowMileage">Intake mileage</label><input id="workflowMileage" name="intake_mileage" type="number" min="0" class="form-control" value="<?= adminH($job['intake_mileage']) ?>"></div>
        <div><label for="workflowNextDate">Next service date</label><input id="workflowNextDate" name="next_service_date" type="date" class="form-control" value="<?= adminH($job['next_service_date']) ?>"></div>
        <div class="wide"><label for="workflowNotes">Completion notes</label><textarea id="workflowNotes" name="completion_notes" rows="3" class="form-control"><?= adminH($job['completion_notes']) ?></textarea></div>
      </div>
      <button class="btn btn-outline-primary mt-2">Save service notes</button>
    </form>
  <?php else: ?>
    <dl>
      <?php foreach (['intake_mileage' => 'Intake mileage', 'next_service_date' => 'Next service date', 'completion_notes' => 'Completion notes'] as $field => $label): ?>
        <dt><?= $label ?></dt><dd><?= nl2br(adminH($job[$field] ?? 'Not recorded')) ?></dd>
      <?php endforeach; ?>
    </dl>
  <?php endif; ?>
</section>
