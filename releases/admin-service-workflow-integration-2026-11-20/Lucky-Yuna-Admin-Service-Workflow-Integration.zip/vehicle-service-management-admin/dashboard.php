<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/job_schedule.php';
require_once __DIR__.'/includes/workflow_integration.php';
$day=$_GET['date']??date('Y-m-d');$parsed=DateTimeImmutable::createFromFormat('!Y-m-d',(string)$day);if(!$parsed||$parsed->format('Y-m-d')!==$day)$day=date('Y-m-d');
$scope=adminJobScope('r');
$stmt=$conn->prepare("SELECT r.*,c.fullname customer_name,v.plate_number,m.fullname mechanic_name FROM reservations r LEFT JOIN customers c ON c.id=r.customer_id LEFT JOIN vehicles v ON v.id=r.vehicle_id LEFT JOIN mechanics m ON m.id=r.mechanic_id WHERE r.appointment_date=? AND r.status NOT IN ('Cancelled','Completed') $scope ORDER BY r.appointment_time,r.id LIMIT 12");
$stmt->bind_param('s',$day);$stmt->execute();$today=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
$stmt=$conn->prepare("SELECT COUNT(*) n FROM reservations r WHERE appointment_date=? AND status NOT IN ('Cancelled','Completed') $scope");$stmt->bind_param('s',$day);$stmt->execute();$todayCount=(int)$stmt->get_result()->fetch_assoc()['n'];$stmt->close();
$counts=[];$rows=$conn->query("SELECT r.status,COUNT(*) n FROM reservations r WHERE 1=1 $scope GROUP BY r.status");while($row=$rows->fetch_assoc())$counts[$row['status']]=(int)$row['n'];
$unassigned=(int)$conn->query("SELECT COUNT(*) n FROM reservations r WHERE mechanic_id IS NULL AND status IN ('Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress') $scope")->fetch_assoc()['n'];
$confirmed=(int)$conn->query("SELECT COUNT(*) n FROM reservations r WHERE status='Pending' AND (reservation_fee_status='Paid' OR user_id IS NULL) $scope")->fetch_assoc()['n'];
$proofs=adminCan('finance')?(int)$conn->query("SELECT COUNT(*) n FROM payments WHERE status='Under Review'")->fetch_assoc()['n']:0;
$refunds=adminCan('finance')?(int)$conn->query("SELECT COUNT(*) n FROM payments WHERE refund_status IN ('Requested','Under Review','Approved')")->fetch_assoc()['n']:0;
$arrivalStmt=$conn->prepare("SELECT COUNT(*) n FROM reservations r WHERE appointment_date=? AND status='Approved' AND checked_in_at IS NULL $scope");$arrivalStmt->bind_param('s',$day);$arrivalStmt->execute();$arrivals=(int)$arrivalStmt->get_result()->fetch_assoc()['n'];$arrivalStmt->close();
$quoteAttention = adminWorkflowQuotationNeedsAttentionSql($conn);
$quotationCount = adminCan('jobs.manage')
    ? (int) $conn->query("SELECT COUNT(*) AS n FROM reservations r WHERE $quoteAttention $scope")->fetch_assoc()['n']
    : 0;
$tasks=[];
if(adminCan('jobs.manage'))$tasks[]=['Check in arrivals',$arrivals,'reservations.php?queue=arrivals&date='.urlencode($day),'Expected vehicles on the selected date.'];
if(adminCan('jobs.manage')){$tasks[]=['Confirm appointments',$confirmed,'reservations.php?queue=confirmation','Reservation fee verified; ready for confirmation.'];$tasks[]=['Assign mechanics',$unassigned,'reservations.php?queue=unassigned','Confirmed jobs without a mechanic.'];$tasks[]=['Review quotation findings',$quotationCount,'reservations.php?queue=quotations','Review findings that need a quotation.'];}
if(adminCan('finance')){$tasks[]=['Verify payment proofs',$proofs,'payments.php?queue=verify','Compare the proof, amount and reference.'];$tasks[]=['Review refunds',$refunds,'payments.php?queue=refunds','Record refunds only after returning the money.'];}
if(adminIsMechanic()){$tasks[]=['Review assigned work',$counts['In Progress']??0,'reservations.php?status=In+Progress','Open your job to record progress.'];$tasks[]=['Inspect assigned vehicles',$counts['Approved']??0,'reservations.php?status=Approved','Start inspection at the reserved time.'];}
$dayConflicts=adminCan('jobs.manage')?jobDayConflicts($conn,$day):[];
include __DIR__.'/includes/admin_header.php';
?>
<?php include __DIR__.'/includes/schedule_conflict_banner.php'; ?>
<?php if(adminCan('jobs.manage')):?><p><a class="btn btn-primary" href="walk_in.php">Register a walk-in</a></p><?php endif;?>
<div class="page-heading"><div><span class="eyebrow">YOUR DAILY SERVICE DESK</span><h1><?= adminIsMechanic()?'My work today':'Today' ?></h1><p><?= adminH(date('l, F j, Y',strtotime($day))) ?> · Philippine time</p></div><form method="get" class="d-flex gap-2"><label class="visually-hidden" for="deskDate">Appointment date</label><input class="form-control" type="date" id="deskDate" name="date" value="<?= adminH($day) ?>"><button class="btn btn-dark">View day</button></form></div>
<div class="workspace-stats"><a class="workspace-stat" href="reservations.php?date=<?= adminH($day) ?>"><span>Active appointments on this date</span><strong><?= $todayCount ?></strong><small>Open the day’s jobs →</small></a>
<?php foreach(array_slice($tasks,0,3) as [$label,$count,$url,$help]):?><a class="workspace-stat" href="<?= adminH($url) ?>"><span><?= adminH($label) ?></span><strong><?= $count ?></strong><small>Open task queue →</small></a><?php endforeach; ?></div>
<div class="workspace-columns"><section class="clean-card p-4"><div class="d-flex justify-content-between align-items-center gap-3 mb-3"><h2 class="h5 mb-0">Appointments</h2><?php if(adminCan('schedule')):?><a href="schedule.php?date=<?= adminH($day) ?>">Open schedule</a><?php endif;?></div>
<?php if(!$today):?><div class="workspace-empty">No active appointments for this date.</div><?php else:?><ul class="workspace-list"><?php foreach($today as $job):$workflow=adminWorkflowSummary($conn,(int)$job['id']);[$action,$url,$help]=adminNextAction($job,$workflow);?><li><div class="job-row"><div><strong><?= adminH(date('g:i A',strtotime($job['appointment_time']))) ?> · <?= adminH($job['customer_name']?:'Customer') ?></strong><small><?= !empty($job['checked_in_at'])?'Arrived · ':'Expected · ' ?><?= adminH($job['plate_number']) ?> · <?= adminH($job['mechanic_name']?:'Mechanic not assigned') ?></small><div class="mt-2"><?= adminWorkflowBadges($job,$workflow) ?></div></div><a class="btn btn-outline-primary btn-sm" href="<?= adminH($url) ?>"><?= adminH($action) ?></a></div></li><?php endforeach;?></ul><a class="d-inline-block mt-3" href="reservations.php?date=<?= adminH($day) ?>">View all <?= $todayCount ?> appointments →</a><?php endif;?></section>
<section class="clean-card p-4"><h2 class="h5">Needs attention</h2><p class="small text-muted">Arrival tasks use the selected date. Other queues include all dates.</p><?php if(!$tasks):?><p class="text-muted">Open Jobs to check appointment progress. Your role has read-only access.</p><?php else:?><ul class="workspace-list"><?php foreach($tasks as [$label,$count,$url,$help]):?><li><div class="job-row"><div><a href="<?= adminH($url) ?>"><strong><?= $count ?> · <?= adminH($label) ?></strong></a><small><?= adminH($help) ?></small></div></div></li><?php endforeach;?></ul><?php endif;?></section></div>
<?php include __DIR__.'/includes/admin_footer.php'; ?>
