<?php
require_once __DIR__ . '/includes/admin_auth.php';
require_once __DIR__ . '/includes/workflow_integration.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('POST required.');
}

$id = (int) filter_var($_POST['reservation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
adminRequireJob($conn, $id);

$action = $_POST['action'] ?? '';
$messages = [
    'inspection_complete' => 'Inspection completed.',
    'finding_add' => 'Finding recorded.',
    'task_start' => 'Service work started.',
    'task_complete' => 'Service marked completed.',
    'task_not_performed' => 'Service marked not performed.',
    'advisory_add' => 'Safety advisory recorded.',
    'advisory_resolve' => 'Safety advisory resolved.',
    'hold_add' => 'Service hold recorded.',
    'hold_release' => 'Service hold closed.',
    'finalize_bill' => 'Final bill saved. The vehicle is ready for pickup.',
];
if (!is_string($action) || !isset($messages[$action])) {
    http_response_code(422);
    exit('Choose a service workflow action.');
}
if ($action === 'finalize_bill' && !adminCan('jobs.manage')) {
    adminDeny('A service adviser or manager must finalize the bill.');
}

$postText = static function (string $key): string {
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) {
        throw new DomainException('Check the submitted service workflow details.');
    }
    return $value;
};
$postId = static function (mixed $value): int {
    $number = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($number === false) {
        throw new DomainException('Choose a valid service record.');
    }
    return $number;
};
$holdTasks = static function () use ($postId): array {
    $tasks = $_POST['task_ids'] ?? [];
    if (!is_array($tasks) || !array_is_list($tasks) || count($tasks) > 100) {
        throw new DomainException('Choose which services the hold affects.');
    }
    return array_map($postId, $tasks);
};

$returnAnchor = $action === 'finalize_bill' ? '#job-action' : '#job-workflow';
try {
    if (!adminWorkflowIsBooking($conn, $id)) {
        throw new DomainException('This booking uses the existing service record.');
    }
    adminWorkflowRequireCore();
    $actor = (int) $_SESSION['admin_id'];
    switch ($action) {
        case 'inspection_complete':
            serviceWorkflowCompleteInspection($conn, $id, $actor, $postText('notes'));
            break;
        case 'finding_add':
            serviceWorkflowRecordFinding($conn, $id, $actor, $postText('description'));
            break;
        case 'task_start':
        case 'task_complete':
        case 'task_not_performed':
            $status = match ($action) {
                'task_start' => 'In Progress',
                'task_complete' => 'Completed',
                'task_not_performed' => 'Not Performed',
            };
            serviceWorkflowSetTaskStatus(
                $conn, $id, $actor, $postId($_POST['task_id'] ?? null), $status,
                $postText('reason'), $postText('full_hold_review')
            );
            break;
        case 'advisory_add':
            serviceWorkflowAddAdvisory($conn, $id, $actor, $postText('message'));
            break;
        case 'advisory_resolve':
            serviceWorkflowResolveAdvisory($conn, $id, $actor, $postId($_POST['advisory_id'] ?? null), $postText('reason'));
            break;
        case 'hold_add':
            serviceWorkflowAddHolds(
                $conn, $id, $actor, $holdTasks(), $postText('reason'),
                $postText('resume_conditions'), $postText('full_hold_review')
            );
            break;
        case 'hold_release':
            serviceWorkflowReleaseHold($conn, $id, $actor, $postId($_POST['hold_id'] ?? null), $postText('reason'));
            break;
        case 'finalize_bill':
            serviceWorkflowFinalizeBill($conn, $id, $actor);
            break;
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'message' => $messages[$action]];
} catch (Throwable $error) {
    $returnAnchor = '';
    if (!$error instanceof DomainException) {
        error_log('Admin service workflow action failed: ' . get_class($error));
    }
    $_SESSION['admin_flash'] = [
        'type' => 'warning',
        'message' => $error instanceof DomainException ? $error->getMessage() : 'The service action could not be saved. Refresh and try again.',
    ];
}
header('Location: reservation_view.php?id=' . $id . $returnAnchor, true, 303);
exit;
