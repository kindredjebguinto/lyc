<?php
require_once __DIR__ . '/includes/admin_auth.php';
require_once __DIR__ . '/includes/workflow_integration.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('POST required.');
}

$id = (int) ($_POST['reservation_id'] ?? 0);
adminRequireJob($conn, $id);
$target = $_POST['status'] ?? '';
$transitions = [
    'Pending' => ['Approved', 'Cancelled'],
    'Approved' => ['Diagnosing', 'Cancelled'],
    'Quotation Accepted' => ['In Progress'],
    'In Progress' => ['Ready for Pickup'],
    'Ready for Pickup' => ['Completed'],
];

try {
    $conn->begin_transaction();
    $job = $conn->execute_query('SELECT * FROM reservations WHERE id=? FOR UPDATE', [$id])->fetch_assoc();
    if (!$job || (adminIsMechanic() && (int) $job['mechanic_id'] !== (int) $_SESSION['admin_mechanic_id'])) {
        throw new DomainException('This job is no longer assigned to your account.');
    }

    $workflow = adminWorkflowIsBooking($conn, $id);
    if ($workflow) {
        if (!adminWorkflowAvailable($conn)) {
            throw new DomainException('Install the complete service workflow update before changing this booking.');
        }
        $transitions['Quotation Accepted'] = [];
        $transitions['In Progress'] = [];
        if (in_array($target, ['In Progress', 'Ready for Pickup'], true)) {
            throw new DomainException('Use the service work panel to start tasks or finalize the bill.');
        }
    }

    if (!in_array($target, $transitions[$job['status']] ?? [], true)) {
        throw new DomainException('The job changed or that action is not available at this stage. Refresh and try again.');
    }
    if (in_array($target, ['Approved', 'Cancelled', 'Completed'], true) && !adminCan('jobs.manage')) {
        throw new DomainException('Ask a service adviser or manager to confirm, cancel or release the job.');
    }
    if ($target === 'Approved' && !empty($job['user_id']) && !in_array($job['reservation_fee_status'], ['Paid', 'Not Required'], true)) {
        throw new DomainException('A cashier must verify the reservation fee first.');
    }
    if (in_array($target, ['Diagnosing', 'In Progress'], true)
        && (empty($job['checked_in_at']) || !$job['mechanic_id'] || strtotime($job['appointment_date'] . ' ' . $job['appointment_time']) > time())) {
        throw new DomainException('Check in the vehicle, assign a mechanic and wait until the appointment time before starting inspection or service work.');
    }
    if ($target === 'Ready for Pickup' && trim($job['work_performed'] ?? '') === '') {
        throw new DomainException('Save the work performed in the service record before marking the vehicle ready.');
    }

    $completedServices = null;
    if ($target === 'Completed') {
        if ($workflow) {
            $completedServices = adminWorkflowReleaseServices($conn, $id);
        }
        $due = $conn->execute_query("SELECT id FROM payments
            WHERE reservation_id=? AND amount>0 AND status NOT IN ('Paid','Cancelled') LIMIT 1 FOR UPDATE", [$id])->fetch_row();
        if ($due) {
            throw new DomainException('Resolve the outstanding payments before releasing the vehicle.');
        }
    }

    if ($target === 'Cancelled') {
        $reason = is_string($_POST['cancellation_reason'] ?? null) ? trim($_POST['cancellation_reason']) : '';
        if ($reason === '') {
            throw new DomainException('Choose a cancellation reason.');
        }
        $paid = $job['reservation_fee_status'] === 'Paid';
        $fee = $paid ? 'Refund Requested' : $job['reservation_fee_status'];
        $eligibility = $paid ? 'Verified reservation-fee refund requested.' : 'No verified reservation fee to refund.';
        $conn->execute_query('UPDATE reservations SET status=?,cancellation_reason=?,refund_eligibility=?,reservation_fee_status=?
            WHERE id=?', [$target, $reason, $eligibility, $fee, $id]);
        $conn->execute_query("UPDATE payments SET refund_status='Requested'
            WHERE reservation_id=? AND payment_type='Reservation Fee' AND status='Paid' AND refund_status='Not Applicable'", [$id]);
    } elseif ($completedServices !== null) {
        $conn->execute_query('UPDATE reservations SET status=?,work_performed=? WHERE id=?',
            [$target, implode(', ', $completedServices), $id]);
    } else {
        $conn->execute_query('UPDATE reservations SET status=? WHERE id=?', [$target, $id]);
    }

    $title = 'Service status updated';
    $message = 'Your booking is now: ' . adminStatus($target) . '.';
    if ($workflow) {
        serviceWorkflowEvent($conn, $job, (int) $_SESSION['admin_id'], 'Booking status updated',
            ['previous_status' => $job['status'], 'status' => $target], $title, $message);
    } elseif ($job['user_id']) {
        $conn->execute_query("INSERT INTO notifications (user_id,title,message,link_type,link_id)
            VALUES (?, ?, ?, 'reservation', ?)", [$job['user_id'], $title, $message, $id]);
    }
    adminAudit($conn, 'Updated job stage', 'reservation', $id, $job['status'] . ' → ' . $target);
    $conn->commit();
    $_SESSION['admin_flash'] = ['type' => 'success', 'message' => 'Job updated: ' . adminStatus($target) . '.'];
} catch (Throwable $error) {
    $conn->rollback();
    $_SESSION['admin_flash'] = [
        'type' => 'warning',
        'message' => $error instanceof DomainException ? $error->getMessage() : 'The update could not be saved. Refresh and try again.',
    ];
}

header('Location: reservation_view.php?id=' . $id, true, 303);
exit;
