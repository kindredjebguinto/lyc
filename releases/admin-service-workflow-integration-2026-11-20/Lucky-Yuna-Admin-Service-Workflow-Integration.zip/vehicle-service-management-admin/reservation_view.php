<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/includes/job_schedule.php';
require_once __DIR__.'/includes/workflow_integration.php';
$id=(int)($_GET['id']??0);adminRequireJob($conn,$id);
$stmt=$conn->prepare('SELECT r.*,c.fullname customer_name,c.email customer_email,c.phone customer_phone,v.brand,v.model,v.year,v.plate_number,v.color,m.fullname mechanic_name FROM reservations r LEFT JOIN customers c ON c.id=r.customer_id LEFT JOIN vehicles v ON v.id=r.vehicle_id LEFT JOIN mechanics m ON m.id=r.mechanic_id WHERE r.id=?');$stmt->bind_param('i',$id);$stmt->execute();$job=$stmt->get_result()->fetch_assoc();$stmt->close();
$workflowBooking = adminWorkflowIsBooking($conn, $id);
$workflow = $workflowBooking ? adminWorkflowSummary($conn, $id) : null;
if ($workflowBooking && !$workflow) {
    http_response_code(503);
}
$stmt=$conn->prepare('SELECT * FROM payments WHERE reservation_id=? ORDER BY created_at,id');$stmt->bind_param('i',$id);$stmt->execute();$payments=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
$job['fee_required']=false;$reviewPayment=null;foreach($payments as $payment){if($payment['payment_type']==='Reservation Fee')$job['fee_required']=true;if($payment['status']==='Under Review')$reviewPayment=$payment;}
$releasePaymentBlocked = false;
if ($workflow && $job['status'] === 'Ready for Pickup') {
    $bill = $workflow['bill'];
    $billPayment = array_column($payments, null, 'id')[$bill['payment_id'] ?? 0] ?? null;
    $releasePaymentBlocked = !$billPayment || $billPayment['payment_type'] !== 'Final Balance' || $billPayment['status'] !== 'Paid'
        || !in_array($billPayment['refund_status'], ['Not Applicable', 'Rejected'], true)
        || $billPayment['amount'] !== $bill['amount_due'];
}
$stmt=$conn->prepare('SELECT * FROM job_quotations WHERE reservation_id=? LIMIT 1');$stmt->bind_param('i',$id);$stmt->execute();$quote=$stmt->get_result()->fetch_assoc();$stmt->close();
$stmt=$conn->prepare("SELECT * FROM admin_audit_logs WHERE entity_type='reservation' AND entity_id=? ORDER BY created_at DESC,id DESC LIMIT 15");$stmt->bind_param('i',$id);$stmt->execute();$activity=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
$stmt=$conn->prepare("SELECT id,appointment_date,service_type,work_performed FROM reservations WHERE vehicle_id=? AND id<>? AND status='Completed' ORDER BY appointment_date DESC,id DESC LIMIT 5");$stmt->bind_param('ii',$job['vehicle_id'],$id);$stmt->execute();$history=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
$free=adminCan('jobs.manage')?jobFreeMechanics($conn,$job):[];
$scheduleConflicts=jobConflicts($conn,$job);
$scheduleMechanics=adminCan('jobs.manage')?$conn->query("SELECT id,fullname FROM mechanics WHERE status IN ('Available','Busy') ORDER BY fullname")->fetch_all(MYSQLI_ASSOC):[];
$stmt=$conn->prepare('SELECT * FROM job_schedule_events WHERE reservation_id=? ORDER BY id DESC LIMIT 30');$stmt->bind_param('i',$id);$stmt->execute();$scheduleEvents=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
[$action,$actionUrl,$help]=adminNextAction($job, $workflow);
$transitions=['Pending'=>'Approved','Approved'=>'Diagnosing','Quotation Accepted'=>'In Progress','In Progress'=>'Ready for Pickup','Ready for Pickup'=>'Completed'];$target=$transitions[$job['status']]??null;
if ($workflowBooking && (!$workflow || !in_array($job['status'], ['Pending', 'Approved', 'Ready for Pickup'], true))) {
    $target = null;
}
$workflowCanWork = $workflow && adminCan('jobs.work') && in_array($job['status'], ['Diagnosing', 'In Progress'], true)
    && !empty($job['checked_in_at']) && !empty($job['mechanic_id'])
    && strtotime($job['appointment_date'].' '.$job['appointment_time']) <= time();
if ($workflowBooking && !$workflow) {
    [$action, $help] = ['Service workflow unavailable', 'The structured service record will return when the workflow is available.'];
}
$feeBlocked=$job['status']==='Pending'&&$job['fee_required']&&$job['reservation_fee_status']!=='Paid';
$canAdvance=adminCan('jobs.work')&&$target&&!$feeBlocked&&($job['status']!=='Approved'||($job['mechanic_id']&&!empty($job['checked_in_at'])))&&(!in_array($target,['Approved','Completed'],true)||adminCan('jobs.manage'))&&(!in_array($target,['Diagnosing','In Progress'],true)||!empty($job['checked_in_at']));
$tooEarly=in_array($target,['Diagnosing','In Progress'],true)&&strtotime($job['appointment_date'].' '.$job['appointment_time'])>time();
$closed=in_array($job['status'],['Completed','Cancelled'],true);
$stages=['Pending','Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress','Ready for Pickup','Completed'];$stageIndex=array_search($job['status'],$stages,true);
if ($workflowBooking) {
    $stages = ['Pending', 'Approved', 'Diagnosing', 'In Progress', 'Ready for Pickup', 'Completed'];
    $stageIndex = array_search($job['status'], $stages, true);
}
$workspaceBadge = $workflow ? adminWorkflowStateLabel($job, $workflow) : adminStatus($job['status']);
$workflowCanFinalize = false;
$workflowActivity = [];
$flash=$_SESSION['admin_flash']??null;unset($_SESSION['admin_flash']);
include __DIR__.'/includes/admin_header.php';
?>
<?php if($flash):?><div class="alert alert-<?= adminH($flash['type']) ?>" role="status"><?= adminH($flash['message']) ?></div><?php endif;?>
<div class="page-heading"><div><span class="eyebrow">JOB WORKSPACE</span><h1><?= adminH($job['reference_number']?:'Job #'.$id) ?></h1><p><?= adminH($job['plate_number']) ?> · <?= adminH(date('M j, Y · g:i A',strtotime($job['appointment_date'].' '.$job['appointment_time']))) ?> · <?= max(30,(int)$job['scheduled_duration_minutes']) ?> reserved minutes</p></div><a class="btn btn-light" href="reservations.php">← Jobs</a></div>
<nav class="job-tabs" aria-label="Job sections"><a href="#job-overview">Overview</a><a href="#job-action">Next action</a><a href="#job-schedule">Schedule</a><a href="<?= $workflowBooking ? '#job-workflow' : '#job-record' ?>">Service record</a><a href="#job-quote">Quotation</a><a href="#job-payments">Payments</a><a href="#job-activity">Activity</a></nav>
<div class="clean-card p-4 job-section"><div class="d-flex justify-content-between gap-3"><strong>Service progress</strong><div><?= adminWorkflowBadges($job, $workflow) ?></div></div><div class="status-timeline"><?php foreach($stages as $i=>$stage):?><div class="status-step <?= $stageIndex!==false&&$i<$stageIndex?'done':'' ?> <?= $stageIndex===$i?'active':'' ?>"><?= adminH($stageIndex === $i ? $workspaceBadge : adminStatus($stage)) ?></div><?php endforeach;?></div><?php if($closed):?><p class="text-muted small mb-0">Closed jobs remain available for reference.</p><?php endif;?></div>
<div class="workspace-columns"><div>
<section id="job-overview" class="clean-card p-4 job-section"><h2 class="h5">Customer & vehicle</h2><div class="record-grid mt-3"><div><span class="detail-label">Customer</span><div class="detail-value"><?= adminH($job['customer_name']?:'Customer') ?></div><small><?= adminH($job['customer_email']) ?><br><?= adminH($job['customer_phone']) ?></small></div><div><span class="detail-label">Vehicle</span><div class="detail-value"><?= adminH($job['brand'].' '.$job['model']) ?></div><small><?= adminH($job['year'].' · '.$job['plate_number'].' · '.$job['color']) ?></small></div><div class="wide"><span class="detail-label">Requested services</span><p><?= adminH($job['service_type']) ?></p><span class="detail-label">Customer concern</span><p class="staff-notice"><?= nl2br(adminH($job['remarks']?:'No additional concern provided.')) ?></p></div></div></section>
<?php if ($workflow): ?>
  <?php include __DIR__ . '/includes/service_workflow_panel.php'; ?>
<?php elseif ($workflowBooking): ?>
  <section id="job-workflow" class="clean-card p-4 job-section">
    <h2 class="h5">Service record unavailable</h2>
    <p class="alert alert-warning mb-0">Refresh after the service workflow has been restored.</p>
  </section>
<?php else: ?>
<section id="job-record" class="clean-card p-4 job-section"><?php if(($job['booking_channel']??'Online')==='Walk-in'):?><p class="staff-notice">Walk-in · arrival recorded · no advance reservation fee</p><?php endif;?><h2 class="h5">Service record</h2><p class="text-muted small">Save inspection findings and work performed. These notes appear in customer history.</p>
<?php if(adminCan('jobs.work')&&!$closed):?><form method="post" action="service_record_save.php"><?= adminCsrfInput() ?><input type="hidden" name="reservation_id" value="<?= $id ?>"><div class="record-grid"><div><label for="intakeMileage">Intake mileage</label><input class="form-control" type="number" min="0" id="intakeMileage" name="intake_mileage" value="<?= adminH($job['intake_mileage']) ?>"></div><div><label for="nextService">Next service date</label><input class="form-control" type="date" id="nextService" name="next_service_date" value="<?= adminH($job['next_service_date']) ?>"></div><?php foreach(['diagnosis'=>'Inspection / diagnosis','work_performed'=>'Work performed','completion_notes'=>'Completion notes'] as $name=>$label):?><div class="wide"><label for="<?= $name ?>"><?= $label ?></label><textarea class="form-control" rows="3" name="<?= $name ?>" id="<?= $name ?>"><?= adminH($job[$name]) ?></textarea></div><?php endforeach;?></div><button class="btn btn-primary mt-3">Save service record</button></form>
<?php else:?><dl><?php foreach(['intake_mileage'=>'Mileage','diagnosis'=>'Diagnosis','work_performed'=>'Work performed','completion_notes'=>'Completion notes','next_service_date'=>'Next service'] as $name=>$label):?><dt class="detail-label mt-3"><?= $label ?></dt><dd><?= nl2br(adminH($job[$name]?:'Not recorded')) ?></dd><?php endforeach;?></dl><?php endif;?></section>
<?php endif; ?>
<section class="clean-card p-4 job-section"><h2 class="h5">Vehicle service history</h2><?php if(!$history):?><p class="text-muted mb-0">No earlier completed jobs for this vehicle.</p><?php else:?><ul class="workspace-list"><?php foreach($history as $entry):?><li><strong><?= adminH($entry['appointment_date']) ?> · <?= adminH($entry['service_type']) ?></strong><small class="d-block text-muted"><?= adminH($entry['work_performed']?:'No work notes recorded.') ?></small></li><?php endforeach;?></ul><?php endif;?></section>
</div><div>
<?php include __DIR__.'/includes/job_schedule_panel.php'; ?>
<section id="job-action" class="clean-card p-4 job-section next-action-card"><span class="eyebrow">NEXT ACTION</span><h2 class="h5 mt-2"><?= adminH($action) ?></h2><p class="text-muted small"><?= adminH($help) ?></p>
<?php if($reviewPayment&&adminCan('finance')):?><a class="btn btn-primary w-100 mb-2" href="payment_view.php?id=<?= (int)$reviewPayment['id'] ?>">Verify submitted payment</a><?php endif;?>
<?php if(!in_array($job['status'],['Pending','Completed','Cancelled'],true)&&empty($job['checked_in_at'])): ?>
<?php if(adminCan('jobs.manage')): ?><form method="post" action="check_in.php" class="mb-3"><?= adminCsrfInput() ?><input type="hidden" name="reservation_id" value="<?= $id ?>"><button class="btn btn-primary w-100" <?= $job['appointment_date']>date('Y-m-d')?'disabled':'' ?>>Check in vehicle</button></form><?php else: ?><p class="staff-notice">Ask the service adviser to check in the vehicle before inspection.</p><?php endif; ?>
<?php elseif(!empty($job['checked_in_at'])): ?><p class="staff-notice">Arrived: <?= adminH($job['checked_in_at']) ?></p><?php endif; ?>
<?php if($feeBlocked):?><p class="staff-notice"><?= adminCan('finance')?'Review the reservation fee below before confirming.':'Ask a cashier or manager to verify the reservation fee.' ?></p>
<?php elseif($canAdvance):?><form method="post" action="reservation_update.php" data-confirm="<?= adminH('Confirm: '.adminStatus($target).'?') ?>"><?= adminCsrfInput() ?><input type="hidden" name="reservation_id" value="<?= $id ?>"><input type="hidden" name="status" value="<?= adminH($target) ?>"><button class="btn btn-primary w-100" <?= $tooEarly || $releasePaymentBlocked ? 'disabled' : '' ?>><?= adminH(['Approved'=>'Confirm appointment','Diagnosing'=>'Start inspection','In Progress'=>'Start work','Ready for Pickup'=>'Mark ready for pickup','Completed'=>'Release & complete'][$target]) ?></button></form><?php if($tooEarly):?><small class="text-muted">Inspection unlocks at the reserved appointment time.</small><?php elseif ($releasePaymentBlocked): ?><small class="text-muted">The final balance must be verified before release.</small><?php endif;?>
<?php elseif ($workflowCanFinalize): ?>
  <form method="post" action="service_workflow_action.php" data-confirm="<?= adminH($workflowPendingRepairs ? 'Finalize the bill for completed services and close pending additional repairs?' : 'Finalize the bill for completed services and mark this vehicle ready?') ?>">
    <?php $workflowForm('finalize_bill'); ?>
    <?php if ($workflowPendingRepairs): ?><p class="small">Pending additional repairs will be closed without charges.</p><?php endif; ?>
    <button class="btn btn-primary w-100">Finalize bill and mark ready</button>
  </form>
<?php elseif ($workflow && $workflowCanWork): ?>
  <a class="btn btn-outline-primary w-100" href="#job-workflow">Open service work</a>
<?php elseif(!$workflowBooking&&$job['status']==='Diagnosing'&&adminCan('quotes')):?><a class="btn btn-primary w-100" href="job_quotation.php?id=<?= $id ?>">Prepare quotation</a><?php elseif(!adminCan('jobs.work')&&!adminCan('finance')):?><p class="staff-notice">Your role can view this job. An authorized team member handles the next action.</p><?php endif;?>
<hr><h3 class="h6">Assigned mechanic</h3><p><?= adminH($job['mechanic_name']?:'Not assigned') ?></p>
<?php if(adminCan('jobs.manage')&&(!$job['mechanic_id']||$job['status']==='Approved')&&in_array($job['status'],['Approved','Diagnosing','Quotation Sent','Quotation Accepted','In Progress'],true)):?><form method="post" action="assign_mechanic.php"><?= adminCsrfInput() ?><input type="hidden" name="reservation_id" value="<?= $id ?>"><label class="visually-hidden" for="jobMechanic">Available mechanic</label><select class="form-select mb-2" id="jobMechanic" name="mechanic_id" required><option value="">Choose a mechanic</option><?php foreach($free as $mechanic):if((int)$mechanic['id']===(int)$job['mechanic_id'])continue;?><option value="<?= (int)$mechanic['id'] ?>"><?= adminH($mechanic['fullname']) ?></option><?php endforeach;?></select><?php if($job['mechanic_id']):?><input type="hidden" name="expected_mechanic" value="<?= (int)$job['mechanic_id'] ?>"><label for="reassignReason">Reassignment reason</label><textarea class="form-control mb-2" id="reassignReason" name="reason" maxlength="500" required></textarea><?php endif;?><button class="btn btn-outline-primary w-100" <?= !$free?'disabled':'' ?>><?= $job['mechanic_id']?'Reassign mechanic':'Assign mechanic' ?></button><small class="text-muted">Only mechanics free for the whole reserved window are listed.</small></form><?php endif;?>
<?php if(adminCan('jobs.manage')&&in_array($job['status'],['Pending','Approved'],true)):?><details class="mt-3"><summary>Cancel appointment</summary><form method="post" action="reservation_update.php" data-confirm="Cancel this booking and request any eligible fee refund?"><?= adminCsrfInput() ?><input type="hidden" name="reservation_id" value="<?= $id ?>"><input type="hidden" name="status" value="Cancelled"><label class="form-label mt-2" for="cancelReason">Reason</label><select class="form-select mb-2" id="cancelReason" name="cancellation_reason" required><option value="">Choose a reason</option><option>Schedule conflict</option><option>Service unavailable</option><option>Shop closure</option><option>Customer request</option><option>Duplicate booking</option></select><button class="btn btn-outline-danger w-100">Confirm cancellation</button></form></details><?php endif;?></section>
<section id="job-quote" class="clean-card p-4 job-section">
  <?php if ($workflow): ?>
    <h2 class="h5">Additional repair quotation</h2>
    <?php if ($workflow['quotation']): ?>
      <p>Revision <?= (int) $workflow['quotation']['version'] ?> · <?= adminH($workflow['quotation']['decision_status']) ?></p>
    <?php else: ?>
      <p class="text-muted"><?= $workflowFindings ? 'Additional findings recorded.' : 'A quotation is needed when additional repairs are recommended.' ?></p>
    <?php endif; ?>
    <?php if (!adminIsMechanic()): ?>
      <dl class="mb-3">
        <?php foreach (['original_authorized' => 'Original authorized', 'proposed_additional' => 'Proposed additional', 'approved_additional' => 'Approved additional', 'updated_authorized' => 'Updated authorized service total'] as $key => $label): ?>
          <dt><?= $label ?></dt><dd>₱<?= number_format((float) $workflow['totals'][$key], 2) ?></dd>
        <?php endforeach; ?>
      </dl>
    <?php endif; ?>
    <?php if (adminCan('quotes') && ($workflow['quotation'] || ($workflowCanWork && $workflow['inspection_completed'] && $workflowFindings))): ?>
      <a class="btn btn-outline-primary" href="job_quotation.php?id=<?= $id ?>"><?= $workflow['quotation'] ? 'Open quotation' : 'Prepare additional repair quotation' ?></a>
    <?php endif; ?>
  <?php elseif (!$workflowBooking): ?>
    <h2 class="h5">Quotation</h2><?php if($quote):?><p class="h3">₱<?= number_format((float)$quote['grand_total'],2) ?></p><p><?= adminH($quote['status']) ?></p><?php else:?><p class="text-muted">No quotation prepared yet.</p><?php endif;if(adminCan('quotes')):?><a class="btn btn-outline-primary" href="job_quotation.php?id=<?= $id ?>"><?= $quote?'Open quotation':'Prepare quotation' ?></a><?php endif;?>
  <?php else: ?>
    <h2 class="h5">Quotation</h2><p class="text-muted mb-0">Quotation information is unavailable.</p>
  <?php endif; ?>
</section>
<section id="job-payments" class="clean-card p-4 job-section"><h2 class="h5">Payments for this job</h2><?php if(!$payments):?><p class="text-muted">No payment records yet.</p><?php else:?><ul class="workspace-list"><?php foreach($payments as $payment):?><li><strong><?= adminH($payment['payment_type']) ?></strong><?php if(!adminIsMechanic()):?><div>₱<?= number_format((float)$payment['amount'],2) ?></div><?php endif;?><?= adminBadge($payment['status']) ?><?php if($payment['refund_status']!=='Not Applicable'):?><small class="d-block">Refund: <?= adminH($payment['refund_status']) ?></small><?php endif;if(adminCan('finance')):?><a class="d-block mt-2" href="payment_view.php?id=<?= (int)$payment['id'] ?>">Open payment review →</a><?php endif;?></li><?php endforeach;?></ul><?php endif;?></section>
</div></div>
<section id="job-activity" class="clean-card p-4 job-section"><h2 class="h5">Recent job activity</h2><?php if(!$activity&&!$workflowActivity):?><p class="text-muted mb-0">New staff actions will appear here.</p><?php else:foreach($activity as $event):?><div class="activity-entry"><strong><?= adminH($event['action']) ?></strong><small><?= adminH($event['admin_name'].' · '.$event['created_at']) ?></small><p class="small mb-0"><?= adminH($event['details']) ?></p></div><?php endforeach;endif;?>
<?php foreach ($workflowActivity as $event): ?>
  <?php
  $eventDetails = json_decode($event['details'], true) ?: [];
  $eventTask = $workflowTasks[(int) ($eventDetails['task_id'] ?? 0)]['name'] ?? null;
  $eventNote = $eventDetails['review'] ?? $eventDetails['reason'] ?? null;
  ?>
  <div class="activity-entry">
    <strong><?= adminH(ucfirst(str_replace('_', ' ', $event['event_type']))) ?></strong>
    <small><?= adminH(($event['actor_name'] ?: 'Account #' . (int) $event['actor_id']) . ' · ' . $event['created_at']) ?></small>
    <?php if ($eventTask): ?><p class="small mb-0"><?= adminH($eventTask . (isset($eventDetails['status']) ? ' · ' . $eventDetails['status'] : '')) ?></p><?php endif; ?>
    <?php if (is_string($eventNote)): ?><p class="small mb-0"><?= adminH($eventNote) ?></p><?php endif; ?>
  </div>
<?php endforeach; ?>
</section>
<?php include __DIR__.'/includes/admin_footer.php'; ?>
