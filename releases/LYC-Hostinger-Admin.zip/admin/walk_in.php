<?php
require_once __DIR__.'/includes/admin_auth.php';
require_once __DIR__.'/../includes/booking_slots.php';
$today=date('Y-m-d'); $error=''; $slots=[]; $selected=[];
$fields=['fullname','phone','email','brand','model','year','plate_number','remarks'];
$values=[];foreach($fields as $key)$values[$key]=trim((string)($_POST[$key]??''));
$vehicleId=(int)($_POST['vehicle_id']??0);
$services=$conn->query("SELECT id,service_name,estimated_duration,price FROM services WHERE status='Active' ORDER BY service_name")->fetch_all(MYSQLI_ASSOC);
$vehicles=$conn->query('SELECT v.id,v.plate_number,v.brand,v.model,c.fullname FROM vehicles v JOIN customers c ON c.id=v.customer_id ORDER BY c.fullname,v.plate_number')->fetch_all(MYSQLI_ASSOC);
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $ids=$_POST['services']??[];if(!is_array($ids))$ids=[];
    $ids=array_unique(array_map('intval',array_filter($ids,'is_scalar')));
    foreach($services as $service)if(in_array((int)$service['id'],$ids,true))$selected[]=$service;
    try {
        if(!$selected || count($selected)!==count($ids))throw new DomainException('Choose at least one active service.');
        $duration=bookingDuration($selected);
        $slots=bookingSlots($conn,$today,$duration,0,true)['slots'];
        if(($_POST['action']??'')==='save') {
            $time=(string)($_POST['appointment_time']??'');
            if($time==='now')$time=date('H:i');
            if(!$vehicleId) {
                foreach(['fullname','phone','brand','model','year','plate_number'] as $key)if($values[$key]==='')throw new DomainException('Complete the customer and vehicle details, or select an existing vehicle.');
                foreach(['fullname'=>100,'phone'=>30,'email'=>100,'brand'=>50,'model'=>50,'plate_number'=>20] as $key=>$max)if(mb_strlen($values[$key])>$max)throw new DomainException('The '.$key.' is too long.');
                if($values['email']!==''&&!filter_var($values['email'],FILTER_VALIDATE_EMAIL))throw new DomainException('Enter a valid email or leave it blank.');
                if(!ctype_digit($values['year'])||(int)$values['year']<1900||(int)$values['year']>(int)date('Y')+1)throw new DomainException('Enter a valid vehicle year.');
            }
            if(strlen($values['remarks'])>1000)throw new DomainException('Keep the customer concern within 1000 characters.');
            $names=implode(', ',array_column($selected,'service_name'));
            if(strlen($names)>500)throw new DomainException('Choose fewer services for one job.');
            bookingLock($conn,$today);
            try {
                // Recheck inside the same daily lock used by website and app bookings.
                bookingRequireSlot($conn,$today,$time,$duration,true);
                $conn->begin_transaction();
                if($vehicleId) {
                    $stmt=$conn->prepare('SELECT v.customer_id,c.user_id FROM vehicles v JOIN customers c ON c.id=v.customer_id WHERE v.id=? FOR UPDATE');$stmt->bind_param('i',$vehicleId);$stmt->execute();$owner=$stmt->get_result()->fetch_assoc();
                    if(!$owner)throw new DomainException('Choose an existing customer vehicle.');
                    $customerId=(int)$owner['customer_id'];$userId=$owner['user_id']===null?null:(int)$owner['user_id'];
                } else {
                    // New guests stay separate from app accounts; staff select an existing
                    // vehicle explicitly rather than attaching by an unverified email.
                    $userId=null;
                    $stmt=$conn->prepare('INSERT INTO customers(fullname,email,phone) VALUES(?,?,?)');$stmt->bind_param('sss',$values['fullname'],$values['email'],$values['phone']);$stmt->execute();$customerId=$stmt->insert_id;
                    $plate=strtoupper($values['plate_number']);$year=(int)$values['year'];
                    $stmt=$conn->prepare('INSERT INTO vehicles(customer_id,brand,model,year,plate_number) VALUES(?,?,?,?,?)');$stmt->bind_param('issis',$customerId,$values['brand'],$values['model'],$year,$plate);$stmt->execute();$vehicleId=$stmt->insert_id;
                }
                $reference='WALK-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(4)));
                $stmt=$conn->prepare("INSERT INTO reservations(reference_number,user_id,customer_id,vehicle_id,service_type,appointment_date,appointment_time,remarks,status,scheduled_duration_minutes,checked_in_at,booking_channel,reservation_fee_status) VALUES(?,?,?,?,?,?,?,?,'Approved',?,NOW(),'Walk-in','Not Required')");
                $stmt->bind_param('siiissssi',$reference,$userId,$customerId,$vehicleId,$names,$today,$time,$values['remarks'],$duration);$stmt->execute();$id=$stmt->insert_id;
                adminAudit($conn,'Walk-in registered','reservation',$id,'Vehicle arrived at the shop; no advance reservation fee.');
                $conn->commit();header('Location: '.ADMIN_BASE_URL.'/reservation_view.php?id='.$id);exit;
            } catch(Throwable $e) { $conn->rollback();throw $e; }
            finally { bookingUnlock($conn,$today); }
        }
    } catch(Throwable $e) { $error=$e instanceof DomainException || $e instanceof BookingScheduleBusyException ? $e->getMessage() : 'Unable to register this walk-in. Refresh availability and try again.'; }
}
include __DIR__.'/includes/admin_header.php';
?>
<div class="page-heading"><div><span class="eyebrow">SERVICE DESK</span><h1>Register a walk-in</h1><p>Today, <?= adminH(date('D, M j, Y')) ?> · Manila time. No app account or advance reservation fee required.</p></div></div>
<?php if($error):?><div class="alert alert-danger" role="alert"><?= adminH($error) ?></div><?php endif;?>
<form method="post" class="clean-card p-4"><?= adminCsrfInput() ?>
<h2 class="h5">Customer and vehicle</h2>
<label for="walkVehicle">Existing customer vehicle</label><select class="form-select mb-3" name="vehicle_id" id="walkVehicle"><option value="0">New customer / vehicle — enter details below</option><?php foreach($vehicles as $vehicle):?><option value="<?= (int)$vehicle['id'] ?>" <?= $vehicleId===(int)$vehicle['id']?'selected':'' ?>><?= adminH($vehicle['fullname'].' · '.$vehicle['plate_number'].' · '.$vehicle['brand'].' '.$vehicle['model']) ?></option><?php endforeach;?></select>
<details <?= !$vehicleId?'open':'' ?>><summary class="mb-3">New customer and vehicle details</summary><div class="row g-3 mb-4"><?php foreach(['fullname'=>'Customer name','phone'=>'Phone','email'=>'Email (optional)','brand'=>'Vehicle brand','model'=>'Model','year'=>'Year','plate_number'=>'Plate number'] as $key=>$label):?><div class="col-md-6"><label for="walk_<?= $key ?>"><?= $label ?></label><input class="form-control" id="walk_<?= $key ?>" name="<?= $key ?>" value="<?= adminH($values[$key]) ?>" <?= $key==='email'?'type="email"':($key==='year'?'type="number" min="1900" max="'.((int)date('Y')+1).'"':'type="text"') ?>></div><?php endforeach;?></div></details>
<label for="walkConcern">Customer concern (optional)</label><textarea class="form-control mb-4" id="walkConcern" name="remarks" maxlength="1000"><?= adminH($values['remarks']) ?></textarea>
<h2 class="h5">Services and available mechanics</h2><div class="row g-2 mb-3"><?php foreach($services as $service):?><label class="col-md-6"><input type="checkbox" name="services[]" value="<?= (int)$service['id'] ?>" <?= in_array((int)$service['id'],array_map('intval',array_column($selected,'id')),true)?'checked':'' ?>> <?= adminH($service['service_name']) ?> <small class="text-muted"><?= max(30,(int)$service['estimated_duration']) ?> min</small></label><?php endforeach;?></div>
<button class="btn btn-outline-primary mb-3" name="action" value="check" formnovalidate>Check / refresh today's slots</button>
<?php if($selected):?><p>Estimated service time: <?= (int)$duration ?> minutes. Availability is checked again when you register the walk-in.</p><div class="row g-2 mb-3"><?php $available=false;foreach($slots as $slot):if(!$slot['available'])continue;$available=true;?><div class="col-sm-6 col-lg-4"><label class="d-block border rounded p-3"><input type="radio" name="appointment_time" value="<?= $slot['is_now']?'now':adminH($slot['time']) ?>" required> <strong><?= $slot['is_now']?'Start now · ':'' ?><?= adminH($slot['label']) ?></strong><small class="d-block"><?= (int)$slot['remaining_capacity'] ?> mechanic<?= $slot['remaining_capacity']===1?'':'s' ?> available</small></label></div><?php endforeach;?></div>
<?php if(!$available):?><p class="alert alert-warning">No remaining slot fits these services today. Check the selected service duration, shop hours and mechanic availability.</p><?php else:?><button class="btn btn-primary" name="action" value="save">Register walk-in and check in vehicle</button><?php endif;?><?php endif;?>
<p class="text-muted small mt-3 mb-0">After registration, assign a mechanic in the job workspace. Quote approval and final payment follow the normal service process. You can record the customer's quotation decision in person.</p>
</form>
<?php include __DIR__.'/includes/admin_footer.php'; ?>
