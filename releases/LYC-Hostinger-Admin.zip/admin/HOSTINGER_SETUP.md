# Hostinger admin portal: customer website at the domain root

This ZIP is for the existing layout with customer website files directly inside public_html and BASE_URL set to an empty string. It is not the XAMPP-layout archive.

1. Upload LYC-Hostinger-Admin.zip into public_html and extract there. It creates public_html/admin/. Keep existing customer files, database configuration and uploaded proofs.
2. The admin portal reuses public_html/includes/config.php. No extra database credentials or SQL import is needed. Use the current full lyc_database.sql schema already installed for the website.
3. Create your own account through the customer website's /register.php (or use your existing personal customer account). Use an email and password you control. Do this before promoting the account; staff accounts no longer sign in through customer login.
4. In phpMyAdmin select the website's database. First run the SELECT below with YOUR actual registered email. Confirm it identifies exactly your account. Then run the UPDATE. Never promote an account you do not control.

```sql
SELECT id,fullname,email,role,staff_level FROM users WHERE email='YOUR_REGISTERED_EMAIL';

UPDATE users SET role='staff',staff_level='Manager'
WHERE email='YOUR_REGISTERED_EMAIL' AND role='customer';
```

5. Sign out of the customer website. Open https://YOUR_DOMAIN/admin/login.php and sign in with that same email and password. No default password or publicly accessible manager-creation page is provided.
6. Add mechanics in Team, then staff accounts through Staff access. Test Schedule, Walk-in, quotations and Payments.
7. Confirm HTTPS and keep uploads/payment_proofs/.htaccess in place. Remove the uploaded ZIP from public_html after extraction.

The package changes admin filesystem/URL paths for a root-domain customer site. It includes no database passwords or accounts. Existing XAMPP admin installations should continue using the regular Websites-XAMPP release.
