<?php
// Root-domain hosting: reuse the customer website's existing connection.
require_once __DIR__ . '/../../includes/config.php';
define('ADMIN_BASE_URL', '/admin');
define('PUBLIC_BASE_URL', BASE_URL);
