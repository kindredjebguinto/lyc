<?php
require_once __DIR__.'/../../includes/booking_slots.php';
function jobStart(array $job): DateTimeImmutable { return new DateTimeImmutable($job['appointment_date'].' '.$job['appointment_time'],new DateTimeZone('Asia/Manila')); }
function jobFinish(array $job): DateTimeImmutable { return jobStart($job)->modify('+'.max(30,(int)$job['scheduled_duration_minutes']).' minutes'); }
function jobUsesMechanic(array $job): bool { return !in_array($job['status'],['Cancelled','Completed','Ready for Pickup'],true); }
function jobFreeMechanics(mysqli $conn,array $job): array {
    $start=jobStart($job)->format('Y-m-d H:i:s');$end=jobFinish($job)->format('Y-m-d H:i:s');$id=(int)$job['id'];
    $stmt=$conn->prepare("SELECT m.id,m.fullname FROM mechanics m WHERE m.status IN ('Available','Busy') AND NOT EXISTS(SELECT 1 FROM reservations r WHERE r.mechanic_id=m.id AND r.id<>? AND r.status NOT IN ('Cancelled','Completed','Ready for Pickup') AND TIMESTAMP(r.appointment_date,r.appointment_time)<? AND DATE_ADD(TIMESTAMP(r.appointment_date,r.appointment_time),INTERVAL GREATEST(r.scheduled_duration_minutes,30) MINUTE)>?) ORDER BY m.fullname");
    $stmt->bind_param('iss',$id,$end,$start);$stmt->execute();return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
function jobConflicts(mysqli $conn,array $job): array {
    if(!jobUsesMechanic($job))return [];
    $start=jobStart($job)->format('Y-m-d H:i:s');$end=jobFinish($job)->format('Y-m-d H:i:s');$id=(int)$job['id'];$mechanic=(int)$job['mechanic_id'];
    $stmt=$conn->prepare("SELECT r.*,c.fullname customer_name,c.phone customer_phone,m.fullname mechanic_name FROM reservations r LEFT JOIN customers c ON c.id=r.customer_id LEFT JOIN mechanics m ON m.id=r.mechanic_id WHERE r.id<>? AND r.status NOT IN ('Cancelled','Completed','Ready for Pickup') AND TIMESTAMP(r.appointment_date,r.appointment_time)<? AND DATE_ADD(TIMESTAMP(r.appointment_date,r.appointment_time),INTERVAL GREATEST(r.scheduled_duration_minutes,30) MINUTE)>? ORDER BY r.appointment_date,r.appointment_time,r.id");
    $stmt->bind_param('iss',$id,$end,$start);$stmt->execute();$conflicts=[];
    foreach($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $other){
        if($mechanic && (int)$other['mechanic_id']===$mechanic){$other['conflict_reason']='Same mechanic is occupied';$conflicts[]=$other;}
        elseif(!$other['mechanic_id'] && bookingRemainingAt($conn,$other['appointment_date'],$other['appointment_time'],max(30,(int)$other['scheduled_duration_minutes']),(int)$other['id'])<1){$other['conflict_reason']='No remaining capacity for this unassigned booking';$conflicts[]=$other;}
        elseif(!$mechanic && bookingRemainingAt($conn,$job['appointment_date'],$job['appointment_time'],max(30,(int)$job['scheduled_duration_minutes']),$id)<1){$other['conflict_reason']='Shop capacity needs review';$conflicts[]=$other;}
    }
    return $conflicts;
}
function jobDayConflicts(mysqli $conn,string $date): array {
    $next=(new DateTimeImmutable($date))->modify('+1 day')->format('Y-m-d');
    $stmt=$conn->prepare("SELECT * FROM reservations WHERE original_duration_minutes IS NOT NULL AND scheduled_duration_minutes>original_duration_minutes AND status NOT IN ('Cancelled','Completed','Ready for Pickup') AND TIMESTAMP(appointment_date,appointment_time)<? AND DATE_ADD(TIMESTAMP(appointment_date,appointment_time),INTERVAL scheduled_duration_minutes MINUTE)>?");
    $stmt->bind_param('ss',$next,$date);$stmt->execute();$pairs=[];
    foreach($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $job)foreach(jobConflicts($conn,$job) as $other){$ids=[(int)$job['id'],(int)$other['id']];sort($ids);$pairs[implode('-',$ids)]=['job'=>$job,'other'=>$other];}
    return array_values($pairs);
}
function jobScheduleEvent(mysqli $conn,array $before,array $after,string $action,string $reason,?string $consent=null): void {
    $id=(int)$before['id'];$actor=(int)$_SESSION['admin_id'];$old=jobStart($before)->format('Y-m-d H:i:s');$new=jobStart($after)->format('Y-m-d H:i:s');$oldDuration=(int)$before['scheduled_duration_minutes'];$newDuration=(int)$after['scheduled_duration_minutes'];
    $stmt=$conn->prepare('INSERT INTO job_schedule_events(reservation_id,actor_id,action,old_start,new_start,old_duration,new_duration,reason,consent_reference) VALUES(?,?,?,?,?,?,?,?,?)');
    $stmt->bind_param('iisssiiss',$id,$actor,$action,$old,$new,$oldDuration,$newDuration,$reason,$consent);$stmt->execute();
}
function jobScheduleNotice(mysqli $conn,array $job,string $title,string $message): void {
    if(!$job['user_id'])return;
    $stmt=$conn->prepare("INSERT INTO notifications(user_id,title,message,link_type,link_id) VALUES(?,?,?,'reservation',?)");$stmt->bind_param('issi',$job['user_id'],$title,$message,$job['id']);$stmt->execute();
}
