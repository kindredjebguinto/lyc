# Restore the mixed root-domain hosting upload

1. Download a backup of the current public_html directory first.
2. Upload LYC-Hostinger-Root-Recovery.zip into public_html. Extract it there with folder structure preserved. Choose replace/overwrite for bundled files. Do not delete public_html or remove its existing folders first.
3. The ZIP restores customer website files at the root and staff files under admin/. It deliberately excludes includes/config.php, api/config/database.php, database scripts and payment-proof images. Your existing database credentials and stored uploads stay in place. It does include admin/includes/config.php, which reuses the root site's configured connection.
4. Confirm public_html/admin/includes/admin_auth.php and public_html/admin/css/workspace.css exist. If admin_auth.php or workspace.css is at the root only, the upload was flattened; extract the ZIP in File Manager instead of uploading loose files.
5. Verify the customer homepage, /services.php and /admin/login.php. The root website config must already contain your Hostinger database name/user/password and BASE_URL set to an empty string. No SQL import is required.
6. Once both sites work, move the misplaced root files listed in ROOT_ADMIN_LEFTOVERS.txt into your backup OUTSIDE public_html. Leave all files inside admin/ and all customer folders intact. Never delete root login.php, logout.php, index.php or services.php; they are the restored customer versions.
7. Remove uploaded ZIP files from public_html. For first manager creation, follow admin/HOSTINGER_SETUP.md: register an owner account then promote that exact account through phpMyAdmin. No default manager password is supplied.
