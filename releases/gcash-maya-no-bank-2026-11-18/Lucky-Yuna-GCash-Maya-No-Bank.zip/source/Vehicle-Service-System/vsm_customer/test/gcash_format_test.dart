import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/services/receipt_classifier.dart';
import 'package:vsm_customer/services/receipt_validation_rules.dart';
import 'package:vsm_customer/models/receipt_screening.dart';

import 'receipt_rules_test.dart' show validText;

ReceiptScreening check(String text) => ReceiptValidationRules().validate(
  ReceiptClassifier().classify(text),
  expectedAmountMinor: 20000,
  accountName: 'TEST MERCHANT',
  accountNumber: '09990000001',
  walletMethod: 'GCash',
  ocrText: text,
);
void main() {
  test(
    'completed GCash receipt passes',
    () => expect(
      check(validText).state,
      ReceiptValidationState.validForSubmission,
    ),
  );
  for (final word in [
    'Pending',
    'Failed',
    'Cancelled',
    'Refunded',
    'Reversed',
  ]) {
    test(
      '$word status prevents GCash submission',
      () => expect(
        check('$validText\n$word').state,
        ReceiptValidationState.invalid,
      ),
    );
  }
  test(
    'matching amount and phone without format blocked',
    () => expect(
      check('Amount: PHP 200.00\nRecipient: 09990000001').state,
      ReceiptValidationState.invalid,
    ),
  );
  test(
    'wrong amount blocked',
    () => expect(
      check(validText.replaceAll('200.00', '250.00')).state,
      ReceiptValidationState.invalid,
    ),
  );
  test(
    'wrong recipient blocked',
    () => expect(
      check(validText.replaceAll('09990000001', '09123456789')).state,
      ReceiptValidationState.invalid,
    ),
  );
  test(
    'missing recipient never ready',
    () => expect(
      check(validText.replaceAll('09990000001', '')).state,
      isNot(ReceiptValidationState.validForSubmission),
    ),
  );
  test(
    'missing success status blocked',
    () => expect(
      check(validText.replaceAll('Payment successfully sent', 'Transfer'))
          .state,
      ReceiptValidationState.invalid,
    ),
  );
  test(
    'missing reference label blocked',
    () => expect(
      check(validText.replaceAll('Reference No.: 1234567890123', '')).state,
      ReceiptValidationState.invalid,
    ),
  );
}
