import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/services/receipt_classifier.dart';
import 'package:vsm_customer/services/receipt_validation_rules.dart';
import 'package:vsm_customer/models/receipt_screening.dart';

import 'maya_receipt_layout_test.dart'
    show mayaOverlay, mayaCompact, mayaExpanded;

ReceiptScreening strict(String text) => ReceiptValidationRules().validate(
  ReceiptClassifier().classify(text),
  expectedAmountMinor: 20000,
  accountName: 'TEST MERCHANT',
  accountNumber: '09990000001',
  walletMethod: 'Maya',
  ocrText: text,
);
void main() {
  final compact = '$mayaCompact\nShare';
  for (final entry in {
    'success popup': mayaOverlay,
    'full receipt': mayaExpanded,
    'compact receipt': compact,
  }.entries) {
    test('${entry.key} passes with the approved amount and recipient', () {
      expect(
        strict(entry.value).state,
        ReceiptValidationState.validForSubmission,
      );
    });
    test('${entry.key} wrong amount blocked', () {
      expect(
        strict(entry.value.replaceAll('200.00', '250.00')).state,
        ReceiptValidationState.invalid,
      );
    });
    test('${entry.key} wrong recipient blocked', () {
      expect(
        strict(entry.value.replaceAll('+639990000001', '+639198765432')).state,
        ReceiptValidationState.invalid,
      );
    });
    test('${entry.key} missing recipient blocked', () {
      expect(
        strict(entry.value.replaceAll('+639990000001', '+63 *** *** 0001'))
            .state,
        isNot(ReceiptValidationState.validForSubmission),
      );
    });
    test('${entry.key} pending or failed status blocked', () {
      expect(
        strict('${entry.value}\nPending').state,
        ReceiptValidationState.invalid,
      );
      expect(
        strict('${entry.value}\nFailed').state,
        ReceiptValidationState.invalid,
      );
    });
  }
  test('generic amount/phone text is not one of the three formats', () {
    expect(
      strict('Amount: PHP 200.00\nRecipient: 09990000001').state,
      ReceiptValidationState.invalid,
    );
  });
  test('unknown Maya layout with matching values blocked', () {
    expect(
      strict('Maya\nAmount: PHP 200.00\nRecipient: 09990000001\nCompleted')
          .state,
      ReceiptValidationState.invalid,
    );
  });
  test('incomplete success format blocked', () {
    expect(
      strict(mayaOverlay.replaceAll('View receipt', '')).state,
      ReceiptValidationState.invalid,
    );
  });
  test('incomplete full format blocked', () {
    expect(
      strict(mayaExpanded.replaceAll('Transaction details', '')).state,
      ReceiptValidationState.invalid,
    );
  });
  test('incomplete compact format blocked', () {
    expect(strict(mayaCompact).state, ReceiptValidationState.invalid);
  });
  test('unreadable image is never ready for submission', () {
    expect(strict('').state, ReceiptValidationState.invalid);
    expect(
      ReceiptScreening.unreadable().state,
      isNot(ReceiptValidationState.validForSubmission),
    );
    expect(
      ReceiptScreening.unreadable().reasons.join(),
      isNot(contains('request manual review')),
    );
  });
}
