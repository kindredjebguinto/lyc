import 'package:flutter/material.dart';

class ReceiptReferenceGuide extends StatelessWidget {
  final String method;
  const ReceiptReferenceGuide({this.method = 'Maya', super.key});

  Widget _example(
    BuildContext context, {
    required String title,
    required String asset,
    required String caption,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      InkWell(
        onTap: () => showDialog<void>(
          context: context,
          builder: (zoomContext) => Dialog(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: InteractiveViewer(
                    child: Image.asset(
                      asset,
                      fit: BoxFit.contain,
                      semanticLabel: title,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(zoomContext),
                  child: const Text('Close image'),
                ),
              ],
            ),
          ),
        ),
        child: Image.asset(
          asset,
          height: 230,
          width: double.infinity,
          cacheWidth: 480,
          fit: BoxFit.contain,
          semanticLabel: title,
        ),
      ),
      const SizedBox(height: 8),
      Text(caption),
    ],
  );

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text('$method receipt guide'),
    content: SizedBox(
      width: 360,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Illustrations only. Upload your own receipt. Tap a picture to enlarge.',
            ),
            const SizedBox(height: 16),
            _example(
              context,
              title: 'Accepted example',
              asset: method == 'GCash'
                  ? 'assets/images/gcash_receipt_accepted_sample.png'
                  : 'assets/images/receipt_accepted_sample.png',
              caption: method == 'GCash'
                  ? 'A completed GCash receipt with the correct amount, full shop recipient number and actual transaction reference. Keep the success message and details readable.'
                  : 'A completed Maya receipt with the correct amount, full shop recipient number and transaction reference. The Maya success popup and full receipt are also supported when their details are readable.',
            ),
            const SizedBox(height: 24),
            _example(
              context,
              title: 'Not accepted example',
              asset: 'assets/images/receipt_rejected_sample.png',
              caption: 'Pending transfers, missing or unreadable details, wrong amount or recipient, and unsupported formats cannot be submitted.',
            ),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Got it'),
      ),
    ],
  );
}
