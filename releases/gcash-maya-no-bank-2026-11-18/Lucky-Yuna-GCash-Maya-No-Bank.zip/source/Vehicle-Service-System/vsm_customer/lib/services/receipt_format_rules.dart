// Recognizes the three shop-approved Maya text layouts. This is screening only,
// not a claim that a screenshot is authentic or funds were received.
class ReceiptFormatRules {
  static String? gcashLayout(String text) {
    final value = text.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    if (!RegExp(r'\bgcash\b').hasMatch(value) ||
        RegExp(
          r'\b(pending|failed|cancelled|canceled|refund|refunded|reversed|reversal)\b',
        ).hasMatch(value)) {
      return null;
    }
    final completed = RegExp(
      r'successfully sent|sent successfully|payment successful|successfully paid|money sent',
    ).hasMatch(value);
    final recipient = RegExp(r'sent to|paid to|recipient|account name')
        .hasMatch(value);
    final reference = RegExp(
      r'reference(?: no\.?| number| id)?|ref\.?(?: no\.?| number)?|transaction (?:id|number)',
    ).hasMatch(value);
    return completed && recipient && reference
        ? 'gcash-successful-transfer'
        : null;
  }

  static String? mayaLayout(String text) {
    final value = text.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    bool has(String phrase) => value.contains(phrase);
    if (RegExp(
      r'\b(pending|failed|cancelled|canceled|refunded|reversed|refund|reversal)\b',
    ).hasMatch(value)) {
      return null;
    }
    if (has('confirm transaction') &&
        has('successfully sent') &&
        has('source') &&
        has('my wallet') &&
        has('destination') &&
        has('view receipt') &&
        has('done')) {
      return 'maya-success';
    }
    if (has('sent money to') &&
        has('completed') &&
        has('reference id') &&
        has('share') &&
        RegExp(r'\bmaya\b').hasMatch(value)) {
      return 'maya-compact';
    }
    if (has('sent money') &&
        !has('sent money to') &&
        has('completed') &&
        has('source') &&
        has('my wallet') &&
        has('destination') &&
        has('transaction details') &&
        RegExp(r'\bmaya\b').hasMatch(value)) {
      return 'maya-expanded';
    }
    return null;
  }
}
