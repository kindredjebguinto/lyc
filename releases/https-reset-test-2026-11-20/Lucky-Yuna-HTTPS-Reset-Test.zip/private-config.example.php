<?php
// Save as lyc-reset-test-private/auth.php beside public_html on Hostinger.
return [
    'staging_host' => 'auth-test.luckyyuna.com',
    'test_email' => '', // A real inbox you control for the single test account.
    'database' => [
        'host' => 'localhost',
        'name' => '', // Full hPanel database name ending in _lyc_reset_test.
        'username' => '',
        'password' => '',
    ],
    'allow_local_http' => false,
    'reset_url' => 'https://auth-test.luckyyuna.com/api/auth/reset_password.php',
    'smtp' => [
        'host' => 'smtp.hostinger.com',
        'port' => 465,
        'encryption' => 'ssl',
        'username' => '', // Full Hostinger mailbox address.
        'password' => '',
        'from_email' => '', // Same mailbox address.
        'from_name' => 'Lucky Yuna Test',
    ],
];
