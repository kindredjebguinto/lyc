<?php
require_once __DIR__.'/../includes/customer_auth.php';
require_once __DIR__.'/../includes/payment_gateway_guard.php';
$userId=(int)$_SESSION['customer_id'];
$id=(int)($_GET['id']??$_POST['id']??0);
if(empty($_SESSION['csrf_token']))$_SESSION['csrf_token']=bin2hex(random_bytes(32));
$error='';
$stmt=$conn->prepare("SELECT p.*,r.reference_number,r.service_type,v.brand,v.model FROM payments p JOIN reservations r ON r.id=p.reservation_id JOIN vehicles v ON v.id=r.vehicle_id WHERE p.id=? AND r.user_id=? AND p.status IN ('Awaiting Proof','Rejected') AND p.amount>0 AND r.status<>'Cancelled' AND (p.payment_type='Reservation Fee' OR EXISTS(SELECT 1 FROM job_quotations q WHERE q.reservation_id=r.id AND q.status='Accepted')) LIMIT 1");
$stmt->bind_param('ii',$id,$userId);$stmt->execute();$payment=$stmt->get_result()->fetch_assoc();$stmt->close();
if(!$payment){header('Location: '.BASE_URL.'/customer/payments.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
    $csrf=$_POST['csrf_token']??'';
    if(!is_string($csrf)||!hash_equals($_SESSION['csrf_token'],$csrf))$error='Request expired. Refresh and try again.';
    $method=is_string($_POST['payment_method']??null)?$_POST['payment_method']:'';
    $reference=is_string($_POST['reference_number']??null)?trim($_POST['reference_number']):'';
    if(!$error&&!in_array($method,['GCash','Maya','Bank Transfer'],true))$error='Choose a valid online payment method.';
    if(!$error&&($reference===''||strlen($reference)>100))$error='Enter a transaction reference of up to 100 characters.';
    if(!$error&&(!isset($_FILES['proof'])||$_FILES['proof']['error']!==UPLOAD_ERR_OK))$error='Upload your payment proof.';
    if(!$error){
        $file=$_FILES['proof'];$mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if($file['size']<=0||$file['size']>5*1024*1024||!isset($ext[$mime]))$error='Use a JPG, PNG, or WEBP image up to 5 MB.';
    }
    if(!$error){
        $destination=null;
        try{
            $conn->begin_transaction();
            gatewayAssertManualAllowed($conn,$id);
            // Recheck eligibility after acquiring the reservation/payment locks.
            $s=$conn->prepare("SELECT p.proof_file FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id=? AND r.user_id=? AND p.status IN ('Awaiting Proof','Rejected') AND p.amount>0 AND r.status<>'Cancelled' AND (p.payment_type='Reservation Fee' OR EXISTS(SELECT 1 FROM job_quotations q WHERE q.reservation_id=r.id AND q.status='Accepted'))");
            $s->bind_param('ii',$id,$userId);$s->execute();$locked=$s->get_result()->fetch_assoc();$s->close();
            if(!$locked)throw new DomainException('This payment changed. Refresh Payments before submitting again.');
            $dir=__DIR__.'/../uploads/payment_proofs';
            if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Upload directory unavailable.');
            $name='proof_'.$id.'_'.bin2hex(random_bytes(6)).'.'.$ext[$mime];$destination=$dir.'/'.$name;
            if(!move_uploaded_file($file['tmp_name'],$destination))throw new RuntimeException('Upload unavailable.');
            $relative='uploads/payment_proofs/'.$name;
            $s=$conn->prepare("UPDATE payments SET payment_method=?,reference_number=?,proof_file=?,status='Under Review',submitted_at=NOW(),paid_at=NULL WHERE id=? AND status IN ('Awaiting Proof','Rejected')");
            $s->bind_param('sssi',$method,$reference,$relative,$id);$s->execute();$changed=$s->affected_rows;$s->close();
            if(!$changed)throw new DomainException('This payment changed. Refresh Payments before submitting again.');
            if(($payment['payment_type']??'')==='Reservation Fee'){
                $rid=(int)$payment['reservation_id'];$s=$conn->prepare("UPDATE reservations SET reservation_fee_status='Under Review' WHERE id=?");$s->bind_param('i',$rid);$s->execute();$s->close();
            }
            $conn->commit();
            $oldProof=$locked['proof_file']??'';
            if($oldProof!==$relative&&str_starts_with($oldProof,'uploads/payment_proofs/')){$oldPath=$dir.'/'.basename($oldProof);if(is_file($oldPath))@unlink($oldPath);}
            header('Location: '.BASE_URL.'/customer/payments.php?submitted=1');exit;
        }catch(Throwable $e){
            $conn->rollback();if($destination&&is_file($destination))@unlink($destination);
            $error=$e instanceof DomainException?$e->getMessage():'Unable to save the proof. Your payment was not marked as paid. Please try again.';
        }
    }
}
require_once __DIR__.'/../includes/customer_header.php';?>
<div class="customer-page-header"><div><h1>Pay Reservation Fee</h1><p><?=htmlspecialchars($payment['reference_number'].' • '.$payment['brand'].' '.$payment['model'])?></p></div></div><?php if($error):?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif;?><div class="customer-card mx-auto" style="max-width:680px"><h2 class="h4">Refundable ₱<?=number_format((float)$payment['amount'],2)?></h2><p>This fee reserves your requested schedule, is credited to your final bill, and is refunded if you or the service center cancels before inspection.</p><form method="post" enctype="multipart/form-data"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>"><label class="form-label">Payment method</label><select class="form-select mb-3" name="payment_method" required><option>GCash</option><option>Maya</option><option>Bank Transfer</option></select><label class="form-label">Transaction reference</label><input class="form-control mb-3" name="reference_number" required><label class="form-label">Proof image</label><input class="form-control mb-3" type="file" name="proof" accept="image/jpeg,image/png,image/webp" required><button class="customer-primary-action w-100">Submit ₱200 Payment Proof</button></form></div>
<?php require_once __DIR__.'/../includes/customer_footer.php';?>
