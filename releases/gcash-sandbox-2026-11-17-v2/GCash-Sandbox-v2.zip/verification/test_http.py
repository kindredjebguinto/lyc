import urllib.request,urllib.error,json,uuid,subprocess,os
from pathlib import Path
base='http://127.0.0.1:8093/Vehicle-Service-System'
f=json.loads(Path('/workspace/work/gcash-integration/http-fixture.json').read_text());pid=f['payment_id'];csrf=f['csrf'];checks=[]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def request(path,method='GET',data=None,headers=None):
 try:r=opener.open(urllib.request.Request(base+path,data=data,method=method,headers=headers or {}),timeout=10)
 except urllib.error.HTTPError as e:r=e
 return r.status,r.read().decode(),dict(r.headers)
def check(name,ok):
 checks.append({'name':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
api='/vehicle-service-management/api/payments/'
for endpoint,method in [('gcash/create.php','POST'),('gcash/status.php','GET'),('gcash/cancel.php','POST')]:
 status,body,_=request(api+endpoint,method,b'{}' if method=='POST' else None,{'Content-Type':'application/json'})
 check(endpoint+' requires authentication',status==401 and json.loads(body)['success']==False)
auth={'Authorization':'Bearer gcash-local-http-test-only','Content-Type':'application/json'}
status,body,_=request(api+'gcash/create.php','POST',json.dumps({'payment_id':pid,'amount':1}).encode(),auth)
check('Unconfigured gateway refuses checkout',status==409 and json.loads(body)['success']==False)
status,body,_=request(api+'gcash/status.php?payment_id=2147483647',headers=auth)
check('Unowned payment cannot be queried',status==409 and json.loads(body)['success']==False)
status,body,_=request(api+'gcash/webhook.php','POST',b'{"data":{"status":"paid"}}',{'Content-Type':'application/json'})
check('Unauthenticated callback cannot report success',status>=400 and json.loads(body)['success']==False)
status,body,_=request(api+f'gcash/return.php?payment_id={pid}&status=paid')
check('Return URL displays navigation only',status==200 and 'Returning here does not confirm payment' in body and 'Payment successful' not in body)
from urllib.parse import urlencode
status,body,_=request(api+'submit.php','POST',urlencode({'payment_id':pid,'payment_method':'Cash'}).encode(),{'Authorization':auth['Authorization'],'Content-Type':'application/x-www-form-urlencoded'})
check('Existing manual API blocks active checkout',status==409 and 'checkout' in body.lower())
status,body,headers=request('/vehicle-service-management-admin/payment_view.php?id='+str(pid),'POST',urlencode({'csrf_token':csrf,'action':'cash_received','receipt_number':'TEST-NOT-REAL'}).encode(),{'Cookie':'PHPSESSID=gcashadmintest','Content-Type':'application/x-www-form-urlencoded'})
check('Admin cash action returns safe redirect',status==302 and 'payment_view.php' in headers.get('Location',''))
status,body,_=request('/vehicle-service-management-admin/payment_view.php?id='+str(pid),headers={'Cookie':'PHPSESSID=gcashadmintest'})
check('Admin explains active checkout guard','awaiting reconciliation' in body and 'Manual payment confirmation is locked' in body)
check('Admin hides cash confirmation form while active','name="receipt_number"' not in body)
# A stale customer proof form cannot override a now-active gateway attempt.
import base64
boundary='----GCashTest'+uuid.uuid4().hex
parts=[]
for key,value in {'id':str(pid),'csrf_token':csrf,'payment_method':'Maya','reference_number':'LOCAL-TEST'}.items():
 parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+key+'"\r\n\r\n'+value+'\r\n').encode())
parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="proof"; filename="test.png"\r\nContent-Type: image/png\r\n\r\n').encode()+base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aV1kAAAAASUVORK5CYII=')+b'\r\n')
parts.append(('--'+boundary+'--\r\n').encode())
status,body,_=request('/vehicle-service-management/customer/payment_submit.php?id='+str(pid),'POST',b''.join(parts),{'Cookie':'PHPSESSID=gcashcustomertest','Content-Type':'multipart/form-data; boundary='+boundary})
check('Customer proof form blocks active checkout',status==200 and 'awaiting reconciliation' in body)
# v2 manual-payment regression checks against the merged current pages.
def qa_sql(sql, read=False):
 env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/runtime/root/usr/lib/x86_64-linux-gnu'
 php="$c=new mysqli('localhost','root','','gcash_gateway_test',0,'/workspace/work/db/mysql.sock');$r=$c->query("+json.dumps(sql)+");"+("echo json_encode($r->fetch_assoc());" if read else "")
 r=subprocess.run(['/workspace/work/runtime/root/usr/bin/php8.4','-c','/workspace/work/php.ini','-r',php],env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 return json.loads(r.stdout) if read else None
qa_sql("UPDATE payment_gateway_attempts SET state='expired' WHERE payment_id="+str(pid))
qa_sql("UPDATE payments SET status='Awaiting Proof',proof_file=NULL WHERE id="+str(pid))
status,body,_=request('/vehicle-service-management/customer/payment_submit.php?id='+str(pid),'POST',b''.join(parts),{'Cookie':'PHPSESSID=gcashcustomertest','Content-Type':'multipart/form-data; boundary='+boundary})
check('v2 manual Maya proof still submits after gateway is resolved',status==302)
row=qa_sql("SELECT p.status,r.reservation_fee_status,p.proof_file FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id="+str(pid),True)
check('v2 manual proof waits for review and synchronizes fee',row['status']=='Under Review' and row['reservation_fee_status']=='Under Review' and bool(row['proof_file']))
qa_sql("UPDATE payments SET proof_file=NULL WHERE id="+str(pid))
status,body,_=request('/vehicle-service-management-admin/payment_view.php?id='+str(pid),'POST',urlencode({'csrf_token':csrf,'action':'approve'}).encode(),{'Cookie':'PHPSESSID=gcashadmintest','Content-Type':'application/x-www-form-urlencoded'})
row=qa_sql("SELECT status FROM payments WHERE id="+str(pid),True)
check('v2 Admin cannot approve a manual payment without proof',status==302 and row['status']=='Under Review')
qa_sql("UPDATE payments SET status='Pay at Shop' WHERE id="+str(pid))
status,body,_=request('/vehicle-service-management-admin/payment_view.php?id='+str(pid),'POST',urlencode({'csrf_token':csrf,'action':'cash_received','receipt_number':'LOCAL-QA-NO-REAL-FUNDS'}).encode(),{'Cookie':'PHPSESSID=gcashadmintest','Content-Type':'application/x-www-form-urlencoded'})
row=qa_sql("SELECT p.status,r.reservation_fee_status FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id="+str(pid),True)
check('v2 Admin cash action works and synchronizes fee when no active checkout',status==302 and row['status']=='Paid' and row['reservation_fee_status']=='Paid')
Path('/workspace/work/gcash-v2/http-results.json').write_text(json.dumps({'environment':'isolated local PHP server and test database','checks':checks,'passed':len(checks)},indent=2))
print(str(len(checks))+' HTTP checks passed.')
