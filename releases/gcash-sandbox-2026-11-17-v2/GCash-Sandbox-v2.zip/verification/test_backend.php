<?php
require '/workspace/work/deliverables/Lucky-Yuna-GCash-Sandbox-v2/source/Vehicle-Service-System/vehicle-service-management/api/gateways/paymongo.php';
function db():mysqli{return new mysqli('localhost','', '', 'gcash_gateway_test',0,'/workspace/work/db/mysql.sock');}
// Use the local fixture server's root account, never a remote or production database.
function connectTest():mysqli{return new mysqli('localhost','root','','gcash_gateway_test',0,'/workspace/work/db/mysql.sock');}
if(($argv[1]??'')==='guard-worker'){
    $c=connectTest();$c->begin_transaction();try{gatewayAssertManualAllowed($c,(int)$argv[2]);echo 'UNSAFE';}catch(DomainException $e){echo 'BLOCKED';}$c->rollback();exit;
}
$admin=new mysqli('localhost','root','',null,0,'/workspace/work/db/mysql.sock');
$admin->query('CREATE DATABASE IF NOT EXISTS gcash_gateway_test');$conn=connectTest();
foreach(['payment_gateway_attempts','notifications','admin_audit_logs','payments','reservations','job_quotations'] as $t)$conn->query("DROP TABLE IF EXISTS $t");
foreach(['reservations','payments','notifications','admin_audit_logs','job_quotations'] as $t)$conn->query("CREATE TABLE $t LIKE vehicle_service_system.$t");
$conn->query('INSERT INTO reservations SELECT * FROM vehicle_service_system.reservations LIMIT 1');
$booking=$conn->query('SELECT * FROM reservations LIMIT 1')->fetch_assoc();if(!$booking)throw new RuntimeException('No local reservation fixture.');$rid=(int)$booking['id'];
$sql=file_get_contents('/workspace/work/deliverables/Lucky-Yuna-GCash-Sandbox-v2/source/Vehicle-Service-System/vehicle-service-management/database/migrations/20261117_payment_gateway_attempts.sql');$conn->multi_query($sql);while($conn->more_results())$conn->next_result();
$checks=[];
function check($name,$ok){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok];if(!$ok)throw new RuntimeException('FAILED: '.$name);}
function fixture():array {
 global $conn,$rid;
 $conn->query("UPDATE reservations SET status='Pending',reservation_fee_status='Awaiting Payment' WHERE id=$rid");
 $conn->query("INSERT INTO payments(reservation_id,amount,payment_method,status,payment_type,gross_amount) VALUES($rid,200.00,'GCash','Pending','Reservation Fee',200.00)");$id=$conn->insert_id;$token=bin2hex(random_bytes(24));$sid='cs_test'.$id;
 $s=$conn->prepare("INSERT INTO payment_gateway_attempts(payment_id,attempt_token,checkout_session_id,checkout_url,expected_amount_minor,previous_status,state) VALUES(?,?,?,'https://checkout.paymongo.com/test',20000,'Awaiting Proof','pending')");$s->bind_param('iss',$id,$token,$sid);$s->execute();$aid=$conn->insert_id;$s->close();return $conn->query("SELECT * FROM payment_gateway_attempts WHERE id=$aid")->fetch_assoc();
}
function snapshot(array $a,string $state='paid'):array {
 return ['id'=>$a['checkout_session_id'],'type'=>'checkout_session','attributes'=>['livemode'=>false,'status'=>$state==='expired'?'expired':'active','payment_intent'=>['attributes'=>['status'=>'awaiting_payment_method']],'metadata'=>['attempt_token'=>$a['attempt_token'],'payment_id'=>(string)$a['payment_id']],'payments'=>in_array($state,['paid','failed'])?[['id'=>'pay_test'.$a['id'],'type'=>'payment','attributes'=>['status'=>$state,'amount'=>20000,'currency'=>'PHP','livemode'=>false,'source'=>['type'=>'gcash']]]]:[]]];
}
function rejected(callable $fn):bool{try{$fn();return false;}catch(DomainException $e){return true;}}
check('Exact decimal to centavos',gcashAmountMinor('200.00')===20000);
check('Fractional amount exact',gcashAmountMinor('123.45')===12345);
check('Invalid precision rejected',rejected(fn()=>gcashAmountMinor('200.001')));
check('Zero amount rejected',rejected(fn()=>gcashAmountMinor('0.00')));
check('Checkout URL rejects external host',!gcashCheckoutUrl('https://checkout.paymongo.com.evil.example/pay'));
check('Checkout URL rejects HTTP',!gcashCheckoutUrl('http://checkout.paymongo.com/pay'));
$raw='{"data":{"id":"evt_test"}}';$t=time();$secret='unit-test-only';$sig=hash_hmac('sha256',$t.'.'.$raw,$secret);
check('Valid sandbox signature',gcashVerifySignature($raw,"t=$t,te=$sig",$secret,$t));
check('Tampered callback rejected',!gcashVerifySignature($raw.' ',"t=$t,te=$sig",$secret,$t));
check('Live signature rejected',!gcashVerifySignature($raw,"t=$t,li=$sig",$secret,$t));
check('Stale replay rejected',!gcashVerifySignature($raw,"t=$t,te=$sig",$secret,$t+301));
check('Missing signature rejected',!gcashVerifySignature($raw,'',$secret,$t));
check('Future replay rejected',!gcashVerifySignature($raw,"t=$t,te=$sig",$secret,$t-61));
check('Disabled gateway fails closed',rejected(fn()=>gcashConfig()));
$a=fixture();$snap=snapshot($a);
check('Pending inspected without marking paid',gcashInspect($a,snapshot($a,'pending'))['state']==='pending');
check('Failed payment remains an active checkout',gcashInspect($a,snapshot($a,'failed'))===['state'=>'pending','outcome'=>'failed']);
foreach(['amount','currency','mode','source','mapping','session','duplicate'] as $case){
 $bad=$snap;
 switch($case){
 case 'amount':$bad['attributes']['payments'][0]['attributes']['amount']=19999;break;
 case 'currency':$bad['attributes']['payments'][0]['attributes']['currency']='USD';break;
 case 'mode':$bad['attributes']['payments'][0]['attributes']['livemode']=true;break;
 case 'source':$bad['attributes']['payments'][0]['attributes']['source']['type']='card';break;
 case 'mapping':$bad['attributes']['metadata']['attempt_token']='different';break;
 case 'session':$bad['id']='cs_different';break;
 case 'duplicate':$bad['attributes']['payments'][]=$bad['attributes']['payments'][0];break;
 }
 check('Reject '.$case.' mismatch',rejected(fn()=>gcashInspect($a,$bad)));
}
$conn->begin_transaction();check('Manual payment blocked during checkout',rejected(fn()=>gatewayAssertManualAllowed($conn,(int)$a['payment_id'])));$conn->rollback();
// A queued manual writer must see a newly committed checkout after waiting for its row lock.
$b=fixture();$pid=(int)$b['payment_id'];$conn->begin_transaction();$conn->query("SELECT id FROM payments WHERE id=$pid FOR UPDATE");
$cmd=[PHP_BINARY,'-c','/workspace/work/php.ini',__FILE__,'guard-worker',(string)$pid];$pipes=[];$proc=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
usleep(150000);check('Concurrent manual writer waits for payment lock',proc_get_status($proc)['running']);$conn->commit();$out=stream_get_contents($pipes[1]);foreach($pipes as $p)fclose($p);proc_close($proc);check('Concurrent manual writer blocked after lock released',$out==='BLOCKED');
// Expiry restores the pre-checkout status, enabling another method only after verification.
gcashApplySnapshot($conn,$b,snapshot($b,'expired'),'evt_expired');$p=$conn->query("SELECT * FROM payments WHERE id=$pid")->fetch_assoc();check('Expired session restores payable state',$p['status']==='Awaiting Proof');check('Expired attempt releases manual guard',gatewayActiveAttempt($conn,$pid)===null);
$inFlight=snapshot($b,'expired');$inFlight['attributes']['payment_intent']['attributes']['status']='processing';
check('Expired checkout with processing payment stays blocked',gcashInspect($b,$inFlight)['state']==='pending');
$missing=snapshot($b,'expired');unset($missing['attributes']['payment_intent']);
check('Expired checkout with unknown intent stays blocked',gcashInspect($b,$missing)['state']==='pending');
// Success + duplicate webhook idempotency.
$id=(int)$a['payment_id'];$before=(int)$conn->query('SELECT COUNT(*) n FROM notifications')->fetch_assoc()['n'];gcashApplySnapshot($conn,$a,$snap,'evt_paid');gcashApplySnapshot($conn,$a,$snap,'evt_paid');
$p=$conn->query("SELECT * FROM payments WHERE id=$id")->fetch_assoc();$fee=$conn->query("SELECT reservation_fee_status FROM reservations WHERE id=$rid")->fetch_assoc();
check('Verified payment becomes Paid',$p['status']==='Paid');check('No screenshot needed after success',$p['proof_file']===null);check('Provider reference recorded',$p['reference_number']==='pay_test'.$a['id']);check('Reservation fee synchronized',$fee['reservation_fee_status']==='Paid');check('Duplicate event creates one notification',(int)$conn->query('SELECT COUNT(*) n FROM notifications')->fetch_assoc()['n']===$before+1);
check('Other customer cannot access payment',rejected(fn()=>gcashOwnedPayment($conn,$id,2147483647)));
$c=fixture();$bad=snapshot($c);$bad['attributes']['payments'][0]['attributes']['amount']=1;check('Wrong amount blocked in DB reconciliation',rejected(fn()=>gcashApplySnapshot($conn,$c,$bad,'evt_bad')));$cid=(int)$c['payment_id'];check('Wrong amount never marks Paid',$conn->query("SELECT status FROM payments WHERE id=$cid")->fetch_assoc()['status']==='Pending');check('Mismatch stays blocked for staff review',gatewayActiveAttempt($conn,$cid)['state']==='review');
// Cancelled booking must not be revived by a late payment.
$d=fixture();$conn->query("UPDATE reservations SET status='Cancelled' WHERE id=$rid");gcashApplySnapshot($conn,$d,snapshot($d),'evt_late');$did=(int)$d['payment_id'];$late=$conn->query("SELECT refund_status FROM payments WHERE id=$did")->fetch_assoc();$job=$conn->query("SELECT status,reservation_fee_status FROM reservations WHERE id=$rid")->fetch_assoc();check('Late payment does not revive cancelled booking',$job['status']==='Cancelled');check('Late paid fee requests refund',$late['refund_status']==='Requested' && $job['reservation_fee_status']==='Refund Requested');
// New payment attempt still active -> block fee credit / quotation repricing.
require '/workspace/work/deliverables/Lucky-Yuna-GCash-Sandbox-v2/source/Vehicle-Service-System/vehicle-service-management/includes/payment_balance.php';$conn->begin_transaction();check('Quotation blocked while gateway attempt unresolved',rejected(fn()=>createFinalBalance($conn,$rid,1000.00)));$conn->rollback();
file_put_contents('/workspace/work/gcash-v2/backend-results.json',json_encode(['environment'=>'isolated local DB; synthetic provider snapshots, NOT PayMongo sandbox','checks'=>$checks,'passed'=>count($checks)],JSON_PRETTY_PRINT));
echo count($checks)." backend assertions passed. Synthetic provider snapshots only.\n";
