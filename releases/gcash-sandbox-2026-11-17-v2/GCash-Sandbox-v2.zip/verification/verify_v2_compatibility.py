from pathlib import Path
import json,hashlib,shutil,subprocess,os
base=Path('/workspace/work/gcash-v2');package=Path('/workspace/work/deliverables/Lucky-Yuna-GCash-Sandbox-v2');root=package/'source/Vehicle-Service-System';current=Path('/workspace/work/gcash-current');oldbefore=Path('/workspace/work/gcash-integration/before')
m=json.loads((package/'manifest.json').read_text());checks=[]
def check(n,v):
 checks.append({'name':n,'passed':bool(v)})
 assert v,n
# Simulate the supplied partial snapshot plus only the other baselines that passed on the owner's PC.
fixture=base/'preflight-project'
if fixture.exists():shutil.rmtree(fixture)
fixture.mkdir()
for e in m['files']:
 n=e['path'];p=fixture/n
 if e['before_sha256']:
  b=current/n
  if not b.exists():b=oldbefore/'flutter'/n.removeprefix('vsm_customer/') if n.startswith('vsm_customer/') else oldbefore/'Vehicle-Service-System'/n
  p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,p)
# Include the actual lock even though it is excluded from the patch.
p=fixture/'vsm_customer/pubspec.lock';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(current/'vsm_customer/pubspec.lock',p);lock_before=p.read_bytes()
def conflicts():
 bad=[]
 for e in m['files']:
  p=fixture/e['path'];h=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
  if h!=e['after_sha256'] and ((h is None and e['before_sha256']) or (h is not None and h!=e['before_sha256'])):bad.append(e['path'])
 return bad
check('v2 preflight accepts supplied files plus previously passed baseline checks',not conflicts())
q=fixture/'vsm_customer/lib/screens/payments/booking_payment_screen.dart';saved=q.read_bytes();q.write_bytes(saved+b'\n// different local edit\n');check('unknown local edits still stop preflight',q.relative_to(fixture).as_posix() in conflicts());q.write_bytes(saved)
for e in m['files']:
 dst=fixture/e['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/e['path'],dst)
check('all applied files match manifest hashes',not conflicts())
check('missing payment dialog is installed as a new file',(fixture/'vsm_customer/lib/screens/payments/payment_proof_dialog.dart').exists())
check('missing balance helper is installed as a new file',(fixture/'vehicle-service-management/includes/payment_balance.php').exists())
check('current SDK dependency lock is preserved',(fixture/'vsm_customer/pubspec.lock').read_bytes()==lock_before)
s=(root/'vehicle-service-management-admin/payment_view.php').read_text();check('Admin keeps session audit identity',"$_SESSION['admin_name']" in s and 'adminActor(' not in s and 'adminH(' not in s)
old=(current/'vehicle-service-management/customer/payment_submit.php').read_text();new=(root/'vehicle-service-management/customer/payment_submit.php').read_text();marker="require_once __DIR__.'/../includes/customer_header.php';?>";check('Customer HTML is retained exactly',old[old.index(marker):]==new[new.index(marker):])
php='/workspace/work/runtime/root/usr/bin/php8.4';env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/runtime/root/usr/lib/x86_64-linux-gnu'
for p in root.rglob('*.php'):
 r=subprocess.run([php,'-c','/workspace/work/php.ini','-l',str(p)],capture_output=True,text=True,env=env);check('PHP syntax '+str(p.relative_to(root)),r.returncode==0)
(base/'v2-results.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'scope':'installer logic simulated in Python, not Windows PowerShell; supplied partial source and previously passed original baselines'},indent=2))
print(len(checks),'v2 compatibility/syntax checks passed.')
# Preserve and reuse existing isolated tests; adapt only the source paths to this version.
test=Path('/workspace/work/gcash-integration/test_backend.php').read_text().replace('/workspace/work/site/Vehicle-Service-System/',str(root)+'/')
test=test.replace('/workspace/work/gcash-integration/backend-results.json',str(base/'backend-results.json'))
(base/'test_backend.php').write_text(test)
# Construct a disposable HTTP test tree from prior full fixture, supplied current files, and v2 source overlay.
http=Path('/workspace/work/gcash-integration/http-root/Vehicle-Service-System')
shutil.copytree(current,http,dirs_exist_ok=True);shutil.copytree(root,http,dirs_exist_ok=True)
