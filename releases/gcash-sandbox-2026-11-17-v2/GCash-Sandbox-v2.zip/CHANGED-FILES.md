# Compatibility patch v2

- `vsm_customer/android/app/src/main/AndroidManifest.xml` — modified
- `vsm_customer/ios/Runner/Info.plist` — modified
- `vsm_customer/lib/api/api_config.dart` — modified
- `vsm_customer/lib/api/customer_api.dart` — modified
- `vsm_customer/lib/main.dart` — modified
- `vsm_customer/lib/screens/payments/booking_payment_screen.dart` — modified
- `vsm_customer/lib/screens/payments/gcash_checkout_screen.dart` — new
- `vsm_customer/lib/screens/payments/payment_proof_dialog.dart` — new
- `vsm_customer/lib/screens/payments/payments_screen.dart` — modified
- `vsm_customer/lib/screens/splash/splash_screen.dart` — modified
- `vsm_customer/lib/services/gcash_checkout_service.dart` — new
- `vsm_customer/lib/services/session_service.dart` — modified
- `vsm_customer/pubspec.yaml` — modified
- `vehicle-service-management/api/config/payment_gateway.php` — new
- `vehicle-service-management/api/gateways/paymongo.php` — new
- `vehicle-service-management/api/payments/gcash/cancel.php` — new
- `vehicle-service-management/api/payments/gcash/create.php` — new
- `vehicle-service-management/api/payments/gcash/return.php` — new
- `vehicle-service-management/api/payments/gcash/status.php` — new
- `vehicle-service-management/api/payments/gcash/webhook.php` — new
- `vehicle-service-management/api/payments/submit.php` — modified
- `vehicle-service-management/api/reservations/cancel.php` — modified
- `vehicle-service-management/customer/payment_submit.php` — modified
- `vehicle-service-management/database/migrations/20261117_payment_gateway_attempts.sql` — new
- `vehicle-service-management/includes/payment_balance.php` — new
- `vehicle-service-management/includes/payment_gateway_guard.php` — new
- `vehicle-service-management/tools/reconcile_gcash.php` — new
- `vehicle-service-management-admin/payment_view.php` — modified

pubspec.lock is deliberately excluded. Run flutter pub get using your working SDK.
