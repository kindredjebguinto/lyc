import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vsm_customer/widgets/receipt_reference_guide.dart';

void main() {
  testWidgets(
    'phone-sized guide scrolls at enlarged text size and images enlarge',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          builder: (context, child) => MediaQuery(
            data: MediaQuery.of(context)
                .copyWith(textScaler: const TextScaler.linear(1.4)),
            child: child!,
          ),
          home: const Scaffold(body: ReceiptReferenceGuide()),
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.byType(Image), findsNWidgets(2));
      await tester.ensureVisible(find.text('Not accepted example'));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      final image = find.byType(Image).last;
      await tester.ensureVisible(image);
      await tester.tap(image);
      await tester.pumpAndSettle();
      expect(find.byType(InteractiveViewer), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('Close image'));
      await tester.pumpAndSettle();
      expect(find.byType(InteractiveViewer), findsNothing);
    },
  );
}
