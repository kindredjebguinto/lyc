import '../models/receipt_screening.dart';
import 'receipt_classifier.dart';
import 'receipt_format_rules.dart';

class ReceiptValidationRules {
  ReceiptScreening validate(
    ReceiptFields fields, {
    required int expectedAmountMinor,
    required String accountName,
    required String accountNumber,
    List<String> approvedNames = const [],
    String? walletMethod,
    String? ocrText,
  }) {
    // Shop-requested screening: only the transfer amount and full recipient phone.
    // Names, wallet branding and OCR reference extraction are not pass/fail gates.
    // This never verifies actual funds; staff approval remains required.
    final invalid = <String>[], review = <String>[];
    if (walletMethod == 'Maya' &&
        ReceiptFormatRules.mayaLayout(ocrText ?? '') == null) {
      invalid.add(
        'Use an approved Maya success, full receipt or compact receipt format. The completed transfer details must be readable.',
      );
    }
    if (fields.amountsMinor.length != 1) {
      review.add('The transfer amount is missing or ambiguous.');
    } else if (fields.amountsMinor.single != expectedAmountMinor) {
      invalid.add(
        'The readable transfer amount does not match the amount due.',
      );
    }
    final expectedPhone = ReceiptClassifier.normalizePhone(accountNumber);
    final phone = fields.recipientPhone == null
        ? null
        : ReceiptClassifier.normalizePhone(fields.recipientPhone!);
    if (expectedPhone == null ||
        phone == null ||
        fields.recipientPhoneAmbiguous) {
      review.add(
        'The full recipient mobile number is missing, masked or ambiguous.',
      );
    } else if (phone != expectedPhone) {
      invalid.add(
        'The readable recipient number does not match the shop account.',
      );
    }
    if (invalid.isNotEmpty) {
      return ReceiptScreening(ReceiptValidationState.invalid, invalid, fields);
    }
    if (review.isNotEmpty) {
      if (fields.clearlyUnrelated &&
          fields.amountsMinor.isEmpty &&
          phone == null) {
        return ReceiptScreening(ReceiptValidationState.invalid, const [
          'This image does not appear to contain payment details.',
        ], fields);
      }
      return ReceiptScreening(
        ReceiptValidationState.needsReview,
        review,
        fields,
      );
    }
    return ReceiptScreening(ReceiptValidationState.validForSubmission, const [
      'Amount and recipient number match. Submit for staff verification of the actual funds received.',
    ], fields);
  }
}
