<?php
require_once __DIR__ . "/../config/bootstrap.php";
requireMethod("POST");
require_once __DIR__."/manual_wallets.php";
require_once dirname(__DIR__,2)."/includes/payment_gateway_guard.php";

$user = requireCustomer($conn);
$userId = (int) $user['id'];
$paymentId = (int) filter_var($_POST['payment_id'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
$method = is_string($_POST['payment_method']??null)?trim($_POST['payment_method']):'';
$reference = is_string($_POST['reference_number']??null)?trim($_POST['reference_number']):'';
$onlineMethods = ['GCash', 'Maya', 'Bank Transfer', 'Card'];
$allowedMethods = array_merge(['Cash'], $onlineMethods);

if ($paymentId <= 0 || !in_array($method, $allowedMethods, true)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Select a valid payment method.']);
    exit;
}

// Check ownership before acquiring locks or reporting any payment-specific condition.
$owner=$conn->prepare('SELECT p.id FROM payments p JOIN reservations r ON r.id=p.reservation_id WHERE p.id=? AND r.user_id=?');
$owner->bind_param('ii',$paymentId,$userId);$owner->execute();$owned=$owner->get_result()->num_rows>0;$owner->close();
if(!$owned){http_response_code(409);echo json_encode(['success'=>false,'message'=>'Payment is not available for this account.']);exit;}
// Retired customer fallback: older clients cannot explicitly request OCR bypass.
$reviewRequest=$_POST['receipt_review_requested']??'0';
if(in_array($method,['GCash','Maya'],true) && (!is_string($reviewRequest)||!in_array($reviewRequest,['','0'],true))){
    http_response_code(422);echo json_encode(['success'=>false,'message'=>'Manual receipt review requests are no longer accepted. Update the app and choose a supported readable receipt.']);exit;
}
$referenceLock=null;
if(in_array($method,['GCash','Maya'],true)){
    if($reference==='' || strlen($reference)>100 || !preg_match('/^[A-Za-z0-9\s-]+$/D',$reference) || manualNormalizeReference($reference)===''){
        http_response_code(422);echo json_encode(['success'=>false,'message'=>'Enter a transaction reference of up to 100 letters/digits.']);exit;
    }
    // Serialize API submissions using the same normalized wallet reference.
    // Protected Website writers are unchanged and do not participate in this lock.
    $referenceLock='lyc-wallet-ref:'.substr(hash('sha256',manualNormalizeReference($reference)),0,40);
    $s=$conn->prepare('SELECT GET_LOCK(?,5) acquired');$s->bind_param('s',$referenceLock);$s->execute();$acquired=(int)$s->get_result()->fetch_assoc()['acquired'];$s->close();
    if($acquired!==1){http_response_code(409);echo json_encode(['success'=>false,'message'=>'Another reference check is in progress. Please try again.']);exit;}
    register_shutdown_function(static function()use($conn,$referenceLock){try{$conn->rollback();$s=$conn->prepare('SELECT RELEASE_LOCK(?)');$s->bind_param('s',$referenceLock);$s->execute();$s->close();}catch(Throwable $e){}});
}
$conn->begin_transaction();
register_shutdown_function(static function() use ($conn) { try { $conn->rollback(); } catch (Throwable $e) {} });
try { gatewayAssertManualAllowed($conn, $paymentId); }
catch (DomainException $e) { $conn->rollback(); http_response_code(409); echo json_encode(['success'=>false,'message'=>$e->getMessage()]); exit; }
$stmt = $conn->prepare("SELECT p.id, p.amount, p.proof_file, p.payment_type, p.reservation_id FROM payments p
    INNER JOIN reservations r ON p.reservation_id=r.id
    LEFT JOIN job_quotations q ON q.reservation_id=r.id
    WHERE p.id=? AND r.user_id=? AND r.status<>'Cancelled' AND (p.payment_type='Reservation Fee' OR q.status='Accepted')
    AND p.status IN ('Awaiting Proof','Rejected','Pay at Shop') LIMIT 1");
$stmt->bind_param('ii', $paymentId, $userId);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$payment) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Payment is not ready for submission. Refresh the booking and try again.']);
    exit;
}

if(in_array($method,['GCash','Maya'],true)){
    if(manualReferenceExists($conn,manualNormalizeReference($reference),$paymentId)){
        http_response_code(409);echo json_encode(['success'=>false,'message'=>'This wallet reference is already submitted or recorded. Contact the service center before paying again.']);exit;
    }
    // Optional version field is additive. Legacy clients retain manual staff verification.
    $version=$_POST['shop_configuration_version']??'';
    if($version!==''){
        $wallet=manualWalletConfig($method);
        if(!is_string($version)||!$wallet['configured']||!hash_equals($wallet['configuration_version'],$version)){
            http_response_code(409);echo json_encode(['success'=>false,'message'=>'Shop payment details changed. Reload them and confirm the recipient before continuing.']);exit;
        }
        $expectedMinor=manualAmountMinor((string)$payment['amount']);
        if($expectedMinor!==$wallet['qr_amount_minor']){http_response_code(409);echo json_encode(['success'=>false,'message'=>'This QR is for a different amount. Contact the service center.']);exit;}
    }
}

if (($payment['payment_type'] ?? '') === 'Reservation Fee' && $method === 'Cash') {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Cash at Shop is not available for the ₱200 app reservation fee. Choose an online payment method.']);
    exit;
}

if ($method === 'Cash') {
    $stmt = $conn->prepare("UPDATE payments SET payment_method='Cash', reference_number=NULL,
        proof_file=NULL, status='Pay at Shop', submitted_at=NOW(), paid_at=NULL,
        admin_notes=NULL WHERE id=? AND status IN ('Awaiting Proof','Rejected','Pay at Shop')");
    $stmt->bind_param('i', $paymentId);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Unable to select cash payment.']);
        exit;
    }
    $conn->commit();
    $oldProof = $payment['proof_file'] ?? '';
    if ($oldProof !== '') {
        $oldPath = dirname(__DIR__, 2) . '/' . ltrim($oldProof, '/');
        if (is_file($oldPath)) @unlink($oldPath);
    }
    echo json_encode(['success' => true, 'message' => 'Cash payment selected. Please pay the exact amount at the service counter.']);
    exit;
}

if ($reference === '' || strlen($reference)>100) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Enter the transaction reference number.']);
    exit;
}
if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Attach a payment proof image.']);
    exit;
}

$file = $_FILES['proof'];
if ($file['size'] <= 0 || $file['size'] > 5 * 1024 * 1024) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Proof image must be 5 MB or smaller.']);
    exit;
}
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
$extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$dimensions=@getimagesize($file['tmp_name']);
if (!isset($extensions[$mime]) || !$dimensions || $dimensions[0]<=0 || $dimensions[1]<=0 || $dimensions[0]*$dimensions[1]>24000000) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Use a JPG, PNG, or WEBP image.']);
    exit;
}

$uploadDir = dirname(__DIR__, 2) . '/uploads/payment_proofs';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to prepare the proof upload folder.']);
    exit;
}
$filename = 'proof_' . $paymentId . '_' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
$destination = $uploadDir . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to save payment proof.']);
    exit;
}

// Client OCR is untrusted screening, not proof of payment or server OCR.
$screeningNote=null;
if(in_array($method,['GCash','Maya'],true)){
    $screeningNote='Receipt remains unverified until staff confirms the actual funds received.';
}
$submissionCommitted=false;
register_shutdown_function(static function()use(&$submissionCommitted,$destination){if(!$submissionCommitted&&is_file($destination))@unlink($destination);});
$relative = 'uploads/payment_proofs/' . $filename;
$stmt = $conn->prepare("UPDATE payments SET payment_method=?, reference_number=?, proof_file=?,
    status='Under Review', submitted_at=NOW(), paid_at=NULL, admin_notes=?
    WHERE id=? AND status IN ('Awaiting Proof','Rejected','Pay at Shop')");
$stmt->bind_param('ssssi', $method, $reference, $relative, $screeningNote, $paymentId);
$ok = $stmt->execute();
$changed = $stmt->affected_rows > 0;
$stmt->close();

if (!$ok || !$changed) {
    @unlink($destination);
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Payment changed before submission. Refresh and try again.']);
    exit;
}
if (($payment['payment_type'] ?? '') === 'Reservation Fee') {
    $reservationId = (int) $payment['reservation_id'];
    $conn->query("UPDATE reservations SET reservation_fee_status='Under Review' WHERE id=$reservationId");
}

$conn->commit();
$submissionCommitted=true;
$oldProof = $payment['proof_file'] ?? '';
if ($oldProof !== '' && $oldProof !== $relative) {
    $oldPath = dirname(__DIR__, 2) . '/' . ltrim($oldProof, '/');
    if (is_file($oldPath)) @unlink($oldPath);
}

echo json_encode(['success' => true, 'message' => 'Payment proof submitted for verification.']);
