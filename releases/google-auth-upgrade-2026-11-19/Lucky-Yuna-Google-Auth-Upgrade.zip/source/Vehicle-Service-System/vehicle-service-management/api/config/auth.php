<?php
// Actual credentials belong outside the document root, never in the app or ZIP.
$documentRoot=rtrim($_SERVER['DOCUMENT_ROOT']??'', '/\\');
$path=getenv('LYC_AUTH_CONFIG')?:($documentRoot!==''?dirname($documentRoot).'/lyc-private/auth.php':'');
if($path===''||!is_file($path))return [];
$config=require $path;
return is_array($config)?$config:[];
