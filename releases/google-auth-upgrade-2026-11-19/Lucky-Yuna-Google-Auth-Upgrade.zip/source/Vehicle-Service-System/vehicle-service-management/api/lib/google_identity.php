<?php
interface LycGoogleIdentityVerifier { public function verify(string $token): array; }
final class LycGoogleVerifier implements LycGoogleIdentityVerifier {
 private array $audiences;
 public function __construct(array $audiences,private array $presenters=[],private ?Google\Auth\AccessToken $verifier=null){$this->audiences=$audiences;}
 public function verify(string $token):array {
  if(!$this->audiences)throw new LycAuthProblem(503,'Google sign-in is not configured. Please use manual sign-in.');
  if(strlen($token)>16384||substr_count($token,'.')!==2)throw new LycAuthProblem(401,'Google sign-in could not be verified. Please try again.');
  if(!class_exists('Google\\Auth\\AccessToken'))throw new LycAuthProblem(503,'Google sign-in is not available. Please use manual sign-in.');
  try{
   $verifier=$this->verifier??new Google\Auth\AccessToken(Google\Auth\HttpHandler\HttpHandlerFactory::build(new GuzzleHttp\Client(['timeout'=>8,'connect_timeout'=>5])));
   $claims=$verifier->verify($token,['throwException'=>true]);
  }
  catch(GuzzleHttp\Exception\GuzzleException $e){throw new LycAuthProblem(503,'Google verification is temporarily unavailable. Please retry.');}
  catch(Throwable $e){throw new LycAuthProblem(401,'Google sign-in could not be verified. Please try again.');}
  if(!is_array($claims))throw new LycAuthProblem(401,'Google sign-in could not be verified.');
  return self::validateClaims($claims,$this->audiences,$this->presenters);
 }
 public static function validateClaims(array $c,array $audiences,array $presenters=[]):array {
  $now=time();$verified=($c['email_verified']??false)===true||($c['email_verified']??null)==='true';
  if(!in_array($c['iss']??'', ['accounts.google.com','https://accounts.google.com'],true)||
   !is_string($c['aud']??null)||!in_array($c['aud'],$audiences,true)||
   (isset($c['azp'])&&!in_array($c['azp'],array_merge($audiences,$presenters),true))||
   !is_numeric($c['exp']??null)||(int)$c['exp']<=$now||
   !is_numeric($c['iat']??null)||(int)$c['iat']>$now+60||
   (isset($c['nbf'])&&(int)$c['nbf']>$now+60)||!$verified||
   !is_string($c['sub']??null)||!preg_match('/^[A-Za-z0-9_-]{1,255}$/D',$c['sub'])||
   !is_string($c['email']??null)||strlen($c['email'])>100||!filter_var($c['email'],FILTER_VALIDATE_EMAIL)) {
    throw new LycAuthProblem(401,'Google sign-in could not be verified.');
  }
  return ['subject'=>$c['sub'],'email'=>strtolower(trim($c['email'])),
   'name'=>mb_substr(is_string($c['name']??null)?$c['name']:'',0,100),'issued_at'=>(int)$c['iat']];
 }
}
