<?php
final class LycAuthProblem extends RuntimeException {
 public function __construct(public int $status,string $message,public string $errorCode='auth_error'){parent::__construct($message);}
}
function lyc_field(array $data,string $key,int $max=1000):string {
 $v=$data[$key]??'';if(!is_string($v)||strlen($v)>$max)throw new LycAuthProblem(400,'Invalid request fields.');return $v;
}
function lyc_email(string $email):string {
 $email=strtolower(trim($email));if(strlen($email)>100||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new LycAuthProblem(400,'Enter a valid email address.');return $email;
}
function lyc_phone(string $phone):string {
 $s=preg_replace('/[\s()-]+/','',trim($phone));if(preg_match('/^\+?639\d{9}$/D',$s))$s='0'.substr(ltrim($s,'+'),2);
 if(!preg_match('/^09\d{9}$/D',$s))throw new LycAuthProblem(400,'Enter a valid Philippine mobile number.');return $s;
}
function lyc_password(string $password,string $confirm):void {
 if(strlen($password)<12||strlen($password)>72)throw new LycAuthProblem(400,'Use a password between 12 and 72 bytes.');
 if($password!==$confirm)throw new LycAuthProblem(400,'Passwords do not match.');
}
function lyc_has_password(array $user):bool {return ($user['password']??'')!==''&&password_get_info($user['password'])['algoName']!=='unknown';}
