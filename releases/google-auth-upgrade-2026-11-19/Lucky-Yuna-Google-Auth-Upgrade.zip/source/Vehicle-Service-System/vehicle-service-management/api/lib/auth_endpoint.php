<?php
ini_set('display_errors','0');
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/auth_service.php';
$autoload=dirname(__DIR__,2).'/vendor/autoload.php';if(is_file($autoload))require_once $autoload;
function lyc_auth_endpoint(string $action):void {
 header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('Referrer-Policy: no-referrer');header('X-Content-Type-Options: nosniff');
 try{
  $method=$action==='me'?'GET':'POST';if(($_SERVER['REQUEST_METHOD']??'')!==$method)throw new LycAuthProblem(405,'Method not allowed.');
  $config=require __DIR__.'/../config/auth.php';$conn=$GLOBALS['conn'];
  $secure=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;
  $local=in_array($_SERVER['REMOTE_ADDR']??'', ['127.0.0.1','::1'],true)&&($config['allow_local_http']??false)===true;
  if(!$secure&&!$local)throw new LycAuthProblem(400,'Authentication requires HTTPS. Use the configured secure backend.');
  $service=new LycAuthService($conn,new LycGoogleVerifier($config['google_web_client_ids']??[],$config['google_presenter_client_ids']??[]),new LycSmtpMailer($config),$config);$service->ready();
  $d=[];if($method==='POST'){$raw=file_get_contents('php://input',false,null,0,32769);if(strlen($raw)>32768)throw new LycAuthProblem(413,'Request too large.');$d=json_decode($raw,true);if(!is_array($d))throw new LycAuthProblem(400,'Send a valid JSON request.');}
  $authorization=$_SERVER['HTTP_AUTHORIZATION']??'';if($authorization===''){foreach(getallheaders() as $k=>$v)if(strtolower($k)==='authorization')$authorization=$v;}
  $bearer=preg_match('/^Bearer ([a-f0-9]{64})$/D',$authorization,$m)?$m[1]:'';
  // REMOTE_ADDR is intentional: do not trust arbitrary forwarded IP headers.
  $ip=$_SERVER['REMOTE_ADDR']??'local';
  $result=match($action){
   'login'=>$service->login($d,$ip),'register'=>$service->register($d,$ip),
   'google'=>$service->google($d,$ip),'complete'=>$service->complete($d,$ip,$bearer),
   'link'=>$service->link($d,$ip),'me'=>$service->me($bearer),'logout'=>$service->logout($bearer),
   'set_password'=>$service->password($d,$ip,$bearer,true),'password'=>$service->password($d,$ip,$bearer,false),
   'forgot'=>$service->forgot($d,$ip),'reset'=>$service->reset($d,$ip),
   default=>throw new LycAuthProblem(404,'Not found.')};
  if(in_array($action,['register','forgot'],true))http_response_code(202);
  echo json_encode($result,JSON_UNESCAPED_SLASHES);
 }catch(LycAuthProblem $e){http_response_code($e->status);if($e->status===429)header('Retry-After: 900');echo json_encode(['success'=>false,'message'=>$e->getMessage(),'code'=>$e->errorCode]);}
 catch(Throwable $e){if(isset($conn)&&$conn instanceof mysqli){try{$conn->rollback();}catch(Throwable $ignored){}}
  error_log('Lucky Yuna: authentication operation failed ('.get_class($e).').');http_response_code(503);echo json_encode(['success'=>false,'message'=>'Unable to complete authentication. Please try again.']);}
}
