<?php
require_once __DIR__.'/auth_security.php';
require_once __DIR__.'/google_identity.php';
require_once __DIR__.'/auth_mailer.php';
final class LycAuthService {
 private array $locks=[];
 public function __construct(private mysqli $db,private LycGoogleIdentityVerifier $google,private LycAuthMailer $mailer,private array $config=[]){$this->db->query("SET time_zone='+00:00'");}
 public function __destruct(){foreach($this->locks as $name){$s=$this->db->prepare('SELECT RELEASE_LOCK(?)');$s->bind_param('s',$name);$s->execute();$s->close();}}
 private function q(string $sql,array $args=[]):mysqli_stmt {
  $s=$this->db->prepare($sql);if($args){$types='';foreach($args as $v)$types.=is_int($v)?'i':'s';$s->bind_param($types,...$args);}$s->execute();return $s;
 }
 private function one(string $sql,array $args=[]):?array {$s=$this->q($sql,$args);$r=$s->get_result()->fetch_assoc();$s->close();return $r;}
 private function lock(string $key):void {
  $name='lycauth_'.substr(hash('sha256',$this->db->query('SELECT DATABASE() d')->fetch_assoc()['d'].'/'.$key),0,48);
  if(isset($this->locks[$name]))return;$r=$this->one('SELECT GET_LOCK(?,5) got',[$name]);if((int)$r['got']!==1)throw new LycAuthProblem(409,'Another request is in progress. Please retry.');$this->locks[$name]=$name;
 }
 public function ready():void {
  $r=$this->one("SELECT COUNT(*) n FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('auth_identities','auth_challenges','auth_password_resets','auth_rate_limits')");
  $c=$this->one("SELECT COUNT(*) n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='api_tokens' AND COLUMN_NAME IN ('auth_method','reauthenticated_at')");
  $unique=$this->one("SELECT COUNT(*) n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='customers' AND INDEX_NAME='auth_customer_user_unique' AND NON_UNIQUE=0");
  if((int)$r['n']!==4||(int)$c['n']!==2||(int)$unique['n']!==1)throw new LycAuthProblem(503,'The authentication update is not installed. Contact the service center.');
 }
 private function rate(string $action,string $identity,string $ip,int $limit=10):void {
  // Shared budgets prevent rotating email addresses from bypassing the IP limit.
  foreach([[$action.'/ip/'.$ip,$limit*3],[$action.'/identity/'.strtolower($identity),$limit]] as [$key,$max]){
   $bucket=hash('sha256',$key);$window=intdiv(time(),900)*900;
   $this->q('INSERT INTO auth_rate_limits(bucket,window_start,attempts) VALUES(?,?,1) ON DUPLICATE KEY UPDATE attempts=IF(window_start=VALUES(window_start),attempts+1,1),window_start=VALUES(window_start)',[$bucket,$window])->close();
   $r=$this->one('SELECT attempts FROM auth_rate_limits WHERE bucket=?',[$bucket]);if((int)$r['attempts']>$max)throw new LycAuthProblem(429,'Too many attempts. Please try again later.');
  }
 }
 private function atomic(callable $fn):array {
  $this->db->begin_transaction();try{$r=$fn();$this->db->commit();return $r;}catch(Throwable $e){$this->db->rollback();throw $e;}
 }
 private function user(int $id,bool $lock=false):array {
  $u=$this->one("SELECT * FROM users WHERE id=? AND role='customer'".($lock?' FOR UPDATE':''),[$id]);
  if(!$u)throw new LycAuthProblem(401,'Unable to authenticate this account.');return $u;
 }
 private function profile(array $u):array {
  $p=$this->one('SELECT * FROM customers WHERE user_id=? ORDER BY id LIMIT 1',[(int)$u['id']]);
  if(!$p)throw new LycAuthProblem(409,'Your existing customer profile needs assistance. Contact the service center; no new account was created.');
  return $p;
 }
 private function publicUser(array $u,array $p):array {
  $linked=$this->one("SELECT id,provider_email FROM auth_identities WHERE user_id=? AND provider='google'",[(int)$u['id']]);
  $complete=trim($p['fullname']??'')!=='';
  try{lyc_phone($p['phone']??'');}catch(LycAuthProblem $e){$complete=false;}
  return ['success'=>true,'user'=>['id'=>(int)$u['id'],'fullname'=>$u['fullname'],'email'=>$u['email'],'role'=>$u['role']],
   'customer'=>$p,'profile_required'=>!$complete,'auth'=>['google_linked'=>(bool)$linked,'google_email'=>$linked['provider_email']??null,'has_password'=>lyc_has_password($u)]];
 }
 private function session(array $u,string $method):array {
  $p=$this->profile($u);$token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$expires=gmdate('Y-m-d H:i:s',time()+7*86400);
  $this->q('INSERT INTO api_tokens(user_id,token_hash,expires_at,auth_method,reauthenticated_at) VALUES(?,?,?,?,NOW())',[(int)$u['id'],$hash,$expires,$method])->close();
  return $this->publicUser($u,$p)+['token'=>$token,'expires_at'=>$expires,'message'=>'Signed in successfully.'];
 }
 private function authenticated(string $bearer):array {
  if(!preg_match('/^[a-f0-9]{64}$/D',$bearer))throw new LycAuthProblem(401,'Please sign in again.');
  $t=$this->one('SELECT * FROM api_tokens WHERE token_hash=? AND expires_at>NOW()',[hash('sha256',$bearer)]);
  if(!$t)throw new LycAuthProblem(401,'Your session expired. Please sign in again.');return $t;
 }
 private function challenge(string $purpose,array $identity,?int $uid=null):array {
  $token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$expiry=gmdate('Y-m-d H:i:s',time()+600);
  $this->q('INSERT INTO auth_challenges(token_hash,purpose,user_id,subject,email,display_name,expires_at) VALUES(?,?,?,?,?,?,?)',[$hash,$purpose,$uid,$identity['subject'],$identity['email'],$identity['name'],$expiry])->close();
  return ['success'=>true,'next'=>$purpose==='google_link'?'link_account':'complete_profile','challenge'=>$token,'name'=>$identity['name'],'email'=>$identity['email'],'expires_in'=>600];
 }
 private function readChallenge(string $token,string $purpose,bool $lock=false):array {
  if(!preg_match('/^[a-f0-9]{64}$/D',$token))throw new LycAuthProblem(400,'This sign-in request expired. Start Google sign-in again.');
  $r=$this->one('SELECT * FROM auth_challenges WHERE token_hash=? AND purpose=? AND used_at IS NULL AND expires_at>NOW()'.($lock?' FOR UPDATE':''),[hash('sha256',$token),$purpose]);
  if(!$r)throw new LycAuthProblem(400,'This sign-in request expired or was already used. Start Google sign-in again.');return $r;
 }
 private function consume(int $id):void {$this->q('UPDATE auth_challenges SET used_at=NOW() WHERE id=?',[$id])->close();}
 public function login(array $d,string $ip):array {
  $email=lyc_email(lyc_field($d,'email',100));$password=lyc_field($d,'password',1024);$this->rate('login',$email,$ip);
  $u=$this->one('SELECT * FROM users WHERE email=?',[$email]);
  // Dummy verification reduces obvious timing differences for missing/Google-only accounts.
  $hash=($u&&lyc_has_password($u))?$u['password']:'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
  $ok=password_verify($password,$hash);
  if(!$ok||!$u||!lyc_has_password($u)||$u['role']!=='customer')throw new LycAuthProblem(401,'Invalid email or password.');
  return $this->atomic(function()use($u,$password){$current=$this->user((int)$u['id'],true);if(!password_verify($password,$current['password']))throw new LycAuthProblem(401,'Invalid email or password.');return $this->session($current,'manual');});
 }
 public function register(array $d,string $ip):array {
  $email=lyc_email(lyc_field($d,'email',100));$this->rate('register',$email,$ip,5);
  $name=trim(lyc_field($d,'fullname',400));$phone=lyc_phone(lyc_field($d,'phone',30));$address=trim(lyc_field($d,'address',1020));
  if(mb_strlen($address)>255)throw new LycAuthProblem(400,'Address is too long.');
  $password=lyc_field($d,'password',72);lyc_password($password,$password);
  if($name===''||mb_strlen($name)>100)throw new LycAuthProblem(400,'Enter a name up to 100 characters.');$this->lock('email/'.$email);
  $this->atomic(function()use($email,$name,$phone,$address,$password){
   if($this->one('SELECT id FROM users WHERE email=?',[$email])||$this->one("SELECT id FROM auth_identities WHERE provider='google' AND provider_email=?",[$email]))return [];
   $hash=password_hash($password,PASSWORD_DEFAULT);$this->q("INSERT INTO users(fullname,email,password,role) VALUES(?,?,?,'customer')",[$name,$email,$hash])->close();$uid=$this->db->insert_id;
   $this->q('INSERT INTO customers(user_id,fullname,email,phone,address) VALUES(?,?,?,?,?)',[$uid,$name,$email,$phone,$address])->close();return [];
  });
  // Same shape/status/message for new and existing emails; never overwrite an account.
  return ['success'=>true,'user'=>null,'customer'=>null,'message'=>'If eligible, your account is ready. Sign in with your chosen method, or use account recovery.'];
 }
 public function google(array $d,string $ip):array {
  $this->rate('google',$ip,$ip,30);$v=$this->google->verify(lyc_field($d,'id_token',16384));$this->lock('google/'.$v['subject']);
  $identity=$this->one("SELECT user_id FROM auth_identities WHERE provider='google' AND subject=?",[$v['subject']]);
  if($identity)return $this->atomic(function()use($identity,$v){$u=$this->user((int)$identity['user_id'],true);$this->q("UPDATE auth_identities SET provider_email=?,email_verified_at=NOW() WHERE provider='google' AND subject=?",[$v['email'],$v['subject']])->close();return $this->session($u,'google');});
  $u=$this->one('SELECT * FROM users WHERE email=?',[$v['email']]);
  if($u&&$u['role']!=='customer')throw new LycAuthProblem(409,'Unable to use this sign-in method for this account.');
  return $this->challenge($u?'google_link':'google_register',$v,$u?(int)$u['id']:null);
 }
 private function attach(int $uid,string $subject,string $email):void {
  $existing=$this->one("SELECT user_id,subject FROM auth_identities WHERE provider='google' AND (subject=? OR user_id=?) FOR UPDATE",[$subject,$uid]);
  if($existing){if((int)$existing['user_id']===$uid&&$existing['subject']===$subject)return;throw new LycAuthProblem(409,'A different identity is already linked. Contact the service center.');}
  $this->q("INSERT INTO auth_identities(user_id,provider,subject,provider_email,email_verified_at) VALUES(?,'google',?,?,NOW())",[$uid,$subject,$email])->close();
 }
 public function complete(array $d,string $ip,string $bearer):array {
  $name=trim(lyc_field($d,'fullname',400));$phone=lyc_phone(lyc_field($d,'phone',30));if($name===''||mb_strlen($name)>100)throw new LycAuthProblem(400,'Enter a name up to 100 characters.');
  $token=lyc_field($d,'challenge',64);$this->rate('complete',$token!==''?hash('sha256',$token):hash('sha256',$bearer),$ip);
  if($token===''){
   $t=$this->authenticated($bearer);return $this->atomic(function()use($t,$name,$phone){$u=$this->user((int)$t['user_id'],true);$p=$this->profile($u);
    $this->q('UPDATE users SET fullname=? WHERE id=?',[$name,(int)$u['id']])->close();$this->q('UPDATE customers SET fullname=?,phone=? WHERE id=?',[$name,$phone,(int)$p['id']])->close();$u['fullname']=$name;$p['fullname']=$name;$p['phone']=$phone;return $this->publicUser($u,$p);});
  }
  $c=$this->readChallenge($token,'google_register');$this->lock('google/'.$c['subject']);$this->lock('email/'.$c['email']);
  return $this->atomic(function()use($token,$name,$phone){$c=$this->readChallenge($token,'google_register',true);
   $linked=$this->one("SELECT user_id FROM auth_identities WHERE provider='google' AND subject=?",[$c['subject']]);
   if($linked){$this->consume((int)$c['id']);return $this->session($this->user((int)$linked['user_id'],true),'google');}
   if($this->one('SELECT id FROM users WHERE email=?',[$c['email']]))throw new LycAuthProblem(409,'An account now exists. Restart Google sign-in to link it securely.');
   $this->q("INSERT INTO users(fullname,email,password,role) VALUES(?,?,'','customer')",[$name,$c['email']])->close();$uid=$this->db->insert_id;
   $this->q('INSERT INTO customers(user_id,fullname,email,phone) VALUES(?,?,?,?)',[$uid,$name,$c['email'],$phone])->close();$this->attach($uid,$c['subject'],$c['email']);$this->consume((int)$c['id']);return $this->session($this->user($uid,true),'google');
  });
 }
 private function linkChallenge(string $token,bool $locked=false):array {
  if(!preg_match('/^[a-f0-9]{64}$/D',$token))throw new LycAuthProblem(400,'Restart Google sign-in to link your account.');
  $c=$this->one("SELECT * FROM auth_challenges WHERE token_hash=? AND purpose IN ('google_link','google_register') AND used_at IS NULL AND expires_at>NOW()".($locked?' FOR UPDATE':''),[hash('sha256',$token)]);
  if(!$c)throw new LycAuthProblem(400,'This linking request expired or was already used. Restart Google sign-in.');return $c;
 }
 public function link(array $d,string $ip):array {
  $token=lyc_field($d,'challenge',64);$c=$this->linkChallenge($token);$this->rate('link',$c['subject'],$ip,5);$this->lock('google/'.$c['subject']);$this->lock('email/'.$c['email']);
  $password=lyc_field($d,'password',1024);$email=$c['user_id']===null?lyc_email(lyc_field($d,'existing_email',100)):null;
  return $this->atomic(function()use($token,$password,$email){$c=$this->linkChallenge($token,true);
   $u=$c['user_id']===null?$this->one("SELECT * FROM users WHERE email=? AND role='customer' FOR UPDATE",[$email]):$this->user((int)$c['user_id'],true);
   $hash=$u&&lyc_has_password($u)?$u['password']:'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
   $verified=password_verify($password,$hash);
   if(!$u||!lyc_has_password($u)||!$verified||($c['user_id']!==null&&strtolower($u['email'])!==strtolower($c['email'])))throw new LycAuthProblem(401,'Unable to confirm account ownership. Sign in or recover your account and try again.');
   $other=$this->one('SELECT id FROM users WHERE email=?',[$c['email']]);
   if($other&&(int)$other['id']!==(int)$u['id'])throw new LycAuthProblem(409,'Two existing accounts cannot be merged automatically. Contact the service center.');
   $this->attach((int)$u['id'],$c['subject'],$c['email']);$this->consume((int)$c['id']);return $this->session($u,'google');});
 }

 public function me(string $bearer):array {$t=$this->authenticated($bearer);return $this->atomic(function()use($t){$u=$this->user((int)$t['user_id'],true);return $this->publicUser($u,$this->profile($u));});}
 public function logout(string $bearer):array {
  if(preg_match('/^[a-f0-9]{64}$/D',$bearer))$this->q('DELETE FROM api_tokens WHERE token_hash=?',[hash('sha256',$bearer)])->close();return ['success'=>true,'message'=>'Signed out.'];
 }
 public function password(array $d,string $ip,string $bearer,bool $setup):array {
  $t=$this->authenticated($bearer);$uid=(int)$t['user_id'];$this->rate('password',(string)$uid,$ip,5);
  $new=lyc_field($d,'new_password',72);lyc_password($new,lyc_field($d,'confirm_password',72));
  $proof=$setup?$this->google->verify(lyc_field($d,'id_token',16384)):null;
  if($proof&&time()-$proof['issued_at']>300)throw new LycAuthProblem(401,'Please sign in with Google again to set your password.');
  return $this->atomic(function()use($uid,$d,$setup,$proof,$new){$u=$this->user($uid,true);
   if($setup){$identity=$this->one("SELECT subject FROM auth_identities WHERE user_id=? AND provider='google'",[$uid]);
    if(!$identity||$identity['subject']!==$proof['subject']||lyc_has_password($u))throw new LycAuthProblem(403,'Use Change Password or account recovery for this account.');
    // Consume this fresh Google proof once for this credential-changing operation.
    $fingerprint=hash('sha256',lyc_field($d,'id_token',16384));
    if($this->one('SELECT id FROM auth_challenges WHERE token_hash=?',[$fingerprint]))throw new LycAuthProblem(409,'Sign in with Google again and retry.');
    $this->q("INSERT INTO auth_challenges(token_hash,purpose,user_id,expires_at,used_at) VALUES(?,'set_password',?,DATE_ADD(NOW(),INTERVAL 5 MINUTE),NOW())",[$fingerprint,$uid])->close();
   }else{if(!lyc_has_password($u)||!password_verify(lyc_field($d,'current_password',1024),$u['password']))throw new LycAuthProblem(400,'Current password is incorrect.');}
   $hash=password_hash($new,PASSWORD_DEFAULT);$this->q('UPDATE users SET password=? WHERE id=?',[$hash,$uid])->close();$this->invalidate($uid);
   return ['success'=>true,'reauthenticate'=>true,'message'=>'Password saved. Please sign in again.'];});
 }
 private function invalidate(int $uid):void {
  $this->q('DELETE FROM api_tokens WHERE user_id=?',[$uid])->close();$this->q('UPDATE auth_password_resets SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[$uid])->close();$this->q('UPDATE auth_challenges SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[$uid])->close();
 }
 public function forgot(array $d,string $ip):array {
  $email=lyc_email(lyc_field($d,'email',100));$this->rate('forgot',$email,$ip,3);
  $url=$this->config['reset_url']??'';$p=is_string($url)?parse_url($url):false;
  if(!$this->mailer->ready()||!$p||($p['scheme']??'')!=='https'||empty($p['host'])||(isset($p['user'])||isset($p['pass']))||isset($p['fragment'])||isset($p['query']))throw new LycAuthProblem(503,'Email recovery is not configured. Please use your existing sign-in method or contact the service center.');
  $u=$this->one("SELECT * FROM users WHERE email=? AND role='customer'",[$email]);
  if($u&&lyc_has_password($u)){
   $raw=bin2hex(random_bytes(32));$hash=hash('sha256',$raw);$finger=hash('sha256',$u['password']);$uid=(int)$u['id'];
   $this->q('INSERT INTO auth_password_resets(user_id,token_hash,email,password_fingerprint,expires_at) VALUES(?,?,?,?,DATE_ADD(NOW(),INTERVAL 30 MINUTE))',[$uid,$hash,$email,$finger])->close();
   try{$this->mailer->sendReset($email,$url.'#token='.$raw);}catch(Throwable $e){$this->q('UPDATE auth_password_resets SET used_at=NOW() WHERE token_hash=?',[$hash])->close();error_log('Lucky Yuna: recovery email delivery failed.');}
  }
  return ['success'=>true,'message'=>'If this account is eligible, a reset link will arrive by email. Google-only accounts should use Continue with Google.'];
 }
 public function reset(array $d,string $ip):array {
  $raw=lyc_field($d,'token',64);$this->rate('reset',hash('sha256',$raw),$ip,5);
  if(!preg_match('/^[a-f0-9]{64}$/D',$raw))throw new LycAuthProblem(400,'This reset link is invalid or expired.');
  $new=lyc_field($d,'new_password',72);lyc_password($new,lyc_field($d,'confirm_password',72));$hash=hash('sha256',$raw);$r=$this->one('SELECT user_id FROM auth_password_resets WHERE token_hash=?',[$hash]);
  if(!$r)throw new LycAuthProblem(400,'This reset link is invalid or expired.');
  return $this->atomic(function()use($r,$hash,$new){$uid=(int)$r['user_id'];$u=$this->user($uid,true);$r=$this->one('SELECT * FROM auth_password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW() FOR UPDATE',[$hash]);
   if(!$r||!lyc_has_password($u)||$r['password_fingerprint']!==hash('sha256',$u['password'])||strtolower($r['email'])!==strtolower($u['email']))throw new LycAuthProblem(400,'This reset link is invalid, expired or already used.');
   $this->q('UPDATE users SET password=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),$uid])->close();$this->invalidate($uid);return ['success'=>true,'message'=>'Password reset. Sign in with your new Lucky Yuna password.'];});
 }
}
