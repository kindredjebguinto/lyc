<?php
interface LycAuthMailer {public function ready():bool;public function sendReset(string $email,string $url):void;}
final class LycSmtpMailer implements LycAuthMailer {
 public function __construct(private array $config){}
 public function ready():bool {
  $s=$this->config['smtp']??[];
  return class_exists('PHPMailer\\PHPMailer\\PHPMailer')&&is_array($s)&&
   !empty($s['host'])&&!empty($s['username'])&&!empty($s['password'])&&filter_var($s['from_email']??'',FILTER_VALIDATE_EMAIL)&&
   in_array($s['encryption']??'tls',['tls','ssl'],true)&&in_array((int)($s['port']??587),[465,587],true);
 }
 public function sendReset(string $email,string $url):void {
  $s=$this->config['smtp'];$m=new PHPMailer\PHPMailer\PHPMailer(true);
  $m->isSMTP();$m->Host=$s['host'];$m->SMTPAuth=true;$m->Username=$s['username'];$m->Password=$s['password'];
  $m->SMTPSecure=($s['encryption']??'tls')==='ssl'?'ssl':'tls';$m->Port=(int)($s['port']??587);
  $m->Timeout=15;$m->SMTPDebug=0;$m->CharSet='UTF-8';
  $m->setFrom($s['from_email'],$s['from_name']??'Lucky Yuna');$m->addAddress($email);
  $m->Subject='Reset your Lucky Yuna password';
  $m->Body="Use this link within 30 minutes to reset your Lucky Yuna password:\n\n".$url."\n\nThis does not change your Google password. If you did not request it, ignore this email.";
  $m->send();
 }
}
