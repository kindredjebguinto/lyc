<?php
require_once __DIR__.'/../lib/auth_endpoint.php';
lyc_auth_endpoint('link');
