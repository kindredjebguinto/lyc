<?php
if(($_SERVER['REQUEST_METHOD']??'')!=='GET'){
 require_once __DIR__.'/../lib/auth_endpoint.php';lyc_auth_endpoint('reset');exit;
}
$nonce=base64_encode(random_bytes(24));
header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');header('Referrer-Policy: no-referrer');header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; script-src 'nonce-$nonce'; style-src 'nonce-$nonce'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
?>
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reset Lucky Yuna password</title>
<style nonce="<?=htmlspecialchars($nonce,ENT_QUOTES)?>">body{font:18px/1.5 system-ui;background:#f7f7f7;max-width:440px;margin:8vh auto;padding:24px}input,button{box-sizing:border-box;width:100%;font:inherit;padding:12px;margin:8px 0 20px}button{background:#c71920;color:white;border:0;border-radius:8px}#status{white-space:pre-wrap}</style>
<h1>Reset your Lucky Yuna password</h1><p>This changes your Lucky Yuna password, not your Google password.</p>
<form id="reset"><label>New password<input id="password" type="password" autocomplete="new-password" minlength="12" maxlength="72" required></label><label>Confirm password<input id="confirm" type="password" autocomplete="new-password" minlength="12" maxlength="72" required></label><button id="submit">Save password</button></form><p id="status" role="status"></p>
<script nonce="<?=htmlspecialchars($nonce,ENT_QUOTES)?>">
const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';
history.replaceState(null,'',location.pathname);
const form=document.getElementById('reset'),status=document.getElementById('status'),button=document.getElementById('submit');
if(!/^[a-f0-9]{64}$/.test(token)){form.hidden=true;status.textContent='This link is invalid. Request a new reset link from the app.';}
form.addEventListener('submit',async event=>{event.preventDefault();if(button.disabled)return;button.disabled=true;status.textContent='Saving...';
try{const response=await fetch(location.pathname,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,new_password:document.getElementById('password').value,confirm_password:document.getElementById('confirm').value})});
const data=await response.json();status.textContent=data.message||'Unable to reset your password.';if(data.success){form.hidden=true;document.getElementById('password').value='';document.getElementById('confirm').value='';}}
catch(error){status.textContent='Unable to connect. Please retry.';}finally{button.disabled=false;}});
</script></html>
