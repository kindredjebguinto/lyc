import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in_platform_interface/google_sign_in_platform_interface.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:vsm_customer/api/auth_api.dart';
import 'package:vsm_customer/api/api_client.dart';
import 'package:vsm_customer/services/google_auth_service.dart';
import 'package:vsm_customer/services/session_service.dart';
import 'package:vsm_customer/services/auth_input_rules.dart';
import 'package:vsm_customer/screens/auth/welcome_screen.dart';
import 'package:vsm_customer/screens/auth/login_screen.dart';
import 'package:vsm_customer/screens/auth/complete_profile_screen.dart';
import 'package:vsm_customer/screens/auth/link_account_screen.dart';
import 'package:vsm_customer/models/auth_result.dart';
import 'package:vsm_customer/screens/splash/splash_screen.dart';

class FakeGoogle extends GoogleSignInPlatform {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
  int count = 0;
  Completer<AuthenticationResults>? pending;
  @override
  Future<void> init(InitParameters params) async {}
  @override
  Future<AuthenticationResults> authenticate(AuthenticateParameters params) {
    count++;
    return pending!.future;
  }

  @override
  Future<void> signOut(SignOutParams params) async {}
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => FlutterSecureStorage.setMockInitialValues({}));
  test('secure session round trip preserves the customer identity', () async {
    await SessionService.saveSession(
      customerId: 51,
      name: 'Existing',
      email: 'existing@example.test',
      token: 'a' * 64,
      expiresAt: '2030-01-01',
    );
    expect(await SessionService.isLoggedIn(), true);
    expect(await SessionService.getCustomerId(), 51);
    await SessionService.logout();
    expect(await SessionService.isLoggedIn(), false);
    expect(await SessionService.getToken(), isNull);
  });
  test('expired business API response invokes central session handler', () {
    var count = 0;
    ApiClient.onUnauthorized = () => count++;
    expect(
      () => ApiClient.decode(http.Response('{"success":false}', 401)),
      throwsException,
    );
    expect(count, 1);
    ApiClient.onUnauthorized = null;
  });
  test(
    'auth API preserves generic credential error without connectivity mislabel',
    () async {
      await http.runWithClient(
        () => expectLater(
          AuthApi.login(email: 'a@example.test', password: 'wrong'),
          throwsA(
            isA<AuthRequestException>()
                .having((e) => e.status, 'status', 401)
                .having(
                  (e) => e.message,
                  'message',
                  'Invalid email or password.',
                ),
          ),
        ),
        () => MockClient(
          (_) async => http.Response(
            '{"success":false,"message":"Invalid email or password."}',
            401,
          ),
        ),
      );
    },
  );
  test('a delayed unauthorized response cannot clear a newer login', () async {
    await SessionService.saveSession(
      customerId: 1,
      name: 'Old',
      email: 'old@example.test',
      token: 'a' * 64,
    );
    var count = 0;
    ApiClient.onUnauthorized = () => count++;
    await http.runWithClient(
      () async {
        await expectLater(
          ApiClient.get('https://example.test/protected'),
          throwsException,
        );
      },
      () => MockClient((_) async {
        await SessionService.saveSession(
          customerId: 2,
          name: 'New',
          email: 'new@example.test',
          token: 'b' * 64,
        );
        return http.Response('{"success":false}', 401);
      }),
    );
    expect(count, 0);
    expect(await SessionService.getToken(), 'b' * 64);
    ApiClient.onUnauthorized = null;
  });
  test(
    'Google auth is single-flight and cancellation leaves no session',
    () async {
      final fake = FakeGoogle();
      GoogleSignInPlatform.instance = fake;
      fake.pending = Completer<AuthenticationResults>();
      final first = GoogleAuthService.signIn(),
          second = GoogleAuthService.signIn();
      await Future<void>.delayed(Duration.zero);
      expect(fake.count, 1);
      fake.pending!.completeError(
        const GoogleSignInException(code: GoogleSignInExceptionCode.canceled),
      );
      expect(await first, isNull);
      expect(await second, isNull);
      expect(await SessionService.isLoggedIn(), false);
    },
  );
  test('PH phone validation supports local and international and rejects malformed', () {
    expect(AuthInputRules.phone('09990000001'), isNull);
    expect(AuthInputRules.phone('+63 999 000 0001'), isNull);
    expect(AuthInputRules.phone('123'), isNotNull);
  });
  test('password confirmation and bcrypt byte limit checked before submit', () {
    expect(
      AuthInputRules.password('LongPassword123!', 'LongPassword123!'),
      isNull,
    );
    expect(AuthInputRules.password('short', 'short'), isNotNull);
    expect(
      AuthInputRules.password('LongPassword123!', 'OtherPassword123!'),
      isNotNull,
    );
    expect(AuthInputRules.password('é' * 40, 'é' * 40), isNotNull);
  });
  testWidgets('welcome keeps Google primary and manual paths visible', (
    tester,
  ) async {
    await tester.pumpWidget(const MaterialApp(home: WelcomeScreen()));
    expect(find.text('Continue with Google'), findsOneWidget);
    expect(find.text('Sign In'), findsOneWidget);
    expect(find.text('Create an Account'), findsOneWidget);
    await tester.tap(find.text('Sign In'));
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
  });
  testWidgets(
    'new Google profile offers explicit existing-account ownership flow',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: CompleteProfileScreen(
            result: AuthResult({
              'next': 'complete_profile',
              'challenge': 'a' * 64,
              'email': 'google@example.test',
              'name': 'Google Name',
            }),
          ),
        ),
      );
      await tester.tap(
        find.text('Already a customer? Link your existing account'),
      );
      await tester.pumpAndSettle();
      expect(find.byType(LinkAccountScreen), findsOneWidget);
      expect(find.text('Existing Lucky Yuna email'), findsOneWidget);
      expect(await SessionService.isLoggedIn(), false);
    },
  );
  testWidgets('expired session cannot open dashboard and is cleared', (
    tester,
  ) async {
    await SessionService.saveSession(
      customerId: 1,
      name: 'Existing',
      email: 'existing@example.test',
      token: 'b' * 64,
    );
    await http.runWithClient(
      () async {
        await tester.pumpWidget(const MaterialApp(home: SplashScreen()));
        await tester.pumpAndSettle();
        expect(find.byType(WelcomeScreen), findsOneWidget);
        expect(await SessionService.getToken(), isNull);
      },
      () => MockClient(
        (_) async =>
            http.Response('{"success":false,"message":"Expired"}', 401),
      ),
    );
  });
  testWidgets(
    'backend offline does not let stored token bypass session check',
    (tester) async {
      await SessionService.saveSession(
        customerId: 1,
        name: 'Existing',
        email: 'existing@example.test',
        token: 'c' * 64,
      );
      await http.runWithClient(() async {
        await tester.pumpWidget(const MaterialApp(home: SplashScreen()));
        await tester.pumpAndSettle();
        expect(find.text('Retry connection'), findsOneWidget);
        expect(await SessionService.getToken(), 'c' * 64);
      }, () => MockClient((_) async => throw http.ClientException('offline')));
    },
  );
  testWidgets(
    'manual login routes incomplete profile to completion and keeps IDs',
    (tester) async {
      final result = {
        'success': true,
        'token': 'd' * 64,
        'user': {'id': 7},
        'customer': {
          'id': 51,
          'user_id': 7,
          'fullname': 'Existing',
          'email': 'existing@example.test',
          'phone': '',
        },
        'profile_required': true,
      };
      await http.runWithClient(() async {
        await tester.pumpWidget(const MaterialApp(home: LoginScreen()));
        final fields = find.byType(TextField);
        await tester.enterText(fields.at(0), 'existing@example.test');
        await tester.enterText(fields.at(1), 'ExistingPassword123!');
        await tester.tap(find.text('LOGIN'));
        await tester.pumpAndSettle();
        expect(find.text('Complete Your Profile'), findsOneWidget);
        expect(await SessionService.getCustomerId(), 51);
      }, () => MockClient((_) async => http.Response(jsonEncode(result), 200)));
    },
  );
}
