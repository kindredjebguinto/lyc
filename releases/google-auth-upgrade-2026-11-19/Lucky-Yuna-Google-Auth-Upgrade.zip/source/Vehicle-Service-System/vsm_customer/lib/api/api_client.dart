import 'dart:convert';

import 'package:http/http.dart' as http;

import '../services/session_service.dart';

class ApiClient {
  static void Function()? onUnauthorized;
  static Future<Map<String, String>> headers({bool json = false}) async {
    final token = await SessionService.getToken();
    return {
      'Accept': 'application/json',
      if (json) 'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  static Map<String, dynamic> decode(
    http.Response response, {
    bool notifyUnauthorized = true,
  }) {
    if (response.statusCode == 401) {
      if (notifyUnauthorized) onUnauthorized?.call();
      throw Exception('Your session expired. Please sign in again.');
    }
    try {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) return value;
    } catch (_) {}
    throw Exception(
      'The server returned an invalid response (${response.statusCode}). Please retry or contact the service center.',
    );
  }

  static Future<Map<String, dynamic>> _sessionResponse(
    http.Response response,
    Map<String, String> sentHeaders,
  ) async {
    if (response.statusCode == 401) {
      final current = await SessionService.getToken();
      // A delayed response for an old session must not clear a newer login.
      if (current != null && sentHeaders['Authorization'] == 'Bearer $current') {
        onUnauthorized?.call();
      }
    }
    return decode(response, notifyUnauthorized: false);
  }

  static Future<Map<String, dynamic>> get(String url) async {
    final sent = await headers();
    final response = await http
        .get(Uri.parse(url), headers: sent)
        .timeout(const Duration(seconds: 15));
    return _sessionResponse(response, sent);
  }

  static Future<Map<String, dynamic>> post(
    String url,
    Map<String, dynamic> body,
  ) async {
    final sent = await headers(json: true);
    final response = await http
        .post(Uri.parse(url), headers: sent, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return _sessionResponse(response, sent);
  }

  static Future<Map<String, dynamic>> multipart(
    String url,
    Map<String, String> fields, {
    String? fieldName,
    String? filePath,
  }) async {
    final request = http.MultipartRequest('POST', Uri.parse(url));
    final sent = await headers();
    request.headers.addAll(sent);
    request.fields.addAll(fields);
    if (fieldName != null && filePath != null && filePath.isNotEmpty) {
      request.files.add(await http.MultipartFile.fromPath(fieldName, filePath));
    }
    final streamed = await request.send().timeout(const Duration(seconds: 30));
    return _sessionResponse(await http.Response.fromStream(streamed), sent);
  }

  static String message(Object error) =>
      error.toString().replaceFirst('Exception: ', '');
}
