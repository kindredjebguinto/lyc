import 'dart:convert';

import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'api_client.dart';
import '../services/google_auth_service.dart';

class AuthRequestException implements Exception {
  final String message;
  final int status;
  AuthRequestException(this.message, this.status);
  @override
  String toString() => message;
}

class AuthApi {
  static Future<Map<String, dynamic>> _request(
    String path,
    Map<String, dynamic>? body, {
    bool authenticated = false,
  }) async {
    try {
      final headers = authenticated
          ? await ApiClient.headers(json: true)
          : {'Content-Type': 'application/json', 'Accept': 'application/json'};
      final uri = Uri.parse('${ApiConfig.baseUrl}/$path');
      final response =
          await (body == null
                  ? http.get(uri, headers: headers)
                  : http.post(uri, headers: headers, body: jsonEncode(body)))
              .timeout(const Duration(seconds: 20));
      dynamic value;
      try {
        value = jsonDecode(response.body);
      } catch (_) {
        throw AuthRequestException(
          'The authentication server returned an invalid response.',
          response.statusCode,
        );
      }
      if (value is! Map<String, dynamic>) {
        throw AuthRequestException(
          'Invalid server response.',
          response.statusCode,
        );
      }
      if (response.statusCode >= 400 || value['success'] != true) {
        throw AuthRequestException(
          value['message']?.toString() ?? 'Unable to complete authentication.',
          response.statusCode,
        );
      }
      return value;
    } on AuthRequestException {
      rethrow;
    } catch (_) {
      throw AuthRequestException(
        'Unable to connect to the server. Check your connection and retry.',
        0,
      );
    }
  }

  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) => _request('auth/login.php', {'email': email, 'password': password});
  static Future<Map<String, dynamic>> register({
    required String fullname,
    required String email,
    required String password,
    required String phone,
    required String address,
  }) => _request('auth/register.php', {
    'fullname': fullname,
    'email': email,
    'password': password,
    'phone': phone,
    'address': address,
  });
  static Future<Map<String, dynamic>> google(String token) =>
      _request('auth/google.php', {'id_token': token});
  static Future<Map<String, dynamic>> complete({
    required String name,
    required String phone,
    String? challenge,
  }) => _request('auth/google_complete.php', {
    'fullname': name,
    'phone': phone,
    'challenge': ?challenge,
  }, authenticated: challenge == null);
  static Future<Map<String, dynamic>> link(
    String challenge,
    String password, {
    String? existingEmail,
  }) => _request('auth/google_link.php', {
    'challenge': challenge,
    'password': password,
    'existing_email': ?existingEmail,
  });
  static Future<Map<String, dynamic>> me() =>
      _request('auth/me.php', null, authenticated: true);
  static Future<Map<String, dynamic>> forgotPassword(String email) =>
      _request('auth/forgot_password.php', {'email': email});
  static Future<Map<String, dynamic>> password({
    required String password,
    required String confirm,
    String? current,
    String? googleToken,
  }) => _request(
    googleToken == null ? 'profile/password.php' : 'auth/set_password.php',
    {
      'new_password': password,
      'confirm_password': confirm,
      'current_password': ?current,
      'id_token': ?googleToken,
    },
    authenticated: true,
  );
  static Future<void> logout() async {
    try {
      await _request('auth/logout.php', {}, authenticated: true);
    } catch (_) {}
    await GoogleAuthService.signOut();
  }
}
