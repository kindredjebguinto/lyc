import 'package:flutter/material.dart';

import 'screens/splash/splash_screen.dart';
import 'screens/auth/welcome_screen.dart';
import 'api/api_client.dart';
import 'services/session_service.dart';

final authNavigatorKey = GlobalKey<NavigatorState>();
bool authResetting = false;

void main() {
  ApiClient.onUnauthorized = () async {
    if (authResetting) return;
    authResetting = true;
    try {
      await SessionService.logout();
      authNavigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const WelcomeScreen()),
        (_) => false,
      );
    } finally {
      authResetting = false;
    }
  };
  runApp(const VSMApp());
}

class VSMApp extends StatelessWidget {
  const VSMApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: authNavigatorKey,
      title: 'Luck Yuna Car Center',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF111111)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: Color(0xFFE5E5E5)),
          ),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
