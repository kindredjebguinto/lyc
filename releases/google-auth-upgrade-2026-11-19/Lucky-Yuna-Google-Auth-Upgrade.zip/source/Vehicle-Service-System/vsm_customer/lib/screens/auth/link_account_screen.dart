import 'package:flutter/material.dart';

import '../../api/auth_api.dart';
import '../../models/auth_result.dart';
import '../../services/auth_controller.dart';
import 'forgot_password_screen.dart';

class LinkAccountScreen extends StatefulWidget {
  final AuthResult result;
  const LinkAccountScreen({required this.result, super.key});
  @override
  State<LinkAccountScreen> createState() => _LinkAccountScreenState();
}

class _LinkAccountScreenState extends State<LinkAccountScreen> {
  final password = TextEditingController();
  final existingEmail = TextEditingController();
  bool busy = false, obscure = true;
  @override
  void dispose() {
    password.dispose();
    existingEmail.dispose();
    super.dispose();
  }

  Future<void> link() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final result = await AuthApi.link(
        widget.result.challenge,
        password.text,
        existingEmail: widget.result.next == 'complete_profile'
            ? existingEmail.text.trim()
            : null,
      );
      if (!mounted) return;
      await AuthController.accept(context, result);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Confirm your existing account')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text('Google account: ${widget.result.email}'),
        if (widget.result.next == 'complete_profile')
          TextField(
            controller: existingEmail,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Existing Lucky Yuna email',
            ),
          ),
        const SizedBox(height: 16),
        const Text(
          'Enter your existing Lucky Yuna password to link Google securely. Your bookings and vehicles will stay in the same account. This is not your Google password.',
        ),
        TextField(
          controller: password,
          obscureText: obscure,
          decoration: InputDecoration(
            labelText: 'Lucky Yuna password',
            suffixIcon: IconButton(
              onPressed: () => setState(() => obscure = !obscure),
              icon: Icon(obscure ? Icons.visibility : Icons.visibility_off),
            ),
          ),
        ),
        FilledButton(
          onPressed: busy ? null : link,
          child: Text(busy ? 'Confirming...' : 'Confirm and Link Google'),
        ),
        TextButton(
          onPressed: busy
              ? null
              : () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ForgotPasswordScreen(),
                  ),
                ),
          child: const Text('Forgot your Lucky Yuna password?'),
        ),
        const Text(
          'After recovery, restart Continue with Google to finish linking.',
        ),
      ],
    ),
  );
}
