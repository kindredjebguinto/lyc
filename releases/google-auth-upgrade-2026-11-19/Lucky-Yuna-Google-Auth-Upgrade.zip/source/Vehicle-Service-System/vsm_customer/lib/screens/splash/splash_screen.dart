import 'package:flutter/material.dart';

import '../../api/auth_api.dart';
import '../../services/auth_controller.dart';
import '../../services/session_service.dart';
import '../auth/welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool busy = true;
  String? error;
  @override
  void initState() {
    super.initState();
    check();
  }

  Future<void> check() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (!await SessionService.isLoggedIn()) {
        if (mounted) welcome();
        return;
      }
      final result = await AuthController.restore();
      final token = await SessionService.getToken();
      if (!mounted) return;
      await AuthController.accept(context, {...result, 'token': token});
    } on AuthRequestException catch (e) {
      if (e.status == 401) {
        await SessionService.logout();
        if (mounted) welcome();
      } else if (mounted) {
        setState(() {
          error = e.message;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = 'Unable to validate your session. Check your connection and retry.';
          busy = false;
        });
      }
    }
  }

  void welcome() => Navigator.of(
    context,
  ).pushReplacement(MaterialPageRoute(builder: (_) => const WelcomeScreen()));
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/logo.png', width: 110, height: 110),
            const SizedBox(height: 18),
            const Text(
              'Luck Yuna Car Center',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 22),
            if (busy)
              const CircularProgressIndicator()
            else ...[
              Text(error ?? '', textAlign: TextAlign.center),
              FilledButton(
                onPressed: check,
                child: const Text('Retry connection'),
              ),
              TextButton(
                onPressed: () async {
                  await SessionService.logout();
                  if (mounted) welcome();
                },
                child: const Text('Return to sign in'),
              ),
            ],
          ],
        ),
      ),
    ),
  );
}
