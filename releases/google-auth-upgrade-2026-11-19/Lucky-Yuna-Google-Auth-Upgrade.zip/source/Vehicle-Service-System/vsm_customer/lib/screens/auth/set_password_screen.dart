import 'package:flutter/material.dart';

import '../../api/auth_api.dart';
import '../../services/google_auth_service.dart';
import '../../services/auth_input_rules.dart';
import '../../services/session_service.dart';
import 'welcome_screen.dart';

class SetPasswordScreen extends StatefulWidget {
  const SetPasswordScreen({super.key});
  @override
  State<SetPasswordScreen> createState() => _SetPasswordScreenState();
}

class _SetPasswordScreenState extends State<SetPasswordScreen> {
  final current = TextEditingController(),
      password = TextEditingController(),
      confirm = TextEditingController();
  bool loading = true,
      busy = false,
      obscure = true,
      hasPassword = false,
      googleLinked = false;
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    current.dispose();
    password.dispose();
    confirm.dispose();
    super.dispose();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final result = await AuthApi.me();
      final auth = result['auth'] as Map<String, dynamic>;
      if (mounted) {
        setState(() {
          hasPassword = auth['has_password'] == true;
          googleLinked = auth['google_linked'] == true;
          loading = false;
          error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e.toString();
          loading = false;
        });
      }
    }
  }

  Future<void> save() async {
    if (busy) return;
    final validation = AuthInputRules.password(password.text, confirm.text);
    if (validation != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(validation)));
      return;
    }
    setState(() => busy = true);
    try {
      String? token;
      if (!hasPassword) {
        token = await GoogleAuthService.signIn(reauthenticate: true);
        if (token == null) return;
      }
      final result = await AuthApi.password(
        password: password.text,
        confirm: confirm.text,
        current: hasPassword ? current.text : null,
        googleToken: token,
      );
      if (result['success'] == true) {
        await AuthApi.logout();
        await SessionService.logout();
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(result['message'].toString())));
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const WelcomeScreen()),
          (_) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget field(TextEditingController c, String label) => Padding(
    padding: const EdgeInsets.only(top: 16),
    child: TextField(
      controller: c,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
    ),
  );
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Sign-in & Password')),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : error != null
        ? Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(error!),
                TextButton(onPressed: load, child: const Text('Retry')),
              ],
            ),
          )
        : ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Text(
                googleLinked ? 'Google is linked to this account.' : 'Google is not linked. Use Continue with Google and confirm your existing Lucky Yuna password to link it.',
              ),
              Text(
                hasPassword ? 'Change your Lucky Yuna password.' : 'Set a Lucky Yuna password to also use manual sign-in. Your Google password will not change.',
              ),
              if (hasPassword) field(current, 'Current Lucky Yuna password'),
              field(password, 'New password'),
              field(confirm, 'Confirm password'),
              TextButton(
                onPressed: () => setState(() => obscure = !obscure),
                child: Text(obscure ? 'Show passwords' : 'Hide passwords'),
              ),
              const Text(
                'Use 12–72 bytes. You will sign in again after saving.',
              ),
              FilledButton(
                onPressed: busy || (!hasPassword && !googleLinked)
                    ? null
                    : save,
                child: Text(
                  busy
                      ? 'Saving...'
                      : hasPassword
                      ? 'Change Password'
                      : 'Verify Google and Set Password',
                ),
              ),
            ],
          ),
  );
}
