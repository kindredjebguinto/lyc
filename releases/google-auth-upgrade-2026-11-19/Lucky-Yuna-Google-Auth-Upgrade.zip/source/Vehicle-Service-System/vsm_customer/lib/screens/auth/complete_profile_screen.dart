import 'package:flutter/material.dart';

import '../../api/auth_api.dart';
import '../../models/auth_result.dart';
import '../../services/auth_controller.dart';
import '../../services/session_service.dart';
import '../../services/auth_input_rules.dart';
import '../dashboard/dashboard_screen.dart';
import 'welcome_screen.dart';
import 'link_account_screen.dart';

class CompleteProfileScreen extends StatefulWidget {
  final AuthResult result;
  const CompleteProfileScreen({required this.result, super.key});
  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  late final TextEditingController name = TextEditingController(
    text: widget.result.name,
  );
  final phone = TextEditingController();
  bool busy = false;
  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (busy) return;
    final validation = name.text.trim().isEmpty
        ? 'Enter your name.'
        : AuthInputRules.phone(phone.text);
    if (validation != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(validation)));
      return;
    }
    setState(() => busy = true);
    try {
      final result = await AuthApi.complete(
        name: name.text.trim(),
        phone: phone.text.trim(),
        challenge: widget.result.challenge.isEmpty
            ? null
            : widget.result.challenge,
      );
      if (!mounted) return;
      if (result['token'] != null) {
        await AuthController.accept(context, result);
      } else {
        final p = result['customer'] as Map<String, dynamic>;
        await SessionService.updateIdentity(
          name: p['fullname'].toString(),
          email: p['email'].toString(),
        );
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const DashboardScreen()),
          (_) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> cancel() async {
    if (busy) return;
    await AuthApi.logout();
    await SessionService.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: widget.result.challenge.isNotEmpty && !busy,
    child: Scaffold(
      appBar: AppBar(
        title: const Text('Complete Your Profile'),
        automaticallyImplyLeading: false,
        actions: [
          TextButton(
            onPressed: busy ? null : cancel,
            child: const Text('Cancel'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(widget.result.email),
          if (widget.result.challenge.isNotEmpty)
            TextButton(
              onPressed: busy
                  ? null
                  : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            LinkAccountScreen(result: widget.result),
                      ),
                    ),
              child: const Text(
                'Already a customer? Link your existing account',
              ),
            ),
          const SizedBox(height: 20),
          TextField(
            controller: name,
            maxLength: 100,
            decoration: const InputDecoration(labelText: 'Name'),
          ),
          TextField(
            controller: phone,
            keyboardType: TextInputType.phone,
            maxLength: 30,
            decoration: const InputDecoration(
              labelText: 'Philippine mobile number',
              hintText: '09XXXXXXXXX',
            ),
          ),
          const Text(
            'Your number is saved as contact information; it is not yet verified.',
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: busy ? null : save,
            child: Text(busy ? 'Saving...' : 'Save Profile'),
          ),
        ],
      ),
    ),
  );
}
