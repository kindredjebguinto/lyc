import 'package:flutter/material.dart';

import '../api/auth_api.dart';
import '../models/auth_result.dart';
import '../models/customer.dart';
import '../screens/auth/complete_profile_screen.dart';
import '../screens/auth/link_account_screen.dart';
import '../screens/dashboard/dashboard_screen.dart';
import 'session_service.dart';

class AuthController {
  static Future<Map<String, dynamic>>? _restore;
  static Future<Map<String, dynamic>> restore() {
    if (_restore != null) return _restore!;
    final task = AuthApi.me();
    _restore = task;
    return task.whenComplete(() => _restore = null);
  }

  static Future<void> accept(
    BuildContext context,
    Map<String, dynamic> data,
  ) async {
    final result = AuthResult(data);
    if (result.next == 'link_account') {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => LinkAccountScreen(result: result)),
      );
      return;
    }
    if (result.next == 'complete_profile') {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => CompleteProfileScreen(result: result),
        ),
      );
      return;
    }
    final token = data['token']?.toString();
    if (token == null || !RegExp(r'^[a-f0-9]{64}$').hasMatch(token)) {
      throw Exception('A valid authenticated session was not returned.');
    }
    final profile = data['customer'];
    if (profile is! Map<String, dynamic>) {
      throw Exception(
        'Your customer profile is unavailable. Contact the service center.',
      );
    }
    final customer = Customer.fromJson(profile);
    await SessionService.saveSession(
      customerId: customer.id,
      name: customer.fullname,
      email: customer.email,
      token: token,
      expiresAt: data['expires_at']?.toString(),
    );
    if (!context.mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => result.profileRequired
            ? CompleteProfileScreen(
                result: AuthResult({
                  ...data,
                  'name': customer.fullname,
                  'email': customer.email,
                }),
              )
            : const DashboardScreen(),
      ),
      (_) => false,
    );
  }
}
