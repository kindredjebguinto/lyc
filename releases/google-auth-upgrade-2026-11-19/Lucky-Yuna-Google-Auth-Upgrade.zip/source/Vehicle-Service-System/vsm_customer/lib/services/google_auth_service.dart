import 'package:google_sign_in/google_sign_in.dart';

class GoogleAuthService {
  static const serverClientId = String.fromEnvironment('GOOGLE_WEB_CLIENT_ID');
  static const iosClientId = String.fromEnvironment('GOOGLE_IOS_CLIENT_ID');
  static Future<void>? _initialization;
  static Future<String?>? _pending;
  static Future<String?> signIn({bool reauthenticate = false}) {
    if (_pending != null) return _pending!;
    final task = _authenticate(reauthenticate);
    _pending = task;
    return task.whenComplete(() => _pending = null);
  }

  static Future<String?> _authenticate(bool reauthenticate) async {
    if (serverClientId.isEmpty) {
      throw Exception(
        'Google sign-in is not configured yet. Please use manual sign-in.',
      );
    }
    try {
      await (_initialization ??= GoogleSignIn.instance.initialize(
        serverClientId: serverClientId,
        clientId: iosClientId.isEmpty ? null : iosClientId,
      ));
      if (reauthenticate) await GoogleSignIn.instance.signOut();
      final account = await GoogleSignIn.instance.authenticate();
      final token = account.authentication.idToken;
      if (token == null || token.isEmpty) {
        throw Exception(
          'Google did not return a valid sign-in result. Please retry.',
        );
      }
      return token;
    } on GoogleSignInException catch (error) {
      if (error.code == GoogleSignInExceptionCode.canceled) return null;
      throw Exception(
        'Google sign-in could not be completed. Please retry or use manual sign-in.',
      );
    }
  }

  static Future<void> signOut() async {
    if (_initialization == null) return;
    try {
      await GoogleSignIn.instance.signOut();
    } catch (_) {}
  }
}
