import 'dart:convert';

class AuthInputRules {
  static String? password(String value, String confirm) {
    final size = utf8.encode(value).length;
    if (size < 12) return 'Use at least 12 characters.';
    if (size > 72) {
      return 'That password is too long. Please use a shorter password.';
    }
    if (value != confirm) return 'Passwords do not match.';
    return null;
  }

  static String? phone(String value) {
    final normalized = value.replaceAll(RegExp(r'[\s()-]'), '');
    return RegExp(r'^(?:09\d{9}|\+?639\d{9})$').hasMatch(normalized)
        ? null
        : 'Enter a valid Philippine mobile number.';
  }
}
