class AuthResult {
  final Map<String, dynamic> data;
  AuthResult(this.data);
  String get next => data['next']?.toString() ?? 'session';
  String get challenge => data['challenge']?.toString() ?? '';
  String get name => data['name']?.toString() ?? '';
  String get email => data['email']?.toString() ?? '';
  bool get profileRequired => data['profile_required'] == true;
}
