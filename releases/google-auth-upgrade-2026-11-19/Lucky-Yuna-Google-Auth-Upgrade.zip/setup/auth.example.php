<?php
// Copy outside htdocs/public_html as lyc-private/auth.php; never publish real credentials.
return [
 'allow_local_http'=>false, // Set true ONLY for a local XAMPP USB/loopback test.
 'google_web_client_ids'=>[], // ['YOUR_WEB_CLIENT_ID.apps.googleusercontent.com']
 'google_presenter_client_ids'=>[], // Registered Android/iOS client IDs if the token includes azp.
 'reset_url'=>'', // Exact HTTPS URL of api/auth/reset_password.php; no query or fragment.
 'smtp'=>[
  'host'=>'','port'=>587,'encryption'=>'tls','username'=>'','password'=>'',
  'from_email'=>'','from_name'=>'Lucky Yuna',
 ],
];
