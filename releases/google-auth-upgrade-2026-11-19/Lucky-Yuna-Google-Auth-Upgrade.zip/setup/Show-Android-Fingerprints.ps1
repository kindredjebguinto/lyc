$ErrorActionPreference = 'Stop'
$candidates = @()
if ($env:JAVA_HOME) { $candidates += Join-Path $env:JAVA_HOME 'bin\keytool.exe' }
if ($env:ProgramFiles) { $candidates += Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\keytool.exe' }
$command = Get-Command keytool -ErrorAction SilentlyContinue
if ($command) { $candidates += $command.Source }
$keytool = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $keytool) { throw 'keytool was not found. Run flutter doctor -v to find the installed Java bin directory, then run its keytool locally.' }
$keystore = Join-Path $env:USERPROFILE '.android\debug.keystore'
if (-not (Test-Path -LiteralPath $keystore)) { throw 'No debug keystore exists yet. Run the existing app in debug mode first, then retry.' }
Write-Host 'These are PUBLIC certificate fingerprints for your debug build. Do not upload the keystore itself.'
& $keytool -list -v -alias androiddebugkey -keystore $keystore -storepass android -keypass android
if ($LASTEXITCODE -ne 0) { throw 'Unable to read the debug certificate.' }
