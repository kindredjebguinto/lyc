-- Select and BACK UP the active database first. No USE, DROP, seed or account updates.
-- MariaDB 10.4+. Duplicate customers.user_id values stop the final unique-index step.
CREATE TABLE IF NOT EXISTS auth_identities (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 provider VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 subject VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 provider_email VARCHAR(100) NOT NULL,
 email_verified_at DATETIME NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY provider_subject (provider,subject),
 UNIQUE KEY user_provider (user_id,provider),
 CONSTRAINT auth_identity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS auth_challenges (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
 purpose VARCHAR(24) NOT NULL,
 user_id INT NULL,
 subject VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NULL,
 email VARCHAR(100) NULL,
 display_name VARCHAR(100) NULL,
 session_hash CHAR(64) NULL,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY challenge_user (user_id,purpose), KEY challenge_expiry (expires_at),
 CONSTRAINT auth_challenge_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS auth_password_resets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
 email VARCHAR(100) NOT NULL,
 password_fingerprint CHAR(64) NOT NULL,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY reset_user (user_id), KEY reset_expiry (expires_at),
 CONSTRAINT auth_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS auth_rate_limits (
 bucket CHAR(64) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 window_start BIGINT NOT NULL, attempts INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE api_tokens ADD COLUMN IF NOT EXISTS auth_method VARCHAR(16) NULL,
 ADD COLUMN IF NOT EXISTS reauthenticated_at DATETIME NULL;
-- NULL user_id guest profiles remain allowed. No duplicate row is merged or deleted.
ALTER TABLE customers ADD UNIQUE INDEX IF NOT EXISTS auth_customer_user_unique (user_id);
